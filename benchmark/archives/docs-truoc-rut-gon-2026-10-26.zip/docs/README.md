# Mục lục tài liệu dự án

- [Việc cần làm](planning/cong-viec-can-lam.md): ưu tiên, tồn đọng và bước tiếp.
- [Tiêu chí thêm vòng phản biện](planning/tieu-chi-them-vong-phan-bien.md).
- [Kế hoạch pilot fine-tuning Verifier](planning/ke-hoach-thu-fine-tuning-verifier.md).
- [Hướng dẫn rà soát nhãn chỉ dẫn/ngữ cảnh](guides/huong-dan-gan-nhan-ngu-canh.md).
- [Lưu trữ huấn luyện trên ổ E](guides/luu-tru-huan-luyen-tren-o-e.md).
- [Báo cáo](reports/): triển khai, phép đo và các giới hạn đã ghi nhận.
  - [Chính sách phân tích một vòng](reports/chinh-sach-phan-tich-mot-vong.md)
  - [Mốc đo ban đầu với model thật](reports/danh-gia-luong-xu-ly-mot-vong.md)
  - [Kiểm chứng trích xuất HTML](reports/kiem-chung-trich-xuat-html.md)
  - [Ánh xạ trích dẫn về nguồn](reports/anh-xa-trich-dan-ve-nguon.md)
  - [Thử nghiệm directive và ngữ cảnh](reports/thu-nghiem-chi-dan-va-ngu-canh.md)
  - [Đo nhận định có cấu trúc](reports/danh-gia-nhan-dinh-co-cau-truc.md)
  - [Đánh giá tham chiếu bằng mã nguồn](reports/danh-gia-tham-chieu-bang-ma-nguon.md)
  - [Rút gọn JSON Verifier và đo lại ca bỏ sót](reports/rut-gon-json-verifier-va-do-lai-ca-bo-sot.md)
  - [Đo nhận diện IPI và gán ngữ cảnh từng model](reports/do-nhan-dien-ipi-va-gan-ngu-canh-tung-model.md)
  - [Thử làm rõ nghĩa stance](reports/thu-nghiem-lam-ro-nghia-stance.md)
  - [Đánh giá model thay thế Verifier](reports/danh-gia-model-thay-the-verifier.md)
  - [Chuẩn bị bộ nhãn chỉ dẫn và ngữ cảnh](reports/chuan-bi-bo-nhan-chi-dan-va-ngu-canh.md)
  - [Kiểm tra môi trường huấn luyện Verifier](reports/kiem-tra-moi-truong-huan-luyen-verifier.md)
  - [Phân tích bộ lọc trên tập phát triển](../benchmark/data/phan-tich-bo-loc-tren-tap-phat-trien.md)
- [Kiến trúc và phạm vi](architecture/pham-vi-va-kien-truc-du-an.md).
- [Kế hoạch và nhật ký tuần](../kế%20hoạch%20-%20nhật%20ký%20tuần/README.md).
- [Dữ liệu benchmark](../benchmark/data/README.md): nguồn, chuẩn hóa và chia tập.
- Kết quả chạy máy và log: `benchmark/results/` (giữ nguyên để bảo toàn baseline).

README, CONTRIBUTING và AGENTS ở gốc là các điểm vào sử dụng/phát triển dự án.

Hướng dẫn mới: [Duyệt batch Verifier đầu tiên](guides/duyet-batch-verifier-dau-tien.md).

Chẩn đoán mới: [Lỗi trích dẫn file Word demo](reports/chan-doan-loi-trich-dan-file-word-demo.md).

Thí nghiệm tiếp: [Mỗi request một chunk với mã tham chiếu nguồn](planning/thu-request-mot-chunk-tham-chieu-nguon.md).

Chẩn đoán model: [Stance và ngữ cảnh trên mẫu tối giản](reports/do-stance-ngu-canh-tren-mau-toi-gian.md).

Dữ liệu pilot: [Mở rộng dữ liệu ngữ cảnh Verifier](guides/mo-rong-du-lieu-ngu-canh-verifier.md).

Chuẩn bị dữ liệu: [Bằng chứng, JSON Verifier và rà trùng toàn kho](reports/chuan-hoa-bang-chung-va-ra-trung-toan-kho.md).

Theo dõi công việc chính: [Cổng hoàn thành Ưu tiên 1](planning/cong-hoan-thanh-uu-tien-1.md).
Xem [tiến độ mới nhất và phần việc kế tiếp](planning/tien-do-uu-tien-1.md).

Thử sửa Agent: [Verifier đọc nguồn trước khi không có nghi vấn](reports/thu-verifier-doc-nguon-khi-khong-co-nghi-van.md).
Đặt báo cáo mới trong `reports/`, kế hoạch trong `planning/`, mô tả thiết kế
trong `architecture/`, rồi cập nhật mục lục này. Các báo cáo cũ là lịch sử đo,
không tự thay số liệu khi code mới thay đổi.

Tổng hợp mới: [Các thử nghiệm Agent và điều kiện học Verifier](reports/tong-hop-thu-nghiem-agent-va-dieu-kien-hoc-verifier.md).

Chuẩn bị Verifier: [Token, chat template, vùng tính loss và dữ liệu bổ sung](reports/kiem-tra-tokenizer-mask-va-bo-sung-du-lieu-verifier.md).

Dữ liệu Verifier mới: [Chuẩn hóa bằng chứng/cửa sổ và rà trùng trước chia tập](reports/chuan-hoa-cua-so-va-ra-trung-du-lieu-bo-sung-verifier.md).

Quy trình mới: [AI tự đánh giá dữ liệu Verifier](guides/tu-danh-gia-du-lieu-verifier.md).
Báo cáo tiếp: [Tự đánh giá cửa sổ và sửa nguồn Verifier](reports/tu-danh-gia-va-sua-nguon-verifier.md).

Backend Verifier: [Kiểm tra collator và ngân sách GPU](reports/kiem-tra-collator-va-ngan-sach-gpu-verifier.md).

Dữ liệu Verifier: [Mở rộng nguồn ngoài và chốt audit v6](reports/mo-rong-nguon-ngoai-va-chot-audit-verifier.md).

Dữ liệu tiếng Việt và coverage: [Nền tài liệu dài, biến thể và audit v7](reports/bo-sung-tieng-viet-tai-lieu-dai-va-do-coverage.md).

Thử coverage: [Selector rải đều và baseline pipeline](reports/thu-selector-rai-deu-va-baseline-pipeline.md).

Thử điều phối: [Đọc bổ sung có ngân sách và tiến độ hai model](reports/thu-doc-bo-sung-co-ngan-sach.md).

Chẩn đoán tiếp: [Tách lỗi trích dẫn và lỗi người nhận chỉ dẫn](reports/tach-loi-trich-dan-va-ngu-canh.md).

Đã tích hợp: [Tiến độ từng model trong pipeline và panel mặc định](reports/tien-do-model-trong-luong-chinh.md).

Dữ liệu tiếp: [Chuẩn hóa nhãn người nhận chỉ dẫn, bằng chứng và audit v8](reports/chuan-hoa-nhan-nguoi-nhan-verifier.md).

Nguồn bổ sung: [Tutorial Python, cặp InjecAgent và audit v9](reports/bo-sung-nguon-ngoai-ngu-canh-verifier.md).

Trước chia tập: [Khoảng trống nguồn, định dạng và ràng buộc nhóm](reports/khoang-trong-va-dieu-kien-chia-tap-verifier.md).

Nguồn Việt đã tải: [Hai PDF, hai DOCX từ cơ quan/giáo dục chính thức](reports/nguon-tai-lieu-viet-pdf-docx-da-tim.md).
