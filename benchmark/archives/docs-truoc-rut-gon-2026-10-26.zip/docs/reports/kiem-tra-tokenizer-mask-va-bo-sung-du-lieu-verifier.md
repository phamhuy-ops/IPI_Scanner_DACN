# Kiểm tra tokenizer, vùng tính loss và bổ sung dữ liệu Verifier

## Phần đã hoàn thành

Đã kiểm tra tokenizer thật của Qwen/Qwen2.5-1.5B-Instruct tại revision
`989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, trên **144 biểu diễn của 72
nguồn đã duyệt**. Đây là bản xem trước cho audit, không phải tập train đã khóa.
Hai biểu diễn cùng nguồn không được tính thành hai nguồn độc lập.

- 144/144 khôi phục đúng JSON đích và token kết thúc từ các token được tính loss.
- Toàn bộ system/user, header assistant, newline sau EOS và padding có label=-100.
- Độ dài cả prompt và completion: 639–1.134 token; 21/144 vượt 1.024 token.
- Không truncate mẫu, không chạy forward/backward và không tải weights.
- Bốn kiểm tra mask bằng tokenizer thật và một kiểm tra cấu trúc dữ liệu mới đạt.

Mốc 1.024 trong kế hoạch chưa dùng được cho mọi bản xem trước. Chưa tăng
ngân sách mặc định vì còn cần đo bộ nhớ backend. Với mẫu quá dài phải chọn
ngân sách có kiểm chứng hoặc chia cửa sổ giữ đủ bằng chứng và ngữ cảnh;
không cắt đầu/cuối ngầm để làm đủ điều kiện.

## Cách kiểm tra chat template và mask

Dùng template đi kèm tokenizer, không sửa template gốc. Template hiện không
có khối generation, nên không giả định thư viện tự sinh assistant mask.
Công cụ tạo prefix system/user với generation header, tạo hội thoại đầy đủ
không thêm generation prompt, rồi xác minh prefix token trùng hoàn toàn.
Nếu ranh giới không trùng, công cụ dừng thay vì suy đoán theo ký tự.

Chỉ các token JSON của assistant và đúng một EOS được giữ làm labels.
Mask không tìm chuỗi “assistant” trong văn bản nguồn. Đối chứng có token
điều khiển giả trong nguồn không làm dịch ranh giới; token kết thúc trong
target, hội thoại ngoài phạm vi và yêu cầu cắt ngầm bị từ chối.

Đây là kiểm tra dữ liệu/labels độc lập, chưa chứng minh trainer tương lai sẽ
dùng đúng mask. Khi có trainer phải kiểm tra batch sau collator và loss thực.
`response_format` vẫn là ràng buộc runtime bên ngoài messages, không coi đó
là nội dung model được học. Nhãn/span đúng ngữ nghĩa là bước duyệt riêng.

Cách dùng template dựa trên [tài liệu Transformers](https://huggingface.co/docs/transformers/chat_templating),
trong đó hội thoại train không thêm generation prompt và tránh thêm lặp special tokens.

## Dữ liệu bổ sung

Đã tạo 15 nguồn nháp trong 5 family đề xuất: 5 confirmed, 5 dismissed và
5 uncertain; 9 tiếng Việt, 6 tiếng Anh, định dạng TXT/MD/HTML. Có 9 nguồn
dài từ 8.000 đơn vị UTF-16. Mỗi family giữ cặp tấn công, ví dụ trích dẫn
sạch và phần thiếu ngữ cảnh để đối chiếu; các biến thể phải ở cùng nhóm.

Tất cả **pending**, chưa có xác nhận người dùng, không đưa vào 72 nguồn
đã duyệt hoặc tập train. Sáu mẫu ngắn dựng được input/target qua parser.
Chín mẫu dài bị renderer chặn vì không vừa một batch: giữ toàn bộ nguồn,
chưa tạo input/target và ghi rõ cần cửa sổ giữ ngữ cảnh. Không tự tăng giới
hạn hoặc giả báo chúng đã qua parser.

Không trùng exact sau NFKC/chuẩn hóa khoảng trắng với 72 nguồn đã duyệt.
Chưa rà gần trùng toàn kho; 5 family chưa phải nhóm chia tập cuối. Nền dài
có lặp mục kiểm tra nên chỉ là fixture có kiểm soát, chưa đại diện văn bản
dài thực tế. Không có DOCX/PDF mới. Dữ liệu tự soạn chưa bổ sung được nguồn
uncertain bên ngoài hoặc holdout độc lập; hai khoảng trống đó vẫn mở.

## Lưu trữ và tái lập

Môi trường Python, các thư viện/tokenizer/cache nằm trên E theo wrapper
`scripts/python-verifier.ps1`; code và báo cáo ở dự án trên C. Đã cài
Transformers 4.57.1, Jinja2 3.1.6 và các phụ thuộc, không cài PyTorch.
Danh sách phiên bản thực tế nằm trong kết quả audit; chưa phải lock cho
backend huấn luyện GPU.

Từ gốc dự án:

1. `node scripts/prepare-verifier-tokenizer-preview.cjs` chỉ chạy khi chưa có
   bản xem trước; công cụ từ chối ghi đè.
2. `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_tokenizer.py`
3. `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_tokenizer.py`
4. `node --test scripts/prepare-verifier-gap-batch.test.cjs`

[Kết quả token/mask và hash](../../benchmark/experiments/verifier-tokenizer-v1/ket-qua.json).
[Phiên bản thư viện](../../benchmark/experiments/verifier-tokenizer-v1/phu-thuoc.txt).
[Nguồn mới chờ duyệt](../../benchmark/data/annotations/verifier-gap-v1/mau-cho-duyet.jsonl).

## Bước kế tiếp và Ưu tiên 1

Duyệt 15 nháp theo lượt 5 mẫu như đã thống nhất. Sau đó thiết kế cửa sổ
cho nguồn dài có đối chứng, audit lại token/mask và kiểm tra nhóm toàn kho.
Tiếp tục bổ sung nguồn ngoài có quyền sử dụng, giữ tập độc lập chưa dùng.
Chưa train, chưa thay model/prompt/policy mặc định và chưa thêm phản biện.
**Ưu tiên 1 chưa hoàn thành**: các kiểm tra này chưa cải thiện hoặc chứng
minh khả năng nhận diện IPI của pipeline.
