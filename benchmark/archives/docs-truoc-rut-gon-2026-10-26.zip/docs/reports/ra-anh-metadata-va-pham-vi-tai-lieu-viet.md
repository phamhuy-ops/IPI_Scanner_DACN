# Rà ảnh metadata và phạm vi tài liệu Việt

Ngày 2026-10-26. Đã rà có mục tiêu bằng AI trên chín trang PDF được render
bằng Poppler, năm contact sheet bao gồm 56 ảnh DOCX văn thư và các trường
metadata/liên kết ngoài của hai DOCX. Không sửa file gốc, không gửi nội dung
cho hai model Ollama và không nhập train/dev/holdout.

## Phát hiện ảnh hưởng trực tiếp đến Ưu tiên 1

PDF cổng trường: trang 1 là bìa có nhiều chữ trong ảnh, trang 63 là trang
cảm ơn có chữ và thông tin hỗ trợ, không phải trang trắng. Extractor hiện
tại chỉ lấy một ký tự ở trang 1 và không lấy chữ ở trang 63. Kiểm tra chuỗi
nhìn thấy trên trang 63, sau chuẩn hóa NFC và hoa thường, cũng không tìm
thấy trong text toàn file. Đây là bằng chứng cụ thể về **giới hạn độ bao
phủ đầu vào**, chưa phải bằng chứng model sai hoặc nội dung có IPI.

Trang 49 có ảnh giao diện, một số vùng đã làm mờ; trang 62 có hướng dẫn
bảo vệ thông tin khi gửi ảnh. Chưa xem hết 63 trang và không dựa vào lời
ghi trong tài liệu để xác nhận mọi ảnh đã được ẩn danh đầy đủ. PDF OMS đã
xem trang 1, 10, 17, 23: có chữ trong ảnh chụp biểu mẫu, danh sách và giao
diện; text bên ngoài ảnh không đại diện toàn bộ nội dung nhìn thấy.

DOCX văn thư: đã xem toàn bộ 56 ảnh ở mức contact sheet, phát hiện tên và
tài khoản hiển thị trong giao diện. Chưa xác minh đó là dữ liệu thật hay
demo. Không duyệt file gốc làm tập huấn luyện; nếu chọn dùng cần bản dẫn
xuất làm sạch riêng, kiểm tra từng ảnh ở độ phân giải gốc và quyền dùng.
Contact sheet không đủ để đọc mọi chữ nhỏ hoặc tuyên bố toàn bộ ảnh an toàn.

## Metadata và liên kết

Hai DOCX có thông tin ứng dụng, người tạo/người sửa và thời điểm lưu trong
core/app XML; không đưa các giá trị nhận dạng vào mẫu model. Văn thư có
12 quan hệ hyperlink ngoài tới thuvienphapluat.vn, HNUE không có quan hệ
ngoài được liệt kê. Chỉ kiểm tra cấu trúc đích, không mở hoặc làm theo link.
Điều này không xác nhận nội dung/độ an toàn của trang đích.

PDF metadata được kiểm kê bằng pdfinfo; không thấy JavaScript theo công cụ.
Đây không phải kiểm tra malware. Không dùng trường Pages trong DOCX metadata
làm số trang thật: giá trị có thể cũ, cần render bố cục để xác minh.
Chưa render toàn bố cục DOCX nên trạng thái kiểm tra hình thức toàn file vẫn mở.

## Quyết định sử dụng

Giữ cả bốn nguồn trong incoming, quyền dùng `not_verified`, không gán nhãn
sạch toàn tài liệu, `training_eligible=false`. Không có phần mềm cần cài
thêm cho lượt rà này: Poppler và Pillow có sẵn trong runtime đi kèm.

Ưu tiên đối chứng tiếp theo bằng tài liệu tự soạn có nội dung kiểm soát:
mỗi nền có bản sạch, chỉ dẫn cho người dùng, attack trích dẫn và attack
đang có hiệu lực; vị trí đầu/giữa/cuối, cùng nội dung trong PDF/DOCX.
Tách ca chữ thật với ca chữ nằm trong ảnh để không quy lỗi extraction cho
Agent. Bản gốc công khai tiếp tục phục vụ chẩn đoán kỹ thuật cục bộ; trước
train/tái phân phối vẫn cần quyền dùng và rà riêng tư phù hợp.

Chưa thêm OCR hoặc sửa chính sách runtime trong lượt này. Bước nâng cấp
tiếp cần baseline có đối chứng cho việc nhận biết phần không đọc được và
trả lý do độ bao phủ chưa đủ; không chỉ tăng số chunk. OCR, nếu chọn sau,
cần đo chữ trích xuất, độ trễ và tác động toàn pipeline trước triển khai.
**Ưu tiên 1 chưa hoàn thành; chưa chứng minh cải thiện nhận diện Agent.**

## Bằng chứng và tái lập

Script `scripts/inspect-public-vi-visual.py` dùng Python/Pillow đi kèm và
`pdfinfo`/`pdftoppm` trên PATH. Hash file nguồn được kiểm tra trước khi đọc;
script từ chối thư mục đầu ra đã có. Kết quả rà riêng nằm tại
`benchmark/experiments/public-vi-native-visual-v1/ket-qua-ra-soat.json`;
ảnh/metadata cục bộ cùng thư mục, không phải dataset phát hành.

Lần chạy đầu đã ghi đầy đủ artifact rồi gặp lỗi console cp1252 ở dòng in
cuối; đã sửa stdout UTF-8, xác nhận artifact và ảnh sau đó, không chạy ghi
đè đầu ra. Chín PNG PDF và 56 PNG media được tạo; chín trang và năm contact
sheet được xem. Không tuyên bố đây là kiểm tra trực quan mọi trang.
