# Thử đọc bổ sung có ngân sách

Ngày 2026-10-25. Thuộc Ưu tiên 1: chính sách kết luận và độ bao phủ.

## Phần đã triển khai

Có bộ điều phối thí nghiệm riêng tại
`src/ai/experiments/boundedDocumentReview.ts`. Scanner xuất catalogue khi bật
`includeSemanticChunkCatalog`; UI và pipeline mặc định chưa gọi nhánh này.
Giữ selector, rule, prompt, schema và cấu hình mặc định.

Mỗi đoạn có alias ổn định và tiến độ riêng cho Detector/Verifier. Cả hai trả
phản hồi được parser chấp nhận trong thời hạn mới tính hoàn tất. JSON đúng
và trích dẫn khớp chưa chứng minh nhận định ngữ nghĩa đúng. Lỗi ở đoạn sau
không xóa tiến độ trước đó; không tự thử lại JSON lỗi hoặc thêm phản biện.

Giới hạn cứng: 64 chat request, 24 đoạn bổ sung, 180 giây. Người gọi phải chọn
ngân sách cụ thể. Fallback dùng chung ngân sách; cleanup giải phóng model có
thời hạn riêng. Deadline tính từ lúc vào bộ điều phối, không gồm extraction.
HTTP bridge nhận timeout nhưng chưa chứng minh server hủy inference tức thì.

Phần chưa hoàn tất, lỗi extraction, cảnh báo HTML, thiếu văn bản từng file,
bất đồng hoặc hai vai trò dùng cùng model vẫn được đưa vào policy. Bằng chứng
đã được cả hai confirmed có thể cho `ipi_detected` kèm hạn chế như policy cũ.
Thiếu coverage/lỗi không được biến thành `not_detected`.

## Kiểm tra kỹ thuật

- Baseline trước sửa: 77/77 kiểm thử scanner và pipeline.
- Sau sửa: 97/97 kiểm thử liên quan; toàn Vitest 212/212, 15 file.
- Typecheck, lint và build đạt. Build vẫn có cảnh báo alias `customResolver`
  và tùy chọn `freeze`; chưa sửa tooling ngoài phạm vi.
- Kiểm thử endpoint giả lập nhưng client/parser/agents thật: ngân sách HTTP
  kể cả fallback, deadline và phản hồi muộn, lỗi JSON/citation, giữ tiến độ,
  alias/không lặp, coverage HTML và confirmed kèm coverage còn thiếu.

Lệnh tái lập:

```powershell
npm test
npm run typecheck
npm run lint
npm run build
node scripts/run-bounded-document-review.cjs --simulate
node scripts/run-bounded-document-review.cjs --ollama
```

Kế hoạch trước sửa: [thiết kế](../planning/thu-doc-bo-sung-co-ngan-sach.md).
Hash baseline: `benchmark/experiments/bounded-document-review-v1/baseline.json`.

## Phép giả lập trên file thật

Raw: `benchmark/results/bounded-review-EFqC6B`.
Nguồn dài mục tiêu có 27 đoạn: không đọc thêm hoàn tất 24 đoạn/48 request;
đọc thêm 3 hoàn tất 27 đoạn/54 request. Hai file ngắn đều 1 đoạn/2 request.

Endpoint giả lập luôn trả không có discovery, nên có thể bỏ sót attack.
Không tính metric bảo mật từ phép này; chỉ xác nhận lịch đọc và hạch toán.

## Phép đo hai model thật

Raw: `benchmark/results/bounded-review-uDFKfs`; kết quả tổng hợp:
`benchmark/experiments/bounded-document-review-v1/ket-qua.json`.
Ba đầu vào duy nhất, mỗi đầu vào chạy hai chế độ, tổng sáu lượt/42 chat request.
Model digest trước/sau không đổi. Manifest/hash code và request/response
được giữ trong thư mục raw, cùng snapshot tài nguyên Ollama sau chat.

- File dài: cả hai chế độ hoàn tất 8/27 đoạn, dùng 17 request rồi lỗi
  citation ở `chunk-5` (đoạn thứ chín được xử lý theo thứ tự selector).
  Quote model chứa cả `</untrusted_document_data>` vốn là marker giao thức,
  không phải nguồn. Validator từ chối đúng; không sửa quote để ép đạt.
- Cặp attack/clean ngắn: attack vẫn bất đồng, trả `needs_review`; clean
  trả `not_detected`, ở cả hai chế độ.
- Mỗi chế độ có TP=0, FP=0, TN=1, attack bị kết luận sạch=0; hai attack
  đều `needs_review`. Recall confirmed=0, F1 confirmed=0, FPR=0;
  precision không xác định vì không có cảnh báo confirmed. Độ phủ quyết
  định nhị phân là 1/3; `needs_review` không được ghi thành phát hiện đúng.

Không có cải thiện kết luận giữa hai chế độ. File dài dừng trước khi tới
phần bổ sung, nên **chưa kiểm chứng được lợi ích đọc thêm bằng model thật**.
Thời gian trung bình khoảng 33,25 giây/lượt không đọc thêm và 30,83 giây/lượt
cho đọc thêm; thứ tự chạy/cache chưa kiểm soát nên không suy ra cải thiện
tốc độ. RSS harness tối đa khoảng 174,5 MiB, không phải peak VRAM.

## Giới hạn và điều kiện chuyển bước

Ba ca dev gồm nguồn dài mục tiêu và cặp attack/clean cũ; không phải holdout.
Hai chế độ dùng cùng giao thức một đoạn/request, classic-v1; khác ở số đoạn
bổ sung cho phép (0 hoặc 3). Không so trực tiếp với batching mặc định để
tuyên bố cải thiện. Một đoạn/request có nguy cơ thiếu ngữ cảnh xuyên đoạn.

Chưa bật UI, chưa train, chưa thêm phản biện. Ưu tiên 1 vẫn chưa hoàn thành;
còn chất lượng Agent, kiểm chứng độc lập và đo toàn luồng/UI.

Tạo đối chứng tách lỗi quote chứa marker bao khung khỏi discovery sai trên
mô tả sạch; đối chiếu các hợp đồng đã thử để chọn một thay đổi có bằng chứng.
Giữ nguyên validator nguồn và kiểm tra tiến độ hiện tại. Chưa đưa đọc bổ sung
vào UI hoặc tuyên bố rằng hoàn tất Ưu tiên 1.
