# Chẩn đoán lỗi trích dẫn khi quét file Word demo

Ngày 2026-10-24, tái hiện lỗi Detector trả trích dẫn không có trong nguồn.
File đọc được 80.041 ký tự, tạo 112 chunk. Không coi tài liệu an ninh mạng
là IPI chỉ vì có lệnh kỹ thuật; chưa có nhãn được duyệt cho toàn tài liệu.

Thử duy nhất một ứng viên: giới hạn phần giải thích `analysis` và `reason`
ở 240 ký tự trong prompt/schema. Nguồn, model, parser, rule và chính sách
kết luận giữ nguyên. Ứng viên chỉ nằm trong bridge chẩn đoán `--bounded`,
không áp dụng vào ứng dụng. Không sửa file Word hoặc đưa file vào Git.

Balanced của baseline lỗi trích dẫn; ứng viên hoàn thành hai vai trò nhưng
vẫn cần xem xét do chỉ chọn 12/112 đoạn. Với đúng Deep Scan 24/112 đoạn,
cả baseline và ứng viên đều lỗi trích dẫn. Chạy xong một lượt Balanced
không đủ để nói demo đã ổn.

Ba fixture đối chứng nằm ở `benchmark/fixtures/demo-output-v1/`. Mẫu sạch
nhắc Dan Evans và công việc của analyst; mẫu tấn công yêu cầu assistant
bỏ nhiệm vụ; mẫu sạch khó đặt câu tấn công trong ví dụ không được thực thi.
Hai mẫu sau chung nhóm hành vi, không dùng như hai nguồn độc lập.
Baseline bỏ sót tấn công; ứng viên lỗi trích dẫn trên tấn công và báo nhầm
ví dụ trích dẫn. Vì vậy loại ứng viên, giữ nguyên mặc định. Đây là bằng chứng
về vấn đề hiểu ngữ cảnh, ngoài vấn đề định dạng/trích dẫn.

Kết quả máy, confusion counts, abstention, precision/recall/F1/FPR và theo
nhóm nằm ở [kết quả thử](../../benchmark/experiments/document-output-budget-v1/ket-qua.json).
Giá trị không xác định dùng `null`. Không đo peak VRAM/RAM; mỗi cấu hình
một lượt, chưa có kết luận thống kê. Log chứa nội dung nguồn chỉ giữ cục bộ
trong `benchmark/results/` bị gitignore. 46 kiểm thử policy/pipeline đạt;
điều đó không chứng minh khả năng phát hiện thực tế.

Lệnh tái hiện tại gốc dự án:

```powershell
node scripts/diagnose-document-demo.cjs 'C:/Users/Admin/Downloads/TheR9ck_Hunting_Lateral_Movement_Windows_VN.docx' --deep
node scripts/diagnose-document-demo.cjs 'C:/Users/Admin/Downloads/TheR9ck_Hunting_Lateral_Movement_Windows_VN.docx' --deep --bounded
node scripts/diagnose-document-demo.cjs benchmark/fixtures/demo-output-v1/quoted.txt --bounded
npm test -- src/ai/agents/document/reviewPolicy.test.ts src/ai/agents/document/ipiPipeline.test.ts
node scripts/summarize-document-demo.cjs
```

Các fixture bản chạy gốc dùng tên file tương ứng trong `benchmark/results/demo-controls/`;
giữ nguyên tên khi cần so prompt vì header chứa tên file. Script tổng hợp
đọc ID log lịch sử đã khóa, không tự chạy lại hoặc thay baseline.
Lượt tham chiếu mã nguồn trước đó có lỗi bridge truyền profile, thực tế
chỉ chọn 12 đoạn dù tham số ghi deep; đã loại khỏi phép so Deep Scan.

Bước tiếp là thử ràng buộc đoạn nguồn và giảm lượng nội dung mỗi request
trong một thí nghiệm riêng; giữ ca ví dụ trích dẫn làm đối chứng bắt buộc.
Chỉ đưa lên UI khi qua cả kiểm tra nguồn, ngữ cảnh và pipeline. Không nới
khớp chữ, tự chữa quote, bỏ finding lỗi hoặc ép trả sạch để làm demo.
