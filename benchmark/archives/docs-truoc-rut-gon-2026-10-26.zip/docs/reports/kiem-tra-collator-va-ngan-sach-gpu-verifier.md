# Kiểm tra collator và ngân sách GPU cho Verifier

## Kết luận hiện tại

Đã kiểm tra tensor sau collator trên **174/174 bản xem trước** và hoàn tất
10 bước QLoRA kỹ thuật trên GPU. Có thể giữ **2.048 token làm ứng viên
ngân sách kỹ thuật**, với backend loss mới và các điều kiện bên dưới.
Đây chưa phải cấu hình pilot đã chứng minh chất lượng hoặc độ ổn định dài.

Có cập nhật adapter thử trên fixture tài nguyên mới. Không dùng 87 nguồn
dev hoặc holdout để cập nhật model; chưa bắt đầu fine-tuning dữ liệu dự án.
Không thay model/rule/prompt/policy mặc định và chưa thêm phản biện.

## Collator

174 bản gồm 144 biểu diễn của 72 nguồn đã duyệt và 30 biểu diễn hiện dùng
của 15 nguồn bổ sung. Hai biểu diễn cùng nguồn không tạo thêm nguồn độc lập.
Dữ liệu chỉ đi qua tokenizer/collator, không được forward qua model để học.

Collator giữ labels đã audit, mask prompt/header/padding bằng -100, không
suy mask bằng cách tìm token có giá trị bằng pad. Causal LM dịch một vị
trí khi tính loss, collator không dịch thêm. Tất cả JSON đích và EOS còn
nguyên sau padding. Có 48 bản vượt 1.024 token, 4 vượt 1.536; không bản
nào vượt 2.048. Target dài nhất hiện tại có 164 token kể cả EOS.

Ba kiểm tra collator đạt, gồm đối chứng pad trùng EOS, không truncate khi
padding vượt ngân sách và từ chối labels mất/sai target.

## Từ lỗi bộ nhớ tới backend loss mới

Cấu hình dense nạp NF4 và chạy được một bước ở 1.024/1.536/2.048 token,
nhưng peak allocation tương ứng khoảng 3,87/4,83/5,78 GiB. Không coi việc
không OOM là bằng chứng vừa VRAM 4 GB: mức 2.048 lớn hơn bộ nhớ vật lý,
và free memory sau bước cuối bằng 0 trong lượt dense đó.

Lượt GPU đầu tiên dừng AssertionError trước khi có đủ log để phân biệt
loss/gradient. Giữ kết quả và bản script cũ. Các lượt v2 thêm chẩn đoán,
đặt FP16 loss scale ban đầu 1.024 và chạy được; không kết luận nguyên
nhân duy nhất của lỗi cũ khi log chưa đủ.

`verifier_supervised_loss.py` chỉ tính lm_head/logits tại vị trí có label
đích. Toàn bộ nguồn vẫn đi qua transformer và attention; không cắt prompt,
không bỏ token JSON/EOS được học. Logit tại t so với label tại t+1.
Hai kiểm tra với Qwen2 nhỏ FP32 đạt: loss và gradient của mọi parameter
tương đương dense trong sai số kiểm tra, kể cả hai hàng có completion dài
khác nhau và pad trùng EOS. Batch không còn target bị từ chối.

Ở fixture 2.048 token/11 target token, loss bước đầu của dense và backend
mới cùng là 3,5345583. Peak allocation giảm từ 5,78 xuống 2,68 GiB.
Norm gradient FP16 khác khoảng 0,56%; không khẳng định bitwise tương
đương trên GPU hoặc coi đây là phép đo chất lượng IPI.

## Phép đo 10 bước có giới hạn bộ nhớ

GPU thực tế: RTX 3050 Ti Laptop, 4 GB. Dùng Qwen/Qwen2.5-1.5B-Instruct
revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, NF4 double quant,
FP16, LoRA r=8/alpha=16 cho q_proj/v_proj, micro-batch=1, SDPA,
gradient checkpointing, AdamW 1e-4, clipping norm=1 và loss scale đầu 1.024.
Không cấu hình CPU/disk offload; device map của model nằm ở GPU 0.

Fixture kỹ thuật có 2.048 token, 256 token đích JSON, lớn hơn target dài
nhất hiện tại. JSON stress là dữ liệu tài nguyên mới, không giả làm nhãn
Verifier hoặc mẫu bảo mật đã duyệt. Giới hạn allocator tiến trình ở 80%
bộ nhớ GPU. Kết quả:

- Đủ 10 bước, loss/gradient hữu hạn; adapter save/reload khớp tensor.
- Peak allocation: 2.954.099.200 byte (~2,75 GiB).
- Peak reserved: 3.246.391.296 byte (~3,02 GiB).
- Free sau các bước: 169.554.740 byte (~162 MiB), dư địa còn nhỏ.
- Mỗi bước mất khoảng 3,96–5,09 giây trên fixture này; không phải latency scan.
- RAM peak working set của tiến trình khoảng 3,69 GiB; peak pagefile/private
  commit được lưu riêng, không nhầm là RAM vật lý hoặc VRAM.

Norm gradient trước clipping có một bước lên khoảng 244,79; vẫn hữu hạn
và được clip. Không diễn giải 10 bước hoặc loss giảm trên chuỗi lặp đơn
giản là bằng chứng train dài ổn định hay nhận diện IPI tốt hơn.

Ứng viên 2.048 chỉ áp dụng cho backend completion_loss và cấu hình đã đo.
Không chuyển kết luận này sang dense loss. Nếu target vượt 256 token,
micro-batch tăng, phần cứng/ứng dụng GPU cạnh tranh hoặc cấu hình thay đổi,
phải đo lại. Chưa kiểm tra Trainer/Accelerate tích hợp, gradient accumulation
8 trên tập train đã khóa, train dài hoặc chất lượng model sau học.

## Môi trường và lưu trữ

Đã cài trên E: torch 2.8.0+cu128, transformers 4.57.1, peft 0.17.1,
accelerate 1.10.1, bitsandbytes 0.48.1 cùng phụ thuộc. Các bản này được
khóa cho phép đo, không tuyên bố là mới nhất. [Lock phiên bản thực tế](../../benchmark/experiments/verifier-collator-v1/phu-thuoc.txt).

Weights HF khoảng 3,10 GB ở cache E, đúng revision; khác weights Ollama.
Các adapter thử cũng ở E và có file `KHONG-DUNG-TRIEN-KHAI.json`. Giữ
bản cũ, không import adapter kỹ thuật vào ứng dụng và không xóa model.
Ổ E giảm khoảng 13,44 GiB trong lượt cài/tải/đo, gồm wheel cache và thư
viện CUDA; đây là dung lượng thực tế, lớn hơn ước lượng 12 GiB cũ.

Lần tải đầu gặp lỗi quyền Windows khi tạo symlink cho generation_config.
Weights, config và tokenizer đã tải đủ. Phép đo không dùng generate nên
không cần tệp generation_config; bước kiểm tra assets sau đó chạy offline.
Script tải lại có chế độ `--download`, chỉ lấy tệp cần và một worker.

Đã đối chiếu [lệnh PyTorch CUDA chính thức](https://pytorch.org/get-started/previous-versions/),
[hỗ trợ Windows/CUDA của bitsandbytes](https://huggingface.co/docs/bitsandbytes/v0.48.1/en/installation)
và [chuẩn bị model quantized cho PEFT](https://huggingface.co/docs/peft/v0.17.0/en/developer_guides/quantization).

## Tái lập và phần tiếp theo

Từ gốc dự án, dùng `scripts/python-verifier.ps1` để cache/temp/output ở E.
Trên môi trường mới, cài torch 2.8.0 từ index cu128 chính thức trước, rồi
cài đúng các phiên bản đã khóa. Các script tạo phép đo từ chối ghi đè;
dùng phiên bản/thư mục mới khi chạy lại, giữ lịch sử.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/prepare_verifier_gpu_assets.py --download
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_collator.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_supervised_loss.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_gpu_fixture.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_collator.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/smoke_verifier_gpu.py --length 2048 --steps 10 --version v3 --loss-mode completion --target-tokens 256 --memory-fraction 0.8
node scripts/summarize-verifier-gpu.cjs
```

Sáu kiểm tra mới đạt (fixture có bốn tổ hợp kích thước), pip check đạt.
[Tổng hợp máy](../../benchmark/experiments/verifier-backend-summary-v1/ket-qua.json)
giữ hash đầu vào và đường dẫn các phép đo dense/candidate/thất bại.

Bước tiếp nên trở lại khoảng trống dữ liệu: bổ sung nguồn ngoài và nhóm
còn thiếu, ghi reviewer/provenance rõ, kiểm tra overlap trước chốt train/dev.
Sau đó tích hợp backend đã đo vào trainer và chạy smoke trên dữ liệu train
hợp lệ. Chưa có holdout độc lập được xác minh; **Ưu tiên 1 chưa hoàn thành**.
