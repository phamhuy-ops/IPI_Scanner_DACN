# Khoảng trống và điều kiện chia tập Verifier

Ngày 2026-10-25. Đã rà phiên bản dữ liệu đang sử dụng và lập ràng buộc nhóm;
**chưa tạo train/dev/holdout và chưa bắt đầu huấn luyện**.

## Phần đã xác minh

Registry có 178 bản ghi ngoài legacy, 131 parent ID và 71 nhóm sau audit v9.
Đã chọn đúng sáu bản gap sửa bằng AI thay cho phiên bản lỗi, giữ nguyên ID
cha; không đếm thành sáu nguồn mới. Phiếu người dùng áp dụng bản cũ không
được chuyển thành duyệt phiên bản sửa. 30 nhãn bài Việt chỉ tính trên cửa sổ
đã duyệt, không gán nhãn toàn bài.

Nhãn hiện có: 59 confirmed, 85 dismissed, 34 uncertain. Ngôn ngữ: 73 Việt,
98 Anh, bốn Trung và ba Anh–Việt. Không cộng bản hỗn hợp vào cả hai ngôn ngữ.
34 ca có addressee=human, nhưng nhãn human không tự chứng minh đủ độ đa dạng
tình huống hoặc model đã phân biệt đúng.

## Ràng buộc trước chia

- 44 nhóm/84 bản ghi dính baseline 72 ca hoặc dấu vết fixture/manifest dev:
  đề nghị giữ làm development regression. Các thành viên cùng nhóm không
  được chia sang holdout chỉ vì bản ghi đó chưa có trong baseline.
- 27 nhóm/94 bản ghi còn lại chưa có dấu vết như trên trong phép đối chiếu:
  **vẫn chưa được duyệt vai trò**, không coi là untouched hoặc độc lập.
  Không có cờ overlap không có nghĩa là chưa được dùng.
- Không bản ghi nào được tự cấp training_eligible=true. Có thể chuẩn bị
  ràng buộc nhóm, nhưng chưa đủ điều kiện chốt train/dev. Holdout độc lập đã
  xác minh: 0 bản ghi.

Đây là đề nghị ràng buộc theo lịch sử và heuristic, không phải split thật.
Nhóm 30 bản InjecAgent phải được giữ chung; không phá nhóm cho đẹp tỷ lệ.
Các parent xuất hiện dưới nhiều tên source không được cộng lại như nguồn mới.

## Khoảng trống quan trọng

**Tài liệu dài:** 34 bản text toàn nguồn dài ít nhất 8.000 đơn vị UTF-16,
nhưng **0 đầu vào có nhãn dài tới mức đó**. Tổng 39 bản dùng cửa sổ ngắn hơn
text nguồn. Việc có nền dài chưa chứng minh đã gán nhãn hoặc kiểm tra đủ cả
tài liệu. Không tự gán benign cho phần ngoài cửa sổ.

**Định dạng:** annotation khai báo 150 TXT, 12 HTML và 16 Markdown. Kiểm kê
file vật lý trong benchmark/data và benchmark/fixtures có **0 PDF/DOCX/DOC**.
Không tìm trong Downloads, không dùng tài liệu riêng đã từng demo. Tạo PDF
hoặc DOCX từ text tự soạn chỉ kiểm tra đường xử lý định dạng; không biến
thành tài liệu thật độc lập.

**Nguồn uncertain:** 12 ca nguồn ngoài đều đến từ InjecAgent, có nhãn text-only
uncertain; 22 ca còn lại thuộc nhóm tự soạn hoặc phần chèn trên Wikipedia.
Chưa có uncertain từ một họ nguồn ngoài khác được xác minh. Không lấy bất
đồng người gán nhãn để tạo uncertain, cũng không suy từ nhãn attack gốc.

**Mục tiêu số lượng:** theo kế hoạch pilot 300 bản ghi/ít nhất 100 nhóm,
còn thiếu tối thiểu 122 bản ghi và 29 nhóm. Với mục tiêu stance 120/120/60,
khoảng thiếu là 61 confirmed, 35 dismissed, 26 uncertain. Để có tối thiểu
40% Việt và 40% Anh trên mốc 300, còn thiếu 47 bản Việt và 22 bản Anh đơn
ngữ. Đây chỉ là số học ngân sách; các khoảng thiếu có thể giao nhau và thêm
đúng số lượng **không tự làm dữ liệu đủ điều kiện train**.

## Tài liệu đề nghị bổ sung

Đợt kế tiếp nên bắt đầu với **4–6 tài liệu gốc tiếng Việt**, có ít nhất hai
PDF có lớp chữ và hai DOCX, từ ít nhất hai đơn vị nguồn. Ưu tiên hướng dẫn
thao tác/quy trình, thông báo, biên bản mẫu hoặc tài liệu kỹ thuật có chỉ dẫn
cho người. Có một tài liệu dài hơn khoảng 8.000 ký tự để kiểm tra phạm vi.
Đợt này chỉ giải quyết bước đầu khoảng trống định dạng, chưa đủ thay pilot.

Đã tạo [thư mục nhận và hướng dẫn](../../benchmark/data/incoming/public-vi-documents/README.md)
và mẫu metadata. Cần kèm URL gốc, tác giả/đơn vị, phiên bản/ngày, license
hoặc quyền sử dụng lại, và mô tả nếu đã khử thông tin riêng. Công khai không
tự có nghĩa được phép dùng làm dữ liệu. Không cần tự chèn attack hoặc cài model.
Nếu cùng nội dung có cả PDF và DOCX, giữ cùng parent/group.

Có thể bổ sung file đủ quyền sử dụng hoặc cung cấp URL công khai để tải và
kiểm tra tự động. **Hiện không cần cài phần mềm thủ công.** File mới chỉ ở
vùng incoming, chưa được tự gán nhãn hoặc nhập train/holdout.

## Tiến độ Ưu tiên 1

Đã hoàn tất bước rà khoảng trống và lập ràng buộc nhóm; ba kiểm thử liên quan
đạt. Không gọi model hoặc đổi runtime. Mốc tiến độ từng model trong ứng dụng
vẫn đã triển khai; phần chất lượng Agent, tài liệu dài/đa định dạng toàn luồng
và kiểm chứng độc lập chưa đạt. **Ưu tiên 1 vẫn chưa hoàn thành.**

Bước tiếp là nhận/thu thập tài liệu đủ nguồn/quyền và kiểm tra extraction,
trước khi thêm đối chứng, nhãn ngữ cảnh và nhóm. Không chia ngay 178 bản ghi
để tạo cảm giác đã có tập train.

## Tái lập

```powershell
node --test scripts/assess-verifier-split-readiness.test.cjs
node scripts/assess-verifier-split-readiness.cjs
```

Script từ chối ghi đè phiên bản đã có. Dữ liệu được kiểm tra hash với audit
v9; snapshot kế hoạch lúc rà được giữ trước cập nhật tiến độ. Registry chỉ
lưu metadata/hash, không xuất SFT. Các ràng buộc không loại hết rò rỉ ngữ nghĩa.

- [Kế hoạch trước rà](../planning/ra-khoang-trong-va-dieu-kien-chia-tap.md).
- [Kết quả](../../benchmark/experiments/verifier-split-readiness-v1/ket-qua.json).
- [Registry phiên bản đang dùng](../../benchmark/experiments/verifier-split-readiness-v1/registry.jsonl).
- [Ràng buộc nhóm, chưa chia tập](../../benchmark/experiments/verifier-split-readiness-v1/rang-buoc-nhom.json).
