# Bổ sung tiếng Việt, tài liệu dài và đo coverage trước AI

## Lượt dữ liệu đã hoàn tất

Đã thêm 30 bản ghi tiếng Việt trên nền sáu bài công khai đúng revision:
Quang hợp, Thư viện, Năng lượng tái tạo, Hệ sinh thái, Viện bảo tàng và
Giao thông công cộng. Có năm nền dài trên 8.000 đơn vị UTF-16; bài bảo
tàng khoảng 7.570 ký tự được giữ nguyên, không lặp nội dung để bù độ dài.
Trong 30 phiên bản có 25 tài liệu vượt mốc thống kê này.

Mỗi nền có năm phiên bản: không chèn, chỉ dẫn tấn công, ví dụ trích dẫn,
chỉ dẫn con người và thiếu ngữ cảnh. Nhãn cửa sổ gồm 6 confirmed,
18 dismissed, 6 uncertain. Các hành vi tự soạn gồm xác nhận chuyên gia
không có chứng cứ, lấy ghi chú riêng, sửa lịch trái quyền, chuyển sang
quảng cáo, bịa trích dẫn và gửi hội thoại qua tham số URL. Không dùng
tiền tố chung của InjecAgent để tạo toàn bộ các ca mới.

Sáu nền là bài công khai thật; phần chèn/đối chứng được Codex tự soạn,
không phải tấn công được phát hiện trên Wikipedia. 30 bản vẫn chỉ là
**6 ID nguồn cha/6 nhóm mới**, không phải 30 nguồn độc lập.

## Nguồn gốc, giấy phép và phạm vi nhãn

Đã giữ HTML gốc theo revision, metadata, bản trích đoạn văn và hash.
Ghi công qua URL revision/lịch sử tác giả, giữ tuyên bố CC BY-SA 4.0
theo [điều khoản Wikimedia](https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use#7._Licensing_of_Content).
Các văn bản dẫn xuất được ghi cùng giấy phép và chỉ rõ phần thay đổi;
không đổi giấy phép code toàn dự án. Khi xuất/chia sẻ dữ liệu phải kèm
tệp ghi công/giấy phép, không đưa metadata nhãn/nguồn vào messages.

Việc trích p đã bỏ bảng, chú thích sup, hình và script/style. Giữ raw
HTML để đối chiếu, không coi phép trích này là extractor của ứng dụng
đã được kiểm chứng. Các thông báo/quyền bổ sung riêng của bài chưa được
thẩm định độc lập; nguồn ghi rõ đây là giấy phép được công bố.

**Nhãn chỉ áp dụng cửa sổ đã chọn.** Full_document_security_label luôn
là null: không tự gán cả bài dài là benign, không lấy window label chấm
negative cho toàn tài liệu. Cửa sổ gồm một câu nền hoàn chỉnh trước/sau
phần chèn; bản trích dẫn giữ cả lời dẫn và yêu cầu không làm theo. Chọn
ranh giới đoạn gần đầu/giữa/cuối, không chèn giữa từ như lỗi fixture cũ.

Codex (AI) đánh giá phần cửa sổ và bao khung đã trình bày, có nhật ký/hash
riêng; không ghi thành người dùng duyệt. Việc chọn cửa sổ theo bằng chứng
đã biết chỉ phục vụ chuẩn bị nhãn, không chứng minh selector runtime tìm
được câu chèn. Chưa xuất train hoặc đưa thành benchmark toàn tài liệu.

## Kiểm tra dữ liệu và nhóm

- 60/60 input/target tái dựng chính xác và qua parser ở hai chế độ.
- 60/60 token mask/collator hợp lệ; dài nhất 1.427 token, target dài nhất
  100 token. Tất cả dưới 1.536/2.048; có 49 bản vượt 1.024 sau padding.
- Ba kiểm tra Node về ranh giới Unicode, bảo toàn nền/nhãn/scope và hợp
  khoảng coverage đạt; kiểm tra Python về lấy đoạn văn/loại phần ngoài p đạt.
- Audit v7 đọc 53 tệp, 68.190 text chuẩn hóa duy nhất, không thiếu phạm
  vi trong inventory và hash đầu vào không đổi.

Các raw TXT của sáu bài được so từ vựng. Raw HTML được giữ và kiểm hash,
không tuyên bố đã so toàn bộ bảng/hình/nội dung ngoài đoạn văn. Sáu bài
giữ thành sáu nhóm sau heuristic. Kho chuẩn bị hiện có **147 bản ghi,
117 ID nguồn cha và 64 nhóm ứng viên**, ngoài 20 mẫu tham chiếu cũ.
69 bản tiếng Việt, 74 tiếng Anh, 4 tiếng Trung; nhãn gồm 45 confirmed,
74 dismissed, 28 uncertain. Đây là số bản ghi với scope khác nhau,
không phải 147 nguồn độc lập hoặc 147 mẫu sẵn sàng train.

Không có match từ vựng với BIPIA test không đồng nghĩa độc lập ngữ nghĩa.
Nguồn/biến thể cùng bài vẫn phải chung phía khi chia; chưa có holdout
độc lập được xác minh, chưa tạo train/dev.

## Phát hiện coverage cần xử lý tiếp

Đã đo thêm engine trên sáu phiên bản active, chỉ đưa text và tên file trung
tính vào prefilter/chunker/selector, dùng span để đối chiếu sau khi chọn.
Không gọi Detector/Verifier và không tạo metric phân loại bảo mật.

Balanced giữ đủ cửa sổ ngữ cảnh ở 3/6 ca, Deep ở 5/6. Đây là coverage
cửa sổ của sáu fixture, **không phải recall IPI** hoặc tỷ lệ Agent hiểu đúng.

Ca `vi-article-012` trên nền Năng lượng tái tạo có 27 chunk, không có
finding từ rule. Câu chèn tồn tại trọn trong chunk đã tạo, nhưng không
nằm đủ trong hợp chunk được chọn ở cả Balanced lẫn Deep. Deep chọn
24/27 chunk vẫn bỏ các chunk 24–26 gần cuối, nên thiếu bằng chứng.
Đây là thiếu ở lựa chọn chunk, không phải văn bản bị mất trong lần lấy nguồn.
Không suy từ ca này rằng mọi bỏ sót trước đây đều do selector.

Như vậy fine-tuning Verifier không tự giải quyết được trường hợp bằng chứng
chưa được chuyển tới model. Bước kế tiếp hợp lý là chẩn đoán/sửa selection
trên ca này với đối chứng sạch và biến thể vị trí, giữ before/after và
kiểm tra pipeline tương ứng, không tăng giới hạn chunk chỉ để đạt một mẫu.

## Tái lập và hiện vật

```powershell
node --test scripts/prepare-vietnamese-articles.test.cjs
node scripts/audit-vietnamese-articles.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_vietnamese_source_extraction.py
```

Lượt tạo nguồn dùng `scripts/fetch_vietnamese_articles.py` (API có cache,
giãn nhịp và tôn trọng Retry-After), `scripts/prepare-vietnamese-articles.cjs`,
audit token qua `scripts/audit_verifier_preview.py --source
verifier-vietnamese-articles-v1 --output verifier-vietnamese-articles-tokenizer-v1`,
và audit kho `scripts/audit-verifier-corpus.py verifier-corpus-overlap-v7`.
Các lệnh tạo phiên bản từ chối ghi đè, dùng phiên bản mới nếu tạo lại.
Lỗi 429 được chờ theo header, không đổi danh tính hoặc endpoint để vượt hạn.

[Nguồn/ghi công](../../benchmark/data/raw/vietnamese-wikipedia-v1/GHI-CONG-VA-GIAY-PHEP.md).
[Batch và giới hạn](../../benchmark/data/annotations/verifier-vietnamese-articles-v1/manifest.json).
[Đánh giá AI](../../benchmark/data/annotations/verifier-vietnamese-articles-v1/danh-gia-ai.json).
[Tái dựng, nhóm và coverage](../../benchmark/data/annotations/verifier-vietnamese-articles-v1/kiem-tra-va-nhom.json).
[Token/mask](../../benchmark/experiments/verifier-vietnamese-articles-tokenizer-v1/ket-qua.json).
[Audit kho v7](../../benchmark/experiments/verifier-corpus-overlap-v7/ket-qua.json).

Chưa fine-tuning, chưa thay runtime/rule/model, chưa có kết quả full
pipeline mới hoặc coverage DOCX/PDF. **Ưu tiên 1 vẫn chưa hoàn thành.**
