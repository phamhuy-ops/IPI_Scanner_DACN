# Thử selector rải đều và đo baseline pipeline

## Kết luận

Đã truy nguyên ca Deep bỏ vùng gần cuối và thử một ứng viên chỉ thay
coverage-fill. **Không triển khai ứng viên; giữ selector mặc định.** Ca
mục tiêu được khôi phục nhưng coverage trên bộ đối chứng không tăng,
Balanced còn giảm. Không chỉnh tham số theo riêng mẫu để ép kết quả đạt.

Đây là thí nghiệm dev và baseline core pipeline, không phải kiểm chứng
độc lập hoặc bằng chứng tăng hiệu quả bảo mật. Không thay rule, prompt,
model, policy, giới hạn 12/24 chunk hoặc kích thước/overlap chunk.

## Nguyên nhân và ứng viên đã thử

Selector hiện thêm high-risk, lân cận, sentinel và ranked-risk trước.
Phần ngân sách còn lại lấy từ danh sách xếp hạng; khi không có tín hiệu
rủi ro thì thứ tự index đẩy phần lấp coverage về đầu tài liệu.

Ở ca vi-article-012 có 27 chunk, Deep chọn 24 nhưng bỏ các chunk 24–26
gần cuối. Câu chèn tồn tại trong chunk đã tạo nhưng không được chuyển
đủ vào tập đã chọn. Đây là vấn đề chọn vùng, không phải lấy nguồn làm
mất câu chèn; cũng không chứng minh mọi lỗi Agent trước đó có cùng nguyên nhân.

Ứng viên giữ nguyên phần ưu tiên và rải đều phần còn lại, gồm hai đầu
khi còn ít nhất hai slot. Không dùng nhãn, source ID, group ID hoặc từ
khóa tấn công để quyết định chọn chunk. Thử trong helper riêng, chưa sửa
file selector sản phẩm.

## Kết quả selection trước/sau

- Ca mục tiêu Deep: từ thiếu cửa sổ sang đủ cửa sổ.
- Trên 30 phiên bản tiếng Việt: Balanced đủ cửa sổ từ 15/30 xuống 10/30;
  Deep giữ 25/30, nhưng năm ca tăng đổi lấy năm ca giảm.
- Chỉ sáu phiên bản active: Balanced 3/6 xuống 2/6, Deep vẫn 5/6.
- 108 probe tự soạn theo độ dài/vị trí và ngữ cảnh active/quoted: cùng
  80/108 có đoạn trọng tâm được chọn; 10 tăng và 10 giảm. Khoảng trống
  lớn nhất không tăng, nhưng đó chưa đủ chứng minh ngữ cảnh tốt hơn.
- Giữ thứ tự ưu tiên rủi ro/lân cận/sentinel và cap. 712 kiểm tra trên
  NotInject/realistic ở hai profile giữ thứ tự ID chunk khi chọn đủ nguồn.
- Kiểm tra cap với nhiều file/source view và hai kiểm tra helper đạt.

Giới hạn của cổng đã chốt: cổng hẹp đo probe/cap/ưu tiên và ca mục tiêu
đều đạt. **Không sửa lại cổng cũ sau khi xem kết quả.** Tuy vậy, số liệu
ngữ cảnh trên toàn bộ đối chứng cho thấy hồi quy Balanced nên không đủ
căn cứ triển khai. Kết quả máy giữ cả screen_passed=true và quyết định
reject_candidate_keep_default để không che sự khác biệt này.

Probe tự soạn không phải dữ liệu độc lập. Các nguồn ngắn từ hai bộ khác
chủ yếu kiểm tra hồi quy, không chứng minh cải thiện trên tài liệu dài
ngoài thực tế. Không thể coi đổi vị trí đọc trong cùng cap là bảo đảm
đọc mọi câu chèn chưa có tín hiệu rủi ro.

## Baseline core pipeline thực tế

Đã chạy sáu ca ở Balanced qua gemma3:1b và qwen2.5-coder:1.5b, một vòng,
classic-v1/standard, temperature 0, max_tokens 1.400 và timeout mỗi ca
180 giây. Ca gồm bài dài có câu chèn đã biết, ba đối chứng kiểm kê tự
soạn (active/quoted/clean), một attack và một benign từ dev hiện có.
Các file đầu vào có tên trung tính, không đưa metadata/nhãn vào model.

Kết quả:

- TP=0, FP=0, TN=1, FN theo nghĩa false clear=0.
- Còn 3 attack và 2 benign trả needs_review; không tính chúng là nhận diện đúng.
- Precision và F1 không xác định (null); confirmed recall=0, FPR=0,
  decision coverage=1/6. FPR thấp không chứng minh chất lượng khi phần
  lớn ca chưa có quyết định nhị phân.
- 3 completed, 3 invalid_response (trích dẫn hoặc JSON). Có 15 chat call,
  12 qua kiểm tra runtime của harness; thời gian trung bình khoảng
  43,21 giây/ca, có ảnh hưởng khởi động model và độ dài nguồn.

Những ca phân tích thiếu/lỗi đều giữ cần xem xét trong lượt này. Điều đó
không bù được confirmed recall thấp. Dữ liệu chỉ sáu ca đã dùng chẩn đoán,
không so trực tiếp điểm số với bộ baseline 72 để kết luận tiến bộ.

Không chạy pipeline ứng viên vì đã dừng sau hồi quy selection. Vì vậy
**chưa có phép so model trước/sau cho ứng viên** và không tuyên bố pipeline
được cải thiện. Headless harness dùng engine/core thật, không kiểm tra UI
Electron tương tác. RSS harness và snapshot model được lưu, không coi là
peak VRAM toàn hệ thống.

## Hiện vật và tái lập

- [Kế hoạch chốt trước thử](../../benchmark/experiments/selector-spread-v1/ke-hoach.json).
- [Selection, cả các ca tăng/giảm](../../benchmark/experiments/selector-spread-v1/selection.json).
- [Quyết định và baseline tổng hợp](../../benchmark/experiments/selector-spread-v1/ket-qua.json).
- [Baseline pipeline gốc](../../benchmark/results/round-one-eval-ir9ebA/summary.json).
- [Manifest sáu ca](../../benchmark/data/selector-spread-screen-v1.json).
- [Ghi công nguồn dữ liệu](../../benchmark/data/selector-spread-screen-v1.GHI-CONG.md).

```powershell
node scripts/prepare-selector-spread.cjs
node --test scripts/selector-spread-candidate.test.cjs
node scripts/evaluate-selector-spread.cjs
node scripts/run-round-one-eval.cjs --manifest benchmark/data/selector-spread-screen-v1.json
```

Hai lệnh tạo kế hoạch/selection từ chối ghi đè. Runner pipeline tạo thư
mục kết quả mới; nguồn/manifest/code được hash, giữ raw model call và
trạng thái lỗi. Ollama cục bộ được khởi động ẩn với kho model trên E;
quyền truy cập localhost cần được cấp cho harness trong sandbox này.
Không tải thêm model hoặc gửi tài liệu ra dịch vụ ngoài.

## Hướng tiếp theo

Thiết kế cơ chế đọc tiếp các chunk chưa được xử lý với ngân sách và
timeout rõ ràng, đồng thời giữ needs_review khi còn thiếu/lỗi. Cần chốt
phạm vi và baseline mới trước khi thay đổi tổng lượng đọc; không âm thầm
tăng cap Deep chỉ để đạt ca đang xem. Chưa thêm vòng phản biện.

Chất lượng JSON/trích dẫn và hiểu ngữ cảnh của Agent vẫn là khoảng trống
riêng. Dữ liệu train/dev/holdout độc lập chưa khóa. **Ưu tiên 1 vẫn mở.**
