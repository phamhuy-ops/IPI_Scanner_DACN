# Chuẩn hóa nhãn người nhận chỉ dẫn cho Verifier

Ngày 2026-10-25. Hoàn tất bước dữ liệu theo lỗi đã đo; không sửa nhận diện
hoặc cấu hình mặc định, không huấn luyện model.

## Đã chuẩn hóa gì

Từ tám ca chẩn đoán đã khóa, giữ nguyên text và chuẩn hóa bảy ca: hai
confirmed, năm dismissed. Bốn tiếng Việt, ba tiếng Anh. cc-02 bị cắt đầu
giữa câu được cách ly, không sửa text, không tự chuyển thành uncertain và
không tạo target huấn luyện cho nó. Nhãn chỉ áp dụng phần nguồn hiển thị,
không biến thành nhãn an toàn toàn bài Wikipedia.

Các trường cần học được ghi rõ: stance, addressee, framing, deviation,
hasDirective, span chỉ dẫn và span ngữ cảnh:

- Chỉ dẫn trực tiếp cho AI thay bản tóm tắt: confirmed/assistant/active/
  answer_manipulation, hasDirective=true.
- Cùng chỉ dẫn nằm trong ví dụ đào tạo có bao khung không thực thi:
  dismissed/assistant/quoted_example/answer_manipulation, hasDirective=true.
- Yêu cầu nhân viên ghi trạng thái trên phiếu giấy: dismissed/human/active/
  none, hasDirective=true. Có câu mệnh lệnh không đồng nghĩa có IPI.
- Đoạn mô tả nguồn năng lượng: dismissed/none/descriptive/none,
  hasDirective=false, vẫn có span ngữ cảnh.

Sáu ca active/quoted/human được đối chiếu với mẫu cũ có phiếu người dùng
duyệt đúng hash. Ví dụ vf-003, vf-004, V3-010 và V3-014 xác lập quy ước công
việc cho người. Ca mô tả không có mẫu cũ trùng toàn bộ bộ trường trong hai
batch đối chiếu; nhãn đó là đánh giá AI riêng, không giả kế thừa duyệt cũ.

Toàn bộ quyết định mới ghi **Codex (AI)**; không thay phiếu cũ hoặc chuyển
xác nhận người dùng sang câu chữ mới. Chúng đã lộ qua chẩn đoán dev, nên
usage là development_regression_previously_evaluated, split=null,
training_eligible=false. Bản xem trước không phải tập train đã phát hành.

## Parser, bằng chứng và token

Có 14 biểu diễn cho bảy ca ở hai setup được ghi rõ: nghi vấn toàn nguồn và
không có nghi vấn. Dùng hợp đồng referenced/compact của kế hoạch Verifier,
không phải tự thay classic-v1 mặc định của ứng dụng.

- 14/14 qua parser thật và tái dựng đúng target/payload từ text.
- Nhãn, group, parent ID và đáp án không được thêm vào model input.
- 14/14 qua token/mask/collator offline, đúng tokenizer revision đã chốt.
- Tối đa 1.225 token; target tối đa 98 token. Ba bản vượt 1.024; không bản
  nào vượt 1.536 hoặc 2.048. Không cắt để ép vừa ngân sách 1.024.
- Python/cache chạy trên E; không tải weights, không forward/backward,
  không cập nhật adapter/checkpoint.

Tái dựng nguồn/phiếu cũ không thay đổi. Bài năng lượng được đối chiếu đúng
page 13199, revision 75640899, CC BY-SA 4.0 và hash snapshot đã lưu. Quyền
từng nội dung bài chưa được kiểm chứng độc lập; giữ ghi công và giới hạn cũ.

## Nhóm và trùng lặp

Sáu biến thể Anh/Việt được gom cùng một family; hai parent ID ngôn ngữ
không có nghĩa hai nhóm độc lập. Đoạn Wikipedia nằm chung nhóm với năm
biến thể bài năng lượng đã có. Không chia active/quoted/human qua train/dev.

Audit v8 quét 57 file, 68.201 văn bản chuẩn hóa duy nhất. Bảng tham chiếu có
174 bản ghi, gồm 20 legacy và 154 ngoài legacy; 77 nhóm tổng, trong đó 65
nhóm ngoài legacy. So với v7, thêm bảy bản ghi nhưng chỉ thêm một nhóm;
toàn bộ quan hệ nhóm cũ được giữ. Nhóm lớn nhất có 18 bản ghi; các thành
phần tiếp theo có 9/6/6 bản ghi. Giữ ranh giới bảo thủ khi chuẩn bị split.

Không thiếu phạm vi đầu vào đã liệt kê, hash không đổi trong lúc audit;
không tìm thấy trùng từ vựng với BIPIA test theo heuristic hiện tại. Đây
không phải chứng minh độc lập ngữ nghĩa: không embedding, shared 12-token
có thể là boilerplate. Chỉ đối chiếu text, không dùng gold test để sửa model.
Các ca mới được đánh dấu đã lộ dev từ manifest chẩn đoán, không thành holdout.

## Tiến độ và bước tiếp

Đã hoàn tất **đối chiếu nhãn cũ → chuẩn hóa span/ngữ cảnh → kiểm tra parser,
token/mask/collator → rà nhóm/trùng toàn kho** cho batch này. Hai kiểm thử
Node và bốn kiểm thử Python liên quan đạt. Runtime/luồng chính không đổi.

**Ưu tiên 1 vẫn chưa hoàn thành.** Mốc hiển thị tiến độ trong ứng dụng vẫn
đã triển khai; chưa có bằng chứng tăng chất lượng nhận diện từ việc chuẩn
hóa dữ liệu. Chưa có split/holdout độc lập và chưa đủ điều kiện train theo
kế hoạch hiện tại (mục tiêu pilot 300 bản ghi/ít nhất 100 nhóm).

Bước tiếp là bổ sung nguồn ngoài cho human/assistant/uncertain còn thiếu,
kèm đối chứng tương đương và nhóm trước khi chốt split. Không tăng số nguồn
độc lập bằng cách nhân biến thể của cùng câu hoặc đưa bảy ca dev này vào train
chỉ để sửa đúng các ví dụ vừa thấy.

## Tái lập và nơi tra cứu

```powershell
node --test scripts/prepare-verifier-addressee.test.cjs
node scripts/prepare-verifier-addressee.cjs
node scripts/audit-verifier-addressee.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_preview.py --source verifier-addressee-context-v1 --output verifier-addressee-tokenizer-v1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_corpus.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit-verifier-corpus.py verifier-corpus-overlap-v8
```

Lệnh tạo/audit dừng nếu phiên bản đầu ra đã tồn tại; không ghi đè baseline.

- [Kế hoạch trước xử lý](../planning/chuan-hoa-nhan-nguoi-nhan-verifier.md).
- [Bộ nhãn mới](../../benchmark/data/annotations/verifier-addressee-context-v1/mau-cho-duyet.jsonl).
- [Đối chiếu với quy ước đã duyệt](../../benchmark/data/annotations/verifier-addressee-context-v1/doi-chieu-nhan-cu.json).
- [Tổng hợp kết quả](../../benchmark/experiments/verifier-addressee-context-v1/ket-qua.json).
- [Token/mask/collator](../../benchmark/experiments/verifier-addressee-tokenizer-v1/ket-qua.json).
- [Audit v8](../../benchmark/experiments/verifier-corpus-overlap-v8/ket-qua.json).
