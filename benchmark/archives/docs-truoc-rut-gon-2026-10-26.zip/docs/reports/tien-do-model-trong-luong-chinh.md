# Tiến độ model trong luồng chính

Ngày 2026-10-25. **Đã tích hợp vào pipeline và panel mặc định**, không còn
chỉ nằm trong bộ điều phối thí nghiệm.

## Thay đổi đã áp dụng

Ứng dụng hiển thị tổng số đoạn trích xuất, số được chọn, số Detector xử lý
thành công, số Verifier xử lý thành công, số hoàn tất cả hai và phần còn lại.
Một batch chỉ được ghi sau parser và applyBatch thành công. Khi batch sau lỗi,
batch trước vẫn được giữ. Tiến độ lưu bằng ID nguồn; alias chỉ dùng cho model.
Snapshot sự kiện được tách riêng để không thay đổi ngược khi batch sau chạy.

`metadata.coverage.aiReviewedChunks` vẫn tương thích với scanner cũ, mang
nghĩa số được chọn. Luồng chính có `reviewProgress` riêng. Tổng chưa biết
hiển thị chưa xác định; kết quả cũ không có ledger không được suy thành đã
đọc hết. Reset bắt đầu lượt mới từ tiến độ rỗng do pipeline khởi tạo mới.

Khi chưa hoàn tất, kết luận và log có thêm lý do nêu số thành công từng vai
trò. Nhãn tiếng Việt là **Cần xem xét**. Policy confirmed giữ nguyên: có bằng
chứng được cả hai xác nhận vẫn có thể trả ipi_detected kèm lỗi/phần chưa đọc.
Hoàn tất xử lý chỉ có nghĩa qua kiểm tra giao thức và citation, không chứng
minh model hiểu đúng ngữ cảnh hoặc bảo đảm an toàn.

Không thay selector, rule, prompt, schema, batching, số vòng hoặc model mặc
định. Chưa bật đọc bổ sung và phản biện. Báo cáo này không tuyên bố giảm lỗi
nhận diện IPI; phần cải thiện là minh bạch tiến độ và lý do kết luận.

## Kiểm tra

Baseline trước sửa: 31 kiểm thử pipeline/panel đạt, code trước sửa lưu tại
`benchmark/experiments/production-review-progress-v1/baseline-code`.
Sau sửa: 38 kiểm thử pipeline/panel đạt; toàn Vitest 221/221, 16 file.
Typecheck, lint và build đạt. Build còn cảnh báo tooling cũ về customResolver
và freeze, không sửa ngoài phạm vi.

Các ca mới kiểm tra Detector lỗi ở batch sau, Verifier lỗi/timeout ở batch
sau, phần còn lại, snapshot không bị cập nhật ngược, tổng chưa biết và UI
của kết quả cũ. Test pipeline hiện có vẫn kiểm tra sạch, attack, bất đồng,
extraction lỗi, thiếu coverage và timeout.

Đã chạy thêm scanner → client/parser → pipeline thật với endpoint giả lập,
rồi thao tác panel React thật trong trình duyệt cục bộ:

- Mẫu sạch và attack đồng thuận: mỗi ca hoàn tất 1/1 đoạn, kết luận theo policy.
- Detector lỗi: 30 đoạn trích xuất, chọn 12, Detector 3/12, Verifier 0/12,
  cả hai 0/30, còn 30 đoạn chưa hoàn tất; trả Cần xem xét.
- Verifier lỗi: 30 đoạn trích xuất, chọn 12, Detector 12/12, Verifier 8/12,
  cả hai 8/30, còn 22 đoạn chưa hoàn tất; trả Cần xem xét.

Ảnh panel có ghi rõ endpoint giả lập, không dùng làm số đo nhận diện.
Raw: `benchmark/results/production-progress-xp8AuC`.
Preview kiểm tra component thật, chưa phải xác minh Electron IPC/native picker.

Smoke hai model thật trên attack/clean dev cũ: attack vẫn needs_review,
clean vẫn not_detected. Cả hai đều có ledger 1/1 cho mỗi vai trò; mỗi ca hai
chat request, cả bốn phản hồi qua parser. Raw lần lượt:
`benchmark/results/round-one-eval-fIX4zi` và
`benchmark/results/round-one-eval-C9SEut`.
Thời gian khoảng 18,82 và 14,37 giây. Baseline lịch sử cùng đầu vào tại
`benchmark/results/round-one-eval-ir9ebA` có cùng kết luận nhưng agent/client
đã có thay đổi opt-in từ thí nghiệm trước; không phải phép so tốc độ được
kiểm soát hoặc bằng chứng tăng chất lượng. Không chạy lại toàn 72 ca vì
không đổi hành vi nhận diện và smoke/kiểm thử chưa chỉ ra hồi quy cần mở rộng.

## Tiến độ Ưu tiên 1

- **A — Chính sách và lỗi:** đã triển khai; kiểm tra cục bộ bảo vệ kết luận
  sạch khi thiếu dữ liệu/lỗi và giữ bằng chứng đã confirmed. Chưa coi đó là
  bảo đảm ngoài các ca đã kiểm tra.
- **B — Chất lượng Agent:** chưa đạt. Baseline 72 mẫu vẫn là phép đo đầy đủ
  gần nhất; recall confirmed 13,64%, coverage quyết định nhị phân 39,34%.
  Các ca mới cho thấy hai model có thể cùng báo nhầm công việc cho người.
- **C — Độ bao phủ:** đã đưa phân biệt số chọn/số xử lý thành công và phần
  còn lại vào UI chính. Việc đọc đủ tài liệu dài, đa file/định dạng với model
  thật và toàn luồng Electron/UI vẫn chưa hoàn tất.
- **D — Điều kiện chốt:** chưa có holdout độc lập đạt sau khóa cấu hình.

**Ưu tiên 1 chưa hoàn thành.** Không đặt phần trăm tùy ý và không thay kết
quả baseline cũ bằng số kiểm thử. Bước tiếp là đối chiếu/bổ sung nhãn người
nhận chỉ dẫn cho Verifier theo lỗi human/assistant đã đo, giữ đối chứng và
nhóm độc lập trước khi cân nhắc thử học một model.

## Tái lập

```powershell
npm test
npm run lint
npm run build
node scripts/check-production-review-progress.cjs
node scripts/check-production-review-progress.cjs --serve
node scripts/run-round-one-eval.cjs --manifest benchmark/data/selector-spread-screen-v1.json --case document-5
node scripts/run-round-one-eval.cjs --manifest benchmark/data/selector-spread-screen-v1.json --case document-6
```

[Kế hoạch trước sửa](../planning/dua-tien-do-model-vao-luong-chinh.md).
[Kết quả máy](../../benchmark/experiments/production-review-progress-v1/ket-qua.json).
[Ảnh kiểm tra panel](../../benchmark/experiments/production-review-progress-v1/giao-dien-verifier-loi.png).
