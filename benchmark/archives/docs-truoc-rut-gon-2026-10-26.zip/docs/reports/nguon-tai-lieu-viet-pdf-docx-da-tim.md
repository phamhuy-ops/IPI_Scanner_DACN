# Nguồn tài liệu Việt PDF/DOCX đã tìm

Ngày 2026-10-25. Đã tìm nguồn chính thức và tải được bốn tài liệu gốc:
hai PDF, hai DOCX. Chỉ đưa vào vùng incoming để kiểm tra kỹ thuật, **chưa
gán nhãn sạch, chưa nhập train/dev/holdout hoặc phát hành dataset**.

## Bốn nguồn đã tải và trích xuất chữ

1. **Tài liệu hướng dẫn cổng thông tin trường học — PDF.**
   [Nguồn admintruong.hanoi.edu.vn](https://admintruong.hanoi.edu.vn/Tailieuhuongdancongthongtin.pdf).
   Trích xuất được 68.317 đơn vị UTF-16. Hữu ích cho các câu hướng dẫn người
   dùng đăng nhập, quản trị nội dung và thao tác hệ thống. Domain là nơi
   công bố tài liệu, không tự suy tác giả hoặc quyền sở hữu nội dung.

2. **Tài liệu hướng dẫn sử dụng OMS — PDF.**
   [Nguồn isi.vast.vn của Viện Hàn lâm KH&CN Việt Nam](https://isi.vast.vn/OMS/upload/default/Tailieuhuongdan.pdf).
   Trích xuất được 11.456 đơn vị UTF-16. Có ngữ cảnh hệ thống quản lý trực
   tuyến và quy trình người dùng, phù hợp kiểm tra lệnh dành cho con người.

3. **Hướng dẫn lĩnh vực tổ chức phi chính phủ và văn thư lưu trữ — DOCX.**
   [Trang công bố của Sở Nội vụ tỉnh Phú Thọ](https://sonoivu.phutho.gov.vn/Chuyen-muc-tin/Chi-tiet-tin/tabid/92/title/4835/ctitle/3/language/vi-VN/Default.aspx).
   Đã tải đúng liên kết DOCX đính kèm; không đổi từ PDF sang Word. Trích xuất
   được 36.605 đơn vị UTF-16. Nhiều bước công việc cho công chức, viên chức
   và văn thư, hữu ích làm ứng viên đối chứng ngữ cảnh con người.

4. **Mẫu xác nhận sinh viên đang học tại trường — DOCX.**
   [Trang biểu mẫu của Đại học Sư phạm Hà Nội, Trường Toán học và CNTT](https://smcs.hnue.edu.vn/bieu-mau-van-ban/bieu-mau-danh-cho-sinh-vien.html).
   Chọn mẫu dành cho sinh viên các khoa đào tạo. Trích xuất được 1.447 đơn
   vị UTF-16; phần thông tin sinh viên đang là ô trống trong văn bản đã
   xem, không phải hồ sơ cá nhân được điền. Vẫn cần rà cả file, ảnh và
   metadata trước phê duyệt về dữ liệu riêng.

Ba tài liệu có text trích xuất dài trên 8.000 đơn vị UTF-16, nhưng việc
trích được chữ chưa chứng minh thứ tự đọc/bảng/ảnh đúng hoặc nội dung sạch
IPI. Chưa có đánh giá model hay nhãn bảo mật cho bốn tài liệu.

## Trạng thái và nơi lưu

- Ba file đầu: `benchmark/data/incoming/public-vi-documents/nguon-vi-v1`.
- Biểu mẫu HNUE: `benchmark/data/incoming/public-vi-documents/nguon-vi-bo-sung-v1`.
- Mỗi đợt có manifest ghi trang gốc, URL tải/final URL, SHA-256, loại file,
  số byte, kết quả extraction và hash text. Giữ snapshot HTML các trang
  liên kết để kiểm chứng file thực sự do trang nguồn công bố.
- PDF được kiểm tra magic `%PDF-`; DOCX có chữ ký ZIP và đã được extractor
  DOCX của dự án đọc thành công. Không thực thi lệnh hoặc macro tài liệu.
- Không cần cài thêm phần mềm hoặc người dùng tải thủ công. Tổng bốn file
  khoảng 11,1 MB, giữ trên C trong vùng dữ liệu của dự án theo cấu hình hiện có.

Hai liên kết PDF/DOCX tại trang công văn giáo dục của xã Sơn Tây Thượng
trả HTTP 404 khi tải trực tiếp. Giữ lịch sử thất bại trong manifest và không
tính chúng là tài liệu đã có. Bản PDF và DOCX của cùng công văn cũng chỉ là
một parent nếu tải được, không phải hai nguồn độc lập.

## Nguồn uy tín và quyền sử dụng là hai việc riêng

Đã xác minh tài liệu được đăng ở các domain cơ quan/giáo dục nêu trên và
tải được file thật. **Chưa tìm thấy hoặc xác minh điều khoản cấp quyền dùng
lại cho huấn luyện/tái phân phối dataset trên từng tài liệu.** Không đổi
việc tải công khai thành license mở. Trạng thái reuse_permission vẫn là
not_verified; training_eligible=false, final_split=null và privacy review
còn pending.

Nguồn này phù hợp đưa vào hàng chờ kiểm tra extraction và phạm vi. Trước
khi dùng làm dữ liệu huấn luyện hoặc phát hành lại cần làm rõ quyền sử dụng,
rà nội dung/metadata, trùng lặp, nhóm và phạm vi nhãn. Không tự gửi thư xin
quyền sử dụng hoặc liên hệ bên ngoài khi chưa được người dùng yêu cầu.

## Phần tiếp theo

Rà chất lượng text và riêng tư/quyền dùng; sau đó mới chọn phạm vi nhãn và
thử extraction/chunking/pipeline có đối chứng. Chưa tăng số bản ghi đã duyệt:
kho annotation vẫn 178 bản/71 nhóm, bốn tài liệu mới chỉ là incoming.
**Ưu tiên 1 vẫn chưa hoàn thành**, chưa có cải thiện nhận diện được chứng minh.

Các kết quả kiểm kê cũ ghi 0 PDF/DOCX là snapshot trước đợt tải này, không
ghi đè lịch sử đó. Hiện vùng incoming đã có hai PDF và hai DOCX thật.

## Tái lập

```powershell
node scripts/fetch-public-vi-documents.cjs
node scripts/fetch-hnue-document.cjs
```

Script từ chối ghi đè đợt đã có. Link nguồn có thể thay đổi; hash và HTML
snapshot là bằng chứng của lượt tải này, không bảo đảm URL luôn còn hoạt động.
