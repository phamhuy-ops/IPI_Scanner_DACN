# Rà tài liệu Việt gốc và độ bao phủ

Ngày 2026-10-26. Hoàn tất lượt rà kỹ thuật trên bốn file incoming bằng
extractor, prefilter và selector hiện tại. Chưa gọi model, chưa sửa runtime,
chưa train và chưa hoàn thành Ưu tiên 1.

## Kết quả có thể tái lập

Chạy `node scripts/audit-public-vi-native.cjs`. Script từ chối ghi đè kết quả
v1, kiểm tra SHA-256 của file gốc trước khi đọc, lưu hash mã và đầu vào tại
`benchmark/experiments/public-vi-native-audit-v1/ket-qua.json`.

Cả bốn file khớp hash nguồn và text snapshot trước đó; không thấy ký tự thay
thế U+FFFD hoặc ký tự điều khiển bất thường theo phép kiểm tra của script.
Điều này không chứng minh đúng thứ tự đọc, đủ chữ trong ảnh hoặc đủ ngữ cảnh.

- Cổng trường: 92 chunk; Balanced chọn 12, Deep chọn 24.
- OMS: 15 chunk; Balanced chọn 12, Deep chọn đủ 15.
- Văn thư Phú Thọ: 52 chunk; Balanced chọn 12, Deep chọn 24.
- Biểu mẫu HNUE: 2 chunk; cả hai chế độ chọn đủ 2.
- Đưa cả bốn vào cùng lượt: 161 chunk; Balanced chọn 12, Deep chọn 24.

Ngân sách selection dùng chung cả lượt quét, không phải mỗi file được thêm
24 chunk. Trường `aiReviewedChunks` trong kết quả scanner này là số được
chọn theo giao diện cũ, **không phải số model đã đọc thành công**. Lượt rà
này chưa gọi model nào. Không tính precision/recall vì chưa có nhãn vàng.
Không có finding rule trên bốn file; không suy ra tài liệu sạch từ điều đó.

## Riêng tư và chất lượng nội dung

Regex gắn cờ 3 email/42 lần nhắc thông tin đăng nhập trong tài liệu cổng
trường, 2 email/18 lần nhắc trong OMS. Đọc mẫu đầu/giữa/cuối và một số dòng
gắn cờ cho thấy có hướng dẫn đăng nhập, đổi mật khẩu dành cho người dùng;
đây chưa phải kiểm tra toàn bộ thông tin nhạy cảm hoặc toàn bộ tài liệu.
Không chép giá trị liên hệ hay thông tin đăng nhập vào báo cáo.

Năm chuỗi giống số điện thoại trong văn thư thực ra là số tiền ở các dòng
quy định về quỹ khi đối chiếu text. Đây là false positive của regex rà riêng
tư, không phải kết quả của Agent. Không tự xóa số trong tài liệu nguồn.

DOCX văn thư chứa 56 media entry; không thấy phần nhúng, macro, comment
hoặc tag theo dõi sửa trong các vị trí được kiểm tra. HNUE có hai bảng,
không có media entry; text biểu mẫu được xem đang có các ô điền trống.
Cả hai DOCX có core/app metadata cần rà tiếp. Không có macro không đồng
nghĩa không có dữ liệu riêng tư; ảnh và các quan hệ liên kết chưa được
kiểm tra nội dung đầy đủ.

PDF cổng trường có trang đầu chỉ một ký tự và trang cuối không có chữ theo
parser; cần xem ảnh trang để phân biệt trang bìa/trắng với nội dung ảnh bị
bỏ qua. PDF OMS cũng có nhiều trang ít chữ. Chưa duyệt trực quan nên chưa
chốt độ đầy đủ extraction và chưa dùng bản text làm chân lý về nội dung PDF.

## Quyền dùng và bước kế tiếp

Giữ trạng thái quyền dùng `not_verified` từ manifest; lượt này không tìm
thêm điều khoản hoặc đưa ra kết luận pháp lý. Không biến việc tải công khai
thành quyền train/tái phân phối. Không liên hệ bên ngoài. Tất cả file giữ
`training_eligible=false`, `final_split=null`, `security_label=null`.

Bước tiếp: kiểm tra trực quan các trang ít chữ, ảnh chụp giao diện và
metadata/liên kết; chọn cửa sổ đối chứng có thể rà được đầy đủ. Các bản
chèn IPI phải được lưu riêng, có span và cùng nhóm với tài liệu nền; chưa
tạo bản biến thể trước khi chốt phạm vi nguồn. Nếu quyền dùng chưa rõ,
có thể tiếp tục đối chứng bằng tài liệu tự soạn, ghi rõ đây là dữ liệu
tổng hợp và không thay thế kiểm chứng trên tài liệu thực.

Trước đánh giá model cần khóa cấu hình và nhãn, ghi riêng extraction,
selection, số đoạn mỗi model xử lý thành công, lỗi, độ trễ và quyết định.
Những tài liệu đã được xem để thiết kế không tự coi là holdout chưa chạm.
Chưa có bằng chứng cải thiện chất lượng nhận diện Agent từ lượt rà này.
