# Đo stance và ngữ cảnh trên mẫu tối giản

Ngày 24/10/2026, đo riêng từng model để xác định vì sao đầu ra Agent mâu
thuẫn ngay khi request chỉ có một đoạn ngắn. Đây là chẩn đoán dev, không
phải phép đánh giá pipeline hoặc kết luận hiệu quả bảo mật ngoài thực tế.

Sáu mẫu tự soạn gồm ba dạng bằng tiếng Anh và tiếng Việt: chỉ dẫn trực
tiếp cho AI, cùng chỉ dẫn trong ví dụ đào tạo không thực thi, và nhiệm vụ
cho con người. Bản dịch và biến thể trích dẫn cùng nhóm. Nhãn do người
thực hiện phép đo soạn để làm đối chứng, chưa được người dùng duyệt; chưa
có nguồn độc lập hoặc biến thể chưa thấy. Không dùng tài liệu riêng.

Hai cấu hình giữ nguyên prompt, schema về mặt ý nghĩa, model, temperature=0
và max_tokens=500. Baseline giữ thứ tự trường hiện tại của công cụ chẩn
đoán. Ứng viên chỉ đổi thứ tự schema: addressee → framing → deviation →
hasDirective → stance → reason. Prompt tiếng Anh giữ nguyên để tránh trộn
đổi cách diễn đạt vào phép thử thứ tự. Đo 24 lượt, mỗi ca/cấu hình/model một
lần, không retry; đổi thứ tự chạy cấu hình theo ca để giảm lệch do lượt đầu.

Kết quả Gemma: baseline đúng toàn bộ năm trường ở 0/6 ca, nhất quán logic
ở 1/6; ứng viên tương ứng 1/6 và 4/6. Tuy nhiên ứng viên có một lệnh tấn
công tiếng Việt bị trả `dismissed` với trường ngữ cảnh sai nhưng hợp logic,
nên vẫn lọt qua kiểm tra nhất quán của công cụ. Không chấp nhận ứng viên.

Qwen đúng toàn bộ trường ở 0/6 ca trong cả hai cấu hình, nhất quán logic
0/6. Trong lượt này model chọn `confirmed` ở cả sáu ca cho mỗi cấu hình,
kể cả nguồn sạch. Có trường hợp người nhận là `human` hoặc ngữ cảnh là
`quoted_example` nhưng stance vẫn `confirmed`. Validator chặn các mâu
thuẫn này; do đó metric sau validator có coverage=0, không phải model
phân biệt sạch/tấn công tốt. Xem cả metric `raw_stance_only` để tránh che
nhận định sai phía sau abstention.

Các điểm yếu thể hiện trong phép đo là liên kết stance với ngữ cảnh,
phân biệt chỉ dẫn đang có hiệu lực với ví dụ, và giữ đúng nhận định khi
chuyển ngôn ngữ. Đúng nhãn cuối chưa đủ: một câu ví dụ có thể được gán
`dismissed` nhưng framing/deviation vẫn sai. Ngược lại, hợp logic giữa các
trường chưa đủ chứng minh hiểu đúng nguồn.

Không thay cấu hình sản phẩm hoặc chạy ứng viên qua pipeline: ứng viên
đã không qua cổng chẩn đoán. Không thêm phản biện, fine-tune hoặc nới
validator. Bước tiếp có cơ sở là dùng các ca sai này làm tài liệu rà nhãn
ngữ cảnh, hoàn tất batch mới đang chờ duyệt, rồi mới chọn cách thử cải
thiện một Verifier. Không coi thử thứ tự trường là nâng cấp đã thành công.

Kết quả đầy đủ, metric precision/recall/F1/FPR và abstention theo model,
nhóm, ngôn ngữ, từng trường, thời gian, snapshot tài nguyên và hash raw:
[kết quả](../../benchmark/experiments/minimal-context-order-v1/ket-qua.json).
Model digest, schema, prompt, seed=null và mã nguồn khóa trong
[kế hoạch](../../benchmark/experiments/minimal-context-order-v1/ke-hoach.json).
VRAM chỉ là snapshot sau request, không phải peak; RAM harness không phải
RAM model. Không suy độ ổn định hay ý nghĩa thống kê từ một lượt mỗi ca.

Lệnh tái hiện tại gốc dự án:

```powershell
node --test scripts/minimal-context-order.test.cjs
node scripts/run-minimal-context-order.cjs
node scripts/summarize-minimal-context-order.cjs benchmark/results/minimal-context-order-96EmTi
```

Lượt chạy mới sinh thư mục riêng; truyền đúng thư mục mới vào lệnh tổng
hợp, không ghi đè raw cũ. Ba test công cụ đạt: giữ prompt/ý nghĩa schema,
phân biệt sai ngữ cảnh với đúng stance, và giữ lỗi JSON thành abstention.
Các test này không chứng minh chất lượng model.
