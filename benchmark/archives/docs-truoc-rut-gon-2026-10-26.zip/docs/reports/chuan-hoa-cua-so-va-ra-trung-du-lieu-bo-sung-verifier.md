# Chuẩn hóa bằng chứng, cửa sổ và rà trùng dữ liệu bổ sung Verifier

## Kết quả của lượt này

Đã chuẩn hóa 15 nguồn có nhãn/ngữ cảnh được người dùng đồng ý, trong đó
9 nguồn dài. Giữ nguyên text, nhãn và đoạn chỉ dẫn gốc. Bản chuẩn hóa nằm
riêng, không ghi đè nguồn hoặc baseline 72 mẫu.

- 251 cửa sổ phủ toàn bộ đơn vị UTF-16 của 15 nguồn, không hở giữa các cửa sổ.
- 15 cửa sổ có bằng chứng được ánh xạ nhãn cơ học; 236 cửa sổ còn lại chưa
  có nhãn, không tự gán benign và không xuất làm bài học.
- 30 bản xem trước (hai chế độ mỗi nguồn) tái dựng chính xác và qua parser.
- 30/30 mask hợp lệ với tokenizer thật đã khóa revision, chạy offline.
- Độ dài hội thoại đầy đủ 978–1.851 token: 27 bản vượt 1.024, 8 vượt
  1.536, không bản nào vượt 2.048. Các mốc là thống kê, chưa đổi cấu hình train.

Không tải weights, không train, không chạy model hoặc pipeline mới trong
lượt này. Các con số trên chứng minh kiểm tra cấu trúc dữ liệu, không chứng
minh khả năng phát hiện IPI được cải thiện.

## Bằng chứng và ngữ cảnh được giữ như thế nào

Cửa sổ chia ở ranh giới dòng, tối đa 900 đơn vị UTF-16 để vừa kích thước
chunk hiện tại; chồng một dòng khi có thể. Dòng quá dài bị từ chối, không
cắt giữa câu để ép vừa. Đây là tiện ích chuẩn bị dữ liệu, không thay chunker
hay selector của ứng dụng.

Mỗi bằng chứng giữ offset gốc dạng [start,end), dòng bắt đầu từ 1 và quote
nguyên văn. Offset cửa sổ ánh xạ ngược được chính xác về gốc. Khoảng trắng
ngoài bản được chọn được bỏ có cập nhật tọa độ, không sửa nội dung bên trong.
Cửa sổ được chọn phải chứa trọn dòng bao quanh chỉ dẫn, giữ cả phần giới
thiệu ví dụ trích dẫn và câu “không thực hiện” nếu chúng ở dòng đó.

Chọn cửa sổ có nhãn dùng span đã biết để chuẩn bị dữ liệu; **không phải**
phép đo selector tìm được tấn công trong tài liệu gốc. Header/ID nguồn,
nhãn và nhóm chỉ nằm ở metadata, không thêm vào messages của model. Bản
xem trước chỉ nhận văn bản cửa sổ với tên file/mã tham chiếu trung tính.

Nhãn đã duyệt được giữ nguyên, nhưng ranh giới cửa sổ mới chưa được người
dùng duyệt riêng. Bảo toàn dòng chưa bảo đảm giữ mọi phụ thuộc ngữ nghĩa
ở xa. Đã tạo [phiếu đối chiếu toàn bộ cửa sổ có nhãn](../../benchmark/data/annotations/verifier-gap-normalized-v1/doi-chieu-cua-so.md)
để kiểm tra điều đó trước khi cho phép train.

## Rà trùng và ranh giới nhóm

Audit v3 đã đọc 38 tệp, 66.046 text chuẩn hóa duy nhất trong phạm vi
benchmark/data và fixture được liệt kê, gồm raw JSONL/Parquet/CSV,
processed, split, manifest và các cửa sổ mới. Không thiếu phạm vi trong
inventory và hash các đầu vào không đổi trong lượt chạy.

Không có trùng exact sau chuẩn hóa giữa 15 nguồn mới với 72 nguồn đã duyệt.
So gần trùng dùng trigram Jaccard ≥0,8, đoạn chung 12 token, family và
cầu nối document_group_id như audit trước. Đây là kiểm tra từ vựng, không
phải kiểm tra tương đồng ngữ nghĩa đầy đủ.

Ba family tiếng Việt có đoạn nền lặp chung, nên nối thành một cụm 9 nguồn.
Hai family tiếng Anh giữ thành hai cụm 3 nguồn. Giữ nguyên văn bản và gom
bảo thủ: **5 family đề xuất thành 3 nhóm**, không tách cụm để đẹp tỷ lệ.
Kho có 87 nguồn đã duyệt stance thuộc 45 nhóm ứng viên; 20 nguồn tham
chiếu cũ vẫn nằm riêng ở 12 nhóm reference_only. Chưa chia train/dev.

Không có nhóm match từ vựng với BIPIA test trong lượt này; điều đó không
chứng minh độc lập ngữ nghĩa hoặc provenance. Các nguồn đều đã được dùng
chuẩn bị/chẩn đoán dev, không tự đổi thành holdout. Bộ kiểm chứng độc lập
vẫn chưa được xác minh. Nền tài liệu dài tự soạn lặp theo mục chỉ là fixture
có kiểm soát, chưa thay thế tài liệu thật và DOCX/PDF.

Mọi cửa sổ/biểu diễn cùng nguồn được gắn cùng nhóm bảo thủ trong
[tổng kết nhóm](../../benchmark/data/annotations/verifier-gap-normalized-v1/tong-ket-nhom.json).
ID nhóm v3 phục vụ chuẩn bị tiếp theo; không sửa manifest/baseline cũ.

## Kiểm tra và tái lập

Đã đạt 2 kiểm tra cửa sổ/span (CRLF/Unicode, không cắt dòng, không treo,
giữ ngữ cảnh trích dẫn và từ chối nguồn/nhãn sai hash), 3 kiểm tra chỉ mục
trùng lặp và 4 kiểm tra mask tokenizer thật. Tái dựng qua parser kiểm tra
cả 30 input/target, hash và vai trò chưa được phép train.

Các lệnh từ gốc dự án:

```powershell
node --test scripts/normalize-verifier-gap.test.cjs
node scripts/normalize-verifier-gap.cjs
node scripts/audit-normalized-verifier-gap.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_gap_tokens.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_tokenizer.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_corpus.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit-verifier-corpus.py verifier-corpus-overlap-v3
node scripts/summarize-verifier-gap.cjs
```

Các lệnh tạo dữ liệu/audit có phiên bản từ chối ghi đè. Muốn chạy lại để
tạo kết quả mới phải dùng phiên bản mới; không xóa lịch sử để chạy lại.
Riêng audit tái dựng có thể chạy lại tại chỗ để xác minh dữ liệu hiện có.

[Kết quả token/mask](../../benchmark/experiments/verifier-gap-tokenizer-v1/ket-qua.json).
[Kiểm tra tái dựng](../../benchmark/data/annotations/verifier-gap-normalized-v1/kiem-tra-chuan-hoa.json).
[Rà toàn kho v3](../../benchmark/experiments/verifier-corpus-overlap-v3/ket-qua.json).

## Phần còn mở

Lượt chuẩn hóa, chia cửa sổ cơ học và audit đã hoàn tất. Tiếp theo cần duyệt
ngữ cảnh/span của các cửa sổ mới; quyết định ngân sách token sau phép đo
collator/backend và GPU; tiếp tục bổ sung dữ liệu bên ngoài có quyền dùng.
Không coi 87 nguồn là tập train đã sẵn sàng. **Ưu tiên 1 chưa hoàn thành**:
chất lượng Agent, nguồn độc lập và tài liệu dài qua model/UI vẫn còn mở.
