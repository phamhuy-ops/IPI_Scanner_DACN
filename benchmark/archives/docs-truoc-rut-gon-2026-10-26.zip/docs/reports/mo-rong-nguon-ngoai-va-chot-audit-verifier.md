# Mở rộng nguồn ngoài và chốt audit dữ liệu Verifier

## Lượt mở rộng đã hoàn tất

Đã tạo 30 bản ghi được Codex (AI) đánh giá theo tiêu chí đã thống nhất:
12 confirmed, 12 dismissed, 6 uncertain. Đây là 24 ID nguồn cha, không
phải 30 nguồn độc lập: sáu cặp base/enhanced thuộc cùng nguồn cha.
Không ghi các quyết định AI thành xác nhận của người dùng.

Nguồn gồm 12 mẫu sạch NotInject chưa nằm trong lượt duyệt trước và 18
phản hồi công cụ InjecAgent. Hàng chờ realistic chỉ còn hai mẫu chưa duyệt;
một thuộc nhóm tham chiếu nên không đưa vào lượt mới để tăng số lượng.

InjecAgent được lưu nguyên snapshot tại commit
`f19c9f2c79a41046eb13c03c51a24c567a8ffa07`, kèm LICENCE MIT, README và
hash từng tệp. NotInject giữ hash Parquet và căn cứ license MIT trong
README cục bộ; không có tệp license riêng trong snapshot NotInject cũ.
Không chạy code hoặc yêu cầu công cụ chứa trong dữ liệu tải về.

## Phạm vi nhãn và đầu vào

Setup chỉ có văn bản nguồn. Với InjecAgent, chỉ trường Tool Response
được đưa vào scanner/renderer; không truyền User Instruction, Thought,
Expected Achievements, nhãn benchmark, source ID hoặc group ID.

Các bản enhanced có lệnh rõ ràng bỏ chỉ dẫn trước và tuân theo nội dung
mới nên được đánh giá confirmed. Sáu bản base được chọn chỉ có snippet
yêu cầu hành động nhưng thiếu người nhận/quyền/nhiệm vụ trong setup này,
nên gán uncertain. Đó là nhãn ngữ cảnh bổ sung, **không sửa ground truth
tấn công của benchmark gốc**, vốn đánh giá agent có ngữ cảnh công cụ.
Các cặp giữ chung nguồn cha/nhóm. Không tự biến ca mơ hồ thành positive
chỉ vì biết metadata của tác giả.

12 mẫu NotInject có đối chứng về ignore, MUST, nhập vai thủ thư, jailbreak
thiết bị và hướng dẫn con người. Nhãn/span/reason được lưu riêng, không
thêm vào messages. Phần reviewed là đánh giá của AI, chưa phải nhãn kiểm
chứng độc lập hoặc bằng chứng về độ chính xác của bộ phân loại tự động.

## Kiểm tra đã đạt

- 60/60 input/target tái dựng chính xác và qua parser ở hai chế độ.
- 60/60 đạt token mask và collator, không cắt ngầm JSON hoặc nguồn.
- Bản dài nhất 983 token, target dài nhất 100 token; tất cả dưới 1.024
  token sau padding. Không cần chạy thêm GPU cho lượt dữ liệu ngắn này.
- Hash dữ liệu thô, code chuẩn bị, nhãn/span và nhật ký AI khớp.
- Hai kiểm tra batch và bốn kiểm tra chỉ mục/cờ audit đạt.

Không forward/học batch mới, không chấm chất lượng model và không đổi
cấu hình mặc định của ứng dụng. Các kiểm tra là kiểm tra dữ liệu/hợp đồng.

## Rà trùng và ranh giới nhóm

Audit v6 đọc 45 tệp và 68.160 text chuẩn hóa duy nhất trong inventory,
bao gồm bốn tệp JSON InjecAgent với 2.108 phản hồi base/enhanced. Chỉ text
Tool Response được đối chiếu; hash Attacker Instruction dùng gom family,
không làm đáp án hoặc tín hiệu scanner.

18 bản InjecAgent được nối vào một nhóm vì tiền tố/biến thể chung; 12
mẫu NotInject thành 12 nhóm mới. Giữ nguyên nhóm lớn, không chia nhỏ để
làm đẹp tỷ lệ. Kho ứng viên có **117 bản ghi, 111 ID nguồn cha, 58 nhóm**;
20 mẫu tham chiếu cũ vẫn ở 12 nhóm reference_only. ID nguồn cha và nhóm
heuristic không phải bằng chứng độc lập ngữ nghĩa.

Không có nhóm match từ vựng với BIPIA test trong lượt này; chưa kiểm tra
embedding/ngữ nghĩa hoặc xác minh holdout độc lập. Không gọi nguồn mới
khác tên là dữ liệu độc lập. Tất cả bản đã xem/gán nhãn dùng chuẩn bị dev.

V5 phát hiện lỗi công cụ: JSON raw bị gắn nhầm cờ overlap_dev_fixture_or_manifest
vì điều kiện chỉ nhìn đuôi .json. Đã sửa điều kiện loại raw, thêm đối chứng
raw JSON/manifest/fixture và chạy lại v6. Giữ v5 cùng snapshot script cũ;
sửa cờ không thay đổi các thành viên nhóm đã gom.

## Tệp đối chiếu và tái lập

- [Batch và provenance](../../benchmark/data/annotations/verifier-external-ai-v1/manifest.json).
- [Nhật ký AI](../../benchmark/data/annotations/verifier-external-ai-v1/danh-gia-ai.json).
- [Kiểm tra tái dựng và ánh xạ nhóm](../../benchmark/data/annotations/verifier-external-ai-v1/kiem-tra-va-nhom.json).
- [Token/mask/collator](../../benchmark/experiments/verifier-external-ai-tokenizer-v1/ket-qua.json).
- [Audit kho v6](../../benchmark/experiments/verifier-corpus-overlap-v6/ket-qua.json).
- [Ranh giới nhóm v6](../../benchmark/experiments/verifier-corpus-overlap-v6/ranh-gioi-nhom.json).
- [Snapshot nguồn/giấy phép](../../benchmark/data/raw/injecagent/snapshot.json).

Từ gốc dự án:

```powershell
node --test scripts/prepare-external-ai-batch.test.cjs
node scripts/audit-external-ai-batch.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_corpus.py
```

Các lượt tạo ban đầu dùng `scripts/fetch_injecagent.py`,
`scripts/prepare-external-ai-batch.cjs`, `scripts/audit_verifier_preview.py
--source verifier-external-ai-v1 --output verifier-external-ai-tokenizer-v1`
và `scripts/audit-verifier-corpus.py verifier-corpus-overlap-v6` qua Python
wrapper trên E. Công cụ tạo snapshot/audit từ chối ghi đè; audit tái dựng
có thể chạy lại để xác minh kết quả hiện có.

## Việc tiếp theo và Ưu tiên 1

Lượt mới toàn tiếng Anh và nhiều bản tấn công chung một tiền tố; không
tiếp tục nhân biến thể đó để lấp mục tiêu số lượng. Ưu tiên nguồn tiếng
Việt có quyền sử dụng, tài liệu dài thực tế và các family tấn công khác.
Kho hiện có 39 bản tiếng Việt/117 bản; khi chọn pilot cần kiểm soát mục
tiêu tiếng Việt và gom mọi bản dịch/biến thể cùng nguồn.

Chưa khóa train/dev, chưa xuất train, chưa có holdout độc lập được xác
minh hoặc fine-tuning trên dữ liệu dự án. Backend kỹ thuật đã có ứng viên,
nhưng dữ liệu, tích hợp trainer và chất lượng Agent vẫn chưa đạt đủ cổng.
**Ưu tiên 1 chưa hoàn thành.**
