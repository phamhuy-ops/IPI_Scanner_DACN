# Tổng hợp thử nghiệm Agent và điều kiện học Verifier

## Kết luận

Chưa có ứng viên đạt điều kiện thay cấu hình mặc định. Dừng các phép đổi bố
cục prompt đơn thuần; bước kỹ thuật kế tiếp là kiểm tra tokenizer, chat template
và vùng tính loss trên đầu ra Verifier trước khi chuẩn bị thử học một model.
Chưa bắt đầu huấn luyện và chưa thêm vòng phản biện. Ưu tiên 1 chưa hoàn thành.

## Bằng chứng dùng ra quyết định

- Phép đo nhận diện trực tiếp và gán ngữ cảnh trên 12 ca cho kết quả khác nhau:
  nhận ra tấn công trong câu hỏi đơn giản không bảo đảm gán đúng stance/ngữ cảnh.
- Làm rõ confirmed/dismissed/uncertain và thử model thay thế đều chưa đạt cổng.
- Đổi thứ tự trường ngữ cảnh, giảm mỗi request còn một chunk và giới hạn đầu
  ra chưa khắc phục ổn định lỗi ngữ nghĩa, trích dẫn hoặc ca sạch đối chứng.
- Thử Verifier đọc nguồn trước trên 6 ca không giảm ba false clear tấn công;
  không mở rộng ứng viên đó lên toàn bộ 72 ca.
- Baseline 72 ca vẫn có 7 false clear dù bằng chứng đã tới prompt cả hai model.
  Trên 61 ca nhị phân: TP=3, FP=1, TN=13, FN=7 và 37 needs_review.

Các phép thử khác dữ liệu/hợp đồng đầu ra nên không cộng gộp thành một điểm
chất lượng. Chúng cho thấy lỗi vượt quá JSON/bố cục, nhưng chưa chứng minh
thiếu fine-tuning là nguyên nhân duy nhất hoặc fine-tuning sẽ sửa được lỗi.
Model lớn hơn cũng chưa được chứng minh là lời giải.

## Dữ liệu hiện có và khoảng trống

Kho đã duyệt có 72 nguồn, 42 nhóm: 22 malicious, 39 benign, 11 uncertain;
30 tiếng Việt, 38 tiếng Anh và 4 tiếng Trung. Có 45 nguồn tự tạo, 27 nguồn
ngoài; toàn bộ uncertain hiện thuộc dữ liệu tự tạo. Chưa có nguồn dài từ
8.000 đơn vị UTF-16 trong manifest này; mốc này chỉ phục vụ thống kê,
không phải ngưỡng bảo mật hoặc độ dài token huấn luyện.

So với ngân sách pilot 300 nguồn/ít nhất 100 nhóm, còn thiếu ít nhất 228
nguồn và 58 nhóm. Đủ số lượng không tự chứng minh chất lượng. Cần bổ sung
ngữ cảnh mơ hồ từ nguồn ngoài, tài liệu dài và các định dạng thực tế, kèm
đối chứng sạch. Không nhân biến thể của cùng nguồn để bù số nguồn/nhóm.

72 nguồn hiện tại đã dùng làm dev. Chưa khóa train/dev, chưa xác minh bộ
kiểm chứng độc lập chưa dùng; không đổi tên chúng thành holdout. Tập probe
tự tạo cũng không thay thế kiểm chứng độc lập.

## Bước tiếp theo đã chọn

1. Dùng tokenizer đúng revision đã chốt của Qwen/Qwen2.5-1.5B-Instruct
   để kiểm tra chat template và token thực tế trên bản xem trước đã duyệt.
2. Kiểm tra completion mask: chỉ tính loss cho đầu ra assistant, không cho
   prompt/nhãn metadata; phát hiện cắt mất JSON hoặc bằng chứng vì giới hạn token.
3. Lưu thư viện/cache/tokenizer trên E theo cấu hình hiện có. Audit tokenizer
   không cần tải weights. Chưa có thao tác cài/tải trong lượt tổng hợp này.
4. Hoàn thiện nguồn và nhóm, tách tập trước biến thể, rồi mới kiểm tra backend
   forward/backward và save/reload trên phần cứng. Chỉ thử train sau các bước đó.

Sau thử học vẫn phải so trước/sau có đối chứng, kiểm chứng độc lập và đo lại
toàn pipeline. Các việc tài liệu dài qua model/UI và độ bao phủ vẫn đang mở.

## Tái lập

Chạy `node --test scripts/assess-verifier-next-step.test.cjs`, sau đó
`node scripts/assess-verifier-next-step.cjs` từ gốc dự án.
Hai kiểm tra về đếm nguồn trùng và điều kiện chưa đủ để train đã đạt.

[Kết quả máy và SHA-256 đầu vào](../../benchmark/experiments/verifier-next-step-v1/ket-qua.json)
lưu đối chiếu các thí nghiệm và thống kê readiness. Đây là tổng hợp dữ liệu
cục bộ đã có, không phải một lượt đo model mới hoặc bằng chứng tăng an toàn.
