# Chuẩn hóa bằng chứng và rà trùng kho benchmark

Đã chuẩn hóa 27 mẫu nguồn ngoài thuộc phạm vi IPI và có nhãn được người
dùng duyệt. Hai direct attack và một mixed vẫn được cách ly; không đưa
trở lại chỉ vì nhãn nguồn là malicious. Nguồn, quyết định duyệt và các
baseline trước đó giữ nguyên.

## Bằng chứng và JSON Verifier

Kết quả ở `benchmark/data/annotations/verifier-external-normalized-v1/`:
27 hàng `nhan-va-bang-chung.jsonl` có offset JavaScript UTF-16, dòng
1-based, directive_spans/context_spans và provenance. Nhãn hasDirective=false
có directive_spans rỗng nhưng vẫn giữ context đầy đủ. Target_quote được
duyệt thì ánh xạ nguyên văn; nếu chưa có quote riêng thì giữ toàn nguồn,
không tự chọn span theo từ khóa hoặc suy ra ranh giới người dùng chưa duyệt.

Mỗi nguồn có hai biểu diễn kiểm tra hợp đồng: whole_source cung cấp toàn
nguồn làm nghi vấn, và none không cung cấp nghi vấn. Cách chọn candidate
độc lập nhãn. Tổng cộng 54 input/target, không phải 54 mẫu độc lập; hai
bản phải cùng source/group/split. Đây là preview hợp đồng, chưa xuất SFT
hoặc token loss mask. Candidate là mô phỏng, chưa chạy Detector thật.

Đã kiểm tra hash tài sản và quyết định, tái dựng chính xác input/target,
span nguyên văn và parser sản phẩm: 54/54 hợp lệ. Input chỉ có prompt,
schema, nguồn trung tính, risk/count từ scanner; không có nhãn/source ID/
group ID/gold. Các trường có nguồn gốc metadata chỉ nằm ngoài input.
Chuẩn hóa cơ học không thay thế duyệt ranh giới bằng chứng: một số span
còn rộng bằng toàn nguồn. Chưa gọi model hoặc đo chất lượng nhận diện.

## Phạm vi rà kho và ranh giới nhóm

Audit phiên bản v2 kiểm tra 34 tệp nguồn/manifest/fixture với 65.889 văn
bản chuẩn hóa duy nhất, gồm raw BIPIA 70.000 hàng, raw NotInject parquet
kể cả alias, realistic JSONL/CSV, các bản chuẩn hóa/conflict, dev/test,
hàng chờ/annotation, manifest ca thử và fixture văn bản. Không thiếu phần
đọc đã liệt kê, hash nguồn không đổi. Inventory và giới hạn nằm trong
[kết quả audit](../../benchmark/experiments/verifier-corpus-overlap-v2/ket-qua.json).
v1 được giữ làm mốc phạm vi trước khi bổ sung manifest thử nghiệm.

So sánh 92 văn bản gồm 72 mẫu trong phạm vi đã duyệt và 20 mẫu tham chiếu
cũ bằng NFKC/casefold/khoảng trắng, Jaccard token trigram>=0.8, và đoạn
12 token liên tiếp. Gom thêm family đã biết, match cùng tài liệu hoặc
cùng document_group_id trong dữ liệu chia sẵn. Kết quả có 54 component:
42 nhóm của 72 ứng viên và 12 nhóm chỉ dành cho 20 mẫu tham chiếu.
Có 9 component chồng với fixture/manifest dev đã dùng. Chưa thấy match
BIPIA test theo tiêu chí này; không phải chứng minh nguồn độc lập.

`matches.jsonl` chỉ lưu ID/phương pháp/nhóm, không in đoạn test, nhãn test
hoặc gold. Text test chỉ dùng cho kiểm tra cấu trúc, không chạy model,
không tính score hoặc chỉnh detection. Raw-only/conflict cũng được rà,
không mặc định rằng bản clean đã đại diện hết dữ liệu thô.

[Ranh giới nhóm](../../benchmark/experiments/verifier-corpus-overlap-v2/ranh-gioi-nhom.json)
có ID nhóm toàn cục và ràng buộc, mọi final_split vẫn null. Không dùng
bucket chia dự kiến cũ để tách các bản cùng component hoặc biến thể cùng
nguồn. Shared passage có thể là boilerplate; chưa dùng embedding hoặc
rà ngữ nghĩa/bản dịch, cần xem xét component trước split cuối. Không quét
đầu ra model trong benchmark/results, code/prompt hoặc file riêng ngoài
workspace; phạm vi “toàn kho” ở đây là nguồn benchmark đã có trong inventory.

## Kiểm tra và việc còn thiếu

8 test chuẩn hóa/renderer và 3 test chỉ mục trùng đạt. Đây là kiểm tra
công cụ dữ liệu, không phải phép đo bảo mật. Chưa thay mặc định sản phẩm.

Chưa chốt train/dev: mới có 72 mẫu và 42 nhóm ứng viên, thấp hơn mục tiêu
300 mẫu/ít nhất 100 nhóm. Chưa có nguồn kiểm chứng độc lập, tài liệu dài
đủ đại diện, duyệt hết ranh giới span hoặc tokenizer/completion mask audit.
FPR/recall không được suy ra từ phép rà trùng. Bước tiếp cần xử lý span
còn rộng, tiếp tục mở rộng nhóm và nguồn độc lập trước khi khóa split.

Lệnh tại gốc dự án:

```powershell
node scripts/audit-normalized-external.cjs
npm test -- scripts/normalize-reviewed-external.test.ts scripts/verifier-batch.test.ts
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 -m unittest scripts.test_verifier_corpus -v
```

Audit corpus dùng `scripts/audit-verifier-corpus.py` qua wrapper Python E,
truyền tên phiên bản mới bắt đầu `verifier-corpus-overlap-`; script từ
chối ghi đè phiên bản cũ và kiểm tra code không đổi trong lượt chạy.
