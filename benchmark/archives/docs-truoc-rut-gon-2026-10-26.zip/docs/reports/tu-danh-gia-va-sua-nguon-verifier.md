# Tự đánh giá cửa sổ và sửa nguồn Verifier

## Kết quả

Đã tiếp tục tự đánh giá theo sự đồng ý của người dùng, không yêu cầu duyệt
lại từng ca rõ ràng. Năm cửa sổ cuối được ghi reviewer là **Codex (AI)**,
giữ nguyên 10 xác nhận ngữ cảnh trước đó của người dùng.

- gap-011/012: chấp nhận ngữ cảnh cho dismissed/uncertain tương ứng.
- gap-013/014: nhãn confirmed/dismissed vẫn phù hợp nhưng bản nguồn có lỗi
  ngắt từ, nên vẫn cách ly chất lượng.
- gap-015: giữ nhãn nguồn uncertain, nhưng từ chối coi cửa sổ cũ đã bảo
  toàn ngữ cảnh vì nó bỏ phần tiếp nối của dòng nền sau câu trọng tâm.

Như vậy phiếu cửa sổ gốc có 10 xác nhận của người dùng và 5 đánh giá AI;
14 ca được chấp nhận về ngữ cảnh trình bày, một ca cần sửa cửa sổ. Sáu
bản nguồn lỗi được cách ly, không tự cho phép train dù nhãn đã được duyệt.
Đánh giá AI này không phải kết quả đo một bộ phân loại độc lập.

## Bản sửa riêng

Đã tạo [bản sửa](../../benchmark/data/annotations/verifier-gap-repair-v1/manifest.json)
cho gap-004/005/006/013/014/015. Công cụ ghép lại hai nửa dòng nền và
chuyển nguyên dòng chứa câu trọng tâm xuống sau đoạn nền hoàn chỉnh.
Không thay câu chỉ dẫn, phần giới thiệu trích dẫn, nhãn hoặc văn bản nền.
Span được tính lại theo phiên bản mới; cửa sổ giữ đủ dòng trước/sau.

Ví dụ `Read` và `ings` được ghép thành `Readings`; `cá nhâ` và `n` được
ghép thành `cá nhân`. Gap-015 mới giữ trọn câu nền nói giấy tờ cá nhân
không được chép vào biên bản, thay vì kết thúc ngay sau câu trọng tâm.

AI đã xem lại toàn bộ sáu cửa sổ mới và giữ các nhãn nguồn tương ứng.
Không gắn xác nhận của người dùng ở bản cũ cho text mới. Các bản v1,
lượt duyệt và kết quả audit cũ vẫn được giữ nguyên; cờ lỗi của bản gốc
không bị xóa chỉ vì đã có bản sửa thay thế.

## Kiểm tra

- Hai kiểm tra sửa nguồn đạt: ba nhãn đều giữ nguyên câu trọng tâm/bao
  khung, ánh xạ span và nhóm đúng; mẫu không có bằng chứng ngắt từ bị từ chối.
- 12/12 input/target mới qua parser; 12/12 mask tokenizer thật hợp lệ,
  chạy offline với revision đã khóa, không tải weights.
- Bản sửa dài 1.208–1.509 token cả prompt và completion. Cả 12 vượt
  1.024 token, không bản nào vượt 1.536 token; không truncate.
- Audit từ vựng toàn kho v4 đọc 39 tệp, 66.052 text chuẩn hóa duy nhất;
  không thiếu phạm vi trong inventory và đầu vào không đổi trong lượt chạy.

Sáu bản sửa là sáu phiên bản của nguồn đã có, không phải sáu nguồn độc lập
mới. Giữ nhóm cha đã gom ở v3. Kho ứng viên vẫn có 87 nguồn/45 nhóm;
20 nguồn tham chiếu cũ giữ riêng. Kiểm tra từ vựng không chứng minh độc
lập ngữ nghĩa hoặc chất lượng holdout.

## Bản sử dụng hiện tại và phần còn thiếu

[Danh sách phiên bản hiện dùng](../../benchmark/data/annotations/verifier-gap-repair-v1/ban-su-dung-hien-tai.json)
chọn 9 bản không lỗi và 6 bản sửa: tổng cộng 15 nguồn cha/30 bản xem trước.
Token nằm trong khoảng 978–1.735; còn 27 bản vượt 1.024 và 4 bản vượt
1.536. Bản sửa không giải quyết được ngân sách token của toàn bộ dữ liệu.
Các mục chỉ được đánh dấu dùng xem trước/chẩn đoán dev; tất cả vẫn chưa
đủ điều kiện train hoặc làm holdout độc lập.

Tiếp theo cần kiểm tra collator/backend và bộ nhớ thực tế trước khi chốt
ngân sách token; tiếp tục bổ sung nguồn ngoài có quyền dùng và kiểm chứng
độc lập. Không chọn mức sequence chỉ vì mọi mẫu hiện tại vừa một con số.
Chưa train, chưa đổi policy/model/rule mặc định, chưa thêm vòng phản biện.
**Ưu tiên 1 chưa hoàn thành.**

## Tái lập

```powershell
node --test scripts/repair-verifier-gap.test.cjs
node scripts/repair-verifier-gap.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_gap_repair_tokens.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit-verifier-corpus.py verifier-corpus-overlap-v4
```

Các lệnh tạo bản sửa/audit từ chối ghi đè; dùng phiên bản mới nếu chạy lại.
Đánh giá ngữ nghĩa của AI được lưu riêng, không giả danh kết quả script.

[Phiếu AI năm cửa sổ gốc](../../benchmark/data/annotations/verifier-gap-normalized-v1/danh-gia-ai-luot-01.json).
[Đánh giá AI bản sửa](../../benchmark/data/annotations/verifier-gap-repair-v1/danh-gia-ai.json).
[Kết quả token/mask](../../benchmark/experiments/verifier-gap-repair-tokenizer-v1/ket-qua.json).
[Audit toàn kho v4](../../benchmark/experiments/verifier-corpus-overlap-v4/ket-qua.json).
[Tiêu chí tự đánh giá](../guides/tu-danh-gia-du-lieu-verifier.md).
