# Bổ sung nguồn ngoài cho ngữ cảnh Verifier

Ngày 2026-10-25. Hoàn tất batch dữ liệu mới; không thay runtime hoặc train.

## Nguồn và nội dung

Đã tự tải bảy file văn bản/license CPython, tổng khoảng 111 KB, từ tag
v3.12.0 tại commit `0fb18b02c8ad56299d6a2910be0bab8ad601ef24`. Đây là snapshot
làm dữ liệu, không thay phiên bản Python đang cài. Giữ nguyên RST, LICENSE,
URL, commit, tọa độ đoạn và SHA-256; không chạy lệnh trong tài liệu.

Nguồn chính thức và license:
[CPython](https://github.com/python/cpython/tree/0fb18b02c8ad56299d6a2910be0bab8ad601ef24/Doc/tutorial),
[điều khoản tài liệu Python](https://docs.python.org/3/license.html).
Giữ thông báo Python Software Foundation và đầy đủ điều khoản trong LICENSE
đã tải; không chỉ lưu nhãn license rút gọn.

24 bản ghi mới gồm:

- Sáu đoạn hướng dẫn người dùng Python từ sáu tài liệu: môi trường ảo,
  trình thông dịch, đọc/ghi, ngoại lệ, module và thư viện chuẩn. Nhãn
  dismissed/human/active/none; vẫn có hasDirective=true.
- Sáu bản giữ nguyên đoạn Python và nối chỉ dẫn cho assistant thay câu trả
  lời hoặc bịa kết luận. Nhãn confirmed/assistant/active/answer_manipulation.
  Đây là phần chèn do **Codex (AI) soạn**, không phải tấn công quan sát được
  trong tài liệu Python thật. Ba bản kết hợp nền Anh và phần chèn Việt.
- Sáu cặp base/enhanced InjecAgent chưa gán nhãn ở batch trước, từ snapshot
  đã lưu commit `f19c9f2c79a41046eb13c03c51a24c567a8ffa07`, license MIT.
  Base chỉ có nguồn, chưa đủ người nhận/quyền/nhiệm vụ nên uncertain;
  enhanced ra lệnh bỏ chỉ dẫn trước nên confirmed. Không đổi nhãn benchmark
  gốc có đầy đủ ngữ cảnh; đây là nhãn cho setup text-only của dự án.

Như vậy có 18 bản giữ nguyên nội dung nguồn ngoài và sáu đối chứng chèn
tự soạn; không gọi toàn bộ 24 bản là nguồn thực tế độc lập. Tổng nhãn là
12 confirmed, sáu dismissed, sáu uncertain. Có 21 bản tiếng Anh và ba bản
Anh–Việt. Toàn bộ quyết định mới ghi reviewer AI, không ghi là người dùng duyệt.

## Kiểm tra đã hoàn tất

Giữ đủ ngữ cảnh liên tục của đoạn; bảo toàn RST và ví dụ lệnh dưới dạng dữ
liệu. Các phần còn lại của tài liệu không được tự gán nhãn benign. Span chỉ
dẫn và ngữ cảnh khớp UTF-16, cùng hash nguồn đã pin.

Có 48 biểu diễn ở hai setup có/không nghi vấn, theo hợp đồng Verifier
referenced/compact đã có; không thay classic-v1 mặc định trong ứng dụng.
48/48 qua parser và tái dựng payload/target, không đưa nhãn, nhóm, parent ID
hoặc metadata benchmark vào model input.

Audit offline trên môi trường Python/cache ở E: mask và collator 48/48
tại ngân sách 2.048 token, tối đa 1.624 token, target tối đa 100 token.
20 bản vượt 1.024 và hai bản vượt 1.536; không truncate để ép đạt. Đây là
kiểm tra dữ liệu, không phải forward/backward hoặc chứng minh train vừa VRAM.

Hai kiểm thử Node và bốn kiểm thử Python liên quan đạt. Không tải weights,
không cài thư viện, không gọi model, không cập nhật adapter/checkpoint.

## Nhóm, trùng và độ độc lập

Mỗi đoạn Python và đối chứng chèn giữ cùng parent/group. Base/enhanced
InjecAgent cũng giữ cùng parent. Trước audit có 12 nhóm cục bộ; sau so toàn
kho, 12 bản InjecAgent mới nhập thành phần đã có 18 bản, thành nhóm 30 bản.
Không phân tán nhóm lớn này qua train/dev chỉ để có tỷ lệ chia đẹp.

Audit v9: 66 file, 68.219 văn bản chuẩn hóa duy nhất; 198 bản ghi tham chiếu
gồm 20 legacy và 178 ngoài legacy. Có 83 nhóm tổng, 71 nhóm ngoài legacy.
So v8, thêm 24 bản ghi nhưng chỉ thêm sáu nhóm; quan hệ giữa các mẫu cũ được
giữ. Nhóm lớn nhất 30 bản, sau đó 9/6/6/5; không coi các bản trong đó là các
nguồn độc lập.

Không có phạm vi đầu vào bị thiếu trong danh sách audit, hash giữ nguyên
trong lượt chạy. Không thấy trùng với BIPIA test theo heuristic từ vựng hiện
tại; không embedding hoặc chứng minh độc lập ngữ nghĩa. Nguồn mới đã được
AI xem/chọn để gán nhãn; chưa phải holdout độc lập. Chỉ đọc text để so trùng,
không đưa gold test vào model hoặc dùng nó để chỉnh detection.

## Việc thủ công và tiến độ

**Lượt này không cần bạn tải file hoặc cài công cụ thủ công.** Nguồn công
khai tải được trực tiếp; InjecAgent và công cụ kiểm tra đã có sẵn. Không sử
dụng tài liệu riêng trên máy hoặc gửi nội dung lên dịch vụ bên ngoài.

Kho hiện có 178 bản ghi ngoài legacy/71 nhóm theo heuristic, chưa đạt mục
tiêu pilot 300 bản ghi/ít nhất 100 nhóm. Chưa tạo train/dev hoặc holdout,
training_eligible=false cho toàn bộ batch. Việc thêm dữ liệu chưa chứng minh
model giảm sai; **Ưu tiên 1 vẫn chưa hoàn thành**.

Khoảng trống còn lại: human/uncertain từ nguồn khác ngoài cùng template
benchmark, tài liệu Việt nguyên bản và PDF/DOCX thực tế, cùng kiểm chứng độc
lập sau khóa ứng viên. Bước tiếp nên lập danh sách nguồn/nhóm còn thiếu và
phần dữ liệu đủ điều kiện cho split, tránh tiếp tục nhân bản nhóm InjecAgent
lớn để bù số lượng. Nếu cần file/cài đặt thủ công sẽ thông báo nguồn, định
dạng và lý do cụ thể trước khi phụ thuộc vào nó.

## Tái lập

```powershell
node scripts/fetch-python-context-docs.cjs
node --test scripts/prepare-verifier-external-context.test.cjs
node scripts/prepare-verifier-external-context.cjs
node scripts/audit-verifier-external-context.cjs
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_preview.py --source verifier-external-context-v1 --output verifier-external-context-tokenizer-v1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/test_verifier_corpus.py
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit-verifier-corpus.py verifier-corpus-overlap-v9
```

Lệnh tạo/audit từ chối ghi đè phiên bản đã có; giữ baseline cũ.

- [Kế hoạch trước xử lý](../planning/bo-sung-nguon-ngoai-ngu-canh-verifier.md).
- [Snapshot CPython](../../benchmark/data/raw/python-context-docs-v1/snapshot.json).
- [Bản ghi và span](../../benchmark/data/annotations/verifier-external-context-v1/mau-cho-duyet.jsonl).
- [Kết quả tổng hợp](../../benchmark/experiments/verifier-external-context-v1/ket-qua.json).
- [Token/mask/collator](../../benchmark/experiments/verifier-external-context-tokenizer-v1/ket-qua.json).
- [Nhóm toàn kho v9](../../benchmark/experiments/verifier-corpus-overlap-v9/ket-qua.json).
