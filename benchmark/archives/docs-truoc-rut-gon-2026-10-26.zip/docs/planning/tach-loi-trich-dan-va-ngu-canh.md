# Tách lỗi trích dẫn và lỗi ngữ cảnh

Ngày 2026-10-25. Chưa đổi hành vi phát hiện hoặc cấu hình mặc định.

## Câu hỏi và giới hạn

1. Phản hồi cũ lỗi vì JSON, quote không khớp hay gán nhầm ngữ cảnh?
2. Nếu chỉ bỏ marker khỏi quote thì schema có hợp lệ nhưng nhận định vẫn sai?
3. Trên đối chứng có chỉ dẫn thật, trích dẫn đào tạo và công việc cho người,
   lỗi còn xuất hiện khi dùng nguyên hợp đồng hiện tại không?

Bản tổng hợp Agent đã kết luận thay bố cục prompt, một chunk/request và
schema khác chưa đạt cổng. Vì vậy lượt này không thêm một prompt ứng viên.
Trước hết khóa baseline chẩn đoán và đối chứng; không nới validator, tự cắt
quote, loại discovery theo từ khóa hoặc coi lý do model là đáp án.

## Thiết kế trước phép đo

- Replay hai phản hồi ở cùng chunk gây lỗi từ hai chế độ cũ, bằng parser thật.
  Thử bỏ marker trên bản sao **chỉ để chẩn đoán**, không ghi vào pipeline.
- Khóa tám ca dev: hai đoạn mô tả sạch gây discovery từ bài năng lượng;
  ba cặp active/quoted/human bằng Anh và Việt (mỗi ngôn ngữ ba ca).
- Giữ nguyên chunk gốc trên hai ca tái hiện; biến thể dùng câu chữ khác
  các mẫu tối giản cũ, không dùng ID/nhãn/đáp án trong scanner hoặc prompt.
- Nhãn do AI đọc ngữ cảnh đề xuất, không ghi là người dùng đã duyệt.
  Hai đoạn cùng bài và các cặp cùng ngữ cảnh phải cùng nhóm. Đây là dev,
  không thay thế kiểm chứng độc lập hoặc làm tăng số nguồn độc lập.
- Chạy scanner và bộ điều phối một chunk/request hiện có, classic-v1,
  hai model mặc định; tối đa 8 chat request/ca, 90 giây/ca, không đọc bổ sung.
  Ghi raw response, tiến độ, lỗi parser, stance từng vai trò, thời gian/tài nguyên.
- Nếu mẫu bị chia khác đoạn đã khóa, dừng để kiểm tra trước khi đo.
- Báo riêng metric quyết định, lỗi giao thức và discovery trên ca sạch;
  không dùng hợp lệ JSON để thay cho đúng ngữ nghĩa.

Sau kết quả mới chọn thay đổi tiếp theo. Chưa bật thí nghiệm đọc bổ sung
trong UI; Ưu tiên 1 vẫn mở, chưa train hoặc thêm phản biện.
