# Bổ sung nguồn ngoài cho ngữ cảnh Verifier

Ngày 2026-10-25. Không đổi runtime hoặc huấn luyện trong bước này.

## Phạm vi

- Tải văn bản tài liệu CPython từ tag v3.12.0, giải tham chiếu tới commit
  cố định; giữ LICENSE, nguồn RST và SHA-256. Không cài Python hoặc chạy
  lệnh minh họa. Chọn các đoạn hướng dẫn người thao tác, giữ đủ ngữ cảnh.
- Dùng các cặp base/enhanced InjecAgent chưa được gán nhãn ở batch trước,
  giữ commit/license đã tải. Nhãn base theo setup chỉ có nguồn, không lấy
  User Instruction/Thought hoặc nhãn attack làm đầu vào để đoán quyền.
- Tạo đối chứng chuyển hướng assistant từ nền tài liệu Python, ghi rõ do
  AI chèn, khác nguyên bản; không gọi chúng là tấn công thật thu thập được.
- Dự kiến 6 đoạn human từ 6 tài liệu, 6 đối chứng chèn tương ứng và 6 cặp
  base/enhanced: tối đa 24 bản ghi. Không ép số lượng nếu mất ngữ cảnh hoặc
  trùng nguồn đã duyệt. Tất cả nhãn mới là AI, training_eligible=false.

## Điều kiện kiểm tra

Pin nguồn/license; kiểm tra quote/span; chuẩn hóa hai setup có/không nghi
vấn bằng parser hiện có; audit token/mask/collator offline trên E; rà trùng
và nhóm toàn kho bằng phiên bản mới. Gom nguyên bản/đối chứng và các bản
dịch/biến thể cùng parent, không tăng số nguồn độc lập bằng nhân bản. Giữ
audit cũ, không tạo split hoặc gọi nguồn vừa xem là holdout độc lập.

Nếu nguồn công khai không truy cập được, cần quyền truy cập hoặc công cụ
chưa có, báo cụ thể việc người dùng cần tải/cài; không tự mua tài nguyên,
gửi tài liệu riêng ra ngoài hoặc cài thư viện chỉ để tải văn bản.
