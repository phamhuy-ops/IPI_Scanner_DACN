# Đưa tiến độ model vào luồng chính

Ngày 2026-10-25. Phạm vi: sổ tiến độ theo batch thành công và giao diện;
không đổi prompt, schema, selector, rule hoặc số lượt phân tích.

## Hành vi cần sửa

Scanner đặt `aiReviewedChunks` bằng số đoạn được chọn. UI chưa hiển thị số
đoạn từng model xử lý hợp lệ, và lỗi giữa chừng mất thông tin tiến độ.

## Thiết kế trước sửa

- Giữ metadata scanner tương thích; UI lấy số đã chọn từ semanticChunks.
- Tiến độ riêng trên IpiRunState: tổng số đoạn (null nếu chưa biết), các ID
  gốc được chọn, Detector thành công, Verifier thành công, giao hai tập.
- Agent chỉ thông báo batch sau parser và applyBatch thành công. Pipeline
  lưu tiến độ trước khi chạy batch tiếp; bản snapshot sự kiện không bị cập
  nhật ngược bởi batch sau. Không thay thứ tự hoặc cách ghép batch.
- Lỗi/timeout vẫn giữ batch trước đó, không tính batch đang lỗi là thành công.
- Kết luận giữ policy confirmed hiện tại; khi chưa hoàn tất hai vai trò phải
  ghi rõ phần thiếu, không trả not_detected. Thiếu extraction/coverage vẫn
  giữ lý do cũ. Hai model thành công chưa chứng minh hiểu đúng ngữ nghĩa.
- UI hiển thị cả khi đang chạy/lỗi: tổng, đã chọn, Detector, Verifier,
  hoàn tất cả hai và phần chưa hoàn tất. Kết quả cũ không có ledger hiển thị
  chưa có thông tin, không suy diễn thành tất cả đã đọc.

## Kiểm tra

Baseline 31/31 kiểm thử pipeline/panel; code trước sửa lưu riêng trong
benchmark/experiments/production-review-progress-v1/baseline-code.
Kiểm tra pipeline sạch, attack, thiếu coverage, lỗi batch sau ở từng vai trò,
timeout và snapshot; render UI trên chính kết quả pipeline; kiểm tra reset và
kết quả cũ. Đo smoke model thật so baseline đã lưu nếu khả thi; không tuyên bố
cải thiện nhận diện. Ghi rõ giới hạn kiểm tra UI/IPC và kiểm chứng độc lập.
