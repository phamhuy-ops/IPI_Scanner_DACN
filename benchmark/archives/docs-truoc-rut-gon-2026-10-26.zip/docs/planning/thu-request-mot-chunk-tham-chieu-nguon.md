# Thử mỗi request một chunk với mã tham chiếu nguồn

Trạng thái: đã hoàn tất lượt chẩn đoán dev ngày 24/10/2026; chưa đạt để
bật mặc định. Kết quả và giới hạn ở phần cuối tài liệu.

Mục tiêu là kiểm tra lỗi trích dẫn của vòng Agent đầu tiên, không thêm phản
biện hoặc huấn luyện. Tùy chọn thử nghiệm `referenceBatchSize: 1` chỉ dùng
với `referenced-v1`, áp dụng cho cả Detector và Verifier. Không bật trên UI.

So sánh hai cấu hình cùng `referenced-v1` và Verifier `compact-v1`: cấu hình
tham chiếu hiện tại và ứng viên một chunk mỗi request. Giữ model, prompt,
schema, nguồn, thứ tự chunk, deadline 180 giây và chính sách kết luận.
Không ghép ứng viên giới hạn phần giải thích `--bounded` đã bị loại trước.

Các đối chứng là `clean.txt`, `attack.txt`, `quoted.txt` trong
`benchmark/fixtures/demo-output-v1/`; cùng tên, cùng đường dẫn giữa hai
lượt. Mẫu tấn công và ví dụ trích dẫn thuộc cùng nhóm. Mỗi fixture này chỉ
có một chunk nên request thực tế của hai cấu hình giống nhau; đây là
đối chứng hành vi và biến động suy luận, không phải bằng chứng về hiệu quả
chia nhỏ request. File Word người dùng cung cấp dùng Deep Scan để kiểm tra
nhiều chunk. Chỉ dùng file đó chẩn đoán xử lý, chưa có nhãn toàn file.

Lệnh tại gốc dự án:

```powershell
node scripts/diagnose-document-demo.cjs benchmark/fixtures/demo-output-v1/clean.txt --referenced
node scripts/diagnose-document-demo.cjs benchmark/fixtures/demo-output-v1/clean.txt --referenced --single-chunk
```

Lặp hai lệnh cho `attack.txt`, `quoted.txt`. Với tài liệu Word, dùng đường
dẫn gốc và thêm `--deep` ở cả hai cấu hình. Không sửa hoặc commit file đó.
Log nội dung chỉ giữ tại `benchmark/results/`, đã bị gitignore.

Ghi riêng lỗi JSON, mã nguồn/trích dẫn, mâu thuẫn trường ngữ cảnh, kết luận,
abstention, số request và thời gian. Mẫu sạch phải không bị kết luận IPI;
mẫu tấn công không được trả chưa phát hiện; hoàn thành JSON chưa đủ để
chấp nhận ứng viên. Chưa đọc đủ chunk thì vẫn cần xem xét. Nhiều request
có thể làm cạn deadline dù từng request nhỏ hơn; không tự tăng thời hạn
hoặc bỏ chunk để làm kết quả đẹp hơn.

Kiểm tra code gồm typecheck, lint và các test pipeline/source references/
review policy. Không coi test code là phép đo model. Chưa có nguồn độc lập,
biến thể chưa thấy hoặc nhiều lượt suy luận, nên kết quả chỉ có giá trị dev
sơ bộ và không đủ chứng minh cải thiện bảo mật tổng quát. Snapshot RAM chỉ
là mức tại thời điểm ghi, không phải peak RAM/VRAM.

## Kết quả lượt chẩn đoán

Đã đo tám lượt: ba fixture và một file Word, mỗi nguồn chạy hai cấu hình.
Cả sáu lượt fixture đều trả `invalid_response` do trường ngữ cảnh mâu
thuẫn, kết luận `needs_review`. Có trường hợp `quoted_example` đi cùng
`confirmed`, nên validator từ chối. Hai cấu hình có cùng hash request đầu
trên từng fixture ngắn; không suy rằng chia batch gây ra khác biệt thời gian.

Word Deep Scan vẫn chọn cùng 24/112 chunk. Cấu hình tham chiếu gốc dừng
ở Detector vì phản hồi mâu thuẫn sau khoảng 40 giây. Ứng viên một chunk
mỗi request dừng ở Detector vì request model timeout sau khoảng 77 giây
tổng lượt chạy, chưa tới Verifier. Không gọi đây là hết toàn bộ deadline
180 giây: mỗi lần gọi model còn có ngân sách request tối đa 45 giây.

Không có lượt đối chứng nào đủ điều kiện ra quyết định nhị phân. Trong
ma trận có abstention: TP=FP=TN=FN=0, mẫu sạch cần xem xét=2 và mẫu tấn
công cần xem xét=1 ở mỗi cấu hình. Precision và F1 không xác định (`null`),
confirmed recall=0, FPR=0 nhưng coverage quyết định=0; không diễn giải
FPR=0 thành model phân biệt tốt dữ liệu sạch.

Kết quả có cấu trúc ở
[ket-qua.json](../../benchmark/experiments/single-chunk-reference-v1/ket-qua.json),
kèm hash code, đầu vào, artifact log, thời gian, metric theo nhóm. Snapshot
môi trường/model digest ở
[moi-truong.json](../../benchmark/experiments/single-chunk-reference-v1/moi-truong.json).
Log `calls` chỉ đếm HTTP có phản hồi, không gồm request đã timeout; dùng
`elapsed_ms` để xem cả thời gian chờ thất bại. Script tổng hợp chạy bằng
`node scripts/summarize-single-chunk.cjs`; nếu có nhiều lượt khớp, script
dừng để tránh tự chọn kết quả thuận lợi.

68 kiểm thử pipeline, tham chiếu nguồn và policy đạt; typecheck và lint
đạt. Chỉ bổ sung tùy chọn chẩn đoán, chưa bật trong UI, chưa fine-tune,
chưa phản biện và chưa đánh giá độc lập. File demo chưa ổn định. Kết quả
này chưa ủng hộ việc tăng deadline hoặc chỉ thay batch size; bước điều tra
sau cần tập trung cách model gán stance/ngữ cảnh trên các ca tối giản.
