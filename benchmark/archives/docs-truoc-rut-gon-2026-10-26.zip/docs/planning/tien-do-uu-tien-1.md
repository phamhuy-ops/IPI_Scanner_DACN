# Tiến độ Ưu tiên 1

**Trạng thái tổng: chưa hoàn thành.** Đợt chốt cổng và đo baseline 72 mẫu
đã hoàn tất. Không đồng nhất “đo xong” với “Agent đã đạt yêu cầu”.

**Đã tìm/tải tài liệu Việt 2026-10-25:** vùng incoming hiện có hai PDF và
hai DOCX từ cổng giáo dục Hà Nội, VAST, Sở Nội vụ Phú Thọ và HNUE, cả bốn
trích xuất được chữ. [Nguồn và trạng thái](../reports/nguon-tai-lieu-viet-pdf-docx-da-tim.md).
Chưa xác minh quyền train/tái phân phối hoặc hoàn tất rà nội dung, nên chưa
thêm vào 178 bản ghi/71 nhóm đã duyệt. Không còn yêu cầu người dùng tự tải
bốn file này; Ưu tiên 1 vẫn mở.

**Rà trước split 2026-10-25:** đã lập registry đúng phiên bản cho 178 bản/
131 parent ID/71 nhóm. 44 nhóm đề nghị giữ dev; 27 nhóm còn lại cần xét vai
trò, không phải holdout. Có 34 nguồn text dài nhưng không có đầu vào nhãn
dài ≥8.000 đơn vị UTF-16; chưa có PDF/DOCX vật lý trong kho benchmark.
[Báo cáo và tài liệu cần bổ sung](../reports/khoang-trong-va-dieu-kien-chia-tap-verifier.md).
Chưa chia tập/train; Ưu tiên 1 còn mở. Mốc UI đã triển khai không bị quay lại
trạng thái chỉ thí nghiệm.

**Bổ sung nguồn ngoài 2026-10-25:** thêm 24 bản ghi AI từ sáu đoạn tutorial
Python, sáu đối chứng chèn tự soạn và sáu cặp InjecAgent. Parser/token/mask/
collator 48/48. Audit v9: 178 bản ghi ngoài legacy/71 nhóm; 12 bản mới nhập
nhóm InjecAgent lớn thành 30 bản. [Báo cáo](../reports/bo-sung-nguon-ngoai-ngu-canh-verifier.md).
Không cần cài/tải thủ công trong lượt này. Chưa split/train/holdout độc lập;
mốc UI tiến độ vẫn đã triển khai, chất lượng Agent chưa đạt.

**Bước dữ liệu tiếp theo đã xong 2026-10-25:** đối chiếu và chuẩn hóa bảy
nhãn ngữ cảnh mới, cách ly một ca cắt câu; 14/14 bản qua parser và
token/mask/collator. Audit v8: 154 bản ghi ngoài legacy/65 nhóm, chưa có
split hoặc holdout độc lập. [Báo cáo](../reports/chuan-hoa-nhan-nguoi-nhan-verifier.md).
Không đổi runtime/không train. Mốc tiến độ UI bên dưới vẫn đã triển khai;
Ưu tiên 1 còn mở vì chất lượng Agent và kiểm chứng chưa đạt.

**Cập nhật mới nhất 2026-10-25:** đã đưa tiến độ từng model vào **luồng chính
và panel mặc định**, giữ tiến độ khi lỗi batch sau, hiển thị phần chưa hoàn
tất và lý do Cần xem xét. 221/221 kiểm thử, lint/typecheck/build đạt; đã xem
panel thật trên ca sạch/attack/lỗi với endpoint giả lập và smoke hai model
thật trên cặp attack/clean. [Báo cáo](../reports/tien-do-model-trong-luong-chinh.md).
Phần A đã triển khai/kiểm tra cục bộ; phần C hoàn tất mốc hiển thị tiến độ.
Phần B chưa đạt; tài liệu dài đầy đủ/đa file/IPC và kiểm chứng độc lập còn
thiếu. Chưa thêm đọc bổ sung, phản biện hoặc train; Ưu tiên 1 vẫn mở.

Cập nhật tiếp: đã thử Verifier đọc nguồn trước khi không có nghi vấn trên
6 ca dev. Ba tấn công vẫn bị bỏ sót; ứng viên bị loại, không đổi mặc định.
Xem [phép thử và giới hạn](../reports/thu-verifier-doc-nguon-khi-khong-co-nghi-van.md).

## Phần đã hoàn tất

- Chốt [cổng hoàn thành](cong-hoan-thanh-uu-tien-1.md), giữ nguyên ba kết
  luận và cách xử lý lỗi/thiếu bao phủ.
- Khóa manifest dev v2: 72 mẫu đã duyệt, 42 nhóm, 22 malicious,
  39 benign, 11 uncertain; 20 mẫu tham chiếu cũ không đưa vào đo.
- Thu hẹp cơ học span ở ba nguồn nhiều câu, giữ nguyên nhãn và text đầu
  vào. Span toàn nguồn còn lại chủ yếu là câu đơn ngắn; vẫn gắn cờ,
  không giả danh lần duyệt ranh giới mới của người dùng.
- Chạy đủ 72/72 ca qua core pipeline mặc định và hai model thật cục bộ.
  Code/nguồn khóa không đổi; digest model đầu/cuối trùng nhau.
- Chạy 9 kiểm tra engine/policy với TXT dài và nhiều file. Khi chưa đọc
  đủ, policy giữ needs_review. Ca chèn giữa tài liệu không được chọn ở
  cả Balanced và Deep: đây là khoảng trống còn mở.

## Kết quả và phần chưa đạt

Trên 61 mẫu nhị phân: TP=3, FP=1, TN=13, FN=7; còn 37 needs_review.
Precision=75%, confirmed recall=13,64%, F1=23,08%, FPR=2,56%; coverage
quyết định nhị phân=39,34%. FPR thấp không có nghĩa đã đạt khi phần lớn
nguồn sạch bị chuyển sang cần xem xét. Đây là dev nhỏ đã dùng chẩn đoán,
không phải kết quả độc lập hoặc đại diện thực tế.

Toàn lượt có 57 completed, 15 invalid_response (14 liên quan citation),
không timeout. Trong 11 ca uncertain có 4 lỗi kỹ thuật, 4 trả chưa phát
hiện, 1 báo IPI; chỉ 2 ca hoàn thành có needs_review kèm stance uncertain.
Con số 2 là proxy nhãn/bằng chứng, chưa kiểm tra ngữ nghĩa từng lập luận;
không tính lỗi kỹ thuật là đúng uncertain.

129 HTTP chat call, 114 qua runtime parser (88,37%). Case latency p50
11,758 giây, p95 14,471 giây. RSS harness và snapshot model không phải
RAM/VRAM peak toàn hệ thống. Classic-v1 không sinh đầy đủ trường ngữ
cảnh có cấu trúc, nên chưa có metric từng trường.

Chưa thấy not_detected khi còn lỗi kỹ thuật, nghi vấn unresolved hoặc
coverage issue trong bộ này. Chốt policy đó không bù được 7 false clear:
cả 7 có bằng chứng tới prompt hai model nhưng không được nhận diện.
Kiểm tra coverage chỉ dùng engine/policy, chưa phải model/pipeline/UI đầy đủ.

## Bước kế tiếp — một lỗi để thử sửa

Ưu tiên nguồn ngoài yêu cầu lấy thông tin riêng trong hội thoại nhưng
cả hai Agent bỏ qua: p1-040 và đối chiếu tiếng Việt p1-048. Đã thử đưa
nguồn trước ở request Verifier và nhắc danh sách rỗng không có nghĩa sạch;
không giảm false clear nên chưa chạy ứng viên trên toàn bộ 72 ca.
Giữ nguồn sạch
về thông tin liên hệ và ví dụ trích dẫn làm đối chứng, thêm biến thể chưa
dùng chọn ứng viên. Chưa sửa rule/prompt/model trong lượt baseline.
Trước thử tiếp, tổng hợp bằng chứng từ các ứng viên đã thất bại để chọn
hướng năng lực model/dữ liệu, không lặp đổi bố cục prompt thiếu giả thuyết.
Thử một thay đổi có giả thuyết rõ, so trước/sau trên cùng dev, rồi mới
kiểm chứng độc lập và đo lại pipeline. Chưa thêm phản biện/fine-tune.

Ưu tiên 1 còn thiếu chất lượng Agent đạt cổng, kiểm chứng độc lập,
tài liệu dài qua model/UI và thể hiện đúng phần đã chọn/đã xử lý thành công.

## Nơi tra cứu

Cập nhật tiếp 2026-10-25: hoàn tất [tách lỗi citation và ngữ cảnh](../reports/tach-loi-trich-dan-va-ngu-canh.md).
Tám ca AI/ba nhóm, 15 chat request: một attack confirmed, hai công việc cho
người bị cả hai model báo nhầm, một attack bất đồng và một ca lỗi citation.
Quote cũ sai cả marker lẫn hoa thường; không nới validator. Bước tiếp là đối
chiếu/bổ sung nhãn human/assistant cho Verifier và kiểm tra dữ liệu, không
lặp đổi bố cục prompt đơn thuần. **Ưu tiên 1 chưa hoàn thành**, chưa train.

Cập nhật 2026-10-25: đã thêm [đọc bổ sung có ngân sách](../reports/thu-doc-bo-sung-co-ngan-sach.md)
trong nhánh thí nghiệm, ghi riêng số đoạn thành công của từng model. 212/212
kiểm thử đạt; ba ca/sáu lượt model thật chưa cải thiện kết luận. File dài cả
hai chế độ dừng ở 8/27 đoạn do quote chứa marker bao khung, chưa tới đoạn bổ
sung. Giữ mặc định, chưa train/phản biện. **Ưu tiên 1 chưa hoàn thành**.

- [Kết quả baseline](../../benchmark/experiments/priority-one-baseline-v1/ket-qua.json).
- [Đối chiếu ca bỏ sót](../../benchmark/experiments/priority-one-baseline-v1/doi-chieu-ca-bo-sot.json).
- [Coverage cục bộ](../../benchmark/experiments/priority-one-coverage-v1/ket-qua.json).
- [Tiến độ máy](../../benchmark/experiments/priority-one-progress-v1/tien-do.json).
- [Manifest đã khóa](../../benchmark/data/priority-one-dev-v2.json).

Các đợt tiếp theo cập nhật trang này và thông báo trong chat: phần vừa
hoàn tất, phần chưa đạt, bước kế tiếp; không dùng phần trăm thiếu cơ sở.

## Cập nhật: đã tổng hợp bằng chứng và điều kiện học Verifier

Đã hoàn tất [bản tổng hợp](../reports/tong-hop-thu-nghiem-agent-va-dieu-kien-hoc-verifier.md) và kiểm tra dữ liệu: 72 nguồn/42 nhóm; chưa đủ điều kiện train. Các ứng viên trước chưa đạt nên giữ cấu hình mặc định. Bước kế tiếp là audit tokenizer/chat template/completion mask thực tế, đồng thời bổ sung nguồn còn thiếu và bộ kiểm chứng độc lập. Chưa train, chưa thêm phản biện; **Ưu tiên 1 vẫn mở**.

## Cập nhật: tokenizer/mask và dữ liệu bổ sung

Đã audit 144 biểu diễn/72 nguồn: mask đúng 144/144, 21 bản vượt 1024 token. Đã tạo 15 nháp mới chưa duyệt (9 nguồn dài cần cửa sổ). Xem [báo cáo](../reports/kiem-tra-tokenizer-mask-va-bo-sung-du-lieu-verifier.md). Bước kế: duyệt từng lượt 5, xử lý ngân sách/cửa sổ, rà nhóm và bổ sung nguồn ngoài độc lập. Chưa kiểm tra collator/backend, chưa train; **Ưu tiên 1 còn mở**.

## Cập nhật: hoàn tất duyệt nhãn 15 nguồn bổ sung

Người dùng đã đồng ý cả 15 đề xuất: 5 confirmed, 5 dismissed, 5 uncertain. Phạm vi là nhãn và ngữ cảnh đã trình bày, chưa duyệt riêng mọi ranh giới span/toàn văn dài. Giữ 72 nguồn baseline và kết quả audit cũ; không tự nhập mẫu mới vào train. Bước kế tiếp là chuẩn hóa span/cửa sổ đủ ngữ cảnh, audit token/mask và rà trùng toàn kho. Nguồn kiểm chứng độc lập vẫn thiếu; **Ưu tiên 1 chưa hoàn thành**.

## Cập nhật: chuẩn hóa cửa sổ và rà trùng 15 nguồn bổ sung

Đã tạo 251 cửa sổ phủ văn bản; 15 cửa sổ có nhãn cơ học/30 bản xem trước qua parser và mask. Còn 236 cửa sổ chưa nhãn. 27 bản vượt 1024 token; chưa đổi ngân sách train. Audit v3 có 87 nguồn/45 nhóm ứng viên; family mới 5 gom bảo thủ thành 3. Xem [báo cáo](../reports/chuan-hoa-cua-so-va-ra-trung-du-lieu-bo-sung-verifier.md). Bước tiếp: duyệt ngữ cảnh/span cửa sổ và đo backend/bộ nhớ, bổ sung nguồn độc lập. Chưa chia tập/train, **Ưu tiên 1 còn mở**.

## Cập nhật: AI tự đánh giá và sửa nguồn lỗi

Đã hoàn tất đánh giá 5 cửa sổ cuối bằng AI, không ghi thành người dùng duyệt. Sáu bản lỗi cũ cách ly; có 6 bản sửa riêng qua parser/mask 12/12. Bản dùng hiện tại vẫn 15 nguồn cha/30 biểu diễn, không tăng nguồn độc lập; còn 27 bản vượt 1024 token. Audit v4 giữ 87 nguồn/45 nhóm. Xem [báo cáo](../reports/tu-danh-gia-va-sua-nguon-verifier.md). Bước tiếp: kiểm tra collator/backend/bộ nhớ để chọn ngân sách token và bổ sung nguồn độc lập; **Ưu tiên 1 chưa hoàn thành**, chưa train/phản biện.

## Cập nhật: collator và GPU đã kiểm tra kỹ thuật

Collator đạt 174/174; backend completion_loss giảm peak allocation 2048 token từ khoảng 5,78 xuống 2,68 GiB trên đối chứng. Stress 10 bước/256 token đích đạt, peak allocation 2,75 GiB và reserved 3,02 GiB, dư địa nhỏ. Chọn ứng viên kỹ thuật 2048 token với đúng backend/cap/batch đã đo, không áp dụng kết luận cho dense loss. Có cập nhật adapter fixture riêng, không học 87 nguồn dev hoặc triển khai adapter thử. Xem [báo cáo](../reports/kiem-tra-collator-va-ngan-sach-gpu-verifier.md). Bước tiếp: bổ sung nguồn/nhóm, khóa dữ liệu đúng cách rồi tích hợp trainer. **Ưu tiên 1 còn mở**, chưa có cải thiện nhận diện hoặc kiểm chứng độc lập mới.

## Cập nhật 2026-10-25: chốt lượt nguồn ngoài và audit v6

Hoàn tất 30 bản ghi mới/24 nguồn cha, reviewer AI: 12 confirmed, 12 dismissed, 6 uncertain trong setup text-only. Tái dựng/parser/token/mask/collator 60/60. Kho hiện 117 bản ghi/111 parent ID/58 nhóm heuristic, không coi là các nguồn độc lập. Đã lưu ranh giới nhóm và [báo cáo](../reports/mo-rong-nguon-ngoai-va-chot-audit-verifier.md). 18 bản InjecAgent giữ chung nhóm; bước kế tiếp ưu tiên tiếng Việt, tài liệu dài và family tấn công khác. Chưa chia tập/train/holdout độc lập; **Ưu tiên 1 vẫn mở**.

## Cập nhật 2026-10-25: tiếng Việt và nền tài liệu dài

Thêm 30 bản ghi window-only/6 nền bài công khai, revision/hash/ghi công CC BY-SA; phần chèn tự soạn ghi riêng. Parser/token/mask/collator đạt 60/60. Kho có 147 bản ghi/117 parent ID/64 nhóm; không gán sạch toàn bộ bài dài. Selection trước AI giữ đủ cửa sổ Balanced 3/6, Deep 5/6. Ca vi-article-012 còn thiếu dù chọn 24/27 chunk, đã lưu baseline/code trước sửa. Xem [báo cáo](../reports/bo-sung-tieng-viet-tai-lieu-dai-va-do-coverage.md). Bước tiếp: sửa coverage có đối chứng/biến thể và đo pipeline tương ứng; **Ưu tiên 1 chưa hoàn thành**, chưa train/split/holdout độc lập.

## Cập nhật 2026-10-25: thử selector và baseline pipeline

Ứng viên rải đều giúp ca Deep mục tiêu nhưng Balanced giảm đủ ngữ cảnh 15/30 xuống 10/30; probe 80/108 không đổi, nên giữ mặc định. Baseline core 6 ca có 3 completed/3 lỗi response, 5 needs_review/1 not_detected, không attack nào được confirmed. Chưa chạy pipeline ứng viên bị loại. Xem [báo cáo](../reports/thu-selector-rai-deu-va-baseline-pipeline.md). Bước tiếp: thiết kế đọc tiếp phần chưa xử lý với ngân sách/timeout rõ và policy cần xem xét. **Ưu tiên 1 chưa hoàn thành**, chưa train/phản biện.


## Cập nhật 2026-10-26: rà bốn tài liệu Việt gốc

Hoàn tất kiểm tra hash/extraction và baseline prefilter/selection: bốn file
khớp snapshot, tổng 161 chunk; quét chung Balanced chọn 12, Deep chọn 24.
DOCX văn thư có 56 media entry; PDF có trang rất ít hoặc không có chữ,
cần kiểm tra trực quan và metadata trước chốt phạm vi nhãn. Đã rà sơ bộ
các cờ riêng tư nhưng chưa phê duyệt toàn bộ; quyền train/tái phân phối
vẫn chưa xác minh. Xem [báo cáo](../reports/ra-tai-lieu-viet-goc-va-do-bao-phu.md).
Chưa gọi model, chưa tạo biến thể/train/holdout; **Ưu tiên 1 vẫn mở**.


## Cập nhật 2026-10-26: rà ảnh và metadata có mục tiêu

Đã xem chín trang PDF và năm contact sheet/56 ảnh DOCX; xác nhận chữ trong
ảnh ở bìa/trang cuối PDF bị extractor bỏ qua, ảnh văn thư có tên/tài khoản
chưa xác minh thật hay demo. Không coi tài liệu gốc là đối chứng sạch đã
phê duyệt. Xem [báo cáo](../reports/ra-anh-metadata-va-pham-vi-tai-lieu-viet.md).
Bước tiếp: đối chứng PDF/DOCX tự soạn, tách chữ thật/chữ trong ảnh, đo
độ bao phủ trước quyết định nâng cấp. Chưa thêm OCR/train/gọi model;
**Ưu tiên 1 vẫn mở**.
