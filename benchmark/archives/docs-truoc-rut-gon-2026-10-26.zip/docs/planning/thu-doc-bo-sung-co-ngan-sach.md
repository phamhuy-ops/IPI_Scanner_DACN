# Thử đọc bổ sung có ngân sách

Ngày 2026-10-25. Đây là nhánh thí nghiệm của Ưu tiên 1; chưa bật trong UI.

## Lỗi cần giải quyết

Selector có thể bỏ qua đoạn cuối. Ứng viên rải đều đã bị loại vì hồi quy.
`aiReviewedChunks` hiện là số đoạn được chọn, không phải số đoạn hai model
đã trả phản hồi hợp lệ. Giữ baseline cũ và không thay nghĩa trường này ở UI.

## Thiết kế khóa trước khi thử

- Scanner chỉ trả thêm toàn bộ catalogue khi gọi rõ `includeSemanticChunkCatalog`.
- Bộ điều phối riêng đọc tập được chọn trước, sau đó đoạn chưa chọn theo thứ tự
  catalogue; mỗi đoạn tối đa một lượt Detector rồi Verifier. Không phản biện/retry.
- Alias được gán một lần trên toàn catalogue. Không dùng nhãn hoặc đáp án để chọn.
- Bắt buộc truyền ngân sách: tối đa 64 chat request, 24 đoạn bổ sung,
  thời hạn phân tích tối đa 180 giây. Mọi lần fallback endpoint đều tính request.
- Mỗi request chỉ có một đoạn để giữ tiến độ khi đoạn sau lỗi. Cả đối chứng
  không đọc thêm và ứng viên phải dùng cùng giao thức này; không so trực tiếp
  với batching mặc định để kết luận cải thiện.
- Sổ tiến độ ghi riêng đoạn được chọn, Detector hợp lệ, Verifier hợp lệ và
  hoàn tất cả hai. Hợp lệ giao thức chưa chứng minh hiểu đúng ngữ cảnh.
- Dừng khi lỗi/thiếu ngân sách/quá hạn; giữ phần thành công trước đó. Thiếu
  coverage hoặc lỗi không được kết luận `not_detected`. Bằng chứng được cả hai
  xác nhận vẫn theo policy hiện tại, kèm hạn chế còn lại.
- Timeout HTTP được truyền xuống bridge; giới hạn điều phối không bảo đảm
  server đã hủy inference ngay. Cleanup giải phóng model tính riêng, có hạn.

## Kiểm tra và điều kiện chuyển bước

Baseline trước sửa: 77/77 kiểm thử scanner/pipeline đạt bằng lệnh
`npm test -- src/ai/agents/document/ipiPipeline.test.ts engine/scanner/ipi-doc-scan.test.js`.

Kiểm tra catalogue mặc định, alias/không lặp, tiến độ từng vai trò, fallback,
request/time budget, lỗi JSON, HTML và đối chứng sạch/tấn công. Phép thử giả lập
chỉ chứng minh điều phối/policy, không phải recall bảo mật. Sau kiểm tra kỹ thuật,
đo cùng đầu vào qua model thật và dữ liệu độc lập trước cân nhắc đưa vào UI.
Không train hoặc thay cấu hình mặc định trong bước này. Ưu tiên 1 vẫn mở.
