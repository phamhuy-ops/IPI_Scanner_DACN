# Rà khoảng trống và điều kiện chia tập

Ngày 2026-10-25. Chỉ lập registry và ràng buộc; không tạo train/dev/holdout.

- Tái dựng 178 bản ghi ngoài legacy từ đúng phiên bản đang dùng. Sáu bản
  gap đã sửa phải trỏ bản sửa; 30 nhãn bài Việt chỉ áp dụng cửa sổ đã duyệt.
- Tách bản ghi, parent ID và nhóm sau audit v9; không đếm cửa sổ, bản dịch,
  bản định dạng hoặc base/enhanced là nguồn độc lập mới.
- Đối chiếu nhóm với baseline 72 ca, manifest chẩn đoán và cờ dev/overlap.
  Không có cờ không chứng minh chưa lộ; chỉ ghi là cần xét vai trò riêng.
- Kiểm tra nhãn/span/hash, nguồn, reviewer, ngôn ngữ, định dạng, độ dài toàn
  nguồn và phạm vi có nhãn. Đếm file PDF/DOCX vật lý trong benchmark/data và
  benchmark/fixtures; không coi xuất text thành PDF/DOCX là tài liệu thực mới.
- Báo thiếu hụt theo kế hoạch 300 bản ghi/100 nhóm và từng stance/ngôn ngữ,
  nhưng không dùng đủ số lượng để tự cấp quyền train.
- Giữ trạng thái training_eligible=false và không xuất input/target SFT.
  Lập danh sách nguồn bên ngoài cần bổ sung và thư mục nhận file công khai
  kèm URL/license, tách khỏi tập đã duyệt. Không tự dùng tài liệu Downloads.

Kiểm tra registry giữ mỗi parent/phiên bản một lần, nhóm dính dev không
được cấp vai trò holdout, và cách đếm độ dài không biến nhãn cửa sổ thành
nhãn toàn tài liệu. Không chạy model hoặc thay runtime ở lượt này.
