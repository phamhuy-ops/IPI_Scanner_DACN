# Chuẩn hóa nhãn người nhận chỉ dẫn cho Verifier

Ngày 2026-10-25. Không đổi runtime, không train hoặc tạo split.

## Phạm vi đã chốt trước xử lý

- Giữ nguyên tám ca chẩn đoán đã khóa; đối chiếu cách gán nhãn với những
  mẫu cũ có phiếu người dùng duyệt và hash đúng, không chuyển xác nhận đó
  thành xác nhận cho câu chữ mới.
- Bảy ca đủ ngữ cảnh để chuẩn hóa; cc-02 bị cắt đầu giữa câu nên cách ly,
  không tự sửa text hoặc dùng nó làm nhãn mẫu đầy đủ.
- Nhãn do AI đánh giá: xác định addressee, framing, deviation, hasDirective,
  stance, span chỉ dẫn và toàn ngữ cảnh. Câu công việc cho người vẫn có
  hasDirective=true, nhưng dismissed/human/active/none.
- Ví dụ trích dẫn vẫn có chỉ dẫn hướng AI trong câu được trích, nhưng
  framing=quoted_example và dismissed; giữ đủ câu bao khung.
- Gom cả sáu biến thể Anh/Việt cùng một family xuyên ngôn ngữ. Hai ca bài
  năng lượng cùng page nguồn cũ. Không coi mỗi biến thể là nguồn độc lập.
- Đây là dữ liệu đã lộ qua chẩn đoán dev: training_eligible=false, split=null.
  Chưa nhập vào train hoặc gọi là holdout độc lập.

## Kiểm tra dự kiến

Tái dựng hash và span duy nhất, kiểm tra schema/ngữ nghĩa cơ học; chuẩn hóa
bằng normalizer hiện có ở hai chế độ có/không có nghi vấn. Kiểm tra parser
thật, token/chat template/mask/collator bằng Python trên E, không tải weights.
Audit từ vựng/trùng và nhóm toàn kho bằng phiên bản mới; giữ audit v7 cũ.
Không ghi nhãn/gold vào model input. Ghi rõ mất ngữ cảnh, quan hệ với dữ liệu
đã đo và hạn chế độc lập trước lựa chọn dữ liệu tiếp theo.
