# Duyệt batch Verifier đầu tiên

Đợt đầu đã duyệt xong 30/30 mẫu. Xem
[tổng kết sau duyệt](../../benchmark/data/annotations/verifier-batch-v1/tong-ket-ra-soat.md).
Kiểm tra đáp án cuối bằng `node scripts/audit-reviewed-verifier-batch.cjs`;
các lệnh tái lập nháp bên dưới mô tả giai đoạn trước duyệt.

Đây là bộ 30 mẫu tự soạn để thử quy trình nhãn và JSON `compact-v1`,
chưa phải dữ liệu được phép đưa vào huấn luyện. Bộ 20 mẫu đã duyệt trước
được giữ riêng làm tham chiếu cách gán nhãn.

Mở [phiếu duyệt](../../benchmark/data/annotations/verifier-batch-v1/phieu-ra-soat.md).
Mỗi lần đọc toàn bộ nguồn của một mẫu và kiểm tra: chỉ dẫn hướng tới ai,
là lệnh thực thi hay ví dụ/trích dẫn, có kéo AI lệch nhiệm vụ không,
và có đủ ngữ cảnh để kết luận không. Có thể chấp nhận, sửa hoặc loại mẫu;
mọi quyết định phải gắn đúng ID, phiên bản nguồn, người duyệt và thời điểm.
Chưa nhận quyết định thì giữ `pending`, không suy từ đồng ý với mẫu khác.

Nhãn nháp gồm 12 malicious/confirmed, 12 benign/dismissed và 6 uncertain;
15 mẫu tiếng Việt, 15 tiếng Anh, 10 nhóm tình huống. Các biến thể cùng nhóm
phải đi cùng tập khi chia dữ liệu sau này. Không dùng `uncertain` để che
bất đồng gán nhãn chưa giải quyết.

Đầu vào ở `dau-vao/` chỉ chứa prompt/schema và nguồn trung tính. Metadata,
nhãn và đáp án nháp được lưu riêng. 18 mẫu có nghi vấn mô phỏng ở dòng
không rỗng thứ hai; 12 mẫu không có nghi vấn. Quy tắc này cố định trước
nhãn, nhưng không đại diện phân bố finding của Detector thật. Risk và
rule count được tính bằng scanner hiện tại. Prompt tiếng Anh được giữ
nguyên để kiểm tra tương thích với hợp đồng Verifier đang thử nghiệm.

Chạy `npm run data:verifier:check` để so toàn bộ tài sản với bản nháp tái
lập và chạy parser thật. Lệnh này chỉ dành cho bản nháp chưa chỉnh sửa;
sau khi duyệt/sửa, khác biệt là có chủ đích, không chạy lại prepare để
ghi đè. Cần lưu lịch sử quyết định và kiểm tra đáp án cuối bằng parser
trước khi xuất dữ liệu huấn luyện.

Kiểm thử công cụ: `npm test -- scripts/verifier-batch.test.ts`.
Parser hợp lệ chỉ chứng minh cấu trúc và liên kết trích dẫn, không chứng
minh nhãn đúng hoặc model phát hiện tốt. Bộ này chỉ có nguồn ngắn và
HTML thô; chưa kiểm tra tài liệu dài, PDF/DOCX, tokenizer/mask hoặc toàn
pipeline. Không có trùng toàn văn chuẩn hóa với bộ 20 cũ; chưa hoàn tất
rà gần trùng/ngữ nghĩa với toàn bộ kho. Chưa chia train/dev/test, chưa
huấn luyện, chưa có holdout độc lập. Cache/weights/checkpoint huấn luyện
vẫn dùng E; các mẫu gán nhãn nhỏ nằm cùng dự án trên C.
