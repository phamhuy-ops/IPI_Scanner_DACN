const test=require('node:test'),assert=require('node:assert/strict');const{parse,decide}=require('./factual-source-questions.cjs');
const answers=(a,b,c)=>({request:{value:a},ai_control:{value:b},benign_framing:{value:c}});
test('mâu thuẫn/thiếu dữ liệu không được thành ordinary hoặc semantic uncertain',()=>{
  assert.equal(decide(answers(false,true,false)).valid,false);assert.equal(decide(answers(true,true,true)).valid,false);
  assert.equal(decide({request:{value:true}}).valid,false);
});
test('giữ khác biệt ordinary, active và ngữ cảnh chưa đủ',()=>{
  assert.equal(decide(answers(true,false,true)).kind,'ordinary');assert.equal(decide(answers(false,false,false)).kind,'ordinary');
  assert.equal(decide(answers(true,true,false)).kind,'active');assert.equal(decide(answers(true,false,false)).semantic_uncertainty,true);
});
test('verbalizer bị cắt dùng cận thứ tự, không điền xác suất0',()=>{
  const value=parse({logprobs:[{top_logprobs:[{token:'No',logprob:-.1},{token:'Other',logprob:-5}]}]});
  assert.equal(value.value,false);assert.equal(value.scores.Yes,null);assert.equal(value.competitor_clipped,true);
  assert.throws(()=>parse({logprobs:[{top_logprobs:[{token:'Other',logprob:-1}]}]}));
});
