// Tổng hợp thí nghiệm đã chạy, không chạy model và không đọc lại tài liệu riêng.
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { summarize } = require('./round-one-metrics.cjs');
const root = path.resolve(__dirname, '..');
const sha = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const fixtures = Object.fromEntries(['clean', 'attack', 'quoted'].map(id => [
  sha(path.join(root, `benchmark/fixtures/demo-output-v1/${id}.txt`)),
  { id, label: id === 'attack' ? 'malicious' : 'benign', group: id === 'clean' ? 'human-workshop' : 'quoted-directive' },
]));
const scriptHash = sha(path.join(root, 'scripts/diagnose-document-demo.cjs'));
const runs = [];
for (const entry of fs.readdirSync(path.join(root, 'benchmark/results'), { withFileTypes: true })) {
  if (!entry.isDirectory() || !entry.name.startsWith('document-demo-')) continue;
  const dir = path.join(root, 'benchmark/results', entry.name);
  const file = path.join(dir, 'ket-qua.json');
  if (!fs.existsSync(file)) continue;
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (data.versions?.code_sha256?.['scripts/diagnose-document-demo.cjs'] !== scriptHash ||
    data.configuration?.reviewContract !== 'referenced-v1' || data.bounded_experiment) continue;
  const fixture = fixtures[data.file_sha256];
  if (!fixture && data.configuration.scanProfile !== 'deep') continue;
  const calls = JSON.parse(fs.readFileSync(path.join(dir, 'model-calls.json'), 'utf8'));
  const cap = data.configuration.referenceBatchSize;
  if (cap !== undefined && cap !== 1) throw new Error('Có cấu hình ngoài kế hoạch.');
  runs.push({ ...(fixture || { id: 'private-word', label: null, group: null }),
    variant: cap === 1 ? 'single' : 'reference', artifact: path.relative(root, dir),
    input_sha256: data.file_sha256, processing: data.processingStatus, verdict: data.check.verdict,
    error: data.error, elapsed_ms: data.elapsed_ms, seconds: data.elapsed_ms / 1000,
    configuration: data.configuration, coverage: data.coverage, calls: calls.length,
    first_request_sha256: calls[0]?.request_sha256,
    model_call_ms: calls.reduce((sum, row) => sum + row.elapsed_ms, 0) });
}
for (const id of ['clean', 'attack', 'quoted', 'private-word']) for (const variant of ['reference', 'single']) {
  if (runs.filter(row => row.id === id && row.variant === variant).length !== 1) throw new Error(`Cần đúng một lượt ${id}/${variant}; không tự chọn lượt đẹp.`);
}
const metrics = list => {
  const result = summarize(list), p = result.precision_of_alerts, r = result.confirmed_attack_recall;
  return { ...result, f1_alert_recall: p === null || r === null ? null : p + r ? 2 * p * r / (p + r) : 0 };
};
const codeFiles = ['scripts/diagnose-document-demo.cjs', 'scripts/summarize-single-chunk.cjs',
  'src/ai/agents/document/ipiPipeline.ts', 'src/ai/agents/document/detectorAgent.ts',
  'src/ai/agents/document/verifierAgent.ts', 'src/ai/agents/document/sourceReferences.ts',
  'src/ai/agents/document/reviewPolicy.ts', 'src/ai/agents/document/referencePrompts.ts',
  'src/ai/agents/document/compactVerifier.ts', 'src/ai/agents/document/evidence.ts', 'src/ai/agents/slmClient.ts'];
const result = { version: 1, decision: 'not_promoted', seed: null, temperature: 0,
  scope: 'Dev chẩn đoán, không có nguồn độc lập hoặc holdout; không thay mặc định UI.',
  code_sha256: Object.fromEntries(codeFiles.map(file => [file, sha(path.join(root, file))])), runs,
  metrics: Object.fromEntries(['reference', 'single'].map(variant => {
    const rows = runs.filter(row => row.variant === variant && row.label !== null);
    return [variant, { overall: metrics(rows), per_group: Object.fromEntries([...new Set(rows.map(row => row.group))]
      .map(group => [group, metrics(rows.filter(row => row.group === group))])) }];
  })),
  controls_have_identical_first_request: ['clean', 'attack', 'quoted'].every(id => {
    const pair = runs.filter(row => row.id === id);
    return pair[0].first_request_sha256 === pair[1].first_request_sha256;
  }),
  limitations: ['Ba fixture đều chỉ một chunk; không đo tác động batching trên các fixture này.',
    'File Word chưa có nhãn toàn tài liệu; không tính vào confusion matrix.',
    'Mỗi cấu hình một lượt, không có ý nghĩa thống kê.', 'Chưa đo peak RAM/VRAM hoặc UI/Electron.',
    'Số chunk được chọn không đồng nghĩa số chunk hai model đã xử lý thành công.',
    'calls và model_call_ms chỉ gồm HTTP đã nhận phản hồi; không đếm request bị hủy do timeout. elapsed_ms gồm cả thời gian chờ thất bại và cleanup.',
    'needs_review tách khỏi TP/FP/TN/FN; recall dùng mọi mẫu malicious, FPR dùng mọi mẫu benign.'] };
const output = path.join(root, 'benchmark/experiments/single-chunk-reference-v1/ket-qua.json');
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ output, decision: result.decision, runs: runs.map(row => ({ id: row.id, variant: row.variant,
  processing: row.processing, verdict: row.verdict, calls: row.calls, elapsed_ms: row.elapsed_ms })) }, null, 2));
