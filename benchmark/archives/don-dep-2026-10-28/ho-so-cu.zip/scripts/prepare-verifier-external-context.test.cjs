const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-external-context.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');

test('giữ đoạn RST gốc và gom attack tự soạn cùng parent thay vì tăng nguồn độc lập', () => {
  const rows = buildRows();
  assert.equal(rows.length, 24);
  const python = rows.filter(row => row.source.startsWith('python/'));
  assert.equal(new Set(python.map(row => row.source_parent_id)).size, 6);
  for (let index = 0; index < python.length; index += 2) {
    const clean = python[index], injected = python[index + 1];
    assert.equal(clean.group_id, injected.group_id); assert.equal(clean.source_parent_id, injected.source_parent_id);
    assert.equal(injected.text.slice(0, clean.text.length), clean.text);
    assert.equal(injected.provenance.authored_injection, true);
    assert.equal(clean.annotation.addressee, 'human'); assert.equal(clean.annotation.stance, 'dismissed');
    assert.equal(injected.annotation.stance, 'confirmed');
  }
});
test('base uncertain không dùng nhãn benchmark làm stance và giữ base/enhanced cùng parent', () => {
  const rows = buildRows();
  const injec = rows.filter(row => row.source === 'uiuc-kang-lab/InjecAgent');
  assert.equal(injec.length, 12);
  for (let index = 0; index < injec.length; index += 2) {
    const base = injec[index], enhanced = injec[index + 1];
    assert.equal(base.annotation.stance, 'uncertain'); assert.ok(base.annotation.uncertainty_notes.length);
    assert.equal(base.provenance.source_label_context_disagreement, true);
    assert.equal(base.source_parent_id, enhanced.source_parent_id); assert.equal(base.group_id, enhanced.group_id);
    assert.equal(enhanced.annotation.stance, 'confirmed');
  }
  for (const row of rows) { assert.deepEqual(validateAnnotation(row.text, row.annotation), []); assert.equal(row.training_eligible, false); assert.equal(row.human_approved, false); }
});
