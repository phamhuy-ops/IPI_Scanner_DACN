const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const { buildRows } = require('./prepare-verifier-external-context.cjs');
const root = path.resolve(__dirname, '..');
const dir = path.join(root, 'benchmark/data/annotations/verifier-external-context-v1');
async function main() {
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json')));
  for (const [file, digest] of Object.entries(manifest.assets_sha256)) assert.equal(hash(fs.readFileSync(path.join(dir, file))), digest);
  for (const [file, digest] of Object.entries(manifest.code_sha256)) assert.equal(hash(fs.readFileSync(path.join(root, file))), digest);
  for (const [file, digest] of Object.entries(manifest.source_snapshot_sha256)) assert.equal(hash(fs.readFileSync(path.join(root, file))), digest);
  const rows = fs.readFileSync(path.join(dir, 'mau-cho-duyet.jsonl'), 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  assert.deepEqual(rows, buildRows());
  const examples = JSON.parse(fs.readFileSync(path.join(dir, 'ban-xem-truoc.json'))).examples;
  const reviews = JSON.parse(fs.readFileSync(path.join(dir, 'danh-gia-ai.json'))).reviews;
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  let valid = 0;
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const example of examples) {
      const row = rows.find(row => row.id === example.source_record_id), review = reviews.find(review => review.id === row.id);
      assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
      assert.equal(row.training_eligible, false); assert.equal(example.training_eligible, false); assert.equal(row.human_approved, false);
      assert.equal(review.input_sha256, row.input_sha256); assert.equal(review.annotation_sha256, hash(JSON.stringify(row.annotation)));
      const rendered = renderDraft({ text: row.text, format: row.format, candidate_mode: example.mode }, row.annotation);
      assert.deepEqual(example.target, rendered.response); assert.deepEqual(example.payload, rendered.payload);
      for (const metadata of [row.id, row.source_parent_id, row.group_id, 'source_label_context_disagreement', 'training_eligible']) {
        assert.equal(example.payload.messages.some(message => message.content.includes(metadata)), false);
      }
      assert.equal(rendered.validation.parser_valid, true); valid++;
    }
  } finally { await server.close(); }
  const result = { records: rows.length, payloads_rebuilt_and_parser_valid: valid, metadata_excluded: true, source_hashes_unchanged: true,
    labels: Object.fromEntries(['confirmed', 'dismissed', 'uncertain'].map(value => [value, rows.filter(row => row.annotation.stance === value).length])),
    languages: Object.fromEntries([...new Set(rows.map(row => row.language))].map(value => [value, rows.filter(row => row.language === value).length])),
    source_parent_ids: new Set(rows.map(row => row.source_parent_id)).size,
    unchanged_external_records: rows.filter(row => !row.provenance.authored_injection).length,
    synthetic_attacks: rows.filter(row => row.provenance.authored_injection).length,
    training_ready: false, final_split_created: false, model_called: false,
    code_sha256: hash(fs.readFileSync(__filename)), note: 'Chỉ kiểm tra cơ học; ngữ nghĩa do AI đánh giá, không phải xác nhận độc lập.' };
  fs.writeFileSync(path.join(root, 'benchmark/experiments/verifier-external-context-v1/kiem-tra-tai-dung.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(result));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
