"""Kiến trúc PIGuard đã rà soát, dùng code local thay vì trust_remote_code.

Theo modeling_piguard.py của leolee99/PIGuard, MIT, commit
 dd78b24e330193a22d2293ac66922dd4f982f563.
Giữ phép lấy hidden state token đầu rồi Linear; không dùng ContextPooler cho logits.
"""
import torch
from transformers import DebertaV2Config, DebertaV2ForSequenceClassification
from transformers.modeling_outputs import SequenceClassifierOutput


class ReviewedPIGuard(DebertaV2ForSequenceClassification):
    config_class = DebertaV2Config

    def __init__(self, config):
        super().__init__(config)
        self.classifier = torch.nn.Linear(config.hidden_size, config.num_labels)

    def forward(self, input_ids, attention_mask, **kwargs):
        outputs = self.deberta(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=False)
        return SequenceClassifierOutput(logits=self.classifier(outputs.last_hidden_state[:, 0, :]))
