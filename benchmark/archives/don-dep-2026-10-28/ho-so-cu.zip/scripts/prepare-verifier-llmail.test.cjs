const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { buildRows } = require('./prepare-verifier-llmail.cjs');

test('mở rộng cửa sổ không thay đổi 12 nguồn/nhãn LLMail đã khóa', () => {
  const previous = fs.readFileSync('benchmark/data/annotations/verifier-llmail-v1/mau-cho-duyet.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  assert.deepEqual(buildRows(), previous);
});

test('mẫu thiếu ngữ cảnh giữ uncertain và chuỗi mã hóa nguyên bản, không lấy nhãn nguồn', () => {
  const rows = buildRows('benchmark/experiments/llmail-expansion-v1/nhap-nhan-ngu-canh-ai.json');
  const unknown = rows.find(r => r.id === 'llmail-phase2-044');
  assert.equal(unknown.annotation.stance, 'uncertain');
  assert.equal(unknown.annotation.addressee, 'unclear');
  assert.ok(unknown.provenance.source_label_context_disagreement);
  assert.ok(unknown.window_annotation.directive_spans[0].quote.startsWith("b'"));
  assert.ok(unknown.annotation.uncertainty_notes.length);
  assert.ok(rows.every(r => !r.training_eligible && !r.human_approved && r.split === null));
});

test('cửa sổ bỏ hậu tố vẫn giữ focus và đánh dấu chỉ nhãn cửa sổ', () => {
  const row = buildRows('benchmark/experiments/llmail-expansion-v1/nhap-nhan-ngu-canh-ai.json').find(r => r.id === 'llmail-phase2-041');
  assert.equal(row.selected_window.start, 0);
  assert.ok(row.selected_window.end < row.text.length);
  assert.equal(row.annotation_scope, 'selected_window_only');
  assert.ok(row.selected_window.text.includes(row.window_annotation.directive_spans[0].quote));
});
