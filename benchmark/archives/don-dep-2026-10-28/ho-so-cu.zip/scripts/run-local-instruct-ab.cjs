// Phương án Verifier đã trượt cổng; giữ raw và snapshot, không tự chạy lại.
console.error('Đối chứng Instruct ở Verifier đã bị loại: độ đúng 25% -> 20%, lỗi tăng. Xem benchmark/results/local-instruct-comparison-GGzers. Không gọi model hoặc đổi mặc định.');
process.exitCode = 1;
