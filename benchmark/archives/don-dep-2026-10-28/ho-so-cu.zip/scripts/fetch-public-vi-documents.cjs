const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { extractDocumentText } = require('../engine/document/extractors/document-text-extractor');
const root = path.resolve(__dirname, '..');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const definitions = [
  { id: 'vi-native-001', file: 'huong-dan-cong-thong-tin-truong-hoc-ha-noi.pdf', group: 'hanoi-school-portal-guide',
    title: 'Tài liệu hướng dẫn sử dụng cổng thông tin trường học', publisher: 'Cổng admintruong.hanoi.edu.vn',
    sourcePage: 'https://admintruong.hanoi.edu.vn/Tailieuhuongdancongthongtin.pdf',
    download: 'https://admintruong.hanoi.edu.vn/Tailieuhuongdancongthongtin.pdf' },
  { id: 'vi-native-002', file: 'huong-dan-oms-vien-han-lam.pdf', group: 'vast-oms-guide',
    title: 'Tài liệu hướng dẫn sử dụng OMS', publisher: 'Viện Hàn lâm Khoa học và Công nghệ Việt Nam — cổng isi.vast.vn',
    sourcePage: 'https://isi.vast.vn/OMS/upload/default/Tailieuhuongdan.pdf', download: 'https://isi.vast.vn/OMS/upload/default/Tailieuhuongdan.pdf' },
  { id: 'vi-native-003', file: 'huong-dan-hoi-quy-van-thu-luu-tru-phu-tho.docx', group: 'phutho-guide-4835',
    title: 'Tài liệu hướng dẫn lĩnh vực tổ chức phi chính phủ và văn thư lưu trữ', publisher: 'Sở Nội vụ tỉnh Phú Thọ',
    sourcePage: 'https://sonoivu.phutho.gov.vn/Chuyen-muc-tin/Chi-tiet-tin/tabid/92/title/4835/ctitle/3/language/vi-VN/Default.aspx',
    filenamePattern: /Tai%20lieu%20huong%20dan.*\.docx$/i },
  { id: 'vi-native-004', file: 'cong-van-giao-duc-son-tay-thuong.docx', group: 'sontaythuong-cv-371-2025',
    title: 'Công văn 371/UBND về triển khai hướng dẫn sử dụng và dạy học tài liệu giáo dục địa phương cấp THCS năm học 2025–2026', publisher: 'UBND xã Sơn Tây Thượng, Quảng Ngãi',
    sourcePage: 'https://sontaythuong.quangngai.gov.vn/van-ban/v-v-trien-khai-huong-dan-su-dung-va-day-hoc-tai-lieu-giao-duc-dia-phuong-tinh-quang-ngai-cap-thcs-nam-hoc-2025-2026.html',
    filenamePattern: /vv%20tri.*\.docx$/i },
  { id: 'vi-native-005', file: 'cong-van-giao-duc-son-tay-thuong.pdf', group: 'sontaythuong-cv-371-2025',
    title: 'Bản PDF của cùng Công văn 371/UBND', publisher: 'UBND xã Sơn Tây Thượng, Quảng Ngãi',
    sourcePage: 'https://sontaythuong.quangngai.gov.vn/van-ban/v-v-trien-khai-huong-dan-su-dung-va-day-hoc-tai-lieu-giao-duc-dia-phuong-tinh-quang-ngai-cap-thcs-nam-hoc-2025-2026.html',
    filenamePattern: /vv%20tri.*\.pdf$/i },
];

async function get(url, maxBytes) {
  const response = await fetch(url, { signal: AbortSignal.timeout(45000) });
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
  if (Number(response.headers.get('content-length')) > maxBytes) throw new Error('File vượt giới hạn tải đã đặt.');
  const reader = response.body.getReader(); const chunks = []; let size = 0;
  while (true) {
    const { done, value } = await reader.read(); if (done) break;
    size += value.length;
    if (size > maxBytes) { await reader.cancel(); throw new Error('Nội dung vượt giới hạn tải.'); }
    chunks.push(Buffer.from(value));
  }
  return { bytes: Buffer.concat(chunks), finalUrl: response.url, contentType: response.headers.get('content-type'),
    lastModified: response.headers.get('last-modified'), etag: response.headers.get('etag') };
}

async function main() {
  const output = path.join(root, 'benchmark/data/incoming/public-vi-documents/nguon-vi-v1');
  if (fs.existsSync(output)) throw new Error('Đã có đợt tải; không ghi đè.');
  const pages = new Map(), records = [];
  let totalBytes = 0;
  fs.mkdirSync(output);
  for (const item of definitions) {
    const record = { id: item.id, filename: item.file, title: item.title, hosting_publisher: item.publisher,
      source_page: item.sourcePage, parent_id: item.group, language: 'vi',
      status: 'pending_download', security_label: null, privacy_review: 'pending',
      reuse_permission: { status: 'not_verified', license: null, note: 'Nguồn chính thức/công khai không tự chứng minh quyền dùng lại cho train hoặc phát hành dataset.' },
      training_eligible: false, final_split: null, independent_holdout_verified: false };
    try {
      let url = item.download;
      if (!url) {
        if (!pages.has(item.sourcePage)) pages.set(item.sourcePage, await get(item.sourcePage, 4 * 1024 * 1024));
        const html = pages.get(item.sourcePage).bytes.toString('utf8');
        const links = [...html.matchAll(/href\s*=\s*["']([^"']+)["']/gi)].map(match => new URL(match[1].replaceAll('&amp;', '&'), item.sourcePage).href);
        const found = [...new Set(links.filter(link => item.filenamePattern.test(link)))];
        if (found.length !== 1) throw new Error('Không xác định được URL file duy nhất từ trang nguồn.');
        url = found[0]; record.source_page_sha256 = hash(pages.get(item.sourcePage).bytes);
      }
      const download = await get(url, 20 * 1024 * 1024);
      totalBytes += download.bytes.length;
      if (totalBytes > 50 * 1024 * 1024) throw new Error('Vượt ngân sách 50 MiB của đợt tải.');
      const expected = item.file.endsWith('.pdf') ? '%PDF-' : 'PK';
      if (!download.bytes.subarray(0, expected.length).equals(Buffer.from(expected))) throw new Error('Chữ ký file không khớp PDF/DOCX; không lưu HTML giả file.');
      fs.writeFileSync(path.join(output, item.file), download.bytes, { flag: 'wx' });
      Object.assign(record, { status: 'downloaded_pending_rights_and_annotation', download_url: url, final_url: download.finalUrl,
        content_type: download.contentType, last_modified: download.lastModified, etag: download.etag,
        bytes: download.bytes.length, sha256: hash(download.bytes), file_signature_verified: true });
      const extracted = await extractDocumentText(path.join(output, item.file));
      record.extraction = { ok: extracted.ok, error: extracted.error || null, characters_utf16: extracted.text?.length || 0,
        text_sha256: extracted.ok ? hash(Buffer.from(extracted.text)) : null,
        contains_replacement_characters: extracted.ok ? extracted.text.includes('\uFFFD') : null,
        manual_quality_review_required: true };
      if (extracted.ok) fs.writeFileSync(path.join(output, item.id + '-van-ban.txt'), extracted.text, { flag: 'wx' });
    } catch (error) { record.status = 'download_or_extraction_failed'; record.error = error.message; }
    records.push(record);
    console.log(JSON.stringify({ id: record.id, status: record.status, bytes: record.bytes, extraction: record.extraction, error: record.error }));
  }
  for (const [index, [url, page]] of [...pages].entries()) {
    fs.writeFileSync(path.join(output, `trang-nguon-${index + 1}.html`), page.bytes, { flag: 'wx' });
  }
  const manifest = { created_at: new Date().toISOString(), status: records.every(record => record.extraction?.ok) ? 'downloaded_pending_review' : 'partial',
    files: records, original_document_groups: new Set(records.filter(record => record.extraction?.ok).map(record => record.parent_id)).size,
    records_added_to_annotations: 0, training_ready: false, model_called: false, source_code_executed: false,
    code_sha256: hash(fs.readFileSync(__filename)),
    note: 'Chỉ intake và kiểm tra extraction cục bộ. Chưa xác minh quyền train/tái phân phối, chưa gán nhãn sạch hoặc tạo holdout.' };
  fs.writeFileSync(path.join(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ output: path.relative(root, output), files: records.length, extraction_ok: records.filter(record => record.extraction?.ok).length, original_groups: manifest.original_document_groups, total_bytes: totalBytes }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
