const { test } = require('node:test');
const assert = require('node:assert/strict');
const { hash } = require('./context-annotations.cjs');
const { verify } = require('./freeze-verifier-pilot.cjs');
test('Khóa hash chặn thay dữ liệu, kể cả thay dev/probe sau khi chốt', () => {
  const lock = { locked_files_sha256: { train: hash('a'), dev: hash('b'), probe: hash('c') } };
  const values = { train: 'a', dev: 'b', probe: 'c' };
  assert.equal(verify(lock, f => values[f]), true);
  values.dev = 'khác';
  assert.throws(() => verify(lock, f => values[f]), /dev/);
});
