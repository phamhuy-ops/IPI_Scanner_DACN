const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { pickBoundary, buildRows } = require('./prepare-vietnamese-articles.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
const { covers } = require('./audit-vietnamese-articles.cjs');
test('coverage hợp các chunk: cho phép chồng lấn nhưng không bỏ qua khe hở', () => {
  assert.equal(covers([{ start: 0, end: 10 }, { start: 8, end: 20 }], 3, 19), true);
  assert.equal(covers([{ start: 0, end: 10 }, { start: 11, end: 20 }], 3, 19), false);
  assert.equal(covers([{ start: 4, end: 20 }], 3, 19), false);
});
test('không cắt từ/Unicode và từ chối ngữ cảnh không vừa thay vì truncate', () => {
  const before = 'Một đoạn văn tiếng Việt có ký tự 😀 được giữ nguyên đến hết câu.';
  const after = 'Đoạn tiếp theo vẫn có đủ chủ ngữ và nội dung để đọc riêng một câu.';
  const text = before + '\n' + after;
  const b = pickBoundary(text, 300, 0.5);
  assert.equal(text.slice(0, b.cut), before);
  assert.equal(text.slice(b.cut), '\n' + after);
  assert.throws(() => pickBoundary('a'.repeat(1000) + '\n' + after, 300, 0.5));
});
test('mọi biến thể giữ nền gốc, ánh xạ span và scope cửa sổ, không tạo thêm parent', () => {
  const rows = buildRows();
  assert.equal(rows.length, 30);
  assert.equal(new Set(rows.map(r => r.source_parent_id)).size, 6);
  for (const parent of new Set(rows.map(r => r.source_parent_id))) {
    const family = rows.filter(r => r.source_parent_id === parent);
    const clean = family.find(r => r.variant_kind === 'clean');
    assert.equal(family.length, 5);
    assert.equal(clean.text, fs.readFileSync(clean.provenance.source_file, 'utf8'));
    assert.equal(clean.annotation.hasDirective, false);
    for (const row of family) {
      assert.equal(row.full_document_security_label, null);
      assert.equal(row.annotation_scope, 'selected_window_only');
      assert.equal(row.group_id, clean.group_id);
      assert.equal(row.training_eligible, false);
      assert.equal(row.provenance.variant_text_license, 'CC-BY-SA-4.0');
      assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
      assert.deepEqual(validateAnnotation(row.selected_window.text, row.window_annotation), []);
      assert.equal(row.text.slice(row.selected_window.start, row.selected_window.end), row.selected_window.text);
      for (const d of row.window_annotation.directive_spans) assert.equal(row.text.slice(row.selected_window.start + d.start, row.selected_window.start + d.end), d.quote);
      if (row.variant_kind !== 'clean') {
        const lines = row.text.split('\n');
        const injected = lines.findIndex(line => row.annotation.directive_spans.some(d => line.includes(d.quote)));
        assert.ok(injected > 0);
        assert.equal([...lines.slice(0, injected), ...lines.slice(injected + 1)].join('\n'), clean.text);
      }
    }
  }
});
