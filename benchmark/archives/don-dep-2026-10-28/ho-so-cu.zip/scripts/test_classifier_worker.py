"""Kiểm thử worker local-only bằng backend giả, không có tokenizer/weights model thật."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import classifier_worker as worker


class FixtureBackend:
    forwards = []

    def __init__(self, manifest, tokenizer_only=False):
        self.manifest = manifest
        self.tokenizer_only = tokenizer_only

    def count(self, text):
        return len(re.findall(r'\S+', text)) + 2

    def offsets(self, text):
        return [(match.start(), match.end()) for match in re.finditer(r'\S+', text)]

    def logits(self, text):
        self.forwards.append(text)
        return [0.0, 0.0]


class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='classifier-worker-', dir=os.environ.get('TMP'))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.model_dir = self.root / 'model'
        self.model_dir.mkdir()
        files = {'config.json': '{"num_labels":2}', 'tokenizer.json': '{}', 'model.safetensors': 'FIXTURE ONLY, NOT REAL WEIGHTS'}
        for name, value in files.items():
            (self.model_dir / name).write_text(value, encoding='utf-8')
        artifacts = {name: worker.sha_file(self.model_dir / name) for name in files}
        token_files = ['config.json', 'tokenizer.json']
        token_hash = hashlib.sha256(json.dumps({name: artifacts[name] for name in sorted(token_files)}, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        self.manifest = {'protocol': 1, 'model': 'fixture-only', 'revision': 'a' * 40, 'tokenizerSha256': token_hash,
                         'labels': ['benign', 'malicious'], 'modelDir': str(self.model_dir), 'artifactSha256': artifacts,
                         'tokenizerFiles': token_files, 'maxInputTokens': 7}
        self.path = self.root / 'manifest.json'
        self.path.write_text(json.dumps(self.manifest), encoding='utf-8')
        FixtureBackend.forwards = []

    def request(self):
        return {'protocol': 1, **worker.identity(self.manifest), 'windows': [{'id': 'window-1', 'text': 'Dan Evans đang đọc hồ sơ'}]}

    def test_manifest_hash_and_directory_validation(self):
        self.assertEqual(worker.checked_manifest(self.path, self.root)['revision'], 'a' * 40)
        (self.model_dir / 'tokenizer.json').write_text('{"changed":true}')
        with self.assertRaises(ValueError):
            worker.checked_manifest(self.path, self.root)

    def test_unpinned_files_and_manifest_outside_root(self):
        (self.model_dir / 'extra_config.json').write_text('{}')
        with self.assertRaises(ValueError):
            worker.checked_manifest(self.path, self.root)
        with self.assertRaises(ValueError):
            worker.checked_manifest(self.path, self.model_dir)

    def test_revision_and_tokenizer_set_must_be_pinned(self):
        for key, value in [('revision', 'main'), ('tokenizerFiles', ['tokenizer.json']), ('tokenizerSha256', '0' * 64)]:
            manifest = {**self.manifest, key: value}
            self.path.write_text(json.dumps(manifest))
            with self.assertRaises(ValueError):
                worker.checked_manifest(self.path, self.root)

    def test_classify_preserves_ids_and_logits_only(self):
        request = self.request()
        request['windows'][0]['text'] = 'Dan Evans đọc hồ sơ'
        result = worker.handle(request, self.manifest, FixtureBackend)
        self.assertEqual(result['windows'], [{'id': 'window-1', 'logits': [0.0, 0.0]}])
        self.assertNotIn('verdict', result)
        self.assertEqual(FixtureBackend.forwards, ['Dan Evans đọc hồ sơ'])

    def test_overlength_batch_is_rejected_before_any_forward(self):
        request = self.request()
        request['windows'] = [{'id': 'one', 'text': 'short'}, {'id': 'two', 'text': 'one two three four five six seven eight'}]
        with self.assertRaises(ValueError):
            worker.handle(request, self.manifest, FixtureBackend)
        self.assertEqual(FixtureBackend.forwards, [])

    def test_duplicate_metadata_unknown_operation_or_identity_rejected(self):
        for change in [{'revision': 'b' * 40}, {'label': 'malicious'}, {'operation': 'download'},
                       {'windows': [{'id': 'same', 'text': 'x'}, {'id': 'same', 'text': 'y'}]}]:
            with self.assertRaises(ValueError):
                worker.handle({**self.request(), **change}, self.manifest, FixtureBackend)
        self.assertEqual(FixtureBackend.forwards, [])

    def test_prepare_utf16_crlf_and_real_count_contract(self):
        text = '  Hồ sơ 😀\r\nđang kiểm tra tại phòng hồ sơ.  '
        request = {'protocol': 1, **worker.identity(self.manifest), 'operation': 'prepare', 'text': text,
                   'startLine': 8, 'maxInputTokens': 7, 'overlapTokens': 2}
        result = worker.handle(request, self.manifest, FixtureBackend)
        raw = text.encode('utf-16-le')
        covered = set()
        for window in result['windows']:
            self.assertEqual(raw[window['startOffset'] * 2:window['endOffset'] * 2].decode('utf-16-le'), window['text'])
            self.assertLessEqual(window['inputTokens'], 7)
            covered.update(range(window['startOffset'], window['endOffset']))
        self.assertEqual(len(covered), len(raw) // 2)
        self.assertEqual(result['sourceSha256'], hashlib.sha256(text.encode()).hexdigest())
        self.assertEqual(FixtureBackend.forwards, [])

    def test_local_backend_never_loads_remote_or_pickle(self):
        calls = []
        class Auto:
            @staticmethod
            def from_pretrained(path, **kwargs):
                calls.append((path, kwargs))
                return types.SimpleNamespace(id2label={0: 'BENIGN', 1: 'MALICIOUS'}, num_labels=2, max_position_embeddings=512)
        class Tokenizer:
            @staticmethod
            def from_pretrained(path, **kwargs):
                calls.append((path, kwargs))
                return types.SimpleNamespace(is_fast=True, model_max_length=512)
        class Model:
            @staticmethod
            def from_pretrained(path, **kwargs):
                calls.append((path, kwargs))
                return types.SimpleNamespace(to=lambda device: types.SimpleNamespace(eval=lambda: None))
        fake = types.SimpleNamespace(AutoConfig=Auto, AutoTokenizer=Tokenizer, AutoModelForSequenceClassification=Model)
        with patch.dict(sys.modules, {'torch': types.SimpleNamespace(), 'transformers': fake}):
            worker.LocalBackend(self.manifest)
        self.assertEqual(len(calls), 3)
        for path, kwargs in calls:
            self.assertEqual(path, str(self.model_dir))
            self.assertTrue(kwargs['local_files_only'])
            self.assertFalse(kwargs['trust_remote_code'])
        self.assertTrue(calls[-1][1]['use_safetensors'])
        self.assertEqual(os.environ['HF_HUB_OFFLINE'], '1')

    def test_subprocess_real_protocol_with_fixture_backend(self):
        bootstrap = self.root / 'bootstrap.py'
        bootstrap.write_text('import sys\nsys.path.insert(0,' + repr(str(Path(__file__).parent.resolve())) + ')\nfrom test_classifier_worker import FixtureBackend\nfrom classifier_worker import main\nraise SystemExit(main(FixtureBackend))\n', encoding='utf-8')
        env = {**os.environ, 'IPI_CLASSIFIER_MANIFEST': str(self.path)}
        request = self.request()
        request['windows'][0]['text'] = 'A short fixture'
        result = subprocess.run([sys.executable, str(bootstrap)], input=(json.dumps(request) + '\n').encode(), capture_output=True, timeout=15, env=env)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['windows'][0]['logits'], [0.0, 0.0])

    def test_cli_without_manifest_fails_closed_without_library_import(self):
        env = dict(os.environ)
        env.pop('IPI_CLASSIFIER_MANIFEST', None)
        result = subprocess.run([sys.executable, str(Path(worker.__file__))], input=b'{}\n', capture_output=True, timeout=15, env=env)
        self.assertEqual(result.returncode, 1)
        response = json.loads(result.stdout)
        self.assertIn('error', response)
        self.assertNotIn('windows', response)
        self.assertNotIn('score', response)


if __name__ == '__main__':
    unittest.main()
