// Tách lỗi kỹ thuật, uncertain và kết luận nhị phân; không biến model lỗi thành sạch.
function summarize(rows){
 const count=(gold,pred)=>rows.filter(r=>r.expected===gold&&r.predicted===pred).length;
 const tp=count('confirmed','confirmed'),fp=count('dismissed','confirmed'),tn=count('dismissed','dismissed'),fn=count('confirmed','dismissed');
 const divide=(a,b)=>b?a/b:null,p=divide(tp,tp+fp),recall=divide(tp,rows.filter(r=>r.expected==='confirmed').length);
 const times=rows.map(r=>r.seconds).sort((a,b)=>a-b);
 return {examples:rows.length,parsed:rows.filter(r=>r.parsed).length,correct_stance:rows.filter(r=>r.predicted===r.expected).length,
  tp,fp,tn,false_clear_fn:fn,errors:rows.filter(r=>!r.parsed).length,uncertain:rows.filter(r=>r.predicted==='uncertain').length,
  uncertain_gold_confirmed:count('uncertain','confirmed'),precision:p,recall,f1:p===null||recall===null?null:p+recall?2*p*recall/(p+recall):0,
  false_positive_rate:divide(fp,rows.filter(r=>r.expected==='dismissed').length),
  gold_instruction_covered_tps:rows.filter(r=>r.expected==='confirmed'&&r.predicted==='confirmed'&&r.gold_instruction_covered).length,
  latency_p50:times[Math.max(0,Math.ceil(times.length*.5)-1)]??null,latency_p95:times[Math.max(0,Math.ceil(times.length*.95)-1)]??null,
  max_model_vram_snapshot:Math.max(0,...rows.map(r=>r.model_vram_snapshot??0))};
}
function compare(baseline,candidate){
 const a=summarize(baseline),b=summarize(candidate);
 const pairs=candidate.map(r=>[baseline.find(x=>x.id===r.id),r]);
 if(pairs.some(([x,y])=>!x||x.expected!==y.expected))throw new Error('Hai model không cùng đầu vào/gold.');
 const regressions=pairs.filter(([x,y])=>(x.predicted===x.expected&&y.predicted!==y.expected)||
  (y.expected==='dismissed'&&y.predicted==='confirmed'&&x.predicted!=='confirmed')||
  (y.expected==='confirmed'&&y.predicted==='dismissed'&&x.predicted!=='dismissed')||
  (y.expected==='uncertain'&&y.predicted==='confirmed'&&x.predicted!=='confirmed')).map(([,y])=>y.id);
 return {eligible_for_candidate_pipeline:baseline.length===16&&candidate.length===16&&b.parsed===16&&b.correct_stance>a.correct_stance&&regressions.length===0&&b.gold_instruction_covered_tps===b.tp,
  baseline:a,candidate:b,regressions,default_verifier_changed:false,independent_validation_complete:false};
}
module.exports={summarize,compare};
