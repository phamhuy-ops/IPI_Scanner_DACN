// So sánh ứng viên trên cùng bộ dev; không tự bật cấu hình sản phẩm.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const folder = path.resolve(root, process.argv[2] || '');
if (!folder.startsWith(path.join(root, 'benchmark/results/agent-contrast-'))) throw new Error('Cần thư mục kết quả agent-contrast trong workspace.');
const read = name => JSON.parse(fs.readFileSync(path.join(folder, name)));
const summary = read('summary.json'), plan = read('plan.json'), rows = read('cases.json'), calls = read('model-calls.json');
if (summary.status !== 'complete') throw new Error('Lượt đo chưa hoàn tất hoặc đã bị loại.');
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
for (const [file, expected] of Object.entries(summary.code_sha256)) {
  if (hash(fs.readFileSync(path.join(root, file))) !== expected) throw new Error(`Code thay đổi sau đo: ${file}`);
}
const before = rows.filter(r => r.arm === 'baseline'), after = rows.filter(r => r.arm === 'candidate');
if ([before, after].some(arm => arm.length !== plan.cases.length || new Set(arm.map(r => r.id)).size !== arm.length)) throw new Error('Thiếu hoặc trùng ca.');
for (const row of rows) {
  const original = plan.cases.find(c => c.id === row.id);
  const chunks = row.state.scanResult.metadata.semanticChunks;
  if (!original || original.input_sha256 !== hash(original.text) || chunks.length !== 1 || chunks[0].text !== original.text) throw new Error('Đầu vào không khớp manifest.');
}
for (const call of calls) {
  if (call.request.messages.some(m => m.content.includes(call.case_id))) throw new Error('Mã mẫu trong prompt.');
  const system = call.request.messages.find(m => m.role === 'system').content;
  if ((call.arm === 'candidate') !== system.endsWith(plan.candidate_addition)) throw new Error('Prompt không khớp nhánh đo.');
}
const digest = value => Object.fromEntries(value.models.filter(m => [plan.configuration.detector, plan.configuration.verifier].includes(m.name)).map(m => [m.name, m.digest]));
const modelsUnchanged = JSON.stringify(digest(read('models-before.json'))) === JSON.stringify(digest(read('models-after.json')));
const b = summary.by_arm.baseline.binary, a = summary.by_arm.candidate.binary;
const errors = arm => arm.filter(r => r.processing !== 'completed').length;
const correct = row => row.label === 'malicious' ? row.verdict === 'ipi_detected' : row.verdict === 'not_detected';
const p95 = arm => arm.map(r => r.seconds).sort((x, y) => x-y)[Math.ceil(arm.length*.95)-1];
const latencyRatio = p95(after) / p95(before);
const regressions = after.filter(r => correct(before.find(old => old.id === r.id)) && !correct(r)).map(r => r.id);
const improvements = after.filter(r => !correct(before.find(old => old.id === r.id)) && correct(r)).map(r => r.id);
const perSource = Object.fromEntries([...new Set(rows.map(r => r.source))].map(s => {
  const counts = arm => ({ tp: arm.filter(r => r.source === s && r.label === 'malicious' && r.verdict === 'ipi_detected').length,
    fp: arm.filter(r => r.source === s && r.label === 'benign' && r.verdict === 'ipi_detected').length,
    false_clear: arm.filter(r => r.source === s && r.label === 'malicious' && r.verdict === 'not_detected').length });
  return [s, { before: counts(before), after: counts(after) }];
}));
const gates = {
  models_unchanged: modelsUnchanged,
  no_additional_errors: errors(after) <= errors(before),
  no_new_false_clear: !after.some(r => r.label === 'malicious' && r.verdict === 'not_detected' && before.find(b => b.id === r.id).verdict !== 'not_detected'),
  no_recall_regression: a.confirmed_attack_recall >= b.confirmed_attack_recall,
  no_source_false_alert_regression: Object.values(perSource).every(s => s.after.fp <= s.before.fp),
  strict_binary_accuracy_improvement: after.filter(correct).length > before.filter(correct).length,
  latency_ratio_max: latencyRatio <= plan.gates.latency_ratio_max,
};
const roleDiagnostics = Object.fromEntries(['baseline', 'candidate'].map(arm => [arm, Object.fromEntries(['detector', 'verifier'].map(role => [role, {
  benign_with_confirmed: rows.filter(r => r.arm === arm && r.label === 'benign' && r.role_stances[role].includes('confirmed')).map(r => r.id),
  attack_with_confirmed: rows.filter(r => r.arm === arm && r.label === 'malicious' && r.role_stances[role].includes('confirmed')).map(r => r.id),
  missing_or_error_not_correct_negative: rows.filter(r => r.arm === arm && (r.processing !== 'completed' || r.role_stances[role].includes('missing'))).map(r => r.id),
}]))]));
const result = { status: 'complete', result_folder: path.relative(root, folder), gates,
  development_screen_passed: Object.values(gates).every(Boolean), production_promotion_authorized_by_evidence: false,
  explanation: 'Đạt sàng lọc nhỏ cũng chưa đủ tích hợp: còn cổng chất lượng đầy đủ, biến thể/nguồn độc lập và pipeline tài liệu thực.',
  improvements, regressions, per_source_counts: perSource, role_diagnostics: roleDiagnostics,
  latency: { baseline_p95_seconds: p95(before), candidate_p95_seconds: p95(after), p95_ratio: latencyRatio },
  model_digests: digest(read('models-after.json')), calls: calls.length,
  input_integrity_checked: true, case_ids_absent_from_prompts: true,
  plan_sha256: hash(fs.readFileSync(path.join(folder, 'plan.json'))),
  raw_cases_sha256: hash(fs.readFileSync(path.join(folder, 'cases.json'))),
  raw_calls_sha256: hash(fs.readFileSync(path.join(folder, 'model-calls.json'))),
};
fs.writeFileSync(path.join(folder, 'comparison.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ gates, improvements, regressions, latency: result.latency, per_source_counts: perSource }, null, 2));
