const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
async function get(url) {
  const response = await fetch(url, { headers: { 'User-Agent': 'IPI-Scanner-local-data-audit' }, signal: AbortSignal.timeout(30000) });
  if (!response.ok) throw new Error(`Không tải được ${url}: HTTP ${response.status}. Không bỏ qua giới hạn truy cập.`);
  return Buffer.from(await response.arrayBuffer());
}
async function main() {
  const out = path.join(root, 'benchmark/data/raw/python-context-docs-v1');
  if (fs.existsSync(out)) throw new Error('Snapshot đã có; không ghi đè.');
  const refBytes = await get('https://api.github.com/repos/python/cpython/git/ref/tags/v3.12.0');
  let object = JSON.parse(refBytes).object; const tagEvidence = [];
  while (object.type === 'tag') {
    const bytes = await get(object.url); tagEvidence.push(bytes);
    object = JSON.parse(bytes).object;
  }
  if (object.type !== 'commit' || !/^[a-f0-9]{40}$/.test(object.sha)) throw new Error('Không xác minh được commit của tag.');
  const files = ['LICENSE', 'Doc/tutorial/venv.rst', 'Doc/tutorial/interpreter.rst', 'Doc/tutorial/inputoutput.rst',
    'Doc/tutorial/errors.rst', 'Doc/tutorial/modules.rst', 'Doc/tutorial/stdlib.rst'];
  const assets = new Map(), inventory = {};
  for (const file of files) {
    const url = `https://raw.githubusercontent.com/python/cpython/${object.sha}/${file}`;
    const bytes = await get(url); assets.set(file, bytes); inventory[file] = { url, sha256: hash(bytes), bytes: bytes.length };
  }
  if (!assets.get('LICENSE').toString().includes('PYTHON SOFTWARE FOUNDATION LICENSE VERSION 2')) throw new Error('Thiếu license dự kiến.');
  assets.set('tag-ref.json', refBytes); tagEvidence.forEach((bytes, index) => assets.set(`tag-object-${index + 1}.json`, bytes));
  const snapshot = { repository: 'https://github.com/python/cpython', tag: 'v3.12.0', revision: object.sha, retrieved_at: new Date().toISOString(),
    license_declared: 'PSF License Version 2; xem LICENSE để giữ các thông báo và điều khoản khác',
    official_license_url: 'https://docs.python.org/3/license.html', assets: inventory, independent_holdout_verified: false,
    training_ready: false, note: 'Chỉ tải dữ liệu văn bản RST và LICENSE; không cài hoặc chạy lệnh trong tài liệu.' };
  fs.mkdirSync(out, { recursive: true });
  for (const [file, bytes] of assets) { const target = path.join(out, file); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, bytes, { flag: 'wx' }); }
  fs.writeFileSync(path.join(out, 'snapshot.json'), JSON.stringify(snapshot, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ files: files.length, revision: object.sha, bytes: [...assets.values()].reduce((n, b) => n + b.length, 0) }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
