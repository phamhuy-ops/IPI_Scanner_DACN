"""Kiểm tra fixture GPU giữ đủ JSON/EOS và đúng kích thước stress, không cần GPU."""
import os
import unittest
from transformers import AutoTokenizer
from audit_verifier_tokenizer import MODEL, REVISION
from smoke_verifier_gpu import fixture
from verifier_collator import CompletionCollator


class FixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION,
            cache_dir=os.environ['HF_HUB_CACHE'], local_files_only=True, trust_remote_code=False)

    def test_exact_sequence_and_supervision_lengths_after_collation(self):
        for length, targets in [(1024, 11), (1536, 11), (2048, 11), (2048, 256)]:
            with self.subTest(length=length, targets=targets):
                row = fixture(self.tokenizer, length, targets)
                batch = CompletionCollator(self.tokenizer.pad_token_id, length)([row])
                self.assertEqual(batch['input_ids'].shape[1], length)
                self.assertEqual(int((batch['labels'] != -100).sum()), targets)
                self.assertTrue(self.tokenizer.decode([v for v in row['labels'] if v != -100]).endswith(self.tokenizer.eos_token))
                self.assertEqual(int((batch['attention_mask'] == 0).sum()), 0)


if __name__ == '__main__':
    unittest.main()
