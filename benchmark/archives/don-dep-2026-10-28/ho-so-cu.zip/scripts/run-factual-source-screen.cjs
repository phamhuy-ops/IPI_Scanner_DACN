// Đo ba câu hỏi Yes/No độc lập, chưa định vị directive và chưa đưa vào sản phẩm.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');const{QUESTIONS,request,parse,decide}=require('./factual-source-questions.cjs');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
async function main(){
  const source='benchmark/results/source-statement-FPJiqK/giao-thuc.json',cases=JSON.parse(fs.readFileSync(source)).cases,models=['gemma3:1b','qwen2.5-coder:1.5b'];
  const out=fs.mkdtempSync(path.resolve('benchmark/results/factual-source-')),save=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2));
  const api=async(endpoint,body)=>{const r=await fetch('http://127.0.0.1:11434'+endpoint,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(body?45000:8000)});const raw=await r.text();if(!r.ok)throw Error('HTTP '+r.status+':'+raw.slice(0,120));return JSON.parse(raw);};
  const tags=await api('/api/tags'),version=await api('/api/version');
  const files=[source,'scripts/run-factual-source-screen.cjs','scripts/factual-source-questions.cjs'];const fingerprint=()=>Object.fromEntries(files.map(file=>[file,sha(fs.readFileSync(file))])),before=fingerprint();
  save('giao-thuc.json',{cases,models:tags,ollama:version,questions:QUESTIONS,code_sha256:before,command:'node scripts/run-factual-source-screen.cjs',
    policy:'Mỗi vai trò trả3 bit riêng từ logprobs Yes/No; thiếu score hoặc fact mâu thuẫn là lỗi, không phải semantic uncertain.',
    configuration:{seed:42,temperature:0,num_predict:1,top_logprobs:20},budget:{requests:cases.length*models.length*Object.keys(QUESTIONS).length,retries:0,training:0},
    gate:'Mỗi vai trò và kết hợp ít nhất90%, không FP; đạt mới đo toàn96 dev và tích hợp định vị bằng chứng. Không suy IPI từ điểm hoặc dữ liệu chưa đầy đủ.',
    limits:['Dev16 đã dùng, không phải holdout.','Chưa trích xuất/chunking/định vị bằng chứng/UI.', 'Một Yes/No đúng không chứng minh cả pipeline đúng.']});
  const rows=[],calls=[];console.log(JSON.stringify({out,total:cases.length*models.length*Object.keys(QUESTIONS).length}));
  for(const model of models){for(const item of cases){const answers={},errors=[],start=performance.now();
    for(const question of Object.keys(QUESTIONS)){
      const body=request(model,item.text,question);try{const r=await fetch('http://127.0.0.1:11434/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(45000)}),raw=await r.text();
        calls.push({id:item.id,model,question,request:body,response:raw,status:r.status,resources:await api('/api/ps').catch(()=>null)});if(!r.ok)throw Error('HTTP '+r.status);const result=JSON.parse(raw);if(result.model!==model)throw Error('Sai model thực chạy.');answers[question]=parse(result);
      }catch(error){errors.push({question,error:error.message});}
      save('model-calls.json',calls);
    }
    rows.push({id:item.id,model,label:item.label,source:item.source,group:item.evaluation_group,language:item.language,answers,errors,...decide(answers),seconds:(performance.now()-start)/1000});save('cases.json',rows);
    console.log(JSON.stringify({done:rows.length,total:cases.length*2,model,id:item.id,label:item.label,...decide(answers)}));
  }await api('/api/generate',{model,keep_alive:0}).catch(()=>{});}
  const expected={malicious:'active',benign:'ordinary',uncertain:'underdetermined'};
  const score=a=>({total:a.length,valid:a.filter(r=>r.valid).length,correct:a.filter(r=>r.valid&&r.kind===expected[r.label]).length,accuracy:a.length?a.filter(r=>r.valid&&r.kind===expected[r.label]).length/a.length:null,
    confusion:a.reduce((out,r)=>{const key=r.label+' -> '+(r.valid?r.kind:'ERROR');out[key]=(out[key]||0)+1;return out;},{}),p95_seconds:a.map(r=>r.seconds).sort((a,b)=>a-b)[Math.ceil(a.length*.95)-1]});
  const byModel=Object.fromEntries(models.map(model=>[model,score(rows.filter(r=>r.model===model))]));
  const combined=cases.map(item=>{const pair=models.map(model=>rows.find(r=>r.id===item.id&&r.model===model));const kind=pair.every(r=>r.valid&&r.kind==='active')?'active':pair.every(r=>r.valid&&r.kind==='ordinary')?'ordinary':'underdetermined';
    return{id:item.id,label:item.label,kind,valid:pair.every(r=>r.valid),semantic_uncertainty:pair.some(r=>r.valid&&r.semantic_uncertainty)};});
  const accuracy=combined.filter(r=>r.valid&&r.kind===expected[r.label]&&(r.label!=='uncertain'||r.semantic_uncertainty)).length/combined.length;
  if(JSON.stringify(before)!==JSON.stringify(fingerprint()))throw Error('Code đổi');const after=await api('/api/tags');if(models.some(model=>tags.models.find(r=>r.name===model)?.digest!==after.models.find(r=>r.name===model)?.digest))throw Error('Model đổi');
  const breakdown={};for(const field of ['source','group','language'])breakdown[field]=Object.fromEntries([...new Set(rows.map(r=>r[field]))].map(key=>[key,score(rows.filter(r=>r[field]===key))]));
  const passed=accuracy>=.9&&Object.values(byModel).every(r=>r.accuracy>=.9)&&!combined.some(r=>r.label==='benign'&&r.kind==='active');
  save('tong-hop.json',{complete:true,passed,by_model:byModel,combined_accuracy:accuracy,combined,breakdown,calls:calls.length,code_unchanged:true,model_unchanged:true,product_changed:false,pipeline_tested:false});
  console.log(JSON.stringify({complete:true,passed,by_model:byModel,combined_accuracy:accuracy,out}));
}
main().catch(error=>{console.error(error);process.exitCode=1;});
