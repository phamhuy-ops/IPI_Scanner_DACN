"""Đối chiếu bản sửa train với toàn bộ registry và đối chứng dev theo heuristic đã dùng."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    spec = importlib.util.spec_from_file_location('lex', Path(__file__).with_name('audit-cross-source-overlap.py'))
    lex = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lex)
    source = ROOT / 'benchmark/experiments/verifier-counterfactual-train-v2'
    output = source / 'kiem-tra-tuong-dong.json'
    if output.exists():
        raise ValueError('Không ghi đè audit.')
    files = ['benchmark/data/annotations/verifier-local-release-preview-v2/mau-cho-duyet.jsonl',
             'benchmark/experiments/verifier-eligibility-v12/registry.jsonl',
             'benchmark/data/annotations/verifier-role-authority-controls-v1/mau-cho-duyet.jsonl']
    refs, hashes = [], {}
    for file in files:
        data = (ROOT / file).read_bytes()
        hashes[file] = hashlib.sha256(data).hexdigest()
        for line in data.decode('utf-8-sig').splitlines():
            row = json.loads(line)
            if 'text' not in row:
                continue
            refs.append({**row, 'file': file})
    train = [json.loads(line) for line in (source / 'mau-cho-duyet.jsonl').read_text(encoding='utf-8').splitlines()]
    matches = []
    for row in train:
        if not row.get('counterfactual'):
            continue
        tokens = lex.tokenize(row['text'])
        tri, passages = lex.shingles(tokens, 3), lex.shingles(tokens, 12)
        for ref in refs:
            rt = lex.tokenize(ref['text'])
            rg = lex.shingles(rt, 3)
            reasons = []
            if lex.normalize(row['text']) == lex.normalize(ref['text']):
                reasons.append('normalized_exact')
            if tri and rg and len(tri & rg) / len(tri | rg) >= .8:
                reasons.append('trigram_jaccard_0.8')
            if passages & lex.shingles(rt, 12):
                reasons.append('shared_12_token_passage')
            if reasons:
                matches.append({'id': row['id'], 'reference_id': ref['id'], 'reference_file': ref['file'],
                                'same_group': ref.get('group_id') == row['group_id'],
                                'reference_role': ref.get('planned_role'), 'reasons': reasons})
    # Registry có thể mang ID nhóm trước split; phán quyết vai trò dựa bản split đã khóa.
    protected = [m for m in matches if m['reference_role'] in {'dev', 'probe'} or 'role-authority-controls' in m['reference_file']]
    result = {'changed_records': 12, 'reference_rows_with_text': len(refs), 'matches': matches,
              'protected_matches': protected, 'protected_match_count': len(protected), 'input_sha256': hashes,
              'code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'limitations': ['Heuristic từ vựng không bảo đảm độc lập ngữ nghĩa.', 'Không đọc đáp án test; registry không có text được bỏ qua, bản split cung cấp đủ 324 nguồn đã chọn.']}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'reference_rows': len(refs), 'matches': len(matches), 'protected_matches': len(protected)}))
    if protected:
        raise ValueError('Có tương đồng với dev/probe, cần rà trước khóa.')


if __name__ == '__main__':
    main()
