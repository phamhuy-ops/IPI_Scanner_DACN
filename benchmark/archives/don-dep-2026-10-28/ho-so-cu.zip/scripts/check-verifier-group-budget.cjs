// Chỉ kiểm tra tồn tại phân bổ theo số lượng/stance; không xuất split hoặc chọn cấu hình model.
const fs = require('node:fs');
const { hash } = require('./context-annotations.cjs');
function subset(groups, target) {
  const states = new Map([['0,0,0', []]]);
  for (let i = 0; i < groups.length; i++) {
    for (const [key, chosen] of [...states]) {
      const sum = key.split(',').map((n, j) => Number(n) + groups[i][j]);
      if (sum.some((n, j) => n > target[j])) continue;
      const next = sum.join(',');
      if (!states.has(next)) states.set(next, [...chosen, i]);
    }
    if (states.has(target.join(','))) return states.get(target.join(','));
  }
  return states.get(target.join(',')) ?? null;
}
function check(rows) {
  const pool = rows.filter(r => r.role === 'candidate_pending_source_privacy_and_split_review');
  const grouped = new Map();
  for (const row of pool) {
    if (!row.group_id) throw new Error('Thiếu nhóm.');
    const index = ['confirmed', 'dismissed', 'uncertain'].indexOf(row.stance);
    if (index < 0) throw new Error('Stance không hợp lệ.');
    if (!grouped.has(row.group_id)) grouped.set(row.group_id, [0, 0, 0]);
    grouped.get(row.group_id)[index]++;
  }
  const groups = [...grouped.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, v]) => v);
  const totals = groups.reduce((a, v) => a.map((n, i) => n + v[i]), [0, 0, 0]);
  const target = [96, 96, 48], excess = totals.map((n, i) => n - target[i]);
  const excluded = excess.some(n => n < 0) ? null : subset(groups, excess);
  const retained = excluded === null ? [] : groups.filter((_, i) => !excluded.includes(i));
  const probe = excluded === null ? null : subset(retained, [24, 24, 12]);
  return { candidate_records: pool.length, candidate_groups: groups.length,
    stances: Object.fromEntries(['confirmed', 'dismissed', 'uncertain'].map((key, i) => [key, totals[i]])),
    planning_scenario: { train: { records: 180, stances: [72, 72, 36] }, probe: { records: 60, stances: [24, 24, 12] },
      note: 'Kịch bản 40/40/20 để kiểm tra khả năng số học, không thay cổng đã khóa hoặc chia tập cuối.' },
    count_only_witness_found: probe !== null,
    search_scope: 'Chọn một tập nhóm dư bằng DP rồi kiểm tra probe trong phần còn lại; false không chứng minh mọi phân bổ đều bất khả thi.',
    witness_group_counts: probe === null ? null : { unused: excluded.length, probe: probe.length, train: retained.length - probe.length },
    final_split_created: false, training_ready: false, independent_validation_complete: false,
    limitations: ['Không tối ưu ngôn ngữ, nguồn, độ dài hoặc độ khó; chưa chốt điều kiện từng nhóm.',
      'Một nghiệm số học không chứng minh tính độc lập ngữ nghĩa hoặc khả năng nhận diện của model.',
      'Không xuất danh sách nhóm được phân bổ; probe chưa được niêm phong, không phải holdout độc lập.'] };
}
if (require.main === module) {
  const file = 'benchmark/experiments/verifier-eligibility-v12/registry.jsonl';
  const out = 'benchmark/experiments/verifier-group-budget-v1';
  if (fs.existsSync(out)) throw new Error('Không ghi đè kiểm tra.');
  const bytes = fs.readFileSync(file), result = check(bytes.toString('utf8').trim().split(/\r?\n/).map(JSON.parse));
  result.inputs_sha256 = { [file]: hash(bytes) }; result.code_sha256 = hash(fs.readFileSync(__filename));
  result.command = 'node scripts/check-verifier-group-budget.cjs';
  fs.mkdirSync(out); fs.writeFileSync(`${out}/ket-qua.json`, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
}
module.exports = { subset, check };
