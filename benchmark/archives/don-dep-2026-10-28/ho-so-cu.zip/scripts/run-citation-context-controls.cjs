const fs = require('node:fs');
const path = require('node:path');
const { buildControls, sourceFromCall, hash } = require('./citation-context-controls.cjs');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');
const { summarize } = require('./round-one-metrics.cjs');
const root = path.resolve(__dirname, '..');

async function main() {
  const mode = process.argv[2];
  if (!['--prepare', '--ollama'].includes(mode) || process.argv.length !== 3) throw new Error('Dùng --prepare hoặc --ollama.');
  const definition = buildControls(root);
  const experiment = path.join(root, 'benchmark/experiments/citation-context-controls-v1');
  fs.mkdirSync(experiment, { recursive: true });
  const manifest = path.join(experiment, 'mau-da-khoa.json');
  const content = JSON.stringify(definition, null, 2) + '\n';
  if (fs.existsSync(manifest)) {
    if (fs.readFileSync(manifest, 'utf8') !== content) throw new Error('Bộ ca đã khóa khác bản tái dựng; cần phiên bản mới.');
  } else fs.writeFileSync(manifest, content, { flag: 'wx' });
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true }, appType: 'custom' });
  const output = fs.mkdtempSync(path.join(root, 'benchmark/results/citation-context-'));
  const save = (name, data) => fs.writeFileSync(path.join(output, name), JSON.stringify(data, null, 2) + '\n');
  const codeFiles = ['scripts/citation-context-controls.cjs', 'scripts/run-citation-context-controls.cjs', 'scripts/round-one-metrics.cjs',
    ...Object.keys(JSON.parse(fs.readFileSync(path.join(root, 'benchmark/experiments/bounded-document-review-v1/ket-qua.json'))).code_sha256).filter(file => file.startsWith('src/') || file.startsWith('engine/'))];
  const fingerprints = () => Object.fromEntries(codeFiles.map(file => [file, hash(fs.readFileSync(path.join(root, file)))]));
  const code = fingerprints();
  const localGet = async endpoint => {
    const response = await fetch(`http://127.0.0.1:11434${endpoint}`, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error(`Ollama ${response.status}`);
    return response.json();
  };
  const records = [], calls = [];
  let currentCase, maxRss = process.memoryUsage().rss;
  const timer = setInterval(() => { maxRss = Math.max(maxRss, process.memoryUsage().rss); }, 100);
  try {
    const { parseReviewJson } = await server.ssrLoadModule('/src/ai/agents/document/reviewPolicy.ts');
    const replays = definition.captured.flatMap(({ arm, clean, failed }) => [clean, failed].map((call, index) => {
      const source = sourceFromCall(call);
      const chunk = { chunkId: source.alias, sourceChunkId: source.alias, fileName: 'sample.txt', filePath: '/sample.txt', startLine: 1, endLine: 1,
        text: source.text, riskScore: 0, findingCount: 0, selectionReasons: [] };
      const raw = JSON.parse(call.response).choices[0].message.content;
      const parse = text => { try { const result = parseReviewJson(text, [chunk], []); return { valid: true, discoveries: result.discoveries }; }
        catch (error) { return { valid: false, error: error.message }; } };
      const hypothetical = JSON.parse(raw);
      for (const discovery of hypothetical.discoveries) discovery.quote = discovery.quote.replace(/\n<\/untrusted_document_data>$/, '');
      return { arm, kind: index ? 'wrapper_quote' : 'clean_discovery', source_sha256: hash(Buffer.from(source.text)), original: parse(raw),
        hypothetical_marker_removal: parse(JSON.stringify(hypothetical)), diagnostic_only: true,
        note: 'Không sửa phản hồi thực tế. Hợp lệ cú pháp/citation không chứng minh discovery đúng ngữ cảnh.' };
    }));
    save('replay.json', replays);
    const scans = [];
    for (const item of definition.cases) {
      // Chỉ text đi vào file trung tính; nhãn/nhóm/đáp án nằm ngoài scanner/model.
      const folder = path.join(output, item.id); fs.mkdirSync(folder);
      const file = path.join(folder, 'sample.txt'); fs.writeFileSync(file, item.text);
      const scan = await runIpiDocScan([file], { scanProfile: 'deep', includeSemanticChunkCatalog: true });
      if (scan.metadata.semanticChunkCatalog.length !== 1 || scan.metadata.semanticChunks[0].text !== item.text) throw new Error(`Ranh giới nguồn khác bản đã khóa: ${item.id}`);
      scans.push(scan);
    }
    const config = { detector: 'gemma3:1b', verifier: 'qwen2.5-coder:1.5b', contract: 'classic-v1', chunks_per_request: 1,
      maxChatRequests: 8, maxSupplementalChunks: 0, analysisTimeoutMs: 90000, rounds: 1, seed: null, schedule: 'thứ tự cố định cc-01 tới cc-08' };
    save('plan.json', { mode, configuration: config, manifest_sha256: hash(Buffer.from(content)), code_sha256: code,
      independence: 'Dev có nhóm, không phải holdout; hai ca cắt từ cùng bài cũ.', reviewer: 'AI', human_approved: false });
    if (mode === '--prepare') { console.log(`Đã khóa 8 ca/3 nhóm và replay: ${path.relative(root, output)}`); return; }
    const models = await localGet('/api/tags');
    for (const name of [config.detector, config.verifier]) if (!models.models.some(row => row.name === name)) throw new Error(`Thiếu model ${name}`);
    save('models-before.json', models);
    globalThis.owaspWorkbench = { aiFetch: async payload => {
      if (new URL(payload.url).origin !== 'http://127.0.0.1:11434') throw new Error('Chỉ cho phép model cục bộ.');
      const chat = payload.url.includes('/chat/completions'); const start = performance.now();
      const call = { case_id: currentCase, request: chat ? JSON.parse(payload.body) : null };
      try {
        const response = await fetch(payload.url, { method: payload.method, headers: payload.headers, body: payload.body, signal: AbortSignal.timeout(payload.timeoutMs) });
        const body = await response.text();
        if (chat) { calls.push({ ...call, status: response.status, response: body, elapsed_ms: performance.now() - start,
          resources: await localGet('/api/ps').catch(() => null) }); save('model-calls.json', calls); }
        return { ok: response.ok, status: response.status, body };
      } catch (error) {
        if (chat) { calls.push({ ...call, error: error.message, elapsed_ms: performance.now() - start }); save('model-calls.json', calls); }
        return { ok: false, status: 0, body: '', error: error.message };
      }
    } };
    const { runBoundedDocumentReview } = await server.ssrLoadModule('/src/ai/experiments/boundedDocumentReview.ts');
    for (const [index, item] of definition.cases.entries()) {
      if (JSON.stringify(fingerprints()) !== JSON.stringify(code)) throw new Error('Code thay đổi trong phép đo.');
      currentCase = item.id; console.log(`Đang đo ${currentCase}`);
      const result = await runBoundedDocumentReview({ scan: scans[index], maxChatRequests: 8, maxSupplementalChunks: 0, analysisTimeoutMs: 90000 });
      const roleStances = Object.fromEntries(['detector', 'verifier'].map(role => [role, result.check.suspicions.map(row => row[role]?.stance || 'missing')]));
      records.push({ id: item.id, source: item.source, group: item.group, language: item.language, label: item.label,
        verdict: result.check.verdict, processing: result.stopReason, seconds: result.elapsedMs / 1000, role_stances: roleStances,
        rule_findings: scans[index].findings.length, result });
      save('cases.json', records); console.log(`${item.id}: ${result.check.verdict}, ${result.stopReason}, ${result.chatRequests} request`);
    }
    const modelsAfter = await localGet('/api/tags'); save('models-after.json', modelsAfter);
    const digests = value => Object.fromEntries(value.models.filter(row => [config.detector, config.verifier].includes(row.name)).map(row => [row.name, row.digest]));
    const metrics = rows => { const summary = summarize(rows); const tp = summary.matrix.malicious.ipi_detected, fp = summary.matrix.benign.ipi_detected;
      const positives = Object.values(summary.matrix.malicious).reduce((a, b) => a + b, 0);
      return { ...summary, confirmed_f1_with_abstention_as_unconfirmed: tp + fp + positives ? 2 * tp / (tp + fp + positives) : null }; };
    if (JSON.stringify(fingerprints()) !== JSON.stringify(code)) throw new Error('Code thay đổi trong phép đo.');
    save('summary.json', { status: 'complete', configuration: config, code_sha256: code, models_unchanged: JSON.stringify(digests(models)) === JSON.stringify(digests(modelsAfter)),
      metrics: metrics(records), by_source: Object.fromEntries([...new Set(records.map(row => row.source))].map(source => [source, metrics(records.filter(row => row.source === source))])),
      by_group: Object.fromEntries([...new Set(records.map(row => row.group))].map(group => [group, metrics(records.filter(row => row.group === group))])),
      benign_with_discoveries: records.filter(row => row.label === 'benign' && row.result.check.suspicions.some(s => s.source !== 'rule')).map(row => row.id),
      max_harness_rss_bytes: maxRss, limitations: ['Tám ca dev/ba nhóm, nhãn AI, không phải holdout hoặc kiểm chứng ngoài thực tế.',
        'Đo bằng TXT qua core; không đánh giá UI/IPC hoặc toàn tài liệu dài.', 'Hai đoạn cũ giữ text nhưng filename/alias/selection thay đổi khi tách thành file; không phải tái lập nguyên request cũ.',
        'Chưa đo ngữ cảnh có cấu trúc; stance tổng hợp có thể che khác biệt giữa hai vai trò.', 'RSS không phải tổng RAM/peak VRAM của Ollama.'] });
    console.log(`Đã lưu: ${path.relative(root, output)}`);
  } finally { clearInterval(timer); delete globalThis.owaspWorkbench; await server.close(); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
