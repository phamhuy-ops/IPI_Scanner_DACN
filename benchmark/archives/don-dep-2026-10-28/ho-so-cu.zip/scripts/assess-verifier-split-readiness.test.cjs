const { test } = require('node:test');
const assert = require('node:assert/strict');
const { groupConstraints, summarize, buildRegistry } = require('./assess-verifier-split-readiness.cjs');

test('nhóm dính baseline/dev không được đổi thành holdout; thiếu cờ không chứng minh untouched', () => {
  const rows = ['one','two','three'].map(id => ({ id }));
  const groups = [{ members: ['one','two'], flags: [], constraint: 'development_exposed_keep_group_together' },
    { members: ['three'], flags: [], constraint: 'development_exposed_keep_group_together' }];
  const output = groupConstraints(rows, groups, new Set(['one']));
  assert.equal(output[0].proposed_constraint, 'retain_development_regression');
  assert.deepEqual(output[0].members, ['one','two']);
  assert.equal(output[1].proposed_constraint, 'unassigned_role_review_required');
  assert.ok(output.every(group => group.final_split === null && !group.independently_untouched_verified));
});
test('đếm cửa sổ dài và parent đúng, không cộng ngôn ngữ hỗn hợp hai lần', () => {
  const rows = [
    { id:'one', parent_id:'shared', source:'example', stance:'confirmed', addressee:'assistant', language:'vi', format:'.txt', full_record_units:9000, labeled_input_units:600, selected_window_only:true, training_eligible:false },
    { id:'two', parent_id:'shared', source:'example', stance:'dismissed', addressee:'human', language:'en-vi', format:'.txt', full_record_units:9000, labeled_input_units:600, selected_window_only:true, training_eligible:false },
  ];
  const plan = { data: { pilot_target_records:10, minimum_source_groups:5, stance_targets:{confirmed:.4,dismissed:.4,uncertain:.2}, minimum_language_fraction:{vi:.4,en:.4} } };
  const summary = summarize(rows, [{ id:'group', size:2, proposed_constraint:'unassigned_role_review_required' }], plan);
  assert.equal(summary.parent_ids, 1); assert.equal(summary.long_record_texts_at_least_8000_utf16, 2);
  assert.equal(summary.long_labeled_inputs_at_least_8000_utf16, 0);
  assert.equal(summary.numerical_gaps_only.additional_monolingual_vi_for_300_target, 3);
  assert.equal(summary.numerical_gaps_only.additional_monolingual_en_for_300_target, 4);
  assert.equal(summary.can_finalize_train_dev, false);
});
test('registry thật chỉ dùng phiên bản sửa đang hoạt động và giữ đủ 178 bản ghi', () => {
  const { records, groups, summary } = buildRegistry();
  assert.equal(records.length, 178); assert.equal(summary.parent_ids, 131); assert.equal(groups.length, 71);
  assert.equal(records.filter(row => row.effective_version === 'ai_repaired').length, 6);
  assert.equal(new Set(groups.flatMap(group => group.members)).size, records.length);
  assert.ok(records.every(row => row.split === null && !row.training_eligible));
  assert.equal(summary.approved_training_records, 0);
});
