"""Worker classifier một request qua stdio; chỉ nạp artifact local đã pin, không tải/train."""
import contextlib
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys

# Chặn Hub trước khi import thư viện; không thay môi trường toàn hệ thống.
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['HF_DATASETS_OFFLINE'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
MAX_REQUEST_BYTES = 8 * 1024 * 1024


def sha_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def checked_manifest(path, allowed_root):
    root = Path(allowed_root).resolve(strict=True)
    path = Path(path).resolve(strict=True)
    if not path.is_relative_to(root):
        raise ValueError('Manifest phải nằm trong thư mục local đã cho phép.')
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if data.get('protocol') != 1 or not isinstance(data.get('model'), str) or not data['model']:
        raise ValueError('Sai định danh model.')
    if not re.fullmatch(r'[a-f0-9]{40}', str(data.get('revision', ''))):
        raise ValueError('Chưa pin commit model.')
    if data.get('labels') not in (['benign', 'malicious'], ['malicious', 'benign']):
        raise ValueError('Sai mapping nhãn.')
    limit = data.get('maxInputTokens')
    if type(limit) is not int or not 3 <= limit <= 32768:
        raise ValueError('Sai giới hạn token đã pin.')
    directory = Path(data.get('modelDir', '')).resolve(strict=True)
    if not directory.is_dir() or not directory.is_relative_to(root):
        raise ValueError('Model không ở thư mục local đã cho phép.')
    artifacts = data.get('artifactSha256')
    token_files = data.get('tokenizerFiles')
    if not isinstance(artifacts, dict) or 'config.json' not in artifacts or not isinstance(token_files, list) or not token_files:
        raise ValueError('Thiếu bảng hash artifact/tokenizer.')
    for name, expected in artifacts.items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts or not re.fullmatch(r'[a-f0-9]{64}', str(expected)):
            raise ValueError('Đường dẫn artifact hoặc hash không hợp lệ.')
        target = (directory / relative).resolve(strict=True)
        if not target.is_relative_to(directory) or not target.is_file() or sha_file(target) != expected:
            raise ValueError('Artifact thay đổi hoặc vượt thư mục model.')
    # Không để thư viện nạp một file config/tokenizer/weights chưa có trong bảng pin.
    for item in directory.rglob('*'):
        if item.is_file() and item.suffix.lower() in ('.json', '.model', '.txt', '.safetensors'):
            if item.relative_to(directory).as_posix() not in artifacts:
                raise ValueError('Có artifact có thể được nạp nhưng chưa pin.')
    if not any(name.endswith('.safetensors') for name in artifacts):
        raise ValueError('Chỉ chấp nhận weights safetensors đã pin.')
    expected_token_files = {name for name in artifacts if not name.endswith('.safetensors') and not name.endswith('.safetensors.index.json')}
    if len(set(token_files)) != len(token_files) or set(token_files) != expected_token_files:
        raise ValueError('Danh sách tokenizer chưa pin đầy đủ.')
    token_hash = hashlib.sha256(json.dumps({name: artifacts[name] for name in sorted(token_files)},
                                         sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if data.get('tokenizerSha256') != token_hash:
        raise ValueError('Hash tokenizer không khớp.')
    data['modelDir'] = str(directory)
    return data


class LocalBackend:
    def __init__(self, manifest, tokenizer_only=False):
        import torch
        from transformers import AutoConfig, AutoTokenizer, AutoModelForSequenceClassification
        self.torch = torch
        directory = manifest['modelDir']
        common = {'local_files_only': True, 'trust_remote_code': False}
        reviewed = manifest.get('backend') == 'piguard-reviewed-v1'
        if reviewed:
            if manifest['model'] != 'leolee99/PIGuard' or manifest['revision'] != 'dd78b24e330193a22d2293ac66922dd4f982f563':
                raise ValueError('Backend PIGuard không khớp model/commit đã rà.')
            implementation = Path(__file__).with_name('piguard_local.py')
            if sha_file(implementation) != manifest.get('backendCodeSha256'):
                raise ValueError('Code PIGuard local thay đổi sau pin.')
            from transformers import DebertaV2Config
            config = DebertaV2Config.from_dict(json.loads(Path(directory, 'config.json').read_text(encoding='utf-8')))
        else:
            if manifest.get('backend') not in (None, 'auto-local-v1'):
                raise ValueError('Backend chưa được hỗ trợ.')
            config = AutoConfig.from_pretrained(directory, **common)
        source_labels = [str(config.id2label[i]).casefold() for i in range(config.num_labels)]
        if reviewed and source_labels != ['benign', 'injection']:
            raise ValueError('Mapping PIGuard không giống bản đã rà.')
        labels = ['benign', 'malicious'] if reviewed else source_labels
        if labels != manifest['labels']:
            raise ValueError('id2label thực khác manifest.')
        self.tokenizer = AutoTokenizer.from_pretrained(directory, use_fast=True, **common)
        if not self.tokenizer.is_fast:
            raise ValueError('Tokenizer phải có offset mapping.')
        limits = [manifest['maxInputTokens']]
        for value in (getattr(config, 'max_position_embeddings', None), self.tokenizer.model_max_length):
            if isinstance(value, int) and 0 < value < 1000000:
                limits.append(value)
        if min(limits) < manifest['maxInputTokens']:
            raise ValueError('Ngân sách manifest lớn hơn giới hạn config/tokenizer.')
        self.model = None
        if not tokenizer_only:
            if reviewed:
                from piguard_local import ReviewedPIGuard
                self.model, info = ReviewedPIGuard.from_pretrained(directory, config=config, use_safetensors=True,
                                                                local_files_only=True, output_loading_info=True)
                if any(info.get(key) for key in ('missing_keys', 'unexpected_keys', 'mismatched_keys', 'error_msgs')):
                    raise ValueError('Weights PIGuard không khớp kiến trúc local; không dùng head ngẫu nhiên.')
            else:
                self.model = AutoModelForSequenceClassification.from_pretrained(directory, use_safetensors=True, **common)
            self.model.to('cpu').eval()

    def count(self, text):
        return len(self.tokenizer(text, truncation=False, add_special_tokens=True)['input_ids'])

    def offsets(self, text):
        return self.tokenizer(text, truncation=False, add_special_tokens=False,
                              return_offsets_mapping=True)['offset_mapping']

    def logits(self, text):
        encoded = self.tokenizer(text, truncation=False, add_special_tokens=True, return_tensors='pt')
        with self.torch.inference_mode():
            return self.model(**encoded).logits[0].to('cpu').tolist()


def identity(manifest):
    return {key: manifest[key] for key in ('model', 'revision', 'tokenizerSha256')}


def prepare(text, start_line, maximum, overlap, backend):
    if not isinstance(text, str) or not text.strip() or type(start_line) is not int or start_line < 1:
        raise ValueError('Nguồn chuẩn bị không hợp lệ.')
    if type(maximum) is not int or type(overlap) is not int or maximum < 1 or not 0 <= overlap < maximum:
        raise ValueError('Ngân sách cửa sổ không hợp lệ.')
    offsets = backend.offsets(text)
    previous = (0, 0)
    for start, end in offsets:
        if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text) or start < previous[0] or end < previous[1]:
            raise ValueError('Tokenizer trả offset không hợp lệ.')
        previous = (start, end)
    if not offsets:
        raise ValueError('Nguồn có nội dung nhưng không có offset.')
    # Python đếm code points; JavaScript đếm UTF-16 code units.
    utf16 = [0]
    for char in text:
        utf16.append(utf16[-1] + len(char.encode('utf-16-le')) // 2)
    windows = []
    token_start = 0
    previous_end = 0
    while token_start < len(offsets):
        start = 0 if not windows else offsets[token_start][0] if overlap else previous_end
        token_end = min(len(offsets), token_start + maximum)
        while True:
            end = len(text) if token_end == len(offsets) else offsets[token_end - 1][1]
            piece = text[start:end]
            count = backend.count(piece)
            if type(count) is not int or count < 0:
                raise ValueError('Tokenizer trả số token sai.')
            if count <= maximum:
                break
            token_end -= 1
            if token_end <= token_start:
                raise ValueError('Một đơn vị nguồn vượt ngân sách, không cắt ngầm.')
        if end <= start:
            raise ValueError('Cửa sổ không tiến triển.')
        line = start_line + text[:start].count('\n')
        windows.append({'id': f'window-{len(windows)+1}', 'startOffset': utf16[start], 'endOffset': utf16[end],
                        'startLine': line, 'endLine': line + piece.removesuffix('\n').count('\n'),
                        'text': piece, 'inputTokens': count})
        if token_end == len(offsets):
            break
        if token_end - token_start <= overlap:
            raise ValueError('Overlap không cho phép tiến triển.')
        previous_end = end
        token_start = token_end - overlap
    return windows


def handle(request, manifest, backend_factory=LocalBackend):
    if not isinstance(request, dict) or request.get('protocol') != 1 or any(request.get(key) != value for key, value in identity(manifest).items()):
        raise ValueError('Request khác model/revision/tokenizer đã pin.')
    operation = request.get('operation', 'classify')
    if operation not in ('prepare', 'classify'):
        raise ValueError('Operation không hỗ trợ.')
    common = {'protocol', 'model', 'revision', 'tokenizerSha256'}
    expected = common | ({'operation', 'text', 'startLine', 'maxInputTokens', 'overlapTokens'} if operation == 'prepare' else {'windows'} | ({'operation'} if 'operation' in request else set()))
    if set(request) != expected:
        raise ValueError('Sai trường request.')
    if operation == 'prepare':
        maximum = request['maxInputTokens']
        if type(maximum) is not int or maximum > manifest['maxInputTokens']:
            raise ValueError('Ngân sách vượt giới hạn model.')
        backend = backend_factory(manifest, tokenizer_only=True)
        windows = prepare(request['text'], request['startLine'], maximum, request['overlapTokens'], backend)
        return {'protocol': 1, **identity(manifest), 'operation': 'prepare',
                'sourceSha256': hashlib.sha256(request['text'].encode()).hexdigest(),
                'windows': windows}
    rows = request['windows']
    if not isinstance(rows, list) or not 1 <= len(rows) <= 256:
        raise ValueError('Batch phải có 1–256 cửa sổ.')
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'id', 'text'} or not isinstance(row['id'], str) or not row['id'] or row['id'] in seen or not isinstance(row['text'], str) or not row['text'].strip():
            raise ValueError('ID/text cửa sổ sai hoặc trùng.')
        seen.add(row['id'])
    backend = backend_factory(manifest)
    # Xác thực cả batch trước forward, không trả một phần rồi giấu lỗi nguồn còn lại.
    counts = [backend.count(row['text']) for row in rows]
    if any(type(count) is not int or not 1 <= count <= manifest['maxInputTokens'] for count in counts):
        raise ValueError('Cửa sổ quá dài; không được truncation.')
    result = []
    for row in rows:
        logits = backend.logits(row['text'])
        if not isinstance(logits, list) or len(logits) != 2 or any(type(value) not in (int, float) or not math.isfinite(value) for value in logits):
            raise ValueError('Logits không hợp lệ.')
        result.append({'id': row['id'], 'logits': logits})
    return {'protocol': 1, **identity(manifest), 'labels': manifest['labels'], 'windows': result}


def main(backend_factory=LocalBackend):
    try:
        manifest_path = os.environ.get('IPI_CLASSIFIER_MANIFEST')
        root = Path(os.environ.get('IPI_TRAINING_ROOT', 'E:/IPI-Training')).resolve()
        if os.name == 'nt' and root.drive.upper() != 'E:':
            raise ValueError('Runtime classifier phải nằm trên E.')
        if not manifest_path:
            raise ValueError('Chưa có manifest model local đã pin.')
        manifest = checked_manifest(manifest_path, root)
        raw = sys.stdin.buffer.readline(MAX_REQUEST_BYTES + 1)
        if len(raw) > MAX_REQUEST_BYTES or not raw.endswith(b'\n'):
            raise ValueError('Request quá dài hoặc thiếu kết thúc dòng.')
        request = json.loads(raw.decode('utf-8'))
        # Thư viện không được ghi log lẫn vào kênh JSON stdout.
        with contextlib.redirect_stdout(sys.stderr):
            response = handle(request, manifest, backend_factory)
        print(json.dumps(response, ensure_ascii=False, allow_nan=False), flush=True)
        return 0
    except Exception:
        # Không in nội dung request, đường dẫn người dùng hay token tài khoản vào lỗi.
        print(json.dumps({'protocol': 1, 'error': {'code': 'classifier_worker_failed',
              'message': 'Worker local không xử lý được request; kiểm tra manifest, artifact và ngân sách.'}}), flush=True)
        return 1


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    raise SystemExit(main())
