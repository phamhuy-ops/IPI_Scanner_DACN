"""Tạo ảnh rà nguồn cục bộ; không sửa hoặc thực thi nội dung tài liệu."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, ImageOps
sys.stdout.reconfigure(encoding='utf-8')

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'benchmark/experiments/public-vi-native-visual-v1'
if OUT.exists():
    raise SystemExit('Đợt kiểm tra đã tồn tại; không ghi đè.')
OUT.mkdir(parents=True)
source = json.loads((ROOT / 'benchmark/experiments/public-vi-native-intake-v1/ket-qua.json').read_text(encoding='utf-8'))
records = []
for item in source['files']:
    file = ROOT / item['path']
    assert hashlib.sha256(file.read_bytes()).hexdigest() == item['sha256']
    rec = {'id': item['id'], 'source_sha256': item['sha256']}
    if file.suffix == '.pdf':
        result = subprocess.run([shutil.which('pdfinfo'), str(file)], capture_output=True, check=True)
        (OUT / (item['id'] + '-pdfinfo.txt')).write_bytes(result.stdout)
        pages = [1, 2, 49, 62, 63] if item['id'] == 'vi-native-001' else [1, 10, 17, 23]
        rec['rendered_pages'] = pages
        for page in pages:
            subprocess.run([shutil.which('pdftoppm'), '-f', str(page), '-l', str(page), '-singlefile',
                            '-scale-to', '1400', '-png', str(file), str(OUT / f"{item['id']}-p{page}")],
                           capture_output=True, check=True)
    else:
        with zipfile.ZipFile(file) as archive:
            names = archive.namelist()
            metadata = {}
            for name in names:
                if name.startswith('docProps/') and name.endswith('.xml'):
                    tree = ET.fromstring(archive.read(name))
                    metadata[name] = {el.tag.split('}')[-1]: el.text for el in tree if el.text}
            # Giá trị metadata chỉ giữ trong artifact cục bộ để rà, không đưa vào model.
            (OUT / (item['id'] + '-metadata.json')).write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
            relationships = []
            for name in names:
                if name.endswith('.rels'):
                    for el in ET.fromstring(archive.read(name)):
                        if el.attrib.get('TargetMode') == 'External':
                            relationships.append({'part': name, **el.attrib})
            (OUT / (item['id'] + '-external-links.json')).write_text(json.dumps(relationships, ensure_ascii=False, indent=2), encoding='utf-8')
            media = [n for n in names if n.startswith('word/media/') and not n.endswith('/')]
            rec['media'] = []
            tiles = []
            for index, name in enumerate(media):
                raw = archive.read(name)
                try:
                    image = Image.open(io.BytesIO(raw)).convert('RGB')
                    rec['media'].append({'name': name, 'size': image.size, 'sha256': hashlib.sha256(raw).hexdigest()})
                    image.save(OUT / f"{item['id']}-media-{index+1:02}.png")
                    tile = Image.new('RGB', (460, 350), 'white')
                    thumb = ImageOps.contain(image, (450, 315))
                    tile.paste(thumb, ((460-thumb.width)//2, 25))
                    ImageDraw.Draw(tile).text((5, 5), f'{index+1:02} {Path(name).name}', fill='black')
                    tiles.append(tile)
                except Exception as error:
                    rec['media'].append({'name': name, 'render_error': str(error)})
            for start in range(0, len(tiles), 12):
                batch = tiles[start:start+12]
                sheet = Image.new('RGB', (1380, 350*((len(batch)+2)//3)), '#ddd')
                for i, tile in enumerate(batch):
                    sheet.paste(tile, ((i%3)*460, (i//3)*350))
                sheet.save(OUT / f"{item['id']}-contact-{start//12+1}.png")
            rec['external_relationship_count'] = len(relationships)
    records.append(rec)
(OUT / 'kiem-ke.json').write_text(json.dumps({'records': records, 'model_called': False,
    'visual_review_status': 'images_generated_pending_review', 'training_eligible': False}, ensure_ascii=False, indent=2), encoding='utf-8')
print('Đã tạo ảnh và metadata cục bộ cho bốn nguồn; chưa phê duyệt riêng tư/quyền dùng.')
