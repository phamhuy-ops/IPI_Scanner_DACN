// Chạy A/B riêng với core hiện tại sau sửa chẩn đoán cắt đầu ra.
const { main } = require('./run-semantic-stance-ab.cjs');
main({ name: 'bounded-review', module: '/src/ai/experiments/boundedReview.ts', request: 'boundedReviewRequest',
  entry: 'scripts/run-bounded-review-ab.cjs',
  change: 'Chỉ thêm maxLength=240 cho analysis và maxLength=320 cho reason trong schema classic; không giới hạn quote hoặc số bằng chứng, không sửa prompt/user/nguồn/stance/model/parser/chính sách.' })
  .catch(error => { console.error(error); process.exitCode = 1; });
