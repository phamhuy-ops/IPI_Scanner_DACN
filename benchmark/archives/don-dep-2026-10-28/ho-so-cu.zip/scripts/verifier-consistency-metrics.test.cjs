const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {summarize,decide}=require('./verifier-consistency-metrics.cjs');
const gates=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-consistency-candidate-v1/ung-vien.json')).selection_gates;
function fixture(){const candidate=Array.from({length:68},(_,i)=>({id:`case-${i}`,expected:'confirmed',predicted:'confirmed',parsed:true,correct_stance:true,
  cohort:i<12?'old_screen':'new_controls',language:'vi',group_id:'group-1',lexical_group:'lex-1',mode:'whole_source',seconds:1,peak_vram_allocated:100,
  gold_directive_covered:true,field_matches:{addressee:true,framing:true,deviation:true,hasDirective:true}}));
 const baseline=structuredClone(candidate);Object.assign(baseline[12],{parsed:false,predicted:null,correct_stance:false});return {baseline,candidate};}
test('Chỉ tăng JSON không đủ; cần tăng stance mới và không hồi quy',()=>{
 const {baseline,candidate}=fixture();assert.equal(decide(baseline,candidate,gates).passed,true);
 assert.equal(decide(candidate,candidate,gates).passed,false);
 Object.assign(candidate[0],{parsed:false,predicted:null,correct_stance:false});
 const result=decide(baseline,candidate,gates);assert.ok(result.failed_gates.some(g=>g.gate==='no_correct_to_error_or_uncertain_regression'));
});
test('TP mới cần đúng context/span; không bỏ qua tài nguyên hoặc thiếu ca',()=>{
 const {baseline,candidate}=fixture();candidate[12].field_matches.addressee=false;
 assert.ok(decide(baseline,candidate,gates).failed_gates.some(g=>g.gate==='new_attack_tp_requires_gold_directive_and_all_context_fields'));
 candidate[12].field_matches.addressee=true;candidate[1].peak_vram_allocated=120;
 assert.ok(decide(baseline,candidate,gates).failed_gates.some(g=>g.gate==='peak_allocated_vram_ratio_max'));
 assert.equal(decide(baseline,candidate.slice(1),gates).passed,false);
});
test('Lỗi và uncertain không thành TN; chia cho 0 là null',()=>{
 const result=summarize([{expected:'dismissed',predicted:null,parsed:false,correct_stance:false,seconds:1},
 {expected:'confirmed',predicted:'uncertain',parsed:true,correct_stance:false,seconds:1}]);
 assert.equal(result.tn,0);assert.equal(result.false_clear_fn,0);assert.equal(result.errors,1);assert.equal(result.precision,null);
});
