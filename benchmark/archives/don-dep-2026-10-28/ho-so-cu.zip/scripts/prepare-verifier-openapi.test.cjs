const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-openapi.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Mô tả API không tự là lệnh thực thi; các biến thể cùng tài liệu giữ chung nhóm', () => {
  const rows = buildRows();
  assert.equal(rows.length, 15);
  assert.equal(new Set(rows.map(r => r.source_parent_id)).size, 1);
  assert.equal(new Set(rows.map(r => r.group_id)).size, 1);
  for (let i = 0; i < rows.length; i += 5) {
    assert.deepEqual(rows.slice(i, i + 5).map(r => r.annotation.stance), ['dismissed', 'confirmed', 'confirmed', 'dismissed', 'uncertain']);
    assert.equal(rows[i].annotation.hasDirective, false);
    assert.equal(rows[i + 3].annotation.framing, 'quoted_example');
    assert.equal(rows[i + 4].annotation.framing, 'active');
    assert.equal(rows[i + 4].annotation.addressee, 'unclear');
  }
  for (const row of rows) {
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.training_eligible, false);
    const p = row.provenance, original = fs.readFileSync(p.source_file, 'utf8');
    assert.ok(row.text.includes(original.slice(...p.original_excerpt_range_utf16)));
    assert.equal(p.original_document_contains_this_injection, false);
  }
});
