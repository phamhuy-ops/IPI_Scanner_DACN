"""Kiểm tra bản train phản thực tế bằng tokenizer/collator hiện có; không tải weights."""
import hashlib
import json
import os
from pathlib import Path
from audit_verifier_tokenizer import MODEL, REVISION, completion_example
from verifier_collator import CompletionCollator


def main():
    from transformers import AutoTokenizer
    root = Path(__file__).resolve().parents[1]
    source = root / 'benchmark/experiments/verifier-counterfactual-train-v2'
    output = source / 'token-mask.json'
    if output.exists() or Path(os.environ['IPI_TRAINING_ROOT']).drive.lower() != 'e:':
        raise ValueError('Sai ổ lưu hoặc kết quả đã tồn tại.')
    manifest = json.loads((source / 'ket-qua.json').read_text(encoding='utf-8'))
    for name, expected in manifest['assets_sha256'].items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == expected
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=os.environ['HF_HUB_CACHE'], local_files_only=True, trust_remote_code=False)
    collator = CompletionCollator(tokenizer.pad_token_id, 2048)
    rows = []
    for line in (source / 'train.preview.jsonl').read_text(encoding='utf-8').splitlines():
        e = json.loads(line)
        target = json.dumps(e['target'], ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, e['payload']['messages'], target)
        batch = collator([{'input_ids': ids, 'labels': labels}])
        kept = batch['labels'][0].tolist()
        assert kept[:boundary] == [-100] * boundary
        assert tokenizer.decode([v for v in kept if v != -100]) == target + tokenizer.eos_token
        assert all(v == -100 for v, mask in zip(kept, batch['attention_mask'][0].tolist()) if mask == 0)
        rows.append({'id': e['id'], 'tokens': len(ids), 'loss_tokens': end - boundary})
    result = {'examples': len(rows), 'mask_collator_valid': len(rows), 'token_max': max(r['tokens'] for r in rows),
              'model_revision': REVISION, 'training_started': False, 'model_forward': False, 'rows': rows,
              'input_sha256': manifest['assets_sha256'], 'code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))


if __name__ == '__main__':
    main()
