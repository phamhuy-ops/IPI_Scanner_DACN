﻿# Chuyển bản train đã khóa sang E bằng sao chép và đối chiếu SHA; giữ bản C.
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$taskSource = Join-Path $taskRoot 'benchmark\experiments\verifier-counterfactual-train-v2'
$taskTarget = [System.IO.Path]::GetFullPath('E:\IPI-Training\data\verifier-counterfactual-train-v2')
if (-not $taskTarget.StartsWith('E:\IPI-Training\data\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Sai phạm vi E.' }
if (Test-Path -LiteralPath $taskTarget) { throw 'Đích đã có; không ghi đè.' }
$taskLock = Get-Content -LiteralPath (Join-Path $taskSource 'giao-thuc.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($taskEntry in $taskLock.locked_files_sha256.PSObject.Properties) {
    $taskPath = Join-Path $taskRoot $taskEntry.Name
    if ((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskEntry.Value) { throw 'Bản khóa đã đổi.' }
}
New-Item -ItemType Directory -Path $taskTarget -Force | Out-Null
$taskReceipts = @()
foreach ($taskName in @('train.preview.jsonl', 'mau-cho-duyet.jsonl', 'giao-thuc.json')) {
    $taskFrom = Join-Path $taskSource $taskName
    $taskTo = Join-Path $taskTarget $taskName
    Copy-Item -LiteralPath $taskFrom -Destination $taskTo
    $taskHash = (Get-FileHash -LiteralPath $taskFrom -Algorithm SHA256).Hash.ToLowerInvariant()
    if ((Get-FileHash -LiteralPath $taskTo -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash) { throw 'Hash bản E không khớp.' }
    $taskReceipts += @{ name = $taskName; sha256 = $taskHash }
}
@{ destination = $taskTarget; files = $taskReceipts; originals_preserved = $true; training_started = $false } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskSource 'ban-sao-o-e.json') -Encoding UTF8
Write-Output 'Da sao chep 3 file sang E va doi chieu SHA; chua huan luyen.'
