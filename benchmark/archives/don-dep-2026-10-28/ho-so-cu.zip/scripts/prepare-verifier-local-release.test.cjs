const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { replaceEmails, transform, partition } = require('./prepare-verifier-local-release.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Thay email xác định, giữ placeholder và nội dung mã hóa nguyên trạng', () => {
  const a = replaceEmails('Send to amy.watson@gmail.com.');
  assert.ok(a.includes('@example.invalid'));
  assert.ok(!a.includes('@gmail.com'));
  assert.equal(replaceEmails(a), a);
  assert.equal(replaceEmails('IEhpIGRlYXIs'), 'IEhpIGRlYXIs');
  const plain = replaceEmails('contact@contact.com');
  assert.equal(replaceEmails('`contact@contact.com`'), '`' + plain + '`');
  assert.equal(replaceEmails('"contact@contact.com"'), '"' + plain + '"');
});
test('Ánh xạ lại mọi span và giữ nhãn, nhóm, vai trò trên đúng 324 mẫu', () => {
  const rows = fs.readFileSync('benchmark/data/annotations/verifier-split-preview-v2/mau-cho-duyet.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const before = JSON.stringify(rows);
  let changed = 0;
  for (const row of rows) {
    const result = transform(row);
    assert.deepEqual(validateAnnotation(result.text, result.annotation), []);
    for (const field of ['id', 'group_id', 'source_parent_id', 'planned_role']) assert.equal(result[field], row[field]);
    for (const field of ['label', 'stance', 'addressee', 'framing', 'deviation', 'hasDirective']) assert.equal(result.annotation[field], row.annotation[field]);
    if (result.text !== row.text) changed++;
  }
  assert.equal(changed, 16);
  assert.equal(JSON.stringify(rows), before);
});

test('Giữ nguyên hai nguồn có quan hệ địa chỉ mã hóa/làm rối', () => {
  const rows = fs.readFileSync('benchmark/data/annotations/verifier-split-preview-v2/mau-cho-duyet.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  for (const id of ['verifier-llmail-v1:llmail-phase2-003', 'verifier-llmail-expansion-v1:llmail-phase2-037']) {
    const row = rows.find(r => r.id === id), after = transform(row);
    assert.equal(after.text, row.text);
    assert.deepEqual(after.annotation, row.annotation);
    assert.equal(after.transformation, 'preserved_raw_encoding_relationship_local_only');
  }
});
test('Không cho nhóm lẫn train/probe hoặc tự bật huấn luyện', () => {
  const a = { group_id: 'g', planned_role: 'train', training_eligible: false };
  assert.throws(() => partition([a, { ...a, planned_role: 'probe' }]), /lẫn/);
  assert.throws(() => partition([{ ...a, training_eligible: true }]), /bật/);
  assert.throws(() => partition([{ ...a, planned_role: 'other' }]), /vai trò/);
});
