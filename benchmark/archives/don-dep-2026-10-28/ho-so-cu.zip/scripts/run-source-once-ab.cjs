// Dùng cùng giao thức và cổng A/B; chỉ đổi đóng gói bằng chứng.
const { main } = require('./run-semantic-stance-ab.cjs');
main({ name: 'source-once', module: '/src/ai/experiments/sourceOnce.ts', request: 'sourceOnceRequest',
  entry: 'scripts/run-source-once-ab.cjs',
  change: 'Đưa toàn nguồn lên đầu, giữ nguyên byte nguồn; danh sách ứng viên chỉ còn id/chunkId, không lặp quote, rule, metadata hoặc lập luận. Giữ nguyên system prompt, schema, model, seed và parser/chính sách.' })
  .catch(error => { console.error(error); process.exitCode = 1; });
