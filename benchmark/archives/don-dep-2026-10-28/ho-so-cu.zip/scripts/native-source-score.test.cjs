const test = require('node:test'), assert = require('node:assert/strict');
const {request,parse}=require('./native-source-score.cjs');
test('chọn theo logprob thực, không theo raw token hoặc nhãn ngoài',()=>{
  const result=parse({response:'C',logprobs:[{top_logprobs:[{token:'A',logprob:-0.1},{token:'B',logprob:-3},{token:'C',logprob:-4}]}]});
  assert.equal(result.kind,'active');assert.equal(result.probability_calibrated,false);assert.equal(result.has_directive_evidence,false);
});
test('thiếu hoặc sai logprob là lỗi, không thành ordinary hoặc điểm0',()=>{
  assert.throws(()=>parse({response:'B'}));
  assert.throws(()=>parse({logprobs:[{top_logprobs:[{token:'A',logprob:-1},{token:'B',logprob:-2}]}]}));
});
test('payload native chỉ dùng text nguồn, không thêm metadata',()=>{
  const body=request('gemma3:1b','A normal source.');
  assert.equal(body.options.num_predict,1);assert.equal(body.stream,false);assert.equal(body.top_logprobs,20);
  assert.equal(body.prompt.includes('A normal source.'),true);assert.equal(body.messages,undefined);
});
