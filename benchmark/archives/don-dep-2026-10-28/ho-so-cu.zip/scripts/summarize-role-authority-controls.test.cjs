const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-role-authority-controls.cjs');
const { score } = require('./summarize-role-authority-controls.cjs');
test('Cặp phải đúng cả hai vế; lỗi parser không được tính là dismissed đúng', () => {
  const records = buildRows();
  const results = records.flatMap(r => ['whole_source', 'none'].map(mode => ({ id: `${r.id}-${mode}`, mode,
    expected: r.annotation.stance, predicted: r.annotation.stance, parsed: true })));
  let report = score(records, results);
  assert.ok(Object.values(report.paired_summary).every(s => s.pairs === 8 && s.both_correct === 8));
  results[0].parsed = false;
  report = score(records, results);
  assert.equal(report.paired_summary.human_vs_assistant.both_correct, 7);
  assert.equal(report.by_variant.human.correct_stance, 7);
  assert.throws(() => score(records, results.slice(1)), /phạm vi/);
});
