const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-vietnamese-workflow.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Giữ bốn cách hiểu cùng nhóm và đủ ngữ cảnh bằng chứng', () => {
  const rows = buildRows();
  assert.equal(rows.length, 16);
  const parents = [...new Set(rows.map(r => r.source_parent_id))];
  assert.equal(parents.length, 4);
  for (const parent of parents) {
    const members = rows.filter(r => r.source_parent_id === parent);
    assert.deepEqual(members.map(r => r.annotation.stance), ['dismissed', 'confirmed', 'dismissed', 'uncertain']);
    assert.equal(new Set(members.map(r => r.group_id)).size, 1);
    const attack = members[1].text;
    assert.ok(members[2].text.includes(attack));
    assert.equal(members[2].annotation.framing, 'quoted_example');
    assert.ok(members[3].annotation.uncertainty_notes.length);
  }
  for (const row of rows) {
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.language, 'vi');
    assert.equal(row.training_eligible, false);
    assert.equal(row.human_approved, false);
    assert.equal(row.split, null);
    assert.equal(row.provenance.external_content_reused, false);
    assert.equal(row.provenance.real_personal_data_used, false);
  }
});
