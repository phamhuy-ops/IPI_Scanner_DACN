// Tổng hợp sai sót từ kết quả đã đo; không gọi lại model hoặc thay nhãn nguồn.
const fs = require('node:fs');
const path = require('node:path');
const folder = path.resolve(process.argv[2] || '');
if (!folder.startsWith(path.resolve('benchmark/results') + path.sep)) throw Error('Chỉ đọc lượt đo trong benchmark/results.');
const read = file => JSON.parse(fs.readFileSync(path.join(folder, file), 'utf8'));
const summary = read('tong-hop.json');
if (summary.status !== 'complete') throw Error('Lượt đo chưa hoàn tất.');
const rows = read('cases.json'), plan = read('giao-thuc.json'), calls = read('model-calls.json');
const documents = read('extraction-documents.json');
const ids = predicate => rows.filter(predicate).map(row => row.id);
const sameSpan = (a, b) => a.citation.chunkId === b.citation.chunkId &&
  (a.citation.quote.includes(b.citation.quote) || b.citation.quote.includes(a.citation.quote));
const conflicts = [];
for (const row of rows) for (const role of ['detector', 'verifier']) {
  const assessments = row.state.suspicions.map(item => item[role]).filter(Boolean);
  for (let a = 0; a < assessments.length; a++) for (let b = a + 1; b < assessments.length; b++) {
    if (assessments[a].stance !== assessments[b].stance && sameSpan(assessments[a], assessments[b])) {
      conflicts.push({ id: row.id, role, first: assessments[a], second: assessments[b] });
    }
  }
}
const failures = rows.flatMap(row => (row.state.batchFailures || []).map(failure => ({ id: row.id, ...failure })));
let syntaxValid = 0;
for (const call of calls) {
  try {
    const envelope = JSON.parse(call.response);
    const raw = envelope.choices[0].message.content;
    JSON.parse(raw.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, ''));
    syntaxValid++;
  } catch { /* Không suy JSON lỗi là tấn công hoặc sạch. */ }
}
const forbiddenClean = ids(row => row.verdict === 'not_detected' && (row.processing !== 'completed' || row.coverage_limited));
const unsupportedConfirm = ids(row => row.verdict === 'ipi_detected' && !row.state.suspicions.some(item =>
  item.status === 'confirmed' && item.detector?.stance === 'confirmed' && item.verifier?.stance === 'confirmed'));
const findings = [
  { code: 'false_clear', title: 'Có tấn công nhưng trả chưa phát hiện', cases: ids(row => row.label === 'malicious' && row.verdict === 'not_detected'),
    explanation: 'Nguồn có chỉ dẫn tấn công theo nhãn đang dùng, nhưng Agent trả not_detected. Cổng kỹ thuật đủ coverage không tự chứng minh model hiểu đúng.',
    next: 'Ưu tiên tái hiện discovery theo từng hành vi với đối chứng sạch; không coi hai model cùng bỏ sót là tài liệu an toàn.' },
  { code: 'false_alert', title: 'Tài liệu sạch bị xác nhận IPI', cases: ids(row => row.label === 'benign' && row.verdict === 'ipi_detected'),
    explanation: 'Cả hai vai trò cùng xác nhận sai theo nhãn đối chiếu.', next: 'Kiểm tra người nhận và bao khung bằng nguồn đầy đủ, thêm đối chứng gần giống.' },
  { code: 'benign_review', title: 'Mẫu sạch bị giữ lại cần xem xét', cases: ids(row => row.label === 'benign' && row.verdict === 'needs_review'),
    explanation: 'Không phải false positive đã xác nhận, nhưng làm người dùng phải rà thủ công thêm; có thể do model hiểu nhầm hoặc lỗi kỹ thuật.',
    next: 'Tách lỗi kỹ thuật khỏi nghi vấn ngữ nghĩa; rà riêng câu cho người và ví dụ được trích dẫn.' },
  { code: 'attack_review', title: 'Tấn công chưa được chốt', cases: ids(row => row.label === 'malicious' && row.verdict === 'needs_review'),
    explanation: 'Nguồn có tấn công nhưng model bất đồng, thiếu nhận định hoặc phản hồi lỗi. Không tính những ca này là phát hiện đã xác nhận hoặc false clear.',
    next: 'Đối chiếu batch lỗi và từng vai trò trước khi sửa tầng tạo ứng viên/xác minh.' },
  { code: 'invalid_response', title: 'Model trả đầu ra không hợp lệ', cases: [...new Set(failures.map(row => row.id))],
    explanation: 'JSON hoặc trích dẫn/schema vi phạm hợp đồng nên bị từ chối. Lỗi xử lý đã được giữ riêng khỏi kết luận bảo mật.',
    next: 'Dùng file/dòng/model trong batchFailures và raw response để tái hiện; không nới validator.' },
  { code: 'same_role_conflict', title: 'Một vai trò tự đưa nhận định trái nhau', cases: [...new Set(conflicts.map(row => row.id))],
    explanation: 'Cùng vai trò có các quote chồng nhau nhưng stance khác nhau. Classic schema kiểm cấu trúc từng nhận định, chưa chặn nhất quán ngữ nghĩa giữa các nhận định.',
    next: 'Thiết kế đối chứng cho mâu thuẫn nội bộ và định vị span; chưa tự gộp/chọn stance thuận lợi.' },
  { code: 'uncertain_clear', title: 'Ca nhãn mơ hồ bị kết luận chưa phát hiện', cases: ids(row => row.label === 'uncertain' && row.verdict === 'not_detected'),
    explanation: 'Theo nhãn dev, ngữ cảnh chưa đủ; Agent lại kết luận chưa phát hiện. Nhãn dev vẫn cần giới hạn độ chắc chắn.',
    next: 'Làm rõ loại ngữ cảnh bị thiếu và quy tắc abstention bằng đối chứng, không lấy metadata làm input.' },
].filter(finding => finding.cases.length);
const extraction = documents.individual.map(row => ({ file: row.file, ok: row.scan.ok,
  total: row.scan.metadata?.coverage?.totalChunks, selected: row.scan.metadata?.semanticChunks?.length,
  extraction: row.scan.metadata?.fileResults, model_review_performed: false }));
const stages = {
  extraction: { ok: rows.filter(row => row.state.scanResult?.ok).length, total: rows.length },
  selection: { complete: rows.filter(row => row.state.scanResult?.metadata.coverage?.coverageLimited === false).length,
    selected_chunks: rows.reduce((sum, row) => sum + (row.state.reviewProgress?.selectedChunkIds.length || 0), 0),
    extracted_chunks: rows.reduce((sum, row) => sum + (row.state.reviewProgress?.totalChunks || 0), 0) },
  prefilter: { note: 'Rule chỉ tạo nghi vấn, không phải xác nhận IPI.',
    cases_with_suspicions: rows.filter(row => row.state.scanResult?.findings.length).length,
    attacks_without_rule_suspicions: ids(row => row.label === 'malicious' && !row.state.scanResult?.findings.length) },
};
for (const role of ['detector', 'verifier']) {
  stages[role] = { note: 'Nhận định riêng từng vai trò, không phải kết luận xác nhận của pipeline.',
    metrics: require('./priority-one-metrics.cjs').metrics(rows.map(row => {
      const progress = row.state.reviewProgress;
      const reviewed = progress?.[role === 'detector' ? 'detectorReviewedChunkIds' : 'verifierReviewedChunkIds'] || [];
      const complete = !!progress?.selectedChunkIds.length && progress.selectedChunkIds.every(id => reviewed.includes(id));
      const assessments = row.state.suspicions.map(item => item[role]).filter(Boolean);
      const verdict = assessments.some(item => item.stance === 'confirmed') ? 'ipi_detected'
        : !complete || assessments.some(item => item.stance === 'uncertain') ? 'needs_review' : 'not_detected';
      return { ...row, verdict, processing: complete ? 'completed' : 'incomplete', coverage_limited: !complete };
    })) };
}
const result = { findings, batch_failures: failures, internal_conflicts: conflicts, extraction,
  stages,
  combined_coverage: documents.combined.metadata.coverage,
  invariants: { forbidden_clean_with_incomplete: forbiddenClean, confirmed_without_both_roles: unsupportedConfirm,
    accepted_bad_citations: rows.reduce((sum, row) => sum + row.citations.bad_source_references, 0) },
  calls: { total: calls.length, json_syntax_valid: syntaxValid, syntax_valid_rate: calls.length ? syntaxValid/calls.length : null,
    failed_batches: failures.length, note: 'JSON cú pháp hợp lệ khác schema/citation hợp lệ và khác ý nghĩa đúng.' },
  metrics: summary.metrics, sources: summary.by_source, groups: summary.by_group, languages: summary.by_language,
  model_resources: calls.map(call => call.resources).filter(Boolean), limitations: summary.limits };
fs.writeFileSync(path.join(folder, 'sai-sot.json'), JSON.stringify(result, null, 2));
const ratio = value => value === null ? 'chưa xác định' : `${(value*100).toFixed(1)}%`;
const binary = summary.metrics.binary;
const markdown = '# Kiểm tra luồng Agent bằng benchmark hiện có\n\n' +
  `Đã hoàn tất ${rows.length}/${plan.cases.length} ca, ${calls.length} request model thật, giữ gemma3:1b / qwen2.5-coder:1.5b và classic-v1/standard/Balanced. Seed 42. Không train, không sửa cấu hình giữa lượt.\n\n` +
  `Có ${binary.matrix.malicious.ipi_detected} tấn công được xác nhận, ${binary.matrix.malicious.not_detected} tấn công trả chưa phát hiện, ${binary.matrix.benign.ipi_detected} mẫu sạch bị xác nhận IPI và ${binary.review_needed} ca nhị phân cần xem xét. Hai nhãn uncertain được báo riêng trong JSON.\n\n` +
  `Precision ${ratio(binary.precision_of_alerts)}, confirmed recall ${ratio(binary.confirmed_attack_recall)}, F1 ${ratio(binary.f1)}, FPR ${ratio(binary.false_alert_rate_on_benign)}, decision coverage ${ratio(binary.decision_coverage)}. Recall dùng toàn bộ mẫu tấn công, giữ abstention riêng.\n\n` +
  '## Sai sót quan sát được\n\n' + findings.map((finding, index) => `${index+1}. **${finding.title} (${finding.cases.length} ca: ${finding.cases.join(', ')}).** ${finding.explanation} Hướng xử lý: ${finding.next}`).join('\n\n') +
  '\n\n## Phần luồng đã kiểm chứng\n\n' +
  `Không thấy kết luận sạch khi còn lỗi/coverage thiếu: ${forbiddenClean.length} vi phạm. Không thấy ipi_detected thiếu cả hai vai trò xác nhận: ${unsupportedConfirm.length} vi phạm. Trích dẫn đã được chấp nhận nhưng không khớp nguồn: ${result.invariants.accepted_bad_citations}. Đây là kiểm tra chính sách, không chứng nhận nhận diện đúng.\n\n` +
  `PDF/DOCX: bốn file đã chạy extraction riêng và chung; khi quét chung chọn ${documents.combined.metadata.semanticChunks.length}/${documents.combined.metadata.coverage.totalChunks} chunk. Chưa gọi model cho các tài liệu dài này; không được suy đã đọc hết hoặc có nhãn sạch. Chưa OCR đối chiếu trang ảnh.\n\n` +
  `P95 pipeline: ${summary.pipeline_seconds_p95.toFixed(2)} giây/ca; RSS snapshot Node ${Math.round(summary.harness_rss_bytes/1024/1024)} MiB, không phải peak tổng hệ thống. Snapshot Ollama từng call trong model-calls.json; không dùng làm peak VRAM.\n\n` +
  '## Bằng chứng và giới hạn\n\n' +
  '- [Ca và nhãn khóa trước đo](giao-thuc.json).\n- [Trạng thái pipeline từng ca](cases.json).\n- [Request/response model thật](model-calls.json).\n- [Tổng hợp theo nguồn/nhóm/ngôn ngữ](tong-hop.json).\n- [Sai sót và kiểm tra invariant](sai-sot.json).\n- [Extraction PDF/DOCX](extraction-documents.json).\n\n' +
  'Đây là lượt chẩn đoán trên dev/fixture đã dùng và subset nguồn ngoài, không phải toàn dataset hoặc holdout độc lập. Nhãn nguồn/AI có giới hạn; kết quả không chứng minh mọi lỗi đều do một nguyên nhân duy nhất. UI/native IPC chưa được đo. Test ứng dụng hiện tại 284/284 đạt nhưng không thay thế kết quả model thật này. Ưu tiên 1 vẫn mở.\n';
fs.writeFileSync(path.join(folder, 'sai-sot.md'), markdown);
console.log(JSON.stringify({ findings: findings.map(row => ({ code: row.code, count: row.cases.length })), invariants: result.invariants, calls: result.calls, combined: result.combined_coverage }));
