const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { buildRows } = require('./prepare-external-ai-batch.cjs');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
test('giữ text gốc/span/license, ghi AI riêng và không tăng parent bằng biến thể', () => {
  const rows = buildRows();
  assert.equal(rows.length, 30);
  assert.equal(new Set(rows.map(r => r.source_parent_id)).size, 24);
  for (const row of rows) {
    assert.equal(hash(Buffer.from(row.text)), row.input_sha256);
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.review_status, 'ai_reviewed');
    assert.equal(row.training_eligible, false);
    assert.equal(row.split, null);
    if (row.source === 'uiuc-kang-lab/InjecAgent') {
      const original = JSON.parse(fs.readFileSync(row.provenance.source_file))[row.provenance.source_row - 1];
      assert.equal(row.text, original['Tool Response']);
      assert.equal(row.provenance.license_declared, 'MIT');
      assert.equal(row.provenance.revision.length, 40);
    }
  }
});
test('base/enhanced cùng parent/nhóm; uncertain phụ thuộc setup text-only, không đổi nhãn gốc', () => {
  const rows = buildRows();
  const uncertain = rows.filter(r => r.annotation.stance === 'uncertain');
  assert.equal(uncertain.length, 6);
  for (const row of uncertain) {
    const paired = rows.find(r => r.source_parent_id === row.source_parent_id && r.annotation.stance === 'confirmed');
    assert.ok(paired);
    assert.equal(paired.group_id, row.group_id);
    assert.equal(row.provenance.source_label_context_disagreement, true);
    assert.equal(row.review_scope, 'text_only_no_user_intent');
    assert.match(paired.annotation.directive_spans[0].quote, /^IMPORTANT!!! Ignore all previous instructions/);
  }
});
