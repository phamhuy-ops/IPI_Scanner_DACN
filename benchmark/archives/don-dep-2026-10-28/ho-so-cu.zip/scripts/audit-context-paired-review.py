"""Rà trùng lô paired-context bằng từ vựng; không đọc target/gold để gán nhãn."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_helper(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def texts(value, location='$'):
    # Chỉ lấy trường nội dung; bỏ target/annotation/nhãn và metadata nguồn.
    if isinstance(value, list):
        for index, row in enumerate(value):
            yield from texts(row, f'{location}[{index}]')
    elif isinstance(value, dict):
        for key in ('text', 'context', 'document', 'prompt', 'Tool Response'):
            if isinstance(value.get(key), str) and value[key].strip():
                yield f'{location}.{key}', value[key]
        for key in ('records', 'samples', 'cases', 'chunks', 'semanticChunks', 'inputs', 'windows', 'fixtures'):
            if isinstance(value.get(key), (dict, list)):
                yield from texts(value[key], f'{location}.{key}')
        # Preview cũ bọc nguồn trong user message; bỏ system và assistant target.
        payload = value.get('payload')
        if isinstance(payload, dict) and isinstance(payload.get('messages'), list):
            for index, message in enumerate(payload['messages']):
                if isinstance(message, dict) and message.get('role') == 'user' and isinstance(message.get('content'), str):
                    yield f'{location}.payload.messages[{index}].content', message['content']


def main():
    helper = load_helper('paired_corpus_index', 'audit-verifier-corpus.py')
    folder = ROOT / 'benchmark/experiments/context-paired-review-v1'
    batch_file = folder / 'lo-ra-soat.jsonl'
    rows = [json.loads(line) for line in batch_file.read_text(encoding='utf-8').splitlines() if line.strip()]
    index = helper.Index([{'text': row['document']} for row in rows])
    paths = set((ROOT / 'benchmark/data').rglob('*.json')) | set((ROOT / 'benchmark/data').rglob('*.jsonl'))
    for pattern in ('inputs.jsonl', '*.preview.jsonl', 'mau-tham-chieu.jsonl'):
        paths.update((ROOT / 'benchmark/experiments').rglob(pattern))
    inventory, errors, omitted, cache, matches = [], [], [], {}, {}
    for file in sorted(paths):
        relative = file.relative_to(ROOT).as_posix()
        raw = file.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        count = extracted = 0
        try:
            content = raw.decode('utf-8-sig')
            records = (json.loads(line) for line in content.splitlines() if line.strip()) if file.suffix == '.jsonl' else iter([json.loads(content)])
            for count, record in enumerate(records, 1):
                for field, text in texts(record):
                    extracted += 1
                    normalized = helper.lex.normalize(text)
                    key = hashlib.sha256(normalized.encode()).hexdigest()
                    if key not in cache:
                        cache[key] = index.match(text)
                    for candidate, methods in cache[key].items():
                        hit = matches.setdefault((candidate, relative), {'count': 0, 'methods': set(), 'method_counts': Counter(), 'examples': []})
                        hit['count'] += 1
                        hit['methods'].update(methods)
                        hit['method_counts'].update(methods)
                        if len(hit['examples']) < 3:
                            hit['examples'].append({'record_number': count, 'field': field})
            if not extracted:
                omitted.append(relative)
            inventory.append({'file': relative, 'sha256': digest, 'records': count, 'text_fields': extracted})
        except (ValueError, UnicodeError) as error:
            errors.append({'file': relative, 'error': str(error)})
    details = [{'candidate_id': rows[i]['id'], 'file': file, 'count': hit['count'],
                'methods': sorted(hit['methods']), 'method_counts': dict(hit['method_counts']), 'examples': hit['examples']}
               for (i, file), hit in sorted(matches.items())]
    unchanged = all(hashlib.sha256((ROOT / item['file']).read_bytes()).hexdigest() == item['sha256'] for item in inventory)
    summary = {
        'status': 'phase0_not_ready', 'batch_sha256': hashlib.sha256(batch_file.read_bytes()).hexdigest(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'command': 'python scripts/audit-context-paired-review.py',
        'files': len(inventory), 'records': sum(item['records'] for item in inventory),
        'text_fields': sum(item['text_fields'] for item in inventory), 'unique_normalized_texts': len(cache),
        'matched_candidate_file_pairs': len(details), 'inputs_unchanged': unchanged,
        'per_candidate': [{'id': row['id'], 'files_with_matches': sum(hit['candidate_id'] == row['id'] for hit in details),
                           'training_eligible': False} for row in rows],
        'errors': errors, 'files_without_recognized_text_fields': omitted, 'inventory': inventory,
        'scope': 'benchmark/data JSON/JSONL; experiments inputs, preview và reference JSONL, gồm user message trong payload. Không gồm CSV, PDF/DOCX hoặc mọi tên trường tùy ý.',
        'methods': ['NFKC/casefold/whitespace exact', 'trigram Jaccard >=0.8', 'shared 12-token passage'],
        'policy': 'Mọi hit là cờ cần rà, không tự kết luận nhãn/trùng ngữ nghĩa. Cả nhóm lock-access giữ review-only; chưa phát hành train.',
        'limitations': ['Không chứng minh độc lập từ việc không có lexical hit.', 'Shared passage có thể do phần bao khung sản phẩm/repository dùng chung.',
                       'Chưa có đồ thị nhóm/task/template toàn kho hoặc xác minh danh sách protected đầy đủ.',
                       'User message preview là envelope có prompt/reference; shared passage chỉ là cờ cần rà, không chứng minh nguyên document trùng.',
                       'Không đọc gold/target; các file không có trường được hỗ trợ được liệt kê riêng.'],
        'training_runs': 0, 'model_calls': 0,
    }
    (folder / 'overlap-matches.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in details), encoding='utf-8')
    (folder / 'overlap-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: summary[key] for key in ('status', 'files', 'records', 'text_fields', 'unique_normalized_texts', 'matched_candidate_file_pairs', 'inputs_unchanged', 'errors')}, ensure_ascii=False))
    if errors or not unchanged:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
