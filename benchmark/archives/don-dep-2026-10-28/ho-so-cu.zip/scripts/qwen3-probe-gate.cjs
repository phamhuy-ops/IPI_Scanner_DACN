// Cổng lựa chọn dev: cải thiện định dạng riêng lẻ không đủ điều kiện nhận diện.
function passes({baseline,candidate,uncertainCorrect,regressions,groupRegressions,ratio}){
 return candidate.examples===16&&candidate.parsed===16&&candidate.correct_stance>baseline.correct_stance&&candidate.tp>baseline.tp&&uncertainCorrect>0&&!regressions.length&&!groupRegressions.length&&candidate.gold_instruction_covered_tps===candidate.tp&&Number.isFinite(ratio)&&ratio<=3;
}
module.exports={passes};
