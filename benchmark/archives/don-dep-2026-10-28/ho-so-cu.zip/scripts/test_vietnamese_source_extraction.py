"""Kiểm tra lấy đoạn văn, không gọi mạng và không tuyên bố extractor ứng dụng đạt."""
import unittest
from fetch_vietnamese_articles import Paragraphs


class ExtractionTests(unittest.TestCase):
    def test_keep_unicode_paragraph_boundaries_skip_nonprose(self):
        parser = Paragraphs()
        parser.feed('<p>Nền <b>tiếng Việt</b> 😀<sup>12</sup> còn nguyên.</p>'
                    '<table><tr><td><p>Nội dung bảng không lấy.</p></td></tr></table>'
                    '<script>do_not_execute()</script><p>Đoạn thứ hai &amp; liên kết.</p>')
        self.assertEqual(parser.blocks, ['Nền tiếng Việt 😀 còn nguyên.', 'Đoạn thứ hai & liên kết.'])


if __name__ == '__main__':
    unittest.main()
