// Tái dựng input/target từ nhãn đã duyệt và kiểm tra parser; không gọi model.
const fs = require('node:fs');
const path = require('node:path');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const dir = path.join(root, 'benchmark/data/annotations/verifier-external-normalized-v1');
async function main() {
  const read = file => fs.readFileSync(path.join(dir, file));
  const manifest = JSON.parse(read('manifest.json'));
  const records = read('nhan-va-bang-chung.jsonl').toString().trim().split(/\r?\n/).map(JSON.parse);
  const examples = JSON.parse(read('bien-the-kiem-tra.json'));
  for (const [file, expected] of Object.entries(manifest.assets_sha256)) if (hash(read(file)) !== expected) throw new Error(`Tài sản đã đổi: ${file}`);
  const source = path.join(root, 'benchmark/data/annotations/verifier-expansion-v1');
  for (const [key, file] of Object.entries({ queue: 'hang-cho-gan-nhan.jsonl', reviews: 'luot-duyet-02.json', proposals: 'de-xuat-luot-duyet-02.json' })) {
    if (hash(fs.readFileSync(path.join(source, file))) !== manifest.source_sha256[key]) throw new Error(`Nguồn đã đổi: ${file}`);
  }
  const reviews = JSON.parse(fs.readFileSync(path.join(source, 'luot-duyet-02.json'))).items;
  if (records.length !== 27 || examples.length !== 54 || new Set(records.map(row => row.id)).size !== 27 ||
    new Set(examples.map(row => row.id)).size !== 54) throw new Error('Thiếu hoặc trùng nguồn/biến thể.');
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  let valid = 0;
  try {
    const { normalizeExternal } = await server.ssrLoadModule('/scripts/normalize-reviewed-external.ts');
    for (const row of records) {
      const review = reviews.find(review => review.id === row.id);
      if (review?.decision !== 'accept_annotation' || review.review_status !== 'human_reviewed' ||
        hash(JSON.stringify(review)) !== row.review_sha256 || row.split !== null || row.training_eligible !== false) throw new Error('Mẫu chưa duyệt/ngoài phạm vi hoặc tự chốt split.');
      if (hash(Buffer.from(row.text)) !== row.input_sha256) throw new Error('Nguồn đã đổi.');
      const paired = examples.filter(example => example.source_record_id === row.id);
      if (paired.length !== 2 || new Set(paired.map(e => e.mode)).size !== 2) throw new Error('Thiếu cặp chế độ.');
      for (const example of paired) {
        if (example.group_id !== row.group_id) throw new Error('Biến thể không cùng nhóm nguồn.');
        const rebuilt = normalizeExternal(row.text, review.annotation, example.mode);
        if (validateAnnotation(row.text, rebuilt.annotation).length || JSON.stringify(row.annotation) !== JSON.stringify(rebuilt.annotation)) throw new Error('Span hoặc nhãn không khớp.');
        if (JSON.stringify(JSON.parse(read(example.input_file))) !== JSON.stringify(rebuilt.payload) ||
          JSON.stringify(JSON.parse(read(example.target_file))) !== JSON.stringify(rebuilt.response)) throw new Error('Input/target không khớp tái dựng.');
        if (!rebuilt.validation.parser_valid) throw new Error('Parser không chấp nhận.');
        valid++;
      }
    }
  } finally { await server.close(); }
  const files = ['scripts/normalize-reviewed-external.cjs', 'scripts/normalize-reviewed-external.ts', 'scripts/verifier-batch-renderer.ts',
    'scripts/audit-normalized-external.cjs', 'scripts/context-annotations.cjs', 'src/ai/agents/document/compactVerifier.ts',
    'src/ai/agents/document/sourceReferences.ts', 'src/ai/agents/document/reviewPolicy.ts', 'src/ai/agents/document/evidence.ts'];
  const result = { source_records: records.length, contract_examples: examples.length, parser_valid: valid,
    exact_rebuild_valid: valid === 54, shared_group_preserved: true, metadata_excluded_from_input: true,
    code_sha256: Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(path.join(root, file)))])),
    human_span_review_complete: false, final_split_created: false, training_ready: false, independent: false };
  fs.writeFileSync(path.join(dir, 'kiem-tra-chuan-hoa.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ ...result, code_sha256: '[đã lưu]' }, null, 2));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
