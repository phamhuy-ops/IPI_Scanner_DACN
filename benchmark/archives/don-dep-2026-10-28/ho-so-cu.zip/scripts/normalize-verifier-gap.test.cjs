const { test } = require('node:test');
const assert = require('node:assert/strict');
const { makeWindows, normalizeRow } = require('./normalize-verifier-gap.cjs');
const { hash } = require('./context-annotations.cjs');
const { buildCases } = require('./prepare-verifier-gap-batch.cjs');
test('phủ trọn nguồn CRLF/Unicode, không cắt dòng và không treo với dòng đơn', () => {
  const text = 'A😀\r\nB\r\nC\nD';
  const windows = makeWindows(text, 7);
  const covered = new Set();
  for (const w of windows) { assert.equal(w.text, text.slice(w.start, w.end)); for (let i=w.start;i<w.end;i++) covered.add(i); }
  assert.equal(covered.size, text.length);
  assert.equal(makeWindows('a\nb\nc', 2).length, 3);
  assert.throws(() => makeWindows('dòng quá dài', 3));
});
test('giữ nguyên trích dẫn bao khung và ánh xạ ngược span cho mọi nhãn/vị trí', () => {
  for (const row of buildCases()) {
    const review = { status: 'human_reviewed', decision: 'accept', input_sha256: row.input_sha256,
      draft_sha256: hash(JSON.stringify(row.draft_annotation)) };
    const n = normalizeRow(row, review);
    assert.equal(n.text, row.text);
    assert.equal(n.window_annotation.stance, row.draft_annotation.stance);
    assert.equal(n.training_eligible, false);
    if (row.draft_annotation.stance === 'dismissed') assert.match(n.selected_window.text, /ví dụ|example|quotes|bài giảng/i);
    for (const span of n.window_annotation.directive_spans) assert.equal(row.text.slice(span.start+n.selected_window.start, span.end+n.selected_window.start), span.quote);
    assert.throws(() => normalizeRow(row, { ...review, input_sha256: 'sai' }));
  }
});
