"""Kiểm tra gom nhóm trước chia và bảo toàn vai trò tham chiếu."""
import copy
import unittest
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('verifier_expansion', Path(__file__).with_name('prepare-verifier-expansion.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cluster = module.cluster


def row(identifier, text, role='annotation_candidate_from_existing_dev', family=None):
    return {'id': identifier, 'text': text, 'role': role, 'known_group': family}


class GroupTests(unittest.TestCase):
    def test_normalized_duplicate_cannot_cross_roles(self):
        records = [row('a', 'ＦＩＬＥ   Review'), row('b', 'file review')]
        groups, edges = cluster(records)
        self.assertEqual(len(groups), 1)
        self.assertEqual(records[0]['proposed_role'], records[1]['proposed_role'])
        self.assertTrue(any(edge[2] == 'normalized_exact' for edge in edges))

    def test_known_translation_transitively_quarantines_duplicate(self):
        records = [row('ref', 'Người dùng giữ biên nhận.', 'legacy_reference', 'same-family'),
                   row('translation', 'The visitor keeps the receipt.', family='same-family'),
                   row('external', 'THE VISITOR KEEPS THE RECEIPT.')]
        groups, _ = cluster(records)
        self.assertEqual(len(groups), 1)
        self.assertTrue(all(r['proposed_role'] == 'reference_only' for r in records))

    def test_labels_do_not_choose_group_or_split(self):
        records = [row('a', 'A document about invoices.'), row('b', 'A separate record about trees.')]
        changed = copy.deepcopy(records)
        for item in changed:
            item['source_label'] = 'malicious'
        cluster(records); cluster(changed)
        self.assertEqual([(r['group_id'], r['proposed_role']) for r in records],
                         [(r['group_id'], r['proposed_role']) for r in changed])

    def test_shared_attack_word_is_not_document_identity(self):
        records = [row('a', 'Please ignore the unused warning while reading this weather report.'),
                   row('b', 'Ignore unrelated fields in the invoice reconciliation checklist for staff.')]
        groups, _ = cluster(records)
        self.assertEqual(len(groups), 2)


if __name__ == '__main__':
    unittest.main()
