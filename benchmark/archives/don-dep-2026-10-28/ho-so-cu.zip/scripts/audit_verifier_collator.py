"""Kiểm tra tensor sau collator trên bản xem trước; không forward/học dữ liệu dev."""
import hashlib
import json
import os
from pathlib import Path
import sys
from transformers import AutoTokenizer
from audit_verifier_tokenizer import MODEL, REVISION, completion_example
from verifier_collator import CompletionCollator

ROOT = Path(__file__).resolve().parents[1]


def main():
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=os.environ['HF_HUB_CACHE'],
                                             local_files_only=True, trust_remote_code=False)
    output = ROOT / 'benchmark/experiments/verifier-collator-v1'
    if output.exists():
        raise ValueError('Không ghi đè audit collator đã có.')
    inputs = {}
    def read(relative):
        p = ROOT / relative
        inputs[relative] = hashlib.sha256(p.read_bytes()).hexdigest()
        return json.loads(p.read_text(encoding='utf-8'))
    prepared = []
    external = 'benchmark/data/annotations/verifier-external-normalized-v1/'
    for row in read(external + 'bien-the-kiem-tra.json'):
        prepared.append((row['id'], read(external + row['input_file']), read(external + row['target_file'])))
    for row in read('benchmark/experiments/verifier-tokenizer-v1/ban-xem-truoc/mau.json')['examples']:
        prepared.append((row['id'], row['payload'], row['target']))
    active = read('benchmark/data/annotations/verifier-gap-repair-v1/ban-su-dung-hien-tai.json')['active_sources']
    for folder in sorted({r['version_path'] for r in active}):
        active_ids = {r['source_record_id'] for r in active if r['version_path'] == folder}
        for row in read(folder + '/ban-xem-truoc.json')['examples']:
            if row['source_record_id'] in active_ids:
                prepared.append((row['id'], row['payload'], row['target']))
    examples = []
    for identifier, payload, target in prepared:
        text = json.dumps(target, ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, payload['messages'], text)
        examples.append({'id': identifier, 'input_ids': ids, 'labels': labels,
                         'target': text, 'boundary': boundary, 'end': end})
    # Dùng tensor batch 2 độ dài khác nhau để kiểm tra padding; không dùng batch này để đo GPU.
    examples.sort(key=lambda row: len(row['input_ids']))
    collator = CompletionCollator(tokenizer.pad_token_id, 2048)
    checked = []
    for index in range(0, len(examples), 2):
        source = examples[index:index + 2]
        batch = collator(source)
        for i, row in enumerate(source):
            labels = batch['labels'][i].tolist()
            attention = batch['attention_mask'][i].tolist()
            assert labels[:row['boundary']] == [-100] * row['boundary']
            assert all(label == -100 for label, mask in zip(labels, attention) if mask == 0)
            assert tokenizer.decode([v for v in labels if v != -100]) == row['target'] + tokenizer.eos_token
            # Causal LM tự dịch labels một vị trí; không dịch lần nữa trong collator.
            assert sum(v != -100 for v in labels[1:]) == row['end'] - row['boundary']
            checked.append({'id': row['id'], 'tokens': len(row['input_ids']),
                            'padded_tokens': len(labels), 'target_preserved': True})
    result = {'examples': len(examples), 'collator_valid': len(checked), 'no_dev_model_forward_or_updates': True,
        'test_tensor_batch_size': 2, 'gpu_micro_batch_size_not_inferred_from_this_test': True,
        'over_budget': {str(n): sum(r['padded_tokens'] > n for r in checked) for n in [1024, 1536, 2048]},
        'rows': checked, 'input_sha256': inputs,
        'code_sha256': {name: hashlib.sha256((ROOT / 'scripts' / name).read_bytes()).hexdigest()
                       for name in ['verifier_collator.py', 'audit_verifier_collator.py', 'audit_verifier_tokenizer.py']},
        'training_ready': False, 'runtime_changed': False,
        'limitation': 'Chỉ kiểm tra tensor/labels, chưa chứng minh chất lượng ngữ nghĩa hoặc kết quả train.'}
    output.mkdir(parents=True)
    (output / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ['examples', 'collator_valid', 'over_budget']}))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
