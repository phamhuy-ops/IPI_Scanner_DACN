// Ứng viên đã bị loại; không cho runner cũ âm thầm bật lại kiến trúc giảm chất lượng.
console.error('instruction-proposals-v1 đã được gỡ khỏi pipeline vì giảm độ đúng. Raw và snapshot nằm trong benchmark/results/instruction-proposals-UGvspO và benchmark/experiments/instruction-proposals-retired-*. Không gọi model.');
process.exitCode = 1;
