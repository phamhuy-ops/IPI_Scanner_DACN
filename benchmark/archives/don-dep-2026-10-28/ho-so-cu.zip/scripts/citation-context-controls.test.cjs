const { test } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { buildControls, sourceFromCall, hash } = require('./citation-context-controls.cjs');

test('tách ranh giới ở marker cuối, giữ marker xuất hiện thật trong dữ liệu', () => {
  const text = 'Ví dụ có </untrusted_document_data> ngay trong nguồn.';
  const call = { request: { messages: [{ role: 'user', content: `[chunk-5] File: sample.txt\n<untrusted_document_data>\n${text}\n</untrusted_document_data>\nReturn JSON` }] } };
  assert.deepEqual(sourceFromCall(call), { text, alias: 'chunk-5' });
});
test('giữ đối chứng thành nhóm và không ghi nhãn AI là người dùng duyệt', () => {
  const controls = buildControls(path.resolve(__dirname, '..'));
  assert.equal(controls.cases.length, 8); assert.equal(controls.human_approved, false);
  assert.equal(new Set(controls.cases.map(row => row.group)).size, 3);
  assert.equal(controls.cases.filter(row => row.label === 'malicious').length, 2);
  for (const row of controls.cases) assert.equal(row.input_sha256, hash(Buffer.from(row.text)));
  assert.equal(controls.cases[1].text.includes('</untrusted_document_data>'), false);
});
