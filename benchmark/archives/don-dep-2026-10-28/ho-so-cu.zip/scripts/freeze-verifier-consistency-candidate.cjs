// Khóa thiết kế trước khi viết runner/đo; không cấp quyền triển khai vào Agent.
const fs = require('node:fs');
const { hash } = require('./context-annotations.cjs');
const { verify } = require('./freeze-verifier-pilot.cjs');
const base = 'benchmark/experiments/verifier-consistency-candidate-v1';
const controls = 'benchmark/data/annotations/verifier-consistency-controls-v1';
const file = `${base}/giao-thuc-da-khoa.json`;
function main() {
  if (process.argv.includes('--check')) {
    verify(JSON.parse(fs.readFileSync(file)));
    console.log(JSON.stringify({ locked_inputs_unchanged: true, model_called: false }));
    return;
  }
  if (fs.existsSync(file)) throw new Error('Không ghi đè giao thức đã khóa.');
  const manifest = JSON.parse(fs.readFileSync(`${controls}/manifest.json`));
  const tokenPath = 'benchmark/experiments/verifier-consistency-tokenizer-v2/ket-qua.json';
  const token = JSON.parse(fs.readFileSync(tokenPath));
  if (token.examples !== 112 || token.mask_valid !== 112 || token.collator_valid !== 112 || token.over_budget['2048']) throw new Error('Token/parser chưa đạt.');
  for (const [p, expected] of Object.entries(manifest.assets_sha256)) if (hash(fs.readFileSync(`${controls}/${p}`)) !== expected) throw new Error('Tài sản mới đã đổi.');
  for (const [p, expected] of Object.entries(token.input_sha256)) if (hash(fs.readFileSync(`${controls}/${p}`)) !== expected) throw new Error('Audit token đã cũ.');
  const auditPath = 'benchmark/experiments/verifier-corpus-overlap-v20/ket-qua.json';
  const audit = JSON.parse(fs.readFileSync(auditPath));
  const components = audit.groups.filter(g => g.members.some(m => m.startsWith('verifier-consistency-controls-v1:')));
  if (components.length !== 2 || components.some(g => g.members.some(m => !m.startsWith('verifier-consistency-controls-v1:')))) throw new Error('Nhóm mới có thành viên cũ hoặc số nhóm khác rà soát.');
  for (const entry of audit.inventory) if (hash(fs.readFileSync(entry.file)) !== entry.sha256) throw new Error(`Inventory đã đổi: ${entry.file}`);
  const parent = JSON.parse(fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/giao-thuc.json'));
  verify(parent);
  const paths = [`${base}/ung-vien.json`, `${controls}/manifest.json`, ...Object.keys(manifest.assets_sha256).map(p => `${controls}/${p}`), tokenPath, auditPath,
    'benchmark/experiments/verifier-pilot-candidate-02/ket-qua.json',
    'benchmark/experiments/verifier-hf-base-screen-v1/ke-hoach-truoc-do.json',
    'scripts/prepare-verifier-consistency-candidate.cjs', 'scripts/prepare-verifier-consistency-candidate.test.cjs',
    'scripts/freeze-verifier-consistency-candidate.cjs', 'scripts/summarize-verifier-hf-base.cjs',
    'scripts/verifier-context-scoring.cjs'];
  const lock = { version: 'verifier-consistency-candidate-v1', status: 'design_and_controls_frozen_not_measured',
    candidate_prompt_budget: 1, training_budget: 0, old_screen_requests_per_prompt: 12, new_control_requests_per_prompt: 56,
    requests_per_prompt: 68, total_planned_generation_requests: 136, authored_scenarios: 4, lexical_components: 2,
    lexical_component_sizes: components.map(c => c.size), source_records: 28,
    model_called: false, training_started: false, runtime_changed: false,
    evaluation_runner_implemented: false,
    locked_files_sha256: { ...parent.locked_files_sha256, ...Object.fromEntries(paths.map(p => [p, hash(fs.readFileSync(p))])) },
    preparation_commands: ['node scripts/prepare-verifier-consistency-candidate.cjs', 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit-verifier-corpus.py verifier-corpus-overlap-v20',
      'powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/audit_verifier_preview.py --source verifier-consistency-controls-v1 --output verifier-consistency-tokenizer-v2',
      'node scripts/freeze-verifier-consistency-candidate.cjs'],
    verification_command: 'node scripts/freeze-verifier-consistency-candidate.cjs --check',
    next: 'Viết runner đo đúng hai prompt trên cùng adapter/model, kiểm tra khóa, không thêm candidate hoặc sửa cổng sau kết quả.',
    limitations: ['Mẫu tự soạn AI, chưa duyệt người hoặc holdout độc lập.', 'Từ vựng không chứng minh độc lập ngữ nghĩa.',
      'Thiết kế đã khóa không có nghĩa ứng viên hiệu quả; chưa đo model hoặc toàn pipeline.'] };
  fs.writeFileSync(file, JSON.stringify(lock, null, 2), { flag: 'wx' });
  console.log(JSON.stringify({ locked_files: Object.keys(lock.locked_files_sha256).length, records: 28, lexical_components: 2, model_called: false }));
}
if (require.main === module) main();
