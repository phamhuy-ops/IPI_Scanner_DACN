"""Đối chiếu Trainer thật với dense CE, gồm accumulation đủ/thiếu tám mẫu."""
import copy
import os
from pathlib import Path
import tempfile
import unittest
import torch
from transformers import Qwen2Config, Qwen2ForCausalLM, TrainingArguments
from verifier_collator import CompletionCollator
from verifier_trainer import VerifierTrainer


def examples(count):
    return [{'input_ids': [1, 7, 9, 4, 5, 6, 2],
             'labels': [-100] * (6 - i % 4) + [4, 5, 6, 2][-(1 + i % 4):]}
            for i in range(count)]


class TrainerTests(unittest.TestCase):
    def compare(self, count, accumulation):
        torch.manual_seed(42)
        model = Qwen2ForCausalLM(Qwen2Config(vocab_size=32, hidden_size=16, intermediate_size=32,
            num_hidden_layers=1, num_attention_heads=2, num_key_value_heads=1,
            attention_dropout=0.0, max_position_embeddings=32, use_cache=False))
        expected = copy.deepcopy(model)
        data = examples(count)
        batch = CompletionCollator(2, 16)(data)
        # Một update dense CE với mọi target cùng mẫu số là chuẩn đối chứng.
        optimizer = torch.optim.SGD(expected.parameters(), lr=.01)
        loss = expected(**batch).loss
        loss.backward()
        optimizer.step()
        with tempfile.TemporaryDirectory(dir=os.environ.get('TEMP')) as folder:
            args = TrainingArguments(output_dir=folder, use_cpu=True, per_device_train_batch_size=1,
                gradient_accumulation_steps=accumulation, max_steps=1, learning_rate=.01,
                max_grad_norm=0, save_strategy='no', logging_strategy='no', report_to=[],
                disable_tqdm=True, dataloader_pin_memory=False, remove_unused_columns=False,
                label_names=['labels'], seed=42, data_seed=42, lr_scheduler_type='constant')
            trainer = VerifierTrainer(model=model, args=args, train_dataset=data,
                data_collator=CompletionCollator(2, 16),
                optimizers=(torch.optim.SGD(model.parameters(), lr=.01), None))
            trainer.train()
            self.assertEqual(trainer.state.global_step, 1)
            observations = trainer.loss_observations
            self.assertEqual(len(observations), count)
            tokens = int((batch['labels'] != -100).sum())
            self.assertTrue(all(o['normalizer_tokens'] == tokens for o in observations))
            for (name, actual), (_, target) in zip(model.named_parameters(), expected.named_parameters()):
                torch.testing.assert_close(actual, target, rtol=1e-4, atol=1e-6, msg=name)

    def test_accumulate_eight_unequal_targets_equals_dense_batch(self):
        self.compare(8, 8)

    def test_last_partial_accumulation_uses_actual_token_count(self):
        self.compare(3, 8)

    def test_invalid_normalizer_rejected(self):
        trainer = object.__new__(VerifierTrainer)
        batch = CompletionCollator(2, 16)(examples(1))
        with self.assertRaises(ValueError):
            trainer.compute_loss(None, batch, num_items_in_batch=0)


if __name__ == '__main__':
    unittest.main()
