// Khóa dữ liệu và phạm vi thử nghiệm candidate-02; không thay cấu hình Agent.
const fs = require('node:fs');
const { hash } = require('./context-annotations.cjs');
const { verify } = require('./freeze-verifier-pilot.cjs');
const base = 'benchmark/experiments/verifier-counterfactual-train-v2';
const file = `${base}/giao-thuc.json`;
function main() {
  if (process.argv.includes('--check')) {
    const lock = JSON.parse(fs.readFileSync(file));
    verify(lock);
    console.log(JSON.stringify({ candidate_02_inputs_unchanged: true, training_started_by_check: false }));
    return;
  }
  if (fs.existsSync(file)) throw new Error('Không ghi đè bản khóa.');
  const token = JSON.parse(fs.readFileSync(`${base}/token-mask.json`));
  const audit = JSON.parse(fs.readFileSync(`${base}/kiem-tra-tuong-dong.json`));
  const report = JSON.parse(fs.readFileSync(`${base}/ket-qua.json`));
  if (token.examples !== 360 || token.mask_collator_valid !== 360 || audit.protected_match_count !== 0) throw new Error('Audit chưa đạt.');
  for (const [name, expected] of Object.entries(token.input_sha256)) if (hash(fs.readFileSync(`${base}/${name}`)) !== expected) throw new Error('Token audit đã cũ.');
  for (const [name, expected] of Object.entries(audit.input_sha256)) if (hash(fs.readFileSync(name)) !== expected) throw new Error('Nguồn đối chiếu đã đổi.');
  const original = JSON.parse(fs.readFileSync('benchmark/experiments/verifier-pilot-freeze-v1/giao-thuc.json'));
  verify(original);
  const rows = fs.readFileSync(`${base}/mau-cho-duyet.jsonl`, 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const reviews = rows.filter(r => r.counterfactual).map(r => ({ id: r.id, input_sha256: r.input_sha256,
    stance: r.annotation.stance, reviewer: 'Codex (AI)', human_approved: false,
    decision: 'accepted_for_local_data_intervention',
    rationale: r.annotation.reason,
    limitation: 'Cặp giữ loại hành động nhưng không đồng nhất từng từ; đồng thời thêm lời phê duyệt vào mẫu AI. Chỉ đo tác động gói dữ liệu, không quy riêng cho một cue.' }));
  fs.writeFileSync(`${base}/ra-ngu-nghia.json`, JSON.stringify({ reviews, independent_review: false }, null, 2), { flag: 'wx' });
  const paths = ['mau-cho-duyet.jsonl', 'train.preview.jsonl', 'ket-qua.json', 'token-mask.json', 'kiem-tra-tuong-dong.json', 'ra-ngu-nghia.json'].map(n => `${base}/${n}`);
  paths.push('scripts/prepare-verifier-counterfactual-train.cjs', 'scripts/audit_verifier_counterfactual.py', 'scripts/audit_verifier_counterfactual_overlap.py', 'scripts/freeze-verifier-counterfactual.cjs');
  const locked = { ...original.locked_files_sha256, ...Object.fromEntries(paths.map(p => [p, hash(fs.readFileSync(p))])) };
  const lock = { candidate: 'candidate-02', status: 'data_frozen_not_trained', revision: original.revision,
    source_records: 180, examples: 360, changed_records: report.changed_records, stance_counts: report.counts,
    locked_files_sha256: locked, training_started: false, runtime_changed: false,
    fixed_training: { epochs: 1, optimizer_steps: 45, learning_rate: .0001, seed: 42, micro_batch: 1, accumulation: 8,
      max_tokens: 2048, lora_r: 8, lora_alpha: 16, lora_dropout: .05, modules: ['q_proj', 'v_proj'],
      checkpoint_policy: 'Giữ runner candidate-01: lưu mỗi 15 bước, giữ tối đa 2; chỉ đo adapter cuối epoch. Đề xuất final-only trước đó không phản ánh runner thực tế.' },
    next: 'Chuẩn bị loader chỉ train, sao chép và xác minh SHA trên E, rồi huấn luyện candidate-02 và đo screen off/on.',
    limitations: ['Chỉ so từ vựng bản split 324 và 24 diagnostic, chưa audit toàn raw hoặc tương đồng ngữ nghĩa.',
      'Không có holdout độc lập mới; chưa chứng minh cải thiện.', 'Không đổi gold dev cũ; không dùng probe trong train hoặc chọn ứng viên.'] };
  fs.writeFileSync(file, JSON.stringify(lock, null, 2), { flag: 'wx' });
  verify(lock);
  console.log(JSON.stringify({ frozen_files: Object.keys(locked).length, source_records: 180, training_started: false }));
}
if (require.main === module) main();
