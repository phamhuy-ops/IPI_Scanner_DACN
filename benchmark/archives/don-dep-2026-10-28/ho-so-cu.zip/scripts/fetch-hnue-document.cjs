const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { extractDocumentText } = require('../engine/document/extractors/document-text-extractor');
const root = path.resolve(__dirname, '..');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
async function get(url, maxBytes) {
  const response = await fetch(url, { signal: AbortSignal.timeout(30000) });
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
  if (Number(response.headers.get('content-length')) > maxBytes) throw new Error('File vượt giới hạn tải.');
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length > maxBytes) throw new Error('Nội dung vượt giới hạn tải.');
  return { bytes, final_url: response.url, content_type: response.headers.get('content-type') };
}
async function main() {
  const out = path.join(root, 'benchmark/data/incoming/public-vi-documents/nguon-vi-bo-sung-v1');
  if (fs.existsSync(out)) throw new Error('Không ghi đè bản bổ sung đã có.');
  const source = 'https://smcs.hnue.edu.vn/bieu-mau-van-ban/bieu-mau-danh-cho-sinh-vien.html';
  const page = await get(source, 4 * 1024 * 1024);
  const links = [...page.bytes.toString('utf8').matchAll(/href\s*=\s*["']([^"']+)["']/gi)].map(match => new URL(match[1].replaceAll('&amp;', '&'), source).href);
  const found = [...new Set(links.filter(url => /\.docx$/i.test(url) && decodeURIComponent(url).includes('(Dành cho SV các Khoa đào tạo)')))];
  if (found.length !== 1) throw new Error('Không xác định được link mẫu gốc duy nhất.');
  const data = await get(found[0], 10 * 1024 * 1024);
  if (data.bytes.subarray(0, 2).toString() !== 'PK') throw new Error('Không phải file DOCX dạng ZIP.');
  fs.mkdirSync(out);
  const name = 'mau-xac-nhan-sinh-vien-hnue.docx';
  fs.writeFileSync(path.join(out, name), data.bytes, { flag: 'wx' });
  fs.writeFileSync(path.join(out, 'trang-nguon.html'), page.bytes, { flag: 'wx' });
  const text = await extractDocumentText(path.join(out, name));
  if (text.ok) fs.writeFileSync(path.join(out, 'vi-native-006-van-ban.txt'), text.text, { flag: 'wx' });
  const manifest = { id: 'vi-native-006', filename: name, title: 'Mẫu xác nhận sinh viên đang học tại trường — dành cho sinh viên các khoa đào tạo',
    hosting_publisher: 'Trường Đại học Sư phạm Hà Nội — Trường Toán học và Công nghệ thông tin', source_page: source,
    source_page_sha256: hash(page.bytes), download_url: found[0], final_url: data.final_url, bytes: data.bytes.length,
    sha256: hash(data.bytes), content_type: data.content_type, retrieved_at: new Date().toISOString(), parent_id: 'hnue-form-current-student-faculties',
    extraction: { ok: text.ok, error: text.error || null, characters_utf16: text.text?.length || 0,
      text_sha256: text.ok ? hash(Buffer.from(text.text)) : null, manual_quality_review_required: true },
    status: 'downloaded_pending_rights_and_annotation', security_label: null, privacy_review: 'pending',
    reuse_permission: { status: 'not_verified', license: null, note: 'Mẫu tải công khai chưa chứng minh quyền dùng lại cho train/phát hành dataset.' },
    training_eligible: false, final_split: null, independent_holdout_verified: false,
    replaces_broken_candidate: 'DOCX Sơn Tây Thượng trả HTTP 404; không ghi đè hoặc sửa lịch sử lỗi.',
    code_sha256: hash(fs.readFileSync(__filename)) };
  fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ id: manifest.id, bytes: manifest.bytes, extraction: manifest.extraction }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
