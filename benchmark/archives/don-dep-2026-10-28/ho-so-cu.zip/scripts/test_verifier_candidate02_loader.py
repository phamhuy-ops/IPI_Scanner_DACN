"""Kiểm tra từ chối dev/probe và tính toàn vẹn bản train trên E trước train."""
import unittest
from verifier_candidate02_loader import load_role


class Candidate02LoaderTests(unittest.TestCase):
    def test_reject_other_roles_before_reading(self):
        for role in ['dev', 'probe', '../train']:
            with self.assertRaises(ValueError):
                load_role(role)

    def test_frozen_e_train_matches_declared_scope(self):
        rows = load_role('train')
        self.assertEqual(len(rows), 360)
        self.assertEqual(len({r['source_record_id'] for r in rows}), 180)
        self.assertEqual({r['planned_role'] for r in rows}, {'train'})


if __name__ == '__main__':
    unittest.main()
