const { test } = require('node:test');
const assert = require('node:assert/strict');
const { sourceEvidence } = require('./register-verifier-batch.cjs');
test('Chỉ mẫu tự soạn không dùng nội dung ngoài mới được bỏ bằng chứng license ngoài', () => {
  const p = { source_kind: 'synthetic', external_content_reused: false, real_personal_data_used: false };
  const evidence = sourceEvidence({ provenance: p }, () => { throw new Error('Không cần đọc nguồn ngoài.'); });
  assert.equal(evidence.kind, 'project_authored_release_not_declared');
  assert.equal(evidence.training_reuse_approved, false);
  assert.throws(() => sourceEvidence({ provenance: { ...p, external_content_reused: true } }, () => ''), /thiếu/);
  assert.throws(() => sourceEvidence({ provenance: {} }, () => ''), /thiếu/);
});
