const fs = require('node:fs');
const path = require('node:path');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const version = 'verifier-split-readiness-v1';
const counts = (rows, key) => rows.reduce((out, row) => { const value = typeof key === 'function' ? key(row) : row[key]; out[value] = (out[value] || 0) + 1; return out; }, {});

function groupConstraints(records, groups, baselineIds) {
  const byId = new Map(records.map(row => [row.id, row]));
  return groups.map(group => {
    const members = group.members.filter(id => byId.has(id));
    if (!members.length) return null;
    const baseline = members.filter(id => baselineIds.has(id));
    const exposed = baseline.length > 0 || group.flags.includes('overlap_dev_fixture_or_manifest');
    return { id: `group-${hash(group.members.slice().sort().join('\n')).slice(0, 12)}`, members,
      size: members.length, flags: group.flags, baseline_model_evaluated_members: baseline,
      proposed_constraint: group.constraint === 'reference_only' ? 'retain_reference_only'
        : group.flags.includes('overlap_existing_bipia_test') ? 'quarantine_existing_test_overlap'
          : exposed ? 'retain_development_regression' : 'unassigned_role_review_required',
      final_split: null, independently_untouched_verified: false };
  }).filter(Boolean);
}

function summarize(records, groups, plan) {
  const stances = counts(records, 'stance'), languages = counts(records, 'language');
  const target = plan.data.pilot_target_records;
  const targetStances = Object.fromEntries(Object.entries(plan.data.stance_targets).map(([stance, fraction]) => [stance, Math.round(target * fraction)]));
  return { records: records.length, parent_ids: new Set(records.map(row => row.parent_id)).size, groups: groups.length,
    stances, languages, formats: counts(records, 'format'), reviewer_scopes: counts(records, 'reviewer_scope'),
    by_source: Object.fromEntries([...new Set(records.map(row => row.source))].map(source => {
      const rows = records.filter(row => row.source === source);
      return [source, { records: rows.length, parents: new Set(rows.map(row => row.parent_id)).size,
        stances: counts(rows, 'stance'), addressees: counts(rows, 'addressee'), languages: counts(rows, 'language') }];
    })),
    language_stance_cells: Object.fromEntries(Object.keys(languages).map(language => [language, counts(records.filter(row => row.language === language), 'stance')])),
    uncertain_by_source: counts(records.filter(row => row.stance === 'uncertain'), 'source'),
    human_by_source: counts(records.filter(row => row.addressee === 'human'), 'source'),
    long_record_texts_at_least_8000_utf16: records.filter(row => row.full_record_units >= 8000).length,
    long_labeled_inputs_at_least_8000_utf16: records.filter(row => row.labeled_input_units >= 8000).length,
    selected_window_only: records.filter(row => row.selected_window_only).length,
    repaired_versions_not_new_parents: records.filter(row => row.effective_version === 'ai_repaired').length,
    group_constraints: counts(groups, 'proposed_constraint'),
    largest_groups: groups.slice().sort((a, b) => b.size - a.size).slice(0, 5).map(group => ({ id: group.id, size: group.size, constraint: group.proposed_constraint })),
    numerical_gaps_only: { additional_records_lower_bound: Math.max(0, target - records.length),
      additional_groups_lower_bound: Math.max(0, plan.data.minimum_source_groups - groups.length),
      stance_targets: targetStances,
      additional_stances: Object.fromEntries(Object.entries(targetStances).map(([stance, value]) => [stance, Math.max(0, value - (stances[stance] || 0))])),
      additional_monolingual_vi_for_300_target: Math.max(0, Math.ceil(target * plan.data.minimum_language_fraction.vi) - (languages.vi || 0)),
      additional_monolingual_en_for_300_target: Math.max(0, Math.ceil(target * plan.data.minimum_language_fraction.en) - (languages.en || 0)),
      note: 'Chỉ khoảng thiếu theo ngân sách cũ; không chứng minh thêm đúng số lượng là đủ. Bản Anh–Việt không đếm hai lần.' },
    approved_training_records: records.filter(row => row.training_eligible).length,
    can_prepare_group_constraints: true, can_finalize_train_dev: false, verified_untouched_holdout_records: 0,
    final_split_created: false, training_ready: false };
}

function inventoryFiles(directory) {
  const found = [];
  if (!fs.existsSync(directory)) return found;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) found.push(...inventoryFiles(file));
    else if (entry.isFile() && /\.(pdf|docx|doc)$/i.test(entry.name)) {
      found.push({ file: path.relative(root, file).replaceAll('\\', '/'), bytes: fs.statSync(file).size, sha256: hash(fs.readFileSync(file)) });
    }
  }
  return found;
}

function buildRegistry() {
  const inputs = {};
  const bytes = file => { const value = fs.readFileSync(path.join(root, file)); inputs[file] = hash(value); return value; };
  const json = file => JSON.parse(bytes(file));
  const jsonl = file => bytes(file).toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
  const records = [];
  const add = (id, row, annotation, metadata) => {
    if (row.input_sha256 && hash(Buffer.from(row.text)) !== row.input_sha256) throw new Error(`Sai hash text: ${id}`);
    const text = row.selected_window?.text ?? row.text;
    if (row.selected_window && row.text.slice(row.selected_window.start, row.selected_window.end) !== text) throw new Error(`Sai cửa sổ: ${id}`);
    const errors = validateAnnotation(text, annotation);
    if (errors.length) throw new Error(`${id}: ${errors.join('; ')}`);
    records.push({ id, parent_id: metadata.parent_id || row.source_parent_id || id, source: metadata.source,
      format: row.format || '.txt', language: row.language, stance: annotation.stance, addressee: annotation.addressee,
      framing: annotation.framing, deviation: annotation.deviation, hasDirective: annotation.hasDirective,
      full_record_units: row.text.length, labeled_input_units: text.length,
      selected_window_only: Boolean(row.selected_window && (row.selected_window.start !== 0 || row.selected_window.end !== row.text.length)),
      labeled_scope: row.annotation_scope || (row.selected_window ? 'selected_window' : 'whole_visible_record'),
      effective_input_sha256: hash(Buffer.from(text)), effective_annotation_sha256: hash(JSON.stringify(annotation)),
      effective_version: metadata.effective_version || 'original', reviewer_scope: metadata.reviewer_scope,
      record_file: metadata.record_file, training_eligible: false, split: null });
  };
  for (const folder of ['verifier-batch-v1', 'verifier-vietnamese-v1']) {
    const base = `benchmark/data/annotations/${folder}`;
    const file = base + '/mau-cho-duyet.jsonl', rows = jsonl(file), sheet = json(base + '/ket-qua-ra-soat.json');
    for (const row of rows) {
      const review = sheet.reviews.find(item => item.id === row.id);
      const draft = hash(JSON.stringify({ annotation: row.draft_annotation, response: row.draft_response }, null, 2) + '\n');
      if (review?.status !== 'human_reviewed' || !['accept', 'revise'].includes(review.decision) || review.input_sha256 !== row.input_sha256 || draft !== review.draft_sha256) throw new Error('Phiếu người dùng không khớp.');
      add(`${folder}:${row.id}`, row, review.decision === 'revise' ? review.final_annotation : row.draft_annotation,
        { source: folder, reviewer_scope: 'human_visible_source', record_file: file });
    }
  }
  const externalFile = 'benchmark/data/annotations/verifier-external-normalized-v1/nhan-va-bang-chung.jsonl';
  for (const row of jsonl(externalFile)) add(row.id, row, row.annotation, { source: row.provenance.source_file.includes('/notinject/') ? 'leolee99/NotInject' : 'treycsa/realistic-prompt-injections', reviewer_scope: 'human_stance_mechanical_span', record_file: externalFile });
  const active = json('benchmark/data/annotations/verifier-gap-repair-v1/ban-su-dung-hien-tai.json').active_sources;
  const gapVersions = new Map();
  for (const folder of ['verifier-gap-normalized-v1', 'verifier-gap-repair-v1']) {
    const file = `benchmark/data/annotations/${folder}/nhan-va-cua-so.jsonl`;
    gapVersions.set(folder, { rows: jsonl(file), file });
  }
  for (const item of active) {
    const folder = item.version_path.split('/').at(-1), version = gapVersions.get(folder), row = version.rows.find(row => row.id === item.source_record_id);
    if (!row) throw new Error('Thiếu phiên bản đang dùng của gap.');
    add(item.parent_source_id, row, row.window_annotation, { source: 'verifier-gap-v1', parent_id: item.parent_source_id,
      effective_version: folder.includes('repair') ? 'ai_repaired' : 'original', reviewer_scope: `parent_stance_human_context_${item.context_review_origin}`, record_file: version.file });
  }
  for (const folder of ['verifier-external-ai-v1', 'verifier-vietnamese-articles-v1', 'verifier-addressee-context-v1', 'verifier-external-context-v1']) {
    const file = `benchmark/data/annotations/${folder}/mau-cho-duyet.jsonl`, reviews = json(`benchmark/data/annotations/${folder}/danh-gia-ai.json`);
    for (const row of jsonl(file)) {
      const review = reviews.reviews.find(item => item.id === row.id);
      if (!review || review.input_sha256 !== row.input_sha256 || review.annotation_sha256 !== hash(JSON.stringify(row.annotation))) throw new Error(`Phiếu AI sai: ${row.id}`);
      const annotation = row.window_annotation || row.annotation;
      if (folder.includes('vietnamese-articles') && (review.window_sha256 !== hash(Buffer.from(row.selected_window.text)) || review.window_annotation_sha256 !== hash(JSON.stringify(annotation)))) throw new Error('Phiếu cửa sổ bài Việt sai.');
      add(`${folder}:${row.id}`, row, annotation, { source: row.source, reviewer_scope: 'ai_visible_context', record_file: file });
    }
  }
  if (records.length !== 178 || new Set(records.map(row => row.id)).size !== records.length) throw new Error('Sai registry hoặc đếm trùng phiên bản.');
  const audit = json('benchmark/experiments/verifier-corpus-overlap-v9/ket-qua.json');
  for (const item of audit.inventory) if (hash(fs.readFileSync(path.join(root, item.file))) !== item.sha256) throw new Error(`Audit v9 đã cũ: ${item.file}`);
  const baseline = json('benchmark/data/priority-one-dev-v2.json');
  const groups = groupConstraints(records, audit.groups, new Set(baseline.cases.map(row => row.original_id)));
  if (groups.reduce((n, group) => n + group.size, 0) !== records.length || new Set(groups.flatMap(group => group.members)).size !== records.length) throw new Error('Nhóm không phủ đúng registry.');
  const plan = json('benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json');
  const summary = summarize(records, groups, plan);
  const native = ['benchmark/data', 'benchmark/fixtures'].flatMap(folder => inventoryFiles(path.join(root, folder)));
  return { records, groups, summary, native, inputs };
}

function main() {
  const out = path.join(root, 'benchmark/experiments', version);
  if (fs.existsSync(out)) throw new Error('Không ghi đè lần rà đã có.');
  const { records, groups, summary, native, inputs } = buildRegistry();
  const result = { version, status: 'complete', ...summary, native_pdf_docx_doc_files: native,
    native_file_scope: ['benchmark/data', 'benchmark/fixtures'],
    model_called: false, runtime_changed: false, final_split_created: false, training_ready: false,
    inputs_sha256: inputs, code_sha256: hash(fs.readFileSync(__filename)),
    blockers: ['Chưa đủ mục tiêu 300 bản ghi/100 nhóm; số lượng không tự chứng minh chất lượng.',
      'Nhóm dính baseline/dev phải giữ ràng buộc; không có cờ không đồng nghĩa untouched.',
      'Chưa có PDF/DOCX thực tế đã kiểm chứng nguồn/quyền sử dụng trong phạm vi kiểm kê.',
      'Nhãn tài liệu dài mới áp dụng cửa sổ; chưa chứng minh đủ ngữ cảnh toàn nguồn.',
      'Chưa có holdout độc lập hoặc tập train/dev được duyệt và khóa.'],
    limitations: ['Đếm theo phiên bản/cửa sổ đang dùng, không gán nhãn lại hoặc xuất SFT.',
      'Ràng buộc nhóm dùng heuristic v9, không loại hết rò rỉ ngữ nghĩa.',
      'Không đọc tài liệu Downloads/private hoặc coi PDF/DOCX tự xuất từ text là nguồn mới.'] };
  fs.mkdirSync(out);
  fs.writeFileSync(path.join(out, 'ket-qua.json'), JSON.stringify(result, null, 2) + '\n');
  fs.writeFileSync(path.join(out, 'registry.jsonl'), records.map(row => JSON.stringify(row)).join('\n') + '\n');
  fs.writeFileSync(path.join(out, 'rang-buoc-nhom.json'), JSON.stringify({ final_split_created: false, groups }, null, 2) + '\n');
  console.log(JSON.stringify({ records: result.records, parents: result.parent_ids, groups: result.groups, formats: result.formats,
    constraints: result.group_constraints, long_record_texts: result.long_record_texts_at_least_8000_utf16,
    long_labeled_inputs: result.long_labeled_inputs_at_least_8000_utf16, native_documents: native.length, gaps: result.numerical_gaps_only }));
}
if (require.main === module) main();
module.exports = { groupConstraints, summarize, buildRegistry };
