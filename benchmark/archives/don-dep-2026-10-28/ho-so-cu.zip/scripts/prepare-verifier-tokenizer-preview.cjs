// Tái dựng bản xem trước từ 45 nguồn tự soạn đã duyệt; không xuất train.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
async function main() {
  const output = path.join(root, 'benchmark/experiments/verifier-tokenizer-v1/ban-xem-truoc');
  if (fs.existsSync(output)) throw new Error('Không ghi đè bản xem trước.');
  const manifestFile = path.join(root, 'benchmark/data/priority-one-dev-v2.json');
  const manifest = JSON.parse(fs.readFileSync(manifestFile));
  const rows = manifest.cases.filter(row => ['verifier-batch-v1', 'verifier-vietnamese-v1'].includes(row.source));
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  const examples = [];
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of rows) for (const mode of ['supplied', 'none']) {
      const rendered = renderDraft({ text: row.text, format: row.format, candidate_mode: mode }, row.annotation);
      examples.push({ id: `${row.id}-${mode}`, source_record_id: row.original_id, group_id: row.group_id,
        mode, payload: rendered.payload, target: rendered.response, parser_valid: rendered.validation.parser_valid });
    }
  } finally { await server.close(); }
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, 'mau.json'), JSON.stringify({
    training_export: false, training_ready: false, manifest_sha256: hash(fs.readFileSync(manifestFile)),
    script_sha256: hash(fs.readFileSync(__filename)), examples }, null, 2) + '\n');
  console.log(JSON.stringify({ sources: rows.length, examples: examples.length }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
