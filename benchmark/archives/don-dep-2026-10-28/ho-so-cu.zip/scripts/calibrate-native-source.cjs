// Hiệu chỉnh prior bằng ba input không nội dung, không dùng nhãn dev để fit tham số.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {request,parse}=require('./native-source-score.cjs');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const lse=v=>{const max=Math.max(...v);return max+Math.log(v.reduce((sum,x)=>sum+Math.exp(x-max),0));};
function prior(vectors){
  if(vectors.length!==3)throw Error('Phải có đủ3 calibration input.');
  const normal=vectors.map(scores=>{const total=lse(['A','B','C'].map(k=>scores[k]));return Object.fromEntries(['A','B','C'].map(k=>[k,scores[k]-total]));});
  return Object.fromEntries(['A','B','C'].map(k=>[k,lse(normal.map(row=>row[k]))-Math.log(normal.length)]));
}
function adjust(scores,bias){
  const corrected=Object.fromEntries(['A','B','C'].map(k=>{if(!Number.isFinite(scores[k])||!Number.isFinite(bias[k]))throw Error('Không đủ logprob để hiệu chỉnh.');return[k,scores[k]-bias[k]];}));
  const ranked=Object.entries(corrected).sort((a,b)=>b[1]-a[1]);
  return{kind:{A:'active',B:'ordinary',C:'underdetermined'}[ranked[0][0]],scores:corrected,margin_logprob:ranked[0][1]-ranked[1][1],calibrated_probability:false};
}
async function main(){
  const base='benchmark/results/native-source-score-GvcQcF',rows=JSON.parse(fs.readFileSync(base+'/cases.json')),oldPlan=JSON.parse(fs.readFileSync(base+'/giao-thuc.json'));
  const models=['gemma3:1b','qwen2.5-coder:1.5b'],inputs=['','N/A','[no source]'];
  const out=fs.mkdtempSync(path.resolve('benchmark/results/native-calibration-')),save=(name,v)=>fs.writeFileSync(path.join(out,name),JSON.stringify(v,null,2));
  const get=async endpoint=>{const r=await fetch('http://127.0.0.1:11434'+endpoint,{signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Ollama unavailable');return r.json();};
  const tags=await get('/api/tags');for(const model of models)if(tags.models.find(row=>row.name===model)?.digest!==oldPlan.models.models.find(row=>row.name===model)?.digest)throw Error('Model khác baseline.');
  const files=['scripts/calibrate-native-source.cjs','scripts/native-source-score.cjs',base+'/cases.json'];const before=Object.fromEntries(files.map(file=>[file,sha(fs.readFileSync(file))]));
  save('giao-thuc.json',{inputs,models:tags,source:base,code_sha256:before,command:'node scripts/calibrate-native-source.cjs',requests:6,
    policy:'Chia likelihood cho prior trung bình ba input content-free, không chọn threshold hoặc fit nhãn dev; argmax không có margin abstention.',
    reference:'https://proceedings.mlr.press/v139/zhao21c.html',gate:'Ít nhất90% mỗi model và kết hợp; nếu trượt không đưa vào sản phẩm.',
    limits:['Cùng32 score dev cũ, không phải holdout.','Không phải reproduction chính xác GPT-2/GPT-3 của paper; không suy paper bảo đảm kết quả ở Gemma/Coder.','Không có span bằng chứng hoặc pipeline sản phẩm.']});
  const calls=[],biases={};
  for(const model of models){const vectors=[];for(const text of inputs){
    const body=request(model,text),r=await fetch('http://127.0.0.1:11434/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(45000)}),raw=await r.text();
    calls.push({model,input:text,request:body,response:raw,status:r.status});save('model-calls.json',calls);if(!r.ok)throw Error('HTTP '+r.status);vectors.push(parse(JSON.parse(raw)).scores);
  }biases[model]=prior(vectors);}
  const corrected=rows.map(row=>row.valid?{...row,uncalibrated_kind:row.kind,...adjust(row.scores,biases[row.model])}:row);
  const expected={malicious:'active',benign:'ordinary',uncertain:'underdetermined'};
  const score=a=>({total:a.length,valid:a.filter(r=>r.valid).length,correct:a.filter(r=>r.valid&&r.kind===expected[r.label]).length,accuracy:a.filter(r=>r.valid&&r.kind===expected[r.label]).length/a.length,
    confusion:a.reduce((out,r)=>{const k=r.label+' -> '+(r.valid?r.kind:'ERROR');out[k]=(out[k]||0)+1;return out;},{})});
  const byModel=Object.fromEntries(models.map(model=>[model,{before:score(rows.filter(r=>r.model===model)),after:score(corrected.filter(r=>r.model===model))}]));
  const combined=oldPlan.cases.map(item=>{const pair=models.map(model=>corrected.find(r=>r.id===item.id&&r.model===model));const kind=pair.every(r=>r.valid&&r.kind==='active')?'active':pair.every(r=>r.valid&&r.kind==='ordinary')?'ordinary':'underdetermined';
    return{id:item.id,label:item.label,kind,valid:pair.every(r=>r.valid),semantic_uncertainty:pair.some(r=>r.valid&&r.kind==='underdetermined')};});
  const accuracy=combined.filter(r=>r.valid&&r.kind===expected[r.label]&&(r.label!=='uncertain'||r.semantic_uncertainty)).length/combined.length;
  for(const[file,h]of Object.entries(before))if(sha(fs.readFileSync(file))!==h)throw Error('Input/code đổi.');
  const after=await get('/api/tags');if(models.some(model=>tags.models.find(r=>r.name===model)?.digest!==after.models.find(r=>r.name===model)?.digest))throw Error('Model đổi');
  save('cases.json',corrected);save('tong-hop.json',{complete:true,passed:accuracy>=.9&&Object.values(byModel).every(r=>r.after.accuracy>=.9),biases,by_model:byModel,combined_accuracy:accuracy,combined,product_changed:false,pipeline_tested:false});
  console.log(JSON.stringify({out,by_model:byModel,combined_accuracy:accuracy}));
}
module.exports={prior,adjust};if(require.main===module)main().catch(error=>{console.error(error);process.exitCode=1;});
