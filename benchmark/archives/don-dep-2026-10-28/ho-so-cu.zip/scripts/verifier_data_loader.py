"""Loader chỉ trả dữ liệu của đúng vai trò; metadata không đi vào token input."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCK = ROOT / 'benchmark/experiments/verifier-pilot-freeze-v1/giao-thuc.json'
RELEASE = ROOT / 'benchmark/experiments/verifier-local-release-v2'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def validate_rows(rows, role):
    if role not in {'train', 'dev', 'probe'}:
        raise ValueError('Vai trò không hợp lệ.')
    ids = set()
    for row in rows:
        if row.get('planned_role') != role or row.get('training_eligible') is not False:
            raise ValueError('Dữ liệu sai vai trò hoặc tự bật train.')
        if row['id'] in ids:
            raise ValueError('Trùng biểu diễn.')
        ids.add(row['id'])
        if [m['role'] for m in row['payload']['messages']] != ['system', 'user']:
            raise ValueError('Sai ranh giới hội thoại.')
    return rows


def load_role(role):
    if role not in {'train', 'dev', 'probe'}:
        raise ValueError('Vai trò không hợp lệ.')
    lock = json.loads(LOCK.read_text(encoding='utf-8'))
    for name, expected in lock['locked_files_sha256'].items():
        if digest((ROOT / name).read_bytes()) != expected:
            raise ValueError(f'Đầu vào khóa đã đổi: {name}')
    file = RELEASE / f'{role}.preview.jsonl'
    rows = validate_rows([json.loads(line) for line in file.read_text(encoding='utf-8').splitlines()], role)
    if len(rows) != lock['rendered_examples'][role]:
        raise ValueError('Sai số lượng biểu diễn đã khóa.')
    return rows


def train_features(tokenizer):
    from audit_verifier_tokenizer import completion_example
    from verifier_collator import CompletionCollator
    rows = load_role('train')
    features = []
    collator = CompletionCollator(tokenizer.pad_token_id, 2048)
    for row in rows:
        target = json.dumps(row['target'], ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, row['payload']['messages'], target)
        feature = {'input_ids': ids, 'labels': labels}
        batch = collator([feature])
        if any(v != -100 for v in labels[:boundary]):
            raise ValueError('Prompt lọt vào loss.')
        if tokenizer.decode([v for v in labels if v != -100]) != target + tokenizer.eos_token:
            raise ValueError('Loss không khớp JSON/EOS.')
        if any(v != -100 for v, mask in zip(batch['labels'][0].tolist(), batch['attention_mask'][0].tolist()) if not mask):
            raise ValueError('Padding lọt vào loss.')
        features.append(feature)
    return features


def main():
    import os
    from transformers import AutoTokenizer
    from audit_verifier_tokenizer import MODEL, REVISION
    out = ROOT / 'benchmark/experiments/verifier-train-loader-v1'
    if out.exists():
        raise ValueError('Không ghi đè lượt loader.')
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=os.environ['HF_HUB_CACHE'], local_files_only=True, trust_remote_code=False)
    features = train_features(tokenizer)
    rows = load_role('train')
    result = {'examples': len(features), 'source_records': len({r['source_record_id'] for r in rows}),
        'roles_loaded_for_loss': ['train'], 'dev_or_probe_in_features': False,
        'feature_fields': sorted(features[0]), 'prompt_padding_mask_verified': True,
        'max_tokens': max(len(f['input_ids']) for f in features),
        'supervised_tokens': sum(sum(v != -100 for v in f['labels']) for f in features),
        'lock_sha256': digest(LOCK.read_bytes()), 'train_file_sha256': digest((RELEASE / 'train.preview.jsonl').read_bytes()),
        'code_sha256': digest(Path(__file__).read_bytes()),
        'command': 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/verifier_data_loader.py',
        'model_forward': False, 'training_started': False, 'training_enabled': False}
    out.mkdir()
    (out / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
