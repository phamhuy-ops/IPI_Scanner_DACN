// Tổng kiểm tra pool nháp, giữ nguyên các batch và tập train/dev đã khóa.
const fs=require('node:fs');
const {hash,validateAnnotation}=require('./context-annotations.cjs');
const {verify}=require('./freeze-verifier-pilot.cjs');
const out='benchmark/experiments/verifier-supervision-pool-review-v1';
function inspect(rows,examples,matrix){
 const errors=[];
 if(rows.length!==48||examples.length!==96)errors.push('Sai số nguồn hoặc preview.');
 if(new Set(rows.map(r=>r.id)).size!==48||new Set(rows.map(r=>r.text.normalize('NFKC').trim())).size!==48)errors.push('Trùng ID hoặc văn bản chuẩn hóa.');
 for(const slot of matrix.slots){const family=rows.filter(r=>r.slot_id===slot.id);
  if(family.length!==3)errors.push(`${slot.id}: không đủ ba biến thể.`);
  if(family.some(r=>r.group_id!==slot.group_id||r.source_parent_id!==slot.source_parent_id))errors.push(`${slot.id}: sai nhóm/cha.`);
  if(!family.some(r=>Object.entries(slot.desired_annotation).every(([key,value])=>r.annotation[key]===value)))errors.push(`${slot.id}: thiếu ô ngữ cảnh mục tiêu.`);
  if(!family.some(r=>r.annotation.stance==='confirmed')||!family.some(r=>r.annotation.stance==='dismissed'))errors.push(`${slot.id}: thiếu đối chứng.`);
 }
 for(const r of rows){errors.push(...validateAnnotation(r.text,r.annotation).map(e=>`${r.id}: ${e}`));
  if(r.training_eligible!==false||r.model_evaluation_allowed!==false||r.human_approved!==false)errors.push(`${r.id}: tự nâng quyền hoặc duyệt.`);
  for(const mode of ['whole_source','none']){
   const matches=examples.filter(e=>e.source_record_id===r.id&&e.mode===mode);
   if(matches.length!==1){errors.push(`${r.id}: thiếu/trùng mode ${mode}`);continue;}
   const e=matches[0];
   if(!e.validation.parser_valid)errors.push(`${e.id}: parser chưa đạt.`);
   if(e.payload.messages.some(m=>[r.id,r.group_id,r.source_parent_id].some(marker=>m.content.includes(marker))))errors.push(`${e.id}: lộ metadata.`);
   if(r.annotation.stance==='dismissed'&&mode==='none'&&(e.target.assessments.length||e.target.discoveries.length))errors.push(`${e.id}: benign none phải rỗng.`);
  }
 }
 const count=field=>Object.fromEntries([...new Set(rows.map(field))].map(k=>[k,rows.filter(r=>field(r)===k).length]));
 return {records:rows.length,previews:examples.length,errors,stance_counts:count(r=>r.annotation.stance),languages:count(r=>r.language),
  parent_train_groups:new Set(rows.map(r=>r.group_id)).size,context_cells:count(r=>[r.annotation.stance,r.annotation.addressee,r.annotation.framing,r.annotation.deviation].join('|'))};
}
function main(){
 if(fs.existsSync(out))throw new Error('Không ghi đè bảng rà.');
 verify(JSON.parse(fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/giao-thuc.json')));
 const rows=[],examples=[],inputs={},tokens=[];
 for(let i=1;i<=4;i++){
  const base=`benchmark/data/annotations/verifier-supervision-batch-v${i}`,manifest=JSON.parse(fs.readFileSync(`${base}/manifest.json`));
  for(const [file,expected]of Object.entries(manifest.assets_sha256)){const bytes=fs.readFileSync(`${base}/${file}`);if(hash(bytes)!==expected)throw new Error('Asset đổi');inputs[`${base}/${file}`]=expected;}
  rows.push(...fs.readFileSync(`${base}/mau-cho-duyet.jsonl`,'utf8').trim().split(/\r?\n/).map(JSON.parse).map(r=>({...r,source_file:`${base}/mau-cho-duyet.jsonl`})));
  examples.push(...JSON.parse(fs.readFileSync(`${base}/ban-xem-truoc.json`)).examples);
  const tokenFile=`benchmark/experiments/verifier-supervision-batch-tokenizer-v${i}/ket-qua.json`,t=JSON.parse(fs.readFileSync(tokenFile));
  for(const [file,expected]of Object.entries(t.input_sha256))if(hash(fs.readFileSync(`${base}/${file}`))!==expected)throw new Error('Token audit cũ');
  if(t.mask_valid!==24||t.collator_valid!==24)throw new Error('Token/mask chưa đạt');tokens.push(t.token_max);inputs[tokenFile]=hash(fs.readFileSync(tokenFile));
 }
 const matrixFile='benchmark/experiments/verifier-supervision-review-v1/ma-tran-bo-sung.json',matrix=JSON.parse(fs.readFileSync(matrixFile));inputs[matrixFile]=hash(fs.readFileSync(matrixFile));
 const result=inspect(rows,examples,matrix);
 const auditFile='benchmark/experiments/verifier-corpus-overlap-v21/ket-qua.json',audit=JSON.parse(fs.readFileSync(auditFile));inputs[auditFile]=hash(fs.readFileSync(auditFile));
 const components=audit.groups.filter(g=>g.members.some(m=>m.startsWith('verifier-supervision-batch-v')));
 const split=fs.readFileSync('benchmark/data/annotations/verifier-local-release-preview-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
 for(const row of rows){
  const parent=split.find(r=>r.id===row.parent_record_id);if(!parent||parent.planned_role!=='train'||parent.group_id!==row.group_id)result.errors.push(`${row.id}: parent role không hợp lệ.`);
 }
 if(components.length!==4||components.some(g=>g.members.length!==16||g.members.filter(m=>m.startsWith('verifier-supervision-batch-v')).length!==12||g.members.filter(m=>!m.startsWith('verifier-supervision-batch-v')).some(m=>split.find(r=>r.id===m)?.planned_role!=='train')))result.errors.push('Thành phần toàn kho có liên kết ngoài bốn nhóm train cha.');
 const queue=rows.map(r=>({id:r.id,source_file:r.source_file,
  input_sha256:r.input_sha256,annotation_sha256:hash(JSON.stringify(r.annotation)),slot_id:r.slot_id,group_id:r.group_id,
  fields:{stance:r.annotation.stance,addressee:r.annotation.addressee,framing:r.annotation.framing,deviation:r.annotation.deviation},
  directive:r.annotation.directive_spans[0].quote,reason:r.annotation.reason,status:'ai_draft_semantic_review_before_release',human_approved:false}));
 Object.assign(result,{max_tokens:Math.max(...tokens),full_inventory_files:audit.inventory.length,unique_inventory_texts:audit.unique_normalized_texts_scanned,
  full_corpus_components:components.map(g=>({size:g.size,drafts:12,flags:g.flags})),input_sha256:inputs,code_sha256:hash(fs.readFileSync(__filename)),
  technical_checks_passed:result.errors.length===0,training_ready:false,model_called:false,training_started:false,data_release_changed:false,runtime_changed:false,
  limitations:['Bốn nhóm cha, không phải 48 nguồn độc lập; metadata kế thừa được giữ cả khi từ vựng mới.',
   'Heuristic toàn kho không loại hết tương đồng ngữ nghĩa; chưa xác minh độc lập nhãn.',
   'Chưa quyết định thay thế/ghép/upweight trong train 180; không tự nhập dev hoặc mở ngân sách huấn luyện mới.']});
 fs.mkdirSync(out);
 for(const [name,value]of Object.entries({'ket-qua.json':result,'hang-cho-ra-ngu-nghia.json':{records:queue,training_eligible:false}})){
  const bytes=Buffer.from(JSON.stringify(value,null,2));fs.writeFileSync(`${out}/${name}`,bytes,{flag:'wx'});if(!fs.readFileSync(`${out}/${name}`).equals(bytes))throw new Error('Readback lỗi');}
 console.log(JSON.stringify({records:result.records,previews:result.previews,errors:result.errors,counts:result.stance_counts,technical_checks_passed:result.technical_checks_passed,max_tokens:result.max_tokens}));
 if(result.errors.length)process.exitCode=1;
}
if(require.main===module)main();
module.exports={inspect};
