const { test } = require('node:test');
const assert = require('node:assert/strict');
const { parsePrefix } = require('./fetch-llmail-intake.cjs');
test('đọc entry trọn vẹn, không nhầm dấu ngoặc hoặc escape trong email', () => {
  const original = { 'Email "quoted" {data} \\ ký tự Việt': { attack_attempt: 'True', other: ['}'] }, second: { attack_attempt: 'False' } };
  const rows = parsePrefix(JSON.stringify(original), 48);
  assert.equal(rows.length, 2);
  assert.equal(rows[0].text, Object.keys(original)[0]);
  assert.deepEqual(rows[0].source_annotation, Object.values(original)[0]);
  assert.equal(parsePrefix(JSON.stringify(original), 1).length, 1);
});
test('không nhận entry bị cắt dở hoặc tự sửa JSON thiếu', () => {
  assert.equal(parsePrefix('{"complete":{"attack_attempt":"True"},"broken":{"attack_', 48).length, 1);
  assert.equal(parsePrefix('{"broken":{"attack_', 48).length, 0);
  assert.throws(() => parsePrefix('["email"]', 48));
});
test('giữ nguyên boolean và chuỗi nhãn, không suy False bằng truthiness', () => {
  const rows = parsePrefix('{"one":{"attack_attempt":"False"},"two":{"attack_attempt":false}}', 48);
  assert.equal(rows[0].source_annotation.attack_attempt, 'False');
  assert.equal(rows[1].source_annotation.attack_attempt, false);
});
