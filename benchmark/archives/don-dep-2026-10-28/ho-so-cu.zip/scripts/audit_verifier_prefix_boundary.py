"""Đối chiếu ranh giới token của oracle prefix; không gọi model hoặc train."""
import json
import os
from transformers import AutoTokenizer
from verifier_data_loader import ROOT, load_role
from audit_verifier_tokenizer import MODEL, REVISION


def main():
    out = ROOT / 'benchmark/experiments/verifier-prefix-oracle-v1/ranh-gioi-token.json'
    if out.exists():
        raise ValueError('Không ghi đè audit.')
    plan = json.loads(out.with_name('ke-hoach.json').read_text(encoding='utf-8'))
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=os.environ['HF_HUB_CACHE'], local_files_only=True, trust_remote_code=False)
    rows = []
    for row in load_role('dev'):
        if row['id'] not in plan['provided_prefixes']:
            continue
        prompt = tokenizer.apply_chat_template(row['payload']['messages'], tokenize=False, add_generation_prompt=True)
        target = json.dumps(row['target'], ensure_ascii=False, separators=(',', ':'))
        full = tokenizer.encode(prompt + target, add_special_tokens=False)
        original_prefix = plan['provided_prefixes'][row['id']]
        prefix = tokenizer.encode(prompt + original_prefix, add_special_tokens=False)
        quoted = tokenizer.encode(prompt + original_prefix + '"', add_special_tokens=False)
        rows.append({'id': row['id'], 'prefix_token_aligned_with_gold': full[:len(prefix)] == prefix,
            'quoted_prefix_token_aligned_with_gold': full[:len(quoted)] == quoted,
            'current_prefix_last_token': tokenizer.convert_ids_to_tokens(prefix[-1]),
            'gold_token_at_same_position': tokenizer.convert_ids_to_tokens(full[len(prefix) - 1])})
    result = {'rows': rows, 'current_aligned': sum(r['prefix_token_aligned_with_gold'] for r in rows),
        'quoted_aligned': sum(r['quoted_prefix_token_aligned_with_gold'] for r in rows), 'model_called': False,
        'limitations': ['Ranh giới token khác gold là confound của phép đo prefix, không chứng minh nguyên nhân duy nhất gây JSON lỗi.',
            'Không chạy thêm model sau điều kiện dừng 6 ca; biến thể quote chỉ được kiểm tra token.']}
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    main()
