const fs = require('node:fs');
const crypto = require('node:crypto');
const path = require('node:path');

const digest = data => crypto.createHash('sha256').update(data).digest('hex');
const count = (rows, key) => rows.reduce((out, row) => {
  out[row[key]] = (out[row[key]] || 0) + 1;
  return out;
}, {});

function sourceStatus(row) {
  const kind = row.source_evidence?.kind;
  if (kind === 'project_authored_release_not_declared') return 'own_authored_local_preparation';
  if (['pinned_external_license_document', 'pinned_document_license'].includes(kind)) return 'license_document_present';
  if (['dataset_card_declaration', 'pinned_dataset_card_declaration'].includes(kind)) return 'dataset_card_declaration_present';
  if (kind === 'article_attribution_declared_not_article_specific_clearance') return 'article_attribution_present';
  return 'evidence_not_classified';
}

function audit(rows) {
  const pool = rows.filter(row => row.role === 'candidate_pending_source_privacy_and_split_review');
  const stances = count(pool, 'stance');
  const languages = count(pool, 'language');
  const sources = [...new Set(pool.map(row => row.source))].sort().map(source => {
    const members = pool.filter(row => row.source === source);
    return { source, records: members.length, groups: new Set(members.map(row => row.group_id)).size,
      stances: count(members, 'stance'), languages: count(members, 'language'),
      evidence_status: count(members.map(row => ({ status: sourceStatus(row) })), 'status') };
  });
  return {
    records: pool.length, excluded_records: rows.length - pool.length,
    groups: new Set(pool.map(row => row.group_id)).size, stances, languages, sources,
    planning_scenario: {
      note: 'Kịch bản lập kế hoạch cho 240 bản train/probe, áp tỷ lệ 40/40/20; không đổi cổng đã khóa, không phải split cuối. Ngôn ngữ hỗn hợp không cộng hai lần.',
      target: 240, stance_targets: { confirmed: 96, dismissed: 96, uncertain: 48 },
      stance_gaps: Object.fromEntries(Object.entries({ confirmed: 96, dismissed: 96, uncertain: 48 }).map(([key, target]) => [key, Math.max(0, target - (stances[key] || 0))])),
      vietnamese_gap: Math.max(0, 96 - (languages.vi || 0)),
      additional_records_lower_bound: Math.max(0, 240 - pool.length),
      independent_holdout_target_separate: 200,
    },
    source_status_counts: count(pool.map(row => ({ status: sourceStatus(row) })), 'status'),
    source_use_ledger: pool.map(row => ({ id: row.id, source: row.source,
      status: sourceStatus(row), license_declared: row.source_evidence?.license_declared ?? null,
      evidence_files: row.source_evidence?.files || [],
      local_preparation_external_license_blocker: sourceStatus(row) === 'own_authored_local_preparation' ? false : null,
      remaining_checks: sourceStatus(row) === 'own_authored_local_preparation'
        ? ['Rà riêng tư/ngữ cảnh/nhãn và chia nhóm; license phát hành xử lý riêng nếu công bố.']
        : ['Đối chiếu phạm vi nội dung, ghi công/notice và điều kiện nguồn trước export; rà riêng tư/ngữ cảnh/nhãn và chia nhóm.'],
      training_eligible: false, split: null })),
    acquisition_priorities: [
      'Ưu tiên confirmed/uncertain tiếng Việt trong email, kết quả công cụ, tài liệu nghiệp vụ; giữ đối chứng gần giống và đủ ngữ cảnh người nhận.',
      'Mỗi nhóm giữ bản sạch, trích dẫn và chỉ dẫn có hiệu lực cùng phía split; không nhân bản template để bù số.',
      'Không lấy thêm hàng loạt benign LLMail hoặc coi biến thể tự soạn trên nguồn cũ là nguồn độc lập.',
      'PDF/DOCX và chữ trong ảnh cần phép đo extraction/pipeline riêng; số mẫu văn bản không giải quyết thiếu độ bao phủ.',
    ],
    training_ready: false, training_started: false, runtime_changed: false, priority_one_complete: false,
  };
}

if (require.main === module) {
  const input = 'benchmark/experiments/verifier-eligibility-v5/registry.jsonl';
  const output = 'benchmark/experiments/verifier-pool-gap-v1';
  if (fs.existsSync(output)) throw new Error('Không ghi đè audit đã có.');
  const raw = fs.readFileSync(input);
  const rows = raw.toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
  const result = audit(rows);
  const evidence = new Map();
  for (const row of rows.filter(row => row.role.startsWith('candidate'))) {
    for (const file of row.source_evidence?.files || []) {
      const actual = digest(fs.readFileSync(file));
      if (actual !== row.source_evidence.sha256[file]) throw new Error(`Bằng chứng thay đổi: ${file}`);
      evidence.set(file, actual);
    }
  }
  result.inputs_sha256 = { [input]: digest(raw), [__filename.replace(process.cwd() + path.sep, '').replaceAll('\\', '/')]: digest(fs.readFileSync(__filename)), ...Object.fromEntries(evidence) };
  result.command = 'node scripts/audit-verifier-pool.cjs';
  result.evidence_hashes_verified = true;
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(`${output}/ket-qua.json`, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ records: result.records, stances: result.stances, languages: result.languages, scenario: result.planning_scenario, evidence: result.source_status_counts }));
}
module.exports = { audit, sourceStatus };
