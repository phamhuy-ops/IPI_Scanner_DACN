﻿# Chuyển thư mục kết quả sinh ra: sao chép, đối chiếu hash, tạo junction rồi mới bỏ bản C.
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent)).TrimEnd('\')
$sourceRoot = Join-Path $workspace 'benchmark\results'
$destinationRoot = 'E:\IPI-Training\results\IPI_Scanner'
$reportRoot = Join-Path $workspace 'benchmark\experiments\storage-drive-e-v2'
if (Test-Path -LiteralPath (Join-Path $reportRoot 'ket-qua.json')) { $prior = Get-Content -LiteralPath (Join-Path $reportRoot 'ket-qua.json') -Raw | ConvertFrom-Json; if ($prior.status -eq 'completed') { throw 'Lượt chuyển đã hoàn tất.' } }
if (-not (Test-Path -LiteralPath 'E:\IPI-Training')) { throw 'Chưa có gốc huấn luyện trên E.' }

function Assert-Within([string]$Candidate, [string]$Parent) {
    $absolute = [IO.Path]::GetFullPath($Candidate).TrimEnd('\')
    $root = [IO.Path]::GetFullPath($Parent).TrimEnd('\')
    if (-not $absolute.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Đường vượt phạm vi: $absolute" }
    return $absolute
}
function Get-TreeManifest([string]$Folder) {
    $result = @{}
    $prefix = $Folder.TrimEnd('\') + '\'
    foreach ($file in Get-ChildItem -LiteralPath $Folder -Force -Recurse -File) {
        $relative = $file.FullName.Substring($prefix.Length)
        $result[$relative] = @{ bytes = $file.Length; sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
    }
    return $result
}
function Assert-Same($Expected, $Actual) {
    if ($Expected.Count -ne $Actual.Count) { throw 'Số file khác sau sao chép.' }
    foreach ($key in $Expected.Keys) {
        if (-not $Actual.ContainsKey($key) -or $Actual[$key].sha256 -ne $Expected[$key].sha256 -or $Actual[$key].bytes -ne $Expected[$key].bytes) {
            throw "File không khớp: $key"
        }
    }
}
$folders = @(Get-ChildItem -LiteralPath $sourceRoot -Force -Directory)
$null = New-Item -ItemType Directory -Path $destinationRoot -Force
$null = New-Item -ItemType Directory -Path $reportRoot -Force
$beforeFree = (Get-PSDrive C).Free
$records = @()
foreach ($folder in $folders) {
    if ($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        $expectedTarget = Assert-Within (Join-Path $destinationRoot $folder.Name) $destinationRoot
        if ([IO.Path]::GetFullPath([string]$folder.Target[0]).TrimEnd('\') -ine $expectedTarget) { throw 'Liên kết cũ trỏ đích ngoài phạm vi.' }
        $existing = Get-TreeManifest $folder.FullName
        Assert-Same $existing (Get-TreeManifest $expectedTarget)
        $existingBytes = 0L; foreach ($entry in $existing.Values) { $existingBytes += [long]$entry.bytes }
        $records += @{ source = $folder.FullName; target = $expectedTarget; files = $existing.Count; bytes = $existingBytes; hashes_verified = $true; old_copy_removed = $true; junction_verified = $true; resumed_existing_junction = $true }
        continue
    }
    $source = Assert-Within $folder.FullName $sourceRoot
    $relativeGit = 'benchmark/results/' + $folder.Name + '/'
    $tracked = @(& git -C $workspace ls-files -- $relativeGit)
    if ($LASTEXITCODE -ne 0) { throw 'Không kiểm tra được file Git.' }
    if ($tracked.Count -gt 0) { throw "Không chuyển thư mục chứa file tracked: $source" }
    if (@(Get-ChildItem -LiteralPath $source -Force -Recurse -Attributes ReparsePoint).Count -gt 0) { throw 'Có liên kết lồng, cần kiểm tra riêng.' }
    $target = Assert-Within (Join-Path $destinationRoot $folder.Name) $destinationRoot
    $backup = Assert-Within (Join-Path $sourceRoot ('.c-backup-' + $folder.Name)) $sourceRoot
    if ((Test-Path -LiteralPath $target) -or (Test-Path -LiteralPath $backup)) { throw 'Đích hoặc backup đã tồn tại.' }
    $original = Get-TreeManifest $source
    $bytes = 0L; foreach ($entry in $original.Values) { $bytes += [long]$entry.bytes }
    $original | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $reportRoot ($folder.Name + '-hashes.json')) -Encoding UTF8
    $null = New-Item -ItemType Directory -Path $target
    foreach ($child in Get-ChildItem -LiteralPath $source -Force) { Copy-Item -LiteralPath $child.FullName -Destination $target -Recurse -Force }
    Assert-Same $original (Get-TreeManifest $target)
    Move-Item -LiteralPath $source -Destination $backup
    try {
        $null = New-Item -ItemType Junction -Path $source -Target $target
        $link = Get-Item -LiteralPath $source -Force
        if (-not ($link.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Chưa tạo được junction.' }
        if ([IO.Path]::GetFullPath([string]$link.Target[0]).TrimEnd('\') -ine $target) { throw 'Junction trỏ sai đích.' }
        Assert-Same $original (Get-TreeManifest $source)
    } catch {
        if (Test-Path -LiteralPath $source) { Remove-Item -LiteralPath $source -Force }
        Move-Item -LiteralPath $backup -Destination $source
        throw
    }
    # Kiểm tra lại đường tuyệt đối và nội dung trước thao tác xóa đệ quy.
    $checkedBackup = Assert-Within $backup $sourceRoot
    if ($checkedBackup -ine $backup -or ((Get-Item -LiteralPath $backup -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Backup không đúng phạm vi.' }
    Assert-Same $original (Get-TreeManifest $backup)
    Remove-Item -LiteralPath $checkedBackup -Recurse -Force
    # Tổng byte đã tính và lưu trước khi di chuyển.
    $records += @{ source = $source; target = $target; files = $original.Count; bytes = $bytes; hashes_verified = $true; old_copy_removed = $true; junction_verified = $true }
    @{ status = 'running'; moved = $records } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $reportRoot 'ket-qua.json') -Encoding UTF8
}
$allBytes = 0L; foreach ($record in $records) { $allBytes += [long]$record.bytes }
$result = @{ status = 'completed'; directories = $records.Count; bytes_moved = $allBytes;
    c_free_before = $beforeFree; c_free_after = (Get-PSDrive C).Free; moved = $records;
    tracked_root_files_retained = @(& git -C $workspace ls-files -- 'benchmark/results/'); code_remains_on_c = $true }
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $reportRoot 'ket-qua.json') -Encoding UTF8
@{ status = $result.status; directories = $result.directories; bytes_moved = $result.bytes_moved; c_free_after = $result.c_free_after } | ConvertTo-Json -Compress
