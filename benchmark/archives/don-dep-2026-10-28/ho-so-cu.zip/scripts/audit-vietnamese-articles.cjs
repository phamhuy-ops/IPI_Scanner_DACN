// Kiểm tra bản xem trước và coverage trước AI; không gọi model hoặc đổi selector.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const { buildRows } = require('./prepare-vietnamese-articles.cjs');
const { scanTextForIpi } = require('../engine/prefilter/document-prefilter.js');
const { createSemanticChunks, annotateChunkRisk, selectSemanticChunks } = require('../engine/document/chunking/semantic-chunker.js');
const { SEMANTIC_SCAN_PROFILES } = require('../engine/config/document-scan-config.js');
const root = path.resolve(__dirname, '..');
const dir = path.join(root, 'benchmark/data/annotations/verifier-vietnamese-articles-v1');
const read = p => JSON.parse(fs.readFileSync(p));

function sourceRange(text, chunk) {
  let start = text.indexOf(chunk.text);
  while (start >= 0) {
    if (text.slice(0, start).split(/\r\n?|\n/).length === chunk.startLine) return { start, end: start + chunk.text.length };
    start = text.indexOf(chunk.text, start + 1);
  }
  throw new Error('Không ánh xạ được chunk về nguồn.');
}

function covers(ranges, from, to) {
  let cursor = from;
  for (const r of [...ranges].sort((a, b) => a.start - b.start)) {
    if (r.end <= cursor) continue;
    if (r.start > cursor) return false;
    cursor = r.end;
    if (cursor >= to) return true;
  }
  return false;
}

function measureCoverage(row, profile) {
  // Chỉ text và tên file trung tính tới scanner. Gold dùng đối chiếu sau khi chọn chunk.
  const findings = scanTextForIpi(row.text, 'document.txt');
  const chunks = createSemanticChunks(row.text, 'document.txt', 'document.txt', undefined, undefined, true);
  annotateChunkRisk(chunks, findings);
  const selected = selectSemanticChunks(chunks, SEMANTIC_SCAN_PROFILES[profile].maxAiChunks);
  const quote = row.annotation.directive_spans[0].quote;
  const directive = row.annotation.directive_spans[0];
  const selectedRanges = selected.map(c => sourceRange(row.text, c));
  return { id: row.id, profile, total_chunks: chunks.length, selected_chunks: selected.length,
    rule_findings: findings.length, directive_in_any_selected_chunk: selected.some(c => c.text.includes(quote)),
    directive_in_any_extracted_chunk: chunks.some(c => c.text.includes(quote)),
    directive_covered_by_selected_union: covers(selectedRanges, directive.start, directive.end),
    context_window_covered_by_selected_union: covers(selectedRanges, row.selected_window.start, row.selected_window.end),
    selected_chunk_ids: selected.map(c => c.chunkId), model_called: false, classification_metrics: null };
}

async function main() {
  const coverageFiles = ['engine/prefilter/document-prefilter.js', 'engine/prefilter/rules/ipi-document-rules.js',
    'engine/models/finding.js', 'engine/document/chunking/semantic-chunker.js', 'engine/config/document-scan-config.js'];
  const coverageCode = Object.fromEntries(coverageFiles.map(p => [p, hash(fs.readFileSync(path.join(root, p)))]));
  const manifest = read(path.join(dir, 'manifest.json'));
  for (const [p, h] of Object.entries(manifest.assets_sha256)) if (hash(fs.readFileSync(path.join(dir, p))) !== h) throw new Error('Tài sản đổi.');
  for (const [p, h] of Object.entries(manifest.code_sha256)) if (hash(fs.readFileSync(path.join(root, p))) !== h) throw new Error('Code đổi.');
  const rawDir = path.join(root, 'benchmark/data/raw/vietnamese-wikipedia-v1');
  if (hash(fs.readFileSync(path.join(rawDir, 'snapshot.json'))) !== manifest.snapshot_sha256) throw new Error('Snapshot đổi.');
  const snapshot = read(path.join(rawDir, 'snapshot.json'));
  for (const [p, h] of Object.entries(snapshot.assets_sha256)) if (hash(fs.readFileSync(path.join(rawDir, p))) !== h) throw new Error('Nguồn đổi.');
  const rows = fs.readFileSync(path.join(dir, 'mau-cho-duyet.jsonl'), 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  if (JSON.stringify(rows) !== JSON.stringify(buildRows())) throw new Error('Sai tái dựng nguồn/span.');
  const reviews = read(path.join(dir, 'danh-gia-ai.json'));
  if (reviews.source_sha256 !== hash(fs.readFileSync(path.join(dir, 'mau-cho-duyet.jsonl')))) throw new Error('Nhật ký AI cũ.');
  for (const row of rows) {
    const review = reviews.reviews.find(r => r.id === row.id);
    if (!review || review.window_sha256 !== hash(Buffer.from(row.selected_window.text)) || review.window_annotation_sha256 !== hash(JSON.stringify(row.window_annotation)) || row.full_document_security_label !== null) throw new Error('Sai phạm vi/nhãn.');
  }
  const examples = read(path.join(dir, 'ban-xem-truoc.json')).examples;
  if (examples.length !== 60 || new Set(examples.map(r => r.id)).size !== 60) throw new Error('Sai số lượng/trùng ID.');
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  let valid = 0;
  try {
    const { normalizeExternal } = await server.ssrLoadModule('/scripts/normalize-reviewed-external.ts');
    for (const row of rows) for (const example of examples.filter(e => e.source_record_id === row.id)) {
      const rebuilt = normalizeExternal(row.selected_window.text,
        { ...row.window_annotation, language: 'vi', target_quote: row.window_annotation.directive_spans[0]?.quote }, example.mode);
      if (JSON.stringify(rebuilt.payload) !== JSON.stringify(example.payload) || JSON.stringify(rebuilt.response) !== JSON.stringify(example.target) || !rebuilt.validation.parser_valid) throw new Error('Input/target không khớp.');
      valid++;
    }
  } finally { await server.close(); }
  const corpusPath = path.join(root, 'benchmark/experiments/verifier-corpus-overlap-v7/ket-qua.json');
  const corpus = read(corpusPath);
  for (const entry of corpus.inventory) if (hash(fs.readFileSync(path.join(root, entry.file))) !== entry.sha256) throw new Error('Kho đổi trong lượt audit.');
  const groups = corpus.groups.map(g => ({ ...g, global_group_id: `cg-${hash([...g.members].sort().join('\n')).slice(0, 16)}` }));
  const fresh = groups.filter(g => g.members.some(id => id.startsWith('verifier-vietnamese-articles-v1:')));
  const mapping = rows.map(r => {
    const g = groups.find(g => g.members.includes(`verifier-vietnamese-articles-v1:${r.id}`));
    if (!g) throw new Error('Thiếu nhóm.');
    return { id: r.id, source_parent_id: r.source_parent_id, global_group_id: g.global_group_id,
      constraint: g.constraint, annotation_scope: r.annotation_scope, full_document_security_label: null,
      split: null, training_eligible: false };
  });
  for (const parent of new Set(mapping.map(r => r.source_parent_id))) if (new Set(mapping.filter(r => r.source_parent_id === parent).map(r => r.global_group_id)).size !== 1) throw new Error('Tách nhóm biến thể.');
  const coverage = rows.filter(r => r.variant_kind === 'active').flatMap(r => ['balanced', 'deep'].map(p => measureCoverage(r, p)));
  for (const [p, expected] of Object.entries(coverageCode)) if (hash(fs.readFileSync(path.join(root, p))) !== expected) throw new Error('Code coverage đổi trong lượt đo.');
  const result = { records: rows.length, parent_ids: 6, exact_rebuild_valid: valid, parser_valid: valid,
    global_candidate_records: corpus.candidate_records, global_source_parent_ids: 111 + 6,
    global_candidate_groups: groups.filter(g => g.constraint !== 'reference_only').length,
    new_groups: fresh.length, mapping, coverage, coverage_code_sha256: coverageCode,
    scope: 'window_annotations_only; coverage is engine selection before models, not full pipeline',
    full_document_negative_labels_created: false, training_ready: false, final_split_created: false,
    independent_holdout_verified: false, source_and_added_text_separated: true,
    corpus_sha256: hash(fs.readFileSync(corpusPath)), script_sha256: hash(fs.readFileSync(__filename)) };
  fs.writeFileSync(path.join(dir, 'kiem-tra-va-nhom.json'), JSON.stringify(result, null, 2) + '\n');
  const baselineDir = path.join(root, 'benchmark/experiments/vietnamese-article-selection-baseline-v1');
  const baseline = JSON.stringify({ source_rows_sha256: hash(fs.readFileSync(path.join(dir, 'mau-cho-duyet.jsonl'))),
    coverage_code_sha256: coverageCode, cases: coverage, models_called: false,
    limitation: 'Sáu fixture positive đã xem, không phải kiểm chứng độc lập hoặc full pipeline.' }, null, 2) + '\n';
  const baselineFile = path.join(baselineDir, 'ket-qua.json');
  if (fs.existsSync(baselineFile) && fs.readFileSync(baselineFile, 'utf8') !== baseline) throw new Error('Cần phiên bản mới, không ghi đè baseline selection.');
  fs.mkdirSync(baselineDir, { recursive: true });
  fs.writeFileSync(baselineFile, baseline);
  for (const p of coverageFiles) {
    const target = path.join(baselineDir, 'code', p);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    if (!fs.existsSync(target)) fs.copyFileSync(path.join(root, p), target);
    if (hash(fs.readFileSync(target)) !== coverageCode[p]) throw new Error('Snapshot code không khớp.');
  }
  const boundary = path.join(root, 'benchmark/experiments/verifier-corpus-overlap-v7/ranh-gioi-nhom.json');
  const content = JSON.stringify({ corpus_sha256: result.corpus_sha256, groups, final_split_created: false }, null, 2) + '\n';
  if (fs.existsSync(boundary) && fs.readFileSync(boundary, 'utf8') !== content) throw new Error('Không ghi đè ranh giới khác.');
  fs.writeFileSync(boundary, content);
  console.log(JSON.stringify({ parser_valid: valid, records: rows.length, parent_ids: 6,
    candidate_records: result.global_candidate_records, candidate_groups: result.global_candidate_groups,
    new_groups: fresh.length, coverage: coverage.map(r => ({ id: r.id, profile: r.profile,
      directive_selected: r.directive_in_any_selected_chunk, context_selected: r.context_window_covered_by_selected_union })) }));
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { covers, sourceRange };
