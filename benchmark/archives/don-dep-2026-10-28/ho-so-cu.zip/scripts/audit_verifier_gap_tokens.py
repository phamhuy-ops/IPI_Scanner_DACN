"""Audit tokenizer/mask cho cửa sổ mới, hoàn toàn offline; không train."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
from audit_verifier_tokenizer import MODEL, REVISION, completion_example, pad_example

ROOT = Path(__file__).resolve().parents[1]


def main():
    from transformers import AutoTokenizer
    if Path(os.environ['HF_HUB_CACHE']).resolve().drive.lower() != 'e:':
        raise ValueError('Cache phải ở E.')
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION,
        cache_dir=os.environ['HF_HUB_CACHE'], local_files_only=True, trust_remote_code=False)
    source = ROOT / 'benchmark/data/annotations/verifier-gap-normalized-v1'
    output = ROOT / 'benchmark/experiments/verifier-gap-tokenizer-v1'
    if output.exists():
        raise ValueError('Không ghi đè audit đã có; tạo phiên bản mới.')
    manifest = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))
    for name, digest in manifest['assets_sha256'].items():
        if hashlib.sha256((source / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f'Đầu vào đã đổi: {name}')
    preview = json.loads((source / 'ban-xem-truoc.json').read_text(encoding='utf-8'))
    rows = []
    for example in preview['examples']:
        if not example['validation']['parser_valid'] or example['training_eligible']:
            raise ValueError('Không phải bản xem trước đã qua parser.')
        target = json.dumps(example['target'], ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, example['payload']['messages'], target)
        _, padded_labels, attention = pad_example(ids, labels, len(ids) + 5, tokenizer.pad_token_id)
        assert labels[:boundary] == [-100] * boundary
        assert padded_labels[-5:] == [-100] * 5 and attention[-5:] == [0] * 5
        rows.append({key: example[key] for key in ['id', 'source_record_id', 'group_id', 'mode', 'window_id']} |
            {'tokens': len(ids), 'prompt_masked': boundary, 'loss_tokens': end - boundary,
             'mask_valid': True, 'fits_1024': len(ids) <= 1024,
             'fits_1536': len(ids) <= 1536, 'fits_2048': len(ids) <= 2048})
    # Tọa độ ở đây vẫn theo UTF-16 của JS; Python không tự dùng chúng để slice Unicode.
    sources = [json.loads(line) for line in (source / 'nhan-va-cua-so.jsonl').read_text(encoding='utf-8').splitlines()]
    plain_lengths = [{'id': row['id'], 'full_text_tokens_without_prompt': len(tokenizer.encode(row['text'], add_special_tokens=False)),
        'selected_text_tokens_without_prompt': len(tokenizer.encode(row['selected_window']['text'], add_special_tokens=False))}
        for row in sources]
    result = {'model': MODEL, 'revision': REVISION, 'offline': True, 'sources': len(sources),
        'examples': len(rows), 'mask_valid': sum(row['mask_valid'] for row in rows),
        'token_min': min(row['tokens'] for row in rows), 'token_max': max(row['tokens'] for row in rows),
        'over_budget': {str(limit): sum(row['tokens'] > limit for row in rows) for limit in [1024, 1536, 2048]},
        'mask_method': 'verified_token_prefix_JSON_and_EOS; prompt/header/trailing_newline/padding=-100',
        'no_truncation': True, 'rows': rows, 'text_lengths': plain_lengths,
        'input_sha256': {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                         for name in ['manifest.json', 'ban-xem-truoc.json', 'nhan-va-cua-so.jsonl']},
        'code_sha256': {name: hashlib.sha256((ROOT / 'scripts' / name).read_bytes()).hexdigest()
                        for name in ['audit_verifier_gap_tokens.py', 'audit_verifier_tokenizer.py']},
        'versions': {name: importlib.metadata.version(name) for name in ['transformers', 'tokenizers', 'jinja2']},
        'chat_template_sha256': hashlib.sha256(tokenizer.chat_template.encode()).hexdigest(),
        'training_ready': False, 'runtime_changed': False, 'weights_downloaded': False,
        'limitations': ['Chỉ bản xem trước; chưa kiểm tra collator/backend hoặc bộ nhớ GPU.',
                       'Mask hợp lệ không xác nhận ngữ nghĩa cửa sổ; chưa có đánh giá model/pipeline mới.',
                       'Các mức 1536/2048 chỉ dùng thống kê, không đổi max sequence đã đề xuất.']}
    output.mkdir(parents=True)
    (output / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ['sources', 'examples', 'mask_valid', 'token_min', 'token_max', 'over_budget']}, ensure_ascii=False))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
