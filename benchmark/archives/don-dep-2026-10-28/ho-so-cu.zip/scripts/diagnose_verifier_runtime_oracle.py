"""Giữ nguyên tác vụ compact Verifier; chỉ thêm ngữ cảnh gold trong nhánh oracle chẩn đoán."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from verifier_data_loader import ROOT, load_role


def oracle_messages(payload, annotation, oracle):
    result = copy.deepcopy(payload['messages'])
    if oracle:
        facts = {k: annotation[k] for k in ['addressee', 'framing', 'deviation', 'hasDirective']}
        result[0]['content'] += '\nDiagnostic override supplied by the evaluator, outside the source document: these four facts describe the directive in the document and are correct for this experiment only. Use them when reviewing its stance; still obey the original assessment/discovery and citation contract. Context facts: ' + json.dumps(facts, ensure_ascii=False)
    return result


def main():
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
    from peft import PeftModel, prepare_model_for_kbit_training
    out = ROOT / 'benchmark/experiments/verifier-runtime-oracle-v1'
    if out.exists():
        raise ValueError('Không ghi đè đối chứng.')
    dev = load_role('dev')
    selected = json.loads((ROOT / 'benchmark/experiments/verifier-hf-base-screen-v1/ke-hoach-truoc-do.json').read_text(encoding='utf-8'))['selected_source_ids']
    requests = [r for r in dev if r['source_record_id'] in selected]
    source = ROOT / 'benchmark/data/annotations/verifier-local-release-preview-v2/mau-cho-duyet.jsonl'
    annotations = {r['id']: r['annotation'] for r in map(json.loads, source.read_text(encoding='utf-8').splitlines()) if r['id'] in selected}
    if len(requests) != 12 or len(annotations) != 6:
        raise ValueError('Sai số mẫu dev.')
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    candidate = json.loads((ROOT / 'benchmark/experiments/verifier-pilot-candidate-02/ket-qua.json').read_text(encoding='utf-8'))
    adapter = Path(candidate['adapter_path']).resolve()
    assets = json.loads((ROOT / 'benchmark/experiments/verifier-gpu-assets-v1/ket-qua.json').read_text(encoding='utf-8'))
    local = Path(assets['snapshot']).resolve()
    if storage.drive.lower() != 'e:' or not all(p.is_relative_to(storage) for p in [local, adapter]):
        raise ValueError('Weights ngoài E.')
    def verify():
        for name, expected in candidate['adapter_files_sha256'].items():
            if hashlib.sha256((adapter / name).read_bytes()).hexdigest() != expected:
                raise ValueError('Adapter thay đổi.')
    verify()
    out.mkdir()
    plan = {'scope': 'original_compact_task_with_diagnostic_oracle_context', 'candidate': 'candidate-02', 'adapter': 'on',
        'requests_per_context': 12, 'context_modes': ['infer', 'oracle'], 'max_new_tokens': 256, 'seed': 42,
        'oracle_fields': ['addressee', 'framing', 'deviation', 'hasDirective'],
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'adapter_sha256': candidate['adapter_files_sha256'],
        'limitations': ['Oracle đưa sự thật liên quan nhãn vào system chỉ cho chẩn đoán; không có trong đường scanner/sản phẩm.',
            'Giữ prompt/schema/citation gốc ở nhánh infer; nhánh oracle chỉ thêm 4 trường vào system, không thêm stance hoặc reason.',
            'Cả hai nhánh cùng adapter; đây không phải off/on model. Không mở lại full dev/probe, không sửa gold cũ.',
            'Nếu oracle không tăng, chưa loại được nguyên nhân model bỏ qua oracle; không tự quy lỗi cho dữ liệu hoặc ánh xạ stance.']}
    (out / 'ke-hoach.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    torch.manual_seed(42)
    torch.cuda.set_per_process_memory_fraction(.8)
    tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False)
    base = AutoModelForCausalLM.from_pretrained(local, local_files_only=True, trust_remote_code=False,
        quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4', bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.float16),
        device_map={'': 0}, torch_dtype=torch.float16, attn_implementation='sdpa')
    base = prepare_model_for_kbit_training(base, use_gradient_checkpointing=False)
    model = PeftModel.from_pretrained(base, adapter, is_trainable=False, local_files_only=True)
    model.eval()
    model.config.use_cache = True
    for p in model.parameters():
        p.requires_grad_(False)
    started = time.perf_counter()
    for context in ['infer', 'oracle']:
        folder = out / context
        folder.mkdir()
        responses = []
        for row in requests:
            began = time.perf_counter()
            messages = oracle_messages(row['payload'], annotations[row['source_record_id']], context == 'oracle')
            ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_tensors='pt').to('cuda')
            if ids.shape[-1] + 256 > model.config.max_position_embeddings:
                raise ValueError('Vượt context, không cắt nguồn.')
            with torch.inference_mode():
                generated = model.generate(ids, attention_mask=torch.ones_like(ids), do_sample=False, max_new_tokens=256, pad_token_id=tokenizer.pad_token_id, eos_token_id=tokenizer.eos_token_id)[0, ids.shape[-1]:]
            responses.append({'id': row['id'], 'source_record_id': row['source_record_id'], 'mode': row['mode'], 'status': 'completed',
                'response': tokenizer.decode(generated, skip_special_tokens=True), 'input_tokens': ids.shape[-1], 'generated_tokens': len(generated),
                'hit_token_limit': len(generated) >= 256, 'seconds': time.perf_counter() - began})
            (folder / 'phan-hoi.json').write_text(json.dumps(responses, ensure_ascii=False, indent=2), encoding='utf-8')
            print(json.dumps({'context': context, 'done': len(responses), 'total': 12}), flush=True)
    verify()
    summary = {'seconds': time.perf_counter() - started, 'peak_vram_allocated': torch.cuda.max_memory_allocated(),
        'peak_vram_reserved': torch.cuda.max_memory_reserved(), 'requests': 24, 'adapter_mode': 'on_both_contexts',
        'training_started': False, 'probe_used': False, 'runtime_changed': False, 'adapter_unchanged': True,
        'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad)}
    (out / 'ket-qua.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
