"""Bảo vệ ranh giới oracle chẩn đoán và cách đếm lỗi."""
import json
import unittest
from diagnose_verifier_oracle_context import messages, parse_stance, summarize
from diagnose_verifier_runtime_oracle import oracle_messages


class OracleTests(unittest.TestCase):
    def test_runtime_oracle_preserves_original_task_and_source(self):
        payload = {'messages': [{'role': 'system', 'content': 'Original contract.'}, {'role': 'user', 'content': 'Original evidence.'}]}
        annotation = {'addressee': 'human', 'framing': 'active', 'deviation': 'none', 'hasDirective': True, 'stance': 'dismissed', 'reason': 'SECRET_REASON'}
        self.assertEqual(oracle_messages(payload, annotation, False), payload['messages'])
        changed = oracle_messages(payload, annotation, True)
        self.assertEqual(changed[1], payload['messages'][1])
        self.assertTrue(changed[0]['content'].startswith('Original contract.'))
        self.assertNotIn('SECRET_REASON', changed[0]['content'])
        self.assertNotIn('"stance"', changed[0]['content'])
        self.assertEqual(payload['messages'][0]['content'], 'Original contract.')

    def test_context_excludes_stance_and_metadata(self):
        row = {'id': 'SECRET_CASE_ID', 'group_id': 'SECRET_GROUP', 'text': 'Nội dung nguồn.',
               'annotation': {'stance': 'confirmed', 'label': 'malicious', 'reason': 'SECRET_REASON',
                              'addressee': 'assistant', 'framing': 'active', 'deviation': 'task_override', 'hasDirective': True}}
        for oracle in [False, True]:
            payload = json.loads(messages(row, oracle)[1]['content'])
            self.assertEqual(set(payload), {'document', 'diagnostic_context'})
            if oracle:
                self.assertEqual(set(payload['diagnostic_context']), {'addressee', 'framing', 'deviation', 'hasDirective'})
            else:
                self.assertIsNone(payload['diagnostic_context'])
            self.assertNotIn('SECRET_', json.dumps(payload))

    def test_invalid_not_counted_as_benign(self):
        with self.assertRaises(ValueError):
            parse_stance('{"stance":"dismissed","reason":"extra"}')
        with self.assertRaises(ValueError):
            parse_stance('```json\n{"stance":"confirmed"}\n```')
        rows = [{'expected': 'dismissed', 'predicted': None}, {'expected': 'confirmed', 'predicted': 'uncertain'}]
        result = summarize(rows)
        self.assertEqual(result['tn'], 0)
        self.assertEqual(result['false_clear_fn'], 0)
        self.assertIsNone(result['precision'])
        self.assertEqual(result['correct_stance'], 0)


if __name__ == '__main__':
    unittest.main()
