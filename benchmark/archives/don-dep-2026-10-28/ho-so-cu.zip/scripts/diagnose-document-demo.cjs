// Tái hiện pipeline với model cục bộ; không đưa nội dung tài liệu lên dịch vụ ngoài.
const fs = require('node:fs');
const path = require('node:path');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');
const { createHash } = require('node:crypto');
async function main() {
  if (process.argv.includes('--single-chunk') && (!process.argv.includes('--referenced') || process.argv.includes('--bounded'))) {
    throw new Error('--single-chunk yêu cầu --referenced và không ghép --bounded để tránh trộn thay đổi.');
  }
  const started = Date.now();
  const file = path.resolve(process.argv[2] || '');
  if (!process.argv[2] || !fs.statSync(file).isFile()) throw new Error('Cần đường dẫn tài liệu thực.');
  const root = path.resolve(__dirname, '..');
  const dir = fs.mkdtempSync(path.join(root, 'benchmark/results/document-demo-'));
  const sourceFiles = ['scripts/diagnose-document-demo.cjs', 'src/ai/agents/document/prompts.ts',
    'src/ai/agents/document/reviewPolicy.ts', 'src/ai/agents/document/ipiPipeline.ts', 'src/ai/agents/slmClient.ts'];
  const versions = { node: process.version, code_sha256: Object.fromEntries(sourceFiles.map(name =>
    [name, createHash('sha256').update(fs.readFileSync(path.join(root, name))).digest('hex')])) };
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true }, appType: 'custom' });
  const calls = [];
  globalThis.owaspWorkbench = {
    scanIpiDoc: (files, scanProfile) => runIpiDocScan(files, { scanProfile }),
    aiFetch: async payload => {
      if (new URL(payload.url).origin !== 'http://127.0.0.1:11434') throw new Error('Chỉ cho phép Ollama cục bộ.');
      const begin = Date.now();
      if (process.argv.includes('--bounded') && payload.url.includes('/chat/completions')) {
        const request = JSON.parse(payload.body);
        // Ứng viên chẩn đoán: chỉ giới hạn phần giải thích, giữ nguyên nguồn và validator.
        request.messages[0].content += '\nKeep analysis to one sentence, at most 240 characters. Each reason is one sentence, 20-240 characters. Never put JSON or a list inside analysis. Return complete JSON.';
        const properties = request.response_format?.json_schema?.schema?.properties;
        if (properties?.analysis) properties.analysis.maxLength = 240;
        const limit = shape => {
          if (shape?.properties?.reason) shape.properties.reason.maxLength = 240;
          for (const variant of shape?.anyOf || []) limit(variant);
        };
        limit(properties?.assessments?.items); limit(properties?.discoveries?.items);
        payload = { ...payload, body: JSON.stringify(request) };
      }
      try {
        const res = await fetch(payload.url, { method: payload.method || 'POST', headers: payload.headers,
          body: payload.body, signal: AbortSignal.timeout(payload.timeoutMs || 45000) });
        const body = await res.text();
        if (payload.url.includes('/chat/completions')) {
          const request = JSON.parse(payload.body);
          calls.push({ model: request.model, elapsed_ms: Date.now() - begin, status: res.status,
            request_sha256: createHash('sha256').update(payload.body).digest('hex'), response: body });
          fs.writeFileSync(path.join(dir, 'model-calls.json'), JSON.stringify(calls, null, 2));
          console.log(`Model ${request.model}: ${res.status}, ${Date.now() - begin} ms`);
        }
        return { ok: res.ok, status: res.status, body };
      } catch (error) { return { ok: false, status: 0, body: '', error: error.message }; }
    },
  };
  try {
    const { runIpiDocumentPipeline } = await server.ssrLoadModule('/src/ai/agents/document/ipiPipeline.ts');
    const configuration = { scanProfile: process.argv.includes('--deep') ? 'deep' : 'balanced',
      reviewContract: process.argv.includes('--referenced') ? 'referenced-v1' : 'classic-v1',
      verifierOutput: process.argv.includes('--referenced') ? 'compact-v1' : 'standard',
      ...(process.argv.includes('--single-chunk') ? { referenceBatchSize: 1 } : {}) };
    const state = await runIpiDocumentPipeline({ filePaths: [file], ...configuration, analysisTimeoutMs: 180000,
      onEvent: event => console.log(`${event.phase}: ${event.message}`) });
    const result = { configuration, versions, elapsed_ms: Date.now() - started,
      bounded_experiment: process.argv.includes('--bounded'), file_sha256: createHash('sha256').update(fs.readFileSync(file)).digest('hex'),
      note: 'Chẩn đoán file người dùng bằng pipeline thật qua bridge headless; chưa kiểm tra Electron/UI. Nội dung riêng tư chỉ lưu cục bộ trong benchmark/results bị gitignore.',
      processingStatus: state.processingStatus, error: state.error, check: state.check,
      coverage: state.scanResult?.metadata.coverage, suspicions: state.suspicions, calls: calls.length };
    fs.writeFileSync(path.join(dir, 'ket-qua.json'), JSON.stringify(result, null, 2));
    console.log(JSON.stringify({ output: dir, configuration, bounded_experiment: result.bounded_experiment,
      processingStatus: result.processingStatus, error: result.error, verdict: result.check?.verdict,
      coverage: result.coverage, suspicions: result.suspicions.length, elapsed_ms: result.elapsed_ms }, null, 2));
  } finally { delete globalThis.owaspWorkbench; await server.close(); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
