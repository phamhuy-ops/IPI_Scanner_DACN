// Tổng hợp bằng chứng kỹ thuật, không đổi trạng thái chất lượng hoặc quyền train.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const output = path.join(root, 'benchmark/experiments/verifier-backend-summary-v1');
if (fs.existsSync(output)) throw new Error('Không ghi đè tổng hợp đã có.');
const inputs = {};
const read = relative => { const bytes = fs.readFileSync(path.join(root, relative)); inputs[relative] = hash(bytes); return JSON.parse(bytes); };
const collator = read('benchmark/experiments/verifier-collator-v1/ket-qua.json');
const dense = [1024, 1536, 2048].map(n => read(`benchmark/experiments/verifier-gpu-${n}-1-v2/ket-qua.json`));
const paired = read('benchmark/experiments/verifier-gpu-2048-1-completion-v3/ket-qua.json');
const stress = read('benchmark/experiments/verifier-gpu-2048-10-completion-t256-v3/ket-qua.json');
const originalTokenAudit = read('benchmark/experiments/verifier-tokenizer-v1/ket-qua.json');
const gapTokenAudit = read('benchmark/experiments/verifier-gap-tokenizer-v1/ket-qua.json');
const repairTokenAudit = read('benchmark/experiments/verifier-gap-repair-tokenizer-v1/ket-qua.json');
const repaired = new Set(repairTokenAudit.rows.map(r => r.source_record_id));
const maxTarget = Math.max(...originalTokenAudit.rows.map(r => r.loss_tokens_json_and_eos),
  ...gapTokenAudit.rows.filter(r => !repaired.has(r.source_record_id)).map(r => r.loss_tokens),
  ...repairTokenAudit.rows.map(r => r.loss_tokens));
const technicalComplete = stress.status === 'passed_technical_only' && stress.steps.length === 10 &&
  stress.save_reload_verified && stress.steps.every(s => Number.isFinite(s.loss) && Number.isFinite(s.grad_norm));
const memoryWithinCap = stress.peak_torch_allocated_bytes < stress.gpu.total_bytes * 0.8 &&
  stress.peak_torch_reserved_bytes < stress.gpu.total_bytes * 0.8;
const result = { collator_examples_valid: collator.collator_valid, collator_examples: collator.examples,
  old_and_current_budget_coverage: collator.over_budget,
  dense_trials: dense.map(r => ({ tokens: r.sequence_tokens, status: r.status,
    peak_allocated_bytes: r.peak_torch_allocated_bytes, peak_reserved_bytes: r.peak_torch_reserved_bytes,
    gpu_total_bytes: r.gpu.total_bytes, free_after_steps: r.free_after_steps,
    fits_dedicated_vram_not_inferred_from_success: true })),
  paired_2048: { dense_loss: dense[2].steps[0].loss, completion_loss: paired.steps[0].loss,
    dense_grad_norm: dense[2].steps[0].grad_norm, completion_grad_norm: paired.steps[0].grad_norm,
    dense_peak_allocated_bytes: dense[2].peak_torch_allocated_bytes,
    completion_peak_allocated_bytes: paired.peak_torch_allocated_bytes,
    note: 'FP32 Qwen2 nhỏ đã đối chiếu mọi gradient; FP16 GPU không khẳng định bitwise tương đương.' },
  stress: { completed_steps: stress.steps.length, target_tokens: stress.supervised_tokens,
    peak_allocated_bytes: stress.peak_torch_allocated_bytes, peak_reserved_bytes: stress.peak_torch_reserved_bytes,
    free_after_steps: stress.free_after_steps, seconds_min: Math.min(...stress.steps.map(s => s.seconds)),
    seconds_max: Math.max(...stress.steps.map(s => s.seconds)), max_preclip_grad_norm: Math.max(...stress.steps.map(s => s.grad_norm)),
    process_memory: stress.process_memory, adapter_path: stress.adapter_path, save_reload_verified: stress.save_reload_verified },
  current_max_target_tokens: maxTarget, technical_complete: technicalComplete, memory_within_80_percent_cap: memoryWithinCap,
  candidate_sequence_tokens: technicalComplete && memoryWithinCap && collator.over_budget['2048'] === 0 ? 2048 : null,
  candidate_conditions: ['Chỉ backend completion_loss, NF4/LoRA và micro-batch 1 đã đo.',
    'Giới hạn bộ nhớ tiến trình 80%; FP16 loss scale ban đầu 1024; clipping norm 1.',
    'Theo dõi lại với dữ liệu train mới, target vượt 256 hoặc cấu hình/thiết bị thay đổi.',
    'Free GPU sau bước cuối chỉ khoảng 162 MiB, dư địa nhỏ; không gọi là cấu hình train dài ổn định.'],
  pilot_training_ready: false, security_quality_improvement_measured: false, runtime_changed: false,
  initial_failed_run: 'benchmark/experiments/verifier-gpu-2048-1-v1/ket-qua.json',
  input_sha256: inputs };
fs.mkdirSync(output, { recursive: true });
fs.writeFileSync(path.join(output, 'ket-qua.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ technical_complete: technicalComplete, memory_within_cap: memoryWithinCap,
  candidate_sequence_tokens: result.candidate_sequence_tokens, current_max_target_tokens: maxTarget,
  pilot_training_ready: false }));
