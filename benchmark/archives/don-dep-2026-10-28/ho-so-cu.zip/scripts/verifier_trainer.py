"""Trainer completion-only một thiết bị, khóa phiên bản đã kiểm tra scaling."""
import importlib.metadata
import torch
from transformers import Trainer
from verifier_supervised_loss import completion_loss


class VerifierTrainer(Trainer):
    def __init__(self, *args, **kwargs):
        expected = {'transformers': '4.57.1', 'accelerate': '1.10.1'}
        for package, version in expected.items():
            if importlib.metadata.version(package) != version:
                raise ValueError(f'Cần audit lại Trainer khi đổi {package} khỏi {version}.')
        super().__init__(*args, **kwargs)
        if self.args.world_size != 1 or self.args.n_gpu > 1 or self.is_deepspeed_enabled:
            raise ValueError('Chưa kiểm chứng loss cho distributed hoặc nhiều GPU.')
        if self.label_smoother is not None or self.compute_loss_func is not None:
            raise ValueError('Không ghép thêm label smoothing hoặc loss khác.')
        if self.accelerator.gradient_accumulation_steps != 1:
            raise ValueError('Trainer phải tự quản lý accumulation; không chia loss lần hai.')
        # Override compute_loss thực sự dùng tổng target của cả nhóm micro-batch.
        # Cờ này yêu cầu Trainer tính mẫu số và không chia thêm cho GA steps.
        self.model_accepts_loss_kwargs = True
        self.loss_observations = []

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        labels = inputs['labels']
        if torch.any(labels[:, 0] != -100):
            raise ValueError('Token đầu chưa mask; mẫu số Trainer sẽ sai causal shift.')
        count = (labels[:, 1:] != -100).sum()
        if count.item() <= 0:
            raise ValueError('Không có completion để học.')
        denominator = count if num_items_in_batch is None else torch.as_tensor(num_items_in_batch, device=labels.device)
        if denominator.item() < count.item() or denominator.item() <= 0:
            raise ValueError('Tổng target accumulation không hợp lệ.')
        loss = completion_loss(model, inputs) * count / denominator
        if not torch.isfinite(loss):
            raise FloatingPointError('Loss không hữu hạn.')
        self.loss_observations.append({'supervised_tokens': int(count), 'normalizer_tokens': int(denominator),
                                       'loss_contribution': float(loss.detach())})
        # Smoke dùng prediction_loss_only, không cấp dense vocabulary logits.
        return (loss, {'loss': loss}) if return_outputs else loss
