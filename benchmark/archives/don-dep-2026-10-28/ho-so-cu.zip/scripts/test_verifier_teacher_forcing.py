"""Kiểm tra ranh giới giá trị JSON và tổng hợp theo token của phép chẩn đoán."""
import unittest
from diagnose_verifier_teacher_forcing import categories, summarize


class CharacterTokenizer:
    def apply_chat_template(self, messages, **kwargs):
        return 'P' if len(messages) == 2 else 'P' + messages[-1]['content'] + 'E'

    def __call__(self, text, **kwargs):
        return {'input_ids': list(map(ord, text)), 'offset_mapping': [(i, i + 1) for i in range(len(text))]}


class TeacherForcingTests(unittest.TestCase):
    def test_values_separated_from_keys_and_reason(self):
        target = '{"stance":"confirmed","reason":"stance không phải giá trị nhãn","hasDirective":true}'
        ids = list(map(ord, 'P' + target + 'E'))
        kinds = categories(CharacterTokenizer(), [{}, {}], target, ids, 1, len(ids))
        self.assertEqual(kinds.count('stance'), len('"confirmed"'))
        self.assertEqual(kinds.count('hasDirective'), 4)
        self.assertEqual(kinds.count('reason'), len('"stance không phải giá trị nhãn"'))
        self.assertEqual(kinds[-1], 'structure_or_eos')
        with self.assertRaises(ValueError):
            categories(CharacterTokenizer(), [{}, {}], target, ids[:-1], 1, len(ids) - 1)

    def test_metrics_weighted_by_token_not_record(self):
        rows = [{'fields': {'all': {'tokens': 1, 'nll_sum': 2, 'correct': 0}}},
                {'fields': {'all': {'tokens': 3, 'nll_sum': 2, 'correct': 3}}}]
        result = summarize(rows)['all']
        self.assertEqual(result['mean_nll'], 1)
        self.assertEqual(result['gold_prefix_token_accuracy'], .75)


if __name__ == '__main__':
    unittest.main()
