const { test } = require('node:test');
const assert = require('node:assert/strict');
const { cases, requestFor, assess, summarize } = require('./minimal-context-order.cjs');
test('chỉ đổi thứ tự schema, giữ prompt và ý nghĩa trường, không đưa đáp án vào input', () => {
  const before = requestFor(cases[0].text, 'gemma3:1b', 'baseline');
  const after = requestFor(cases[0].text, 'gemma3:1b', 'context_first');
  assert.deepEqual(before.messages, after.messages);
  const a = before.response_format.json_schema.schema, b = after.response_format.json_schema.schema;
  for (const key of Object.keys(a.properties)) assert.deepEqual(a.properties[key], b.properties[key]);
  assert.equal(Object.keys(b.properties).at(-2), 'stance');
  assert.equal(Object.keys(b.properties).at(-1), 'reason');
  assert.equal(after.messages[1].content, cases[0].text);
  assert.equal(JSON.stringify(after.messages).includes(cases[0].id), false);
});
test('stance đúng không che sai ngữ cảnh; xác nhận ví dụ trích dẫn phải bị chặn', () => {
  const item = cases[1];
  const row = { addressee: 'assistant', framing: 'active', deviation: 'answer_manipulation', hasDirective: true,
    stance: 'dismissed', reason: 'Đây là ví dụ được trích dẫn trong bài học.' };
  const out = assess(JSON.stringify(row), item);
  assert.equal(out.field_correct.stance, true); assert.equal(out.context_exact, false);
  assert.equal(out.consistent, false);
  row.framing = 'quoted_example'; row.stance = 'confirmed';
  assert.equal(assess(JSON.stringify(row), item).consistent, false);
});
test('lỗi JSON là abstention, không biến thành true negative', () => {
  const item = cases[0];
  const result = summarize([{ id: item.id, gold: item.label, audit: assess('{', item) }]);
  assert.equal(result.abstain_malicious, 1); assert.equal(result.fn, 0);
  assert.equal(result.context_exact, 0); assert.equal(result.precision, null);
});
