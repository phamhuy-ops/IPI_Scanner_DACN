"""Kiểm nhánh chưa đăng nhập/chưa có quyền; không gọi Hub hoặc tải weights thật."""
import contextlib
import io
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
import download_specialized_detector as downloader


class DownloadAccessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='classifier-download-test-', dir=os.environ.get('TMP'))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.report = self.root / 'report'
        self.output = io.StringIO()

    def run_case(self, token, api, snapshot):
        with patch.dict(os.environ, {'IPI_TRAINING_ROOT': str(self.root)}), patch.object(downloader, 'REPORT', self.report), \
             patch.object(downloader, 'get_token', return_value=token), patch.object(downloader, 'HfApi', return_value=api), \
             patch.object(downloader, 'snapshot_download', snapshot), contextlib.redirect_stdout(self.output):
            return downloader.main()

    def test_missing_token_never_calls_hub_or_download(self):
        api, snapshot = Mock(), Mock()
        self.assertEqual(self.run_case(None, api, snapshot), 3)
        api.auth_check.assert_not_called()
        snapshot.assert_not_called()
        self.assertIn('needs_huggingface_login', self.output.getvalue())

    def test_denied_access_never_downloads_or_prints_token(self):
        api, snapshot = Mock(), Mock()
        api.auth_check.side_effect = PermissionError('Denied')
        self.assertEqual(self.run_case('FIXTURE_NOT_A_TOKEN', api, snapshot), 3)
        snapshot.assert_not_called()
        self.assertNotIn('FIXTURE_NOT_A_TOKEN', self.output.getvalue())
        self.assertIn('access_check_failed', self.output.getvalue())

    def test_existing_directory_not_overwritten(self):
        directory = self.root / 'weights' / 'prompt-guard-2-86m' / downloader.REVISION
        directory.mkdir(parents=True)
        (directory / 'partial-fixture').write_text('Preserve this fixture')
        api, snapshot = Mock(), Mock()
        self.assertEqual(self.run_case('FIXTURE_NOT_A_TOKEN', api, snapshot), 4)
        snapshot.assert_not_called()
        self.assertEqual((directory / 'partial-fixture').read_text(), 'Preserve this fixture')


if __name__ == '__main__':
    unittest.main()
