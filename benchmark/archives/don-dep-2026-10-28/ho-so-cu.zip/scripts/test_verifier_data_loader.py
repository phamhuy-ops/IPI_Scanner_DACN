"""Kiểm tra ranh giới vai trò trước khi token hóa để tránh học dev/probe."""
import unittest
from verifier_data_loader import validate_rows


class LoaderTests(unittest.TestCase):
    def row(self, role='train'):
        return {'id': 'a', 'planned_role': role, 'training_eligible': False,
                'payload': {'messages': [{'role': 'system'}, {'role': 'user'}]}}

    def test_reject_dev_and_probe_in_train(self):
        for role in ['dev', 'probe']:
            with self.assertRaises(ValueError):
                validate_rows([self.row(role)], 'train')

    def test_reject_duplicate_and_assistant_prompt(self):
        with self.assertRaises(ValueError):
            validate_rows([self.row(), self.row()], 'train')
        row = self.row()
        row['payload']['messages'].append({'role': 'assistant'})
        with self.assertRaises(ValueError):
            validate_rows([row], 'train')

    def test_accept_only_exact_role(self):
        self.assertEqual(len(validate_rows([self.row()], 'train')), 1)
        with self.assertRaises(ValueError):
            validate_rows([], '../dev')


if __name__ == '__main__':
    unittest.main()
