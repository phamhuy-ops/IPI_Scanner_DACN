const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildReview } = require('./review-verifier-external-uncertain.cjs');
const load = () => fs.readFileSync('benchmark/experiments/verifier-eligibility-v8/registry.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
test('Rà đúng 18 ca; serialization không tự thành quoted_example, base64 giữ unclear', () => {
  const registry = load(), before = JSON.stringify(registry);
  const { rows, reviews } = buildReview(registry);
  assert.equal(JSON.stringify(registry), before);
  assert.equal(rows.length, 18);
  assert.equal(rows.filter(r => r.annotation.framing === 'active').length, 17);
  const encoded = rows.find(r => r.id.endsWith(':llmail-phase2-044'));
  assert.equal(encoded.annotation.framing, 'unclear');
  assert.ok(encoded.text.includes('IEhpIGRlYXIs'));
  assert.ok(!encoded.text.includes('REPLY BACK'));
  for (const row of rows) {
    const old = registry.find(r => r.id === row.id);
    assert.equal(row.input_sha256, old.effective_input_sha256);
    assert.equal(row.annotation.stance, 'uncertain');
    assert.equal(row.annotation.addressee, 'unclear');
    assert.equal(row.annotation.deviation, 'unclear');
    assert.equal(row.group_id, old.group_id);
    assert.equal(row.training_eligible, false);
  }
  assert.ok(reviews.every(r => r.source_evidence && !r.independent_review && !r.human_approved));
});
test('Chặn nguồn hoặc nhãn không còn khớp phiên bản đã đọc', () => {
  const rows = load();
  rows.find(r => r.id === 'verifier-external-ai-v1:ext3-013').effective_input_sha256 = 'stale';
  assert.throws(() => buildReview(rows), /nguồn\/nhãn/);
  assert.throws(() => buildReview(load().filter(r => !r.id.endsWith(':llmail-phase2-044'))), /18/);
});
