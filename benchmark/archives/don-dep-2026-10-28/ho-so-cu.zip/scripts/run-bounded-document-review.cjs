const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');
const { summarize } = require('./round-one-metrics.cjs');
const root = path.resolve(__dirname, '..');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

async function main() {
  const mode = process.argv[2];
  if (!['--simulate', '--ollama'].includes(mode) || process.argv.length !== 3) throw new Error('Dùng --simulate hoặc --ollama.');
  const simulated = mode === '--simulate';
  const manifestFile = 'benchmark/data/selector-spread-screen-v1.json';
  const manifestBytes = fs.readFileSync(path.join(root, manifestFile));
  const manifest = JSON.parse(manifestBytes);
  // Chốt trước khi chạy: một nguồn dài mục tiêu và cặp attack/clean cũ.
  const ids = ['document-1', 'document-5', 'document-6'];
  const cases = ids.map(id => {
    const item = manifest.cases.find(row => row.id === id);
    if (!item || hash(Buffer.from(item.text)) !== item.input_sha256) throw new Error(`Đầu vào thay đổi: ${id}`);
    return item;
  });
  const sourceFiles = ['src/ai/experiments/boundedDocumentReview.ts', 'src/ai/agents/slmClient.ts',
    'src/ai/agents/document/detectorAgent.ts', 'src/ai/agents/document/verifierAgent.ts',
    'src/ai/agents/document/reviewPolicy.ts', 'src/ai/agents/document/prompts.ts',
    'src/ai/agents/document/evidence.ts', 'src/ai/agents/slmCatalog.ts',
    'engine/scanner/ipi-doc-scan.js', 'engine/document/chunking/semantic-chunker.js',
    'engine/document/extractors/document-text-extractor.js', 'engine/document/extractors/html-source.js',
    'engine/prefilter/document-prefilter.js', 'engine/prefilter/rules/ipi-document-rules.js',
    'engine/config/document-scan-config.js', 'src/types.ts', 'scripts/run-bounded-document-review.cjs', 'scripts/round-one-metrics.cjs'];
  const fingerprints = () => Object.fromEntries(sourceFiles.map(file => [file, hash(fs.readFileSync(path.join(root, file)))]));
  const codeHashes = fingerprints();
  const localGet = async endpoint => {
    const response = await fetch(`http://127.0.0.1:11434${endpoint}`, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error(`Ollama: ${response.status}`);
    return response.json();
  };
  const models = simulated ? null : await localGet('/api/tags');
  if (!simulated) for (const name of ['gemma3:1b', 'qwen2.5-coder:1.5b']) {
    if (!models.models.some(model => model.name === name)) throw new Error(`Thiếu model ${name}`);
  }
  const output = fs.mkdtempSync(path.join(root, 'benchmark/results/bounded-review-'));
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true }, appType: 'custom' });
  const records = [], calls = [];
  let currentCase, currentArm, maxRss = process.memoryUsage().rss;
  const memoryTimer = setInterval(() => { maxRss = Math.max(maxRss, process.memoryUsage().rss); }, 100);
  const save = (name, data) => fs.writeFileSync(path.join(output, name), JSON.stringify(data, null, 2) + '\n');
  const configuration = { profile: 'deep', contract: 'classic-v1', detector: 'gemma3:1b', verifier: 'qwen2.5-coder:1.5b',
    chunks_per_request: 1, rounds: 1, maxChatRequests: 64, analysisTimeoutMs: 180000, supplemental_arms: [0, 3] };
  save('plan.json', { simulated, cases: ids, manifest: manifestFile, manifest_sha256: hash(manifestBytes), code_sha256: codeHashes,
    configuration, models, seed: null, note: 'Lịch xác định, không xáo trộn; mô phỏng luôn trả JSON rỗng, không đo nhận diện.' });
  globalThis.owaspWorkbench = { aiFetch: async payload => {
    if (new URL(payload.url).origin !== 'http://127.0.0.1:11434') throw new Error('Chỉ dùng Ollama cục bộ.');
    const chat = payload.url.includes('/chat/completions');
    const call = { case_id: currentCase, arm: currentArm, request: chat ? JSON.parse(payload.body) : null };
    const started = performance.now();
    try {
      let response;
      if (simulated) response = { ok: true, status: 200, body: JSON.stringify({ choices: [{ message: { content: JSON.stringify({ analysis: 'Phản hồi rỗng giả lập, không đánh giá bảo mật.', assessments: [], discoveries: [] }) } }] }) };
      else {
        const http = await fetch(payload.url, { method: payload.method, headers: payload.headers, body: payload.body,
          signal: AbortSignal.timeout(payload.timeoutMs) });
        response = { ok: http.ok, status: http.status, body: await http.text() };
      }
      if (chat) {
        calls.push({ ...call, response: response.body, http_status: response.status, elapsed_ms: performance.now() - started,
          resources: simulated ? null : await localGet('/api/ps').catch(() => null) });
        save('model-calls.json', calls);
      }
      return response;
    } catch (error) {
      if (chat) { calls.push({ ...call, error: error.message, elapsed_ms: performance.now() - started }); save('model-calls.json', calls); }
      return { ok: false, status: 0, body: '', error: error.message };
    }
  } };
  try {
    const { runBoundedDocumentReview } = await server.ssrLoadModule('/src/ai/experiments/boundedDocumentReview.ts');
    for (const item of cases) {
      const file = path.join(output, item.id + item.format); fs.writeFileSync(file, item.text);
      const scan = await runIpiDocScan([file], { scanProfile: 'deep', includeSemanticChunkCatalog: true });
      for (const additional of [0, 3]) {
        if (JSON.stringify(fingerprints()) !== JSON.stringify(codeHashes)) throw new Error('Code thay đổi giữa phép đo.');
        currentCase = item.id; currentArm = additional;
        console.log(`${currentCase}, đọc thêm ${additional}, chọn ${scan.metadata.semanticChunks.length}/${scan.metadata.coverage.totalChunks}`);
        const result = await runBoundedDocumentReview({ scan, maxChatRequests: 64, maxSupplementalChunks: additional, analysisTimeoutMs: 180000 });
        const row = { id: item.id, source: item.source, group: item.group, label: item.expected_label, arm: additional,
          verdict: result.check.verdict, processing: result.stopReason, seconds: result.elapsedMs / 1000, result };
        records.push(row); save('cases.json', records);
        console.log(JSON.stringify({ id: item.id, arm: additional, stop: result.stopReason, counts: result.counts, requests: result.chatRequests, verdict: result.check.verdict }));
      }
    }
    if (JSON.stringify(fingerprints()) !== JSON.stringify(codeHashes)) throw new Error('Code thay đổi giữa phép đo.');
    const modelsAfter = simulated ? null : await localGet('/api/tags');
    const modelDigests = value => Object.fromEntries((value?.models || []).filter(row => ['gemma3:1b', 'qwen2.5-coder:1.5b'].includes(row.name)).map(row => [row.name, row.digest]));
    const metrics = rows => {
      const result = summarize(rows), tp = result.matrix.malicious.ipi_detected, fp = result.matrix.benign.ipi_detected;
      const positives = Object.values(result.matrix.malicious).reduce((a, b) => a + b, 0);
      return { ...result, confirmed_f1_with_abstention_as_unconfirmed: 2 * tp + fp + positives - tp ? 2 * tp / (tp + fp + positives) : null };
    };
    save('summary.json', { status: 'complete', simulated, configuration, code_sha256: codeHashes,
      models_unchanged: JSON.stringify(modelDigests(models)) === JSON.stringify(modelDigests(modelsAfter)),
      max_harness_rss_bytes: maxRss, metrics: simulated ? null : Object.fromEntries([0, 3].map(arm => {
        const rows = records.filter(row => row.arm === arm);
        return [arm, { overall: metrics(rows), by_source: Object.fromEntries([...new Set(rows.map(row => row.source))].map(source => [source, metrics(rows.filter(row => row.source === source))])),
          by_group: Object.fromEntries([...new Set(rows.map(row => row.group))].map(group => [group, metrics(rows.filter(row => row.group === group))])) }];
      })), limitations: ['Ba ca dev, không phải kiểm chứng độc lập hoặc bằng chứng tăng hiệu quả bảo mật.',
        'Mô phỏng không đo nhận diện; JSON rỗng chỉ kiểm tra điều phối khi không có suspicion.',
        'Headless core, chưa kiểm tra UI/IPC; chưa đo peak VRAM, RSS chỉ là harness.',
        'Mỗi đoạn một request; thiếu ngữ cảnh xuyên đoạn có thể làm sai stance.',
        'needs_review là từ chối kết luận, không được tính thành benign hoặc true positive.'] });
    console.log(`Đã lưu: ${path.relative(root, output)}`);
  } finally { clearInterval(memoryTimer); delete globalThis.owaspWorkbench; await server.close(); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
