const { test } = require('node:test'); const assert = require('node:assert/strict');
const { parseClassification, labelMetrics } = require('./probe-minimal-recognition.cjs');
test('không nhận trường thêm, nhãn lạ hoặc JSON lỗi', () => {
  assert.equal(parseClassification('{"classification":"benign"}'), 'benign');
  for (const raw of ['{"classification":"safe"}', '{"classification":"benign","quote":"x"}', '{broken']) assert.throws(() => parseClassification(raw));
});
test('giữ ca chưa chạy trong mẫu số và không gọi khớp nhãn là chất lượng pipeline', () => {
  const selected = [{ id: 'a', label: 'malicious' }, { id: 'b', label: 'uncertain' }];
  const result = labelMetrics(selected, [{ id: 'b', valid: true, predicted: 'uncertain' }]);
  assert.equal(result.label_agreement_all_selected, .5); assert.equal(result.binary_label_accuracy, 0);
  assert.equal(result.grounded_uncertain_correct, null); assert.equal(result.pipeline_accuracy, null);
});
