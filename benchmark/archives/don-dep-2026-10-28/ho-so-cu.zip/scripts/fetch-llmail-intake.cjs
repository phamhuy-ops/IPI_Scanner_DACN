// Tải snapshot nhỏ có giới hạn; chỉ đọc dữ liệu, không thực hiện lệnh trong email.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const revision = '1063bdf01ec8762b812d5e06ee768a06faa5a6f7';
const repo = 'microsoft/llmail-inject-challenge';
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

function stringEnd(text, start) {
  if (text[start] !== '"') throw new Error('Khóa JSON không phải chuỗi.');
  let escaped = false;
  for (let i = start + 1; i < text.length; i++) {
    if (escaped) escaped = false;
    else if (text[i] === '\\') escaped = true;
    else if (text[i] === '"') return i + 1;
  }
  return null;
}

function parsePrefix(text, limit) {
  let index = 0;
  const whitespace = () => { while (/\s/.test(text[index] || '') && index < text.length) index++; };
  whitespace();
  if (text[index++] !== '{') throw new Error('Nguồn phải là JSON object keyed by email.');
  const rows = [];
  while (rows.length < limit) {
    whitespace();
    if (index >= text.length || text[index] === '}') break;
    if (rows.length) { if (text[index++] !== ',') throw new Error('Thiếu dấu phân cách.'); whitespace(); }
    const keyStart = index, keyEnd = stringEnd(text, index);
    if (!keyEnd) break;
    const key = JSON.parse(text.slice(index, keyEnd)); index = keyEnd; whitespace();
    if (text[index++] !== ':') throw new Error('Thiếu dấu hai chấm.'); whitespace();
    if (index >= text.length) break;
    if (text[index] !== '{') throw new Error('Metadata nhãn phải là object, không tự suy schema.');
    const valueStart = index;
    let depth = 0, inString = false, escaped = false, end = null;
    for (; index < text.length; index++) {
      const char = text[index];
      if (inString) {
        if (escaped) escaped = false;
        else if (char === '\\') escaped = true;
        else if (char === '"') inString = false;
      } else if (char === '"') inString = true;
      else if (char === '{' || char === '[') depth++;
      else if (char === '}' || char === ']') { depth--; if (!depth) { end = ++index; break; } }
    }
    if (!end) break;
    rows.push({ source_entry_index_1_based: rows.length + 1, text: key,
      source_annotation: JSON.parse(text.slice(valueStart, end)), prefix_key_start_utf16: keyStart, prefix_entry_end_utf16: end });
  }
  return rows;
}

async function get(url, maxBytes, headers = {}) {
  const response = await fetch(url, { headers, signal: AbortSignal.timeout(45000) });
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
  if (Number(response.headers.get('content-length')) > maxBytes) throw new Error('Vượt ngân sách tải; không tự tải file lớn.');
  const reader = response.body.getReader(); const chunks = []; let size = 0;
  while (true) {
    const { done, value } = await reader.read(); if (done) break;
    size += value.length;
    if (size > maxBytes) { await reader.cancel(); throw new Error('Nội dung vượt giới hạn.'); }
    chunks.push(Buffer.from(value));
  }
  return { bytes: Buffer.concat(chunks), status: response.status, final_url: response.url,
    content_range: response.headers.get('content-range') };
}

async function main() {
  const out = path.join(root, 'benchmark/data/raw/llmail-intake-v1');
  if (fs.existsSync(out)) throw new Error('Snapshot đã có; không ghi đè.');
  const metadata = await get(`https://huggingface.co/api/datasets/${repo}?blobs=true`, 1024*1024);
  const info = JSON.parse(metadata.bytes);
  if (info.sha !== revision || info.cardData?.license !== 'mit') throw new Error('Revision/license khác bản đã chọn, cần rà lại.');
  const files = ['README.md', 'data/emails_for_fp_tests.json', 'data/scenarios.json',
    'data/levels_descriptions.json', 'data/objectives_descriptions.json'];
  const assets = new Map([['dataset-metadata.json', metadata.bytes]]), inventory = {};
  for (const file of files) {
    const url = `https://huggingface.co/datasets/${repo}/resolve/${revision}/${file}`;
    const result = await get(url, 1024*1024);
    const upstream = info.siblings.find(s => s.rfilename === file);
    if (!upstream || upstream.size !== result.bytes.length) throw new Error('Sai kích thước file nhỏ.');
    assets.set(file, result.bytes); inventory[file] = { url, bytes: result.bytes.length, sha256: hash(result.bytes) };
  }
  const largeFile = 'data/labelled_unique_submissions_phase2.json';
  const url = `https://huggingface.co/datasets/${repo}/resolve/${revision}/${largeFile}`;
  const prefix = await get(url, 512*1024, { Range: 'bytes=0-524287' });
  if (prefix.status !== 206 || !prefix.content_range?.startsWith('bytes 0-524287/')) throw new Error('Server không đáp ứng range đã yêu cầu; không tải cả file.');
  const rows = parsePrefix(prefix.bytes.toString('utf8'), 48);
  if (rows.length !== 48 || rows.some(r => !['string', 'boolean'].includes(typeof r.source_annotation.attack_attempt))) throw new Error('Không đủ 48 entry hoàn chỉnh hoặc schema đã đổi.');
  assets.set('data/phase2-prefix.bin', prefix.bytes);
  const subset = rows.map(r => JSON.stringify(r)).join('\n') + '\n'; assets.set('data/phase2-subset.jsonl', Buffer.from(subset));
  inventory['data/phase2-prefix.bin'] = { upstream_file: largeFile, url, bytes: prefix.bytes.length, sha256: hash(prefix.bytes),
    content_range: prefix.content_range, full_file_sha256_verified: false, upstream_metadata: info.siblings.find(s => s.rfilename === largeFile) };
  const emails = JSON.parse(assets.get('data/emails_for_fp_tests.json'));
  if (!Array.isArray(emails) || emails.some(text => typeof text !== 'string')) throw new Error('Schema email đối chứng khác dự kiến.');
  const snapshot = { repository: `https://huggingface.co/datasets/${repo}`, revision, retrieved_at: new Date().toISOString(),
    license_declared_in_dataset_card: 'MIT', license_evidence: 'README.md và dataset-metadata.json; không suy từ license repo code.',
    assets: inventory, derived_subset: { file: 'data/phase2-subset.jsonl', sha256: hash(subset), records: rows.length,
      selection: '48 entry hoàn chỉnh đầu tiên trong prefix cố định, không chọn theo thành công hoặc nhãn.',
      scope: 'Partial snapshot; không có hash xác minh toàn file 68 MB.' },
    fp_email_bank_records: emails.length, bytes_saved: [...assets.values()].reduce((n, b) => n + b.length, 0),
    source_annotations_not_verifier_labels: true,
    source_label_types: rows.reduce((out, r) => { const type = typeof r.source_annotation.attack_attempt; out[type] = (out[type] || 0) + 1; return out; }, {}),
    privacy_review: 'pending', training_eligible: false,
    independent_holdout_verified: false, model_called: false, source_code_executed: false,
    code_sha256: hash(fs.readFileSync(__filename)),
    limitations: ['Mới kiểm tra cấu trúc; chưa rà nhãn ngữ cảnh, riêng tư, grouping hoặc overlap.',
      'Mẫu theo thứ tự đầu file có thể lệch về family/team; không đại diện toàn challenge.',
      'Không coi attack_attempt=False hoặc ngân hàng FP là nhãn dismissed tự động.'] };
  fs.mkdirSync(out, { recursive: true });
  for (const [file, bytes] of assets) { const target = path.join(out, file); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, bytes, { flag: 'wx' }); }
  fs.writeFileSync(path.join(out, 'snapshot.json'), JSON.stringify(snapshot, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ revision, subset: rows.length, fp_emails: emails.length, bytes_saved: snapshot.bytes_saved }));
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { parsePrefix };
