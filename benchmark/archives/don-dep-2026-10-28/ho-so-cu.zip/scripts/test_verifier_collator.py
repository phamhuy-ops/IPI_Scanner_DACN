"""Đối chứng lỗi mất EOS khi pad trùng EOS và lỗi cắt ngầm/mask sai."""
import unittest
from verifier_collator import CompletionCollator


class CollatorTests(unittest.TestCase):
    def test_padding_equal_eos_preserves_real_eos(self):
        batch = CompletionCollator(2, 8)([
            {'input_ids': [1, 5, 2], 'labels': [-100, 5, 2]},
            {'input_ids': [1, 6, 7, 2], 'labels': [-100, 6, 7, 2]}])
        self.assertEqual(batch['labels'][0].tolist(), [-100, 5, 2, -100, -100, -100, -100, -100])
        self.assertEqual(batch['attention_mask'][0].tolist(), [1, 1, 1, 0, 0, 0, 0, 0])

    def test_budget_includes_padding_no_truncation(self):
        with self.assertRaises(ValueError):
            CompletionCollator(0, 7)([{'input_ids': [1, 2], 'labels': [-100, 2]}])

    def test_reject_missing_or_changed_target(self):
        for row in [{'input_ids': [1, 2], 'labels': [-100, -100]},
                    {'input_ids': [1, 2], 'labels': [-100, 3]},
                    {'input_ids': [1, 2], 'labels': [-100]}]:
            with self.assertRaises(ValueError):
                CompletionCollator(0, 8)([row])


if __name__ == '__main__':
    unittest.main()
