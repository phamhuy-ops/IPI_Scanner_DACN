const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-vietnamese-business.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Giữ đối chứng/câu trích/thiếu quyền cùng nhóm; không suy uncertain từ biến thể attack', () => {
  const rows = buildRows();
  assert.equal(rows.length, 20);
  assert.equal(new Set(rows.map(r => r.source_parent_id)).size, 4);
  for (let i = 0; i < rows.length; i += 5) {
    const members = rows.slice(i, i + 5);
    assert.equal(new Set(members.map(r => r.group_id)).size, 1);
    assert.deepEqual(members.map(r => r.annotation.stance), ['dismissed', 'confirmed', 'confirmed', 'dismissed', 'uncertain']);
    assert.equal(members[0].annotation.hasDirective, false);
    assert.equal(members[3].annotation.framing, 'quoted_example');
    assert.equal(members[4].annotation.framing, 'active');
    assert.equal(members[4].annotation.addressee, 'unclear');
    assert.equal(members[4].annotation.deviation, 'unclear');
    assert.ok(members[4].annotation.uncertainty_notes.length);
    const quote = members[1].annotation.directive_spans[0].quote;
    assert.ok(members[3].text.includes(quote));
  }
  for (const row of rows) {
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.language, 'vi');
    assert.equal(row.training_eligible, false);
    assert.equal(row.human_approved, false);
    assert.equal(row.provenance.external_content_reused, false);
    assert.equal(row.provenance.real_personal_data_used, false);
  }
});
