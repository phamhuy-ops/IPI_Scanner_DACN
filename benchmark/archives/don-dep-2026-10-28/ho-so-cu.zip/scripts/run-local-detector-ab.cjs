// Phương án đã bị loại; không tự chạy lại ứng viên tăng báo sạch sai.
console.error('Instruct ở Detector đã bị loại: TP=0, báo chưa phát hiện sai 7/8 mẫu tấn công. Xem benchmark/results/local-detector-comparison-z9A9Qd. Không gọi model hoặc đổi mặc định.');
process.exitCode = 1;
