// Lưu ranh giới nhóm và phiếu đối chiếu cơ học; không chia train/dev.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const corpusDir = path.join(root, 'benchmark/experiments/verifier-corpus-overlap-v3');
const dataDir = path.join(root, 'benchmark/data/annotations/verifier-gap-normalized-v1');
const read = p => JSON.parse(fs.readFileSync(p));
const auditFile = path.join(corpusDir, 'ket-qua.json');
const audit = read(auditFile);
if (fs.existsSync(path.join(corpusDir, 'ranh-gioi-nhom.json'))) throw new Error('Không ghi đè ranh giới nhóm.');
const groups = audit.groups.map(group => ({ ...group,
  global_group_id: `cg-${hash([...group.members].sort().join('\n')).slice(0, 16)}` }));
const rows = fs.readFileSync(path.join(dataDir, 'nhan-va-cua-so.jsonl'), 'utf8').trim().split(/\r?\n/).map(JSON.parse);
const old = read(path.join(root, 'benchmark/data/priority-one-dev-v2.json')).cases;
const normalize = text => text.normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim();
const exactExisting = rows.flatMap(r => old.filter(o => normalize(o.text) === normalize(r.text)).map(o => ({ source: r.id, previous: o.original_id })));
const newGroups = groups.filter(g => g.members.some(id => id.startsWith('verifier-gap-v1:')));
const boundaries = { version: 3, audit_sha256: hash(fs.readFileSync(auditFile)),
  final_split_created: false, groups,
  note: 'ID nhóm mới chỉ phục vụ chuẩn bị dữ liệu; không sửa manifest baseline 72 hoặc nhóm lịch sử.' };
fs.writeFileSync(path.join(corpusDir, 'ranh-gioi-nhom.json'), JSON.stringify(boundaries, null, 2) + '\n');
const mapped = rows.map(r => {
  const id = `verifier-gap-v1:${r.id}`;
  const group = groups.find(g => g.members.includes(id));
  if (!group) throw new Error(`Thiếu nhóm ${id}`);
  return { source_record_id: r.id, original_family: r.group_id, global_group_id: group.global_group_id,
    windows: r.windows.map(w => ({ id: w.id, global_group_id: group.global_group_id, final_split: null })),
    selected_window_id: r.selected_window_id, final_split: null, training_eligible: false };
});
const summary = { original_sources: rows.length, original_sources_preserved: true,
  all_windows: rows.reduce((n, r) => n + r.windows.length, 0), selected_annotation_windows: rows.length,
  unlabeled_windows: rows.reduce((n, r) => n + r.windows.length, 0) - rows.length,
  exact_duplicates_against_reviewed_72: exactExisting,
  proposed_families: new Set(rows.map(r => r.group_id)).size, conservative_new_groups: newGroups.length,
  candidate_sources_with_new: audit.candidate_records,
  candidate_groups_with_new: groups.filter(g => g.constraint !== 'reference_only').length,
  new_group_sizes: newGroups.map(g => g.size),
  existing_bipia_test_lexical_overlap_groups: groups.filter(g => g.flags.includes('overlap_existing_bipia_test')).length,
  independent_holdout_verified: false, semantic_near_duplicate_check_complete: false,
  inputs_unchanged: audit.inputs_unchanged, missing_corpus_coverage: audit.missing_coverage,
  human_window_span_review_complete: false, final_split_created: false, training_ready: false,
  source_window_groups: mapped,
  limitations: ['Cụm tiếng Việt 9 mẫu dùng chung nền lặp nên bị nối bởi shared-12-token; giữ chung, không chia để đẹp tỷ lệ.',
    'Không có match từ vựng với BIPIA test không chứng minh độc lập ngữ nghĩa/provenance.',
    '87 nguồn là kho đã duyệt stance, không phải 87 nguồn sẵn sàng train hoặc holdout.'] };
fs.writeFileSync(path.join(dataDir, 'tong-ket-nhom.json'), JSON.stringify(summary, null, 2) + '\n');
let worksheet = '# Đối chiếu cửa sổ và đoạn bằng chứng\n\nNhãn đã được người dùng duyệt; phần dưới là ánh xạ cơ học mới, chưa được xác nhận ngữ nghĩa riêng. Offset UTF-16 [start,end), dòng bắt đầu từ 1. Cửa sổ được chọn theo nhãn để chuẩn bị dữ liệu, không phải kết quả selector runtime.\n';
for (const row of rows) {
  const selected = row.selected_window;
  worksheet += `\n## ${row.id} — ${row.window_annotation.stance}\n\nNguồn gốc: ../verifier-gap-v1/van-ban/${row.id}${row.format}. Cửa sổ: ${row.selected_window_id}; offset [${selected.start},${selected.end}). Nhóm bảo thủ: ${mapped.find(m => m.source_record_id === row.id).global_group_id}.\n\nĐoạn chỉ dẫn gốc:\n\n> ${row.annotation_original.directive_spans[0].quote}\n\nToàn bộ cửa sổ được đưa vào bản xem trước:\n\n${selected.text.split(/\r\n?|\n/).map(line => '> ' + line).join('\n')}\n\nRanh giới span/cửa sổ: chờ duyệt riêng; không đổi nhãn tự động.\n`;
}
fs.writeFileSync(path.join(dataDir, 'doi-chieu-cua-so.md'), worksheet);
console.log(JSON.stringify({ sources: summary.original_sources, all_windows: summary.all_windows,
  unlabeled_windows: summary.unlabeled_windows, conservative_new_groups: summary.conservative_new_groups,
  candidate_sources: summary.candidate_sources_with_new, candidate_groups: summary.candidate_groups_with_new,
  exact_duplicates_against_72: exactExisting.length }));
