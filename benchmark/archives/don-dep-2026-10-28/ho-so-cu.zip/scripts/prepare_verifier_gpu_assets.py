"""Tải weights công khai đúng revision vào E cho phép đo kỹ thuật cục bộ."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import shutil
import sys
from huggingface_hub import snapshot_download
from audit_verifier_tokenizer import MODEL, REVISION

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--download', action='store_true')
args = parser.parse_args()
cache = Path(os.environ['HF_HUB_CACHE']).resolve()
if cache.drive.lower() != 'e:' or shutil.disk_usage(cache).free < 12 * 1024**3:
    raise ValueError('Cần cache E và tối thiểu 12 GiB trống trước tải.')
local = Path(snapshot_download(MODEL, revision=REVISION, cache_dir=str(cache), local_files_only=not args.download,
    max_workers=1, allow_patterns=[
    'config.json', 'model.safetensors', 'tokenizer.json',
    'tokenizer_config.json', 'vocab.json', 'merges.txt']))
assets = {}
for p in local.iterdir():
    if p.is_file():
        digest = hashlib.sha256()
        with p.open('rb') as handle:
            for block in iter(lambda: handle.read(8 * 1024**2), b''):
                digest.update(block)
        assets[p.name] = {'size': p.stat().st_size, 'sha256': digest.hexdigest()}
output = root / 'benchmark/experiments/verifier-gpu-assets-v1'
output.mkdir(parents=True, exist_ok=True)
(output / 'ket-qua.json').write_text(json.dumps({'model': MODEL, 'revision': REVISION,
    'snapshot': str(local), 'assets': assets, 'training_started': False,
    'purpose': 'Chỉ kiểm tra backend/bộ nhớ; không đưa dữ liệu lên mạng.'}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8')
print(json.dumps({'snapshot': str(local), 'bytes': sum(a['size'] for a in assets.values())}))
