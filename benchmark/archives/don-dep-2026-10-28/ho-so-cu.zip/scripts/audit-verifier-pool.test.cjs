const { test } = require('node:test');
const assert = require('node:assert/strict');
const { audit, sourceStatus } = require('./audit-verifier-pool.cjs');
test('Loại dev khỏi pool, không cộng đôi ngôn ngữ hỗn hợp', () => {
  const result = audit([
    { role: 'development_regression_only', stance: 'confirmed', language: 'vi' },
    { id: 'a', role: 'candidate_pending_source_privacy_and_split_review', stance: 'uncertain', language: 'en-vi', source: 's', group_id: 'g' },
  ]);
  assert.equal(result.records, 1);
  assert.equal(result.excluded_records, 1);
  assert.equal(result.stances.confirmed, undefined);
  assert.equal(result.planning_scenario.vietnamese_gap, 96);
});
test('Khai báo nguồn không tự cấp quyền train; mẫu tự soạn được chuẩn bị nội bộ', () => {
  const candidate = kind => ({ id: kind, role: 'candidate_pending_source_privacy_and_split_review', source: kind, source_evidence: { kind } });
  const own = candidate('project_authored_release_not_declared');
  const card = candidate('pinned_dataset_card_declaration');
  assert.equal(sourceStatus(card), 'dataset_card_declaration_present');
  const result = audit([own, card]);
  assert.equal(result.source_use_ledger[0].local_preparation_external_license_blocker, false);
  assert.equal(result.source_use_ledger[1].local_preparation_external_license_blocker, null);
  assert.ok(result.source_use_ledger.every(row => row.training_eligible === false && row.split === null));
  assert.equal(result.training_ready, false);
});
