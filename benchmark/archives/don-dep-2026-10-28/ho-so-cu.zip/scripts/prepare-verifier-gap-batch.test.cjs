const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildCases } = require('./prepare-verifier-gap-batch.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('nguồn dài giữ nguyên span, mỗi nhóm đủ ba ngữ cảnh và chưa được duyệt', () => {
  const rows = buildCases();
  assert.equal(rows.length, 15);
  assert.equal(new Set(rows.map(r => r.input_sha256)).size, 15);
  assert.equal(rows.filter(r => r.text.length >= 8000).length, 9);
  for (const group of new Set(rows.map(r => r.group_id))) {
    assert.deepEqual(rows.filter(r => r.group_id === group).map(r => r.draft_annotation.label), ['malicious', 'benign', 'uncertain']);
  }
  for (const row of rows) {
    assert.deepEqual(validateAnnotation(row.text, row.draft_annotation), []);
    assert.equal(row.training_eligible, false);
    assert.equal(row.human_review_status, 'pending');
    assert.equal(row.provenance.independent, false);
  }
});
