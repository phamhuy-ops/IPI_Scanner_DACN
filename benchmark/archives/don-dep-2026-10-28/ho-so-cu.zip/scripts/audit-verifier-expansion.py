"""Kiểm tra snapshot hàng chờ và ranh giới nhóm; không sửa nhãn hoặc xuất train."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'benchmark/data/annotations/verifier-expansion-v1'


def main():
    read = lambda name: json.loads((BASE / name).read_text(encoding='utf-8'))
    report = read('bao-cao-chuan-bi.json')
    rows = [json.loads(line) for line in (BASE / 'hang-cho-gan-nhan.jsonl').read_text(encoding='utf-8').splitlines()]
    groups = read('nhom-va-chia-du-kien.json')['groups']
    sheet = read('luot-duyet-02.json')
    mapping = read('anh-xa-luot-duyet-02.json')
    proposal_file = BASE / 'de-xuat-luot-duyet-02.json'
    proposals = {p['id']: p for p in read('de-xuat-luot-duyet-02.json')['items']} if proposal_file.exists() else {}
    errors = []
    for file, expected in report['inputs_sha256'].items():
        if hashlib.sha256((ROOT / file).read_bytes()).hexdigest() != expected:
            errors.append(f'Nguồn thay đổi: {file}')
    by_id = {row['id']: row for row in rows}
    if len(rows) != 356 or len(by_id) != len(rows):
        errors.append('Sai số hàng hoặc ID trùng.')
    member_groups = {}
    for group in groups:
        for member in group['members']:
            if member in member_groups:
                errors.append('Một mẫu xuất hiện trong nhiều nhóm.')
            member_groups[member] = group
    for row in rows:
        group = member_groups.get(row['id'])
        if not group or row['group_id'] != group['id'] or row['proposed_role'] != group['proposed_role']:
            errors.append(f'Chia sai nhóm: {row["id"]}')
        if group and group['contains_legacy'] and row['proposed_role'] != 'reference_only':
            errors.append('Nhóm tham chiếu lọt sang tập mới.')
        if row['annotation'] is not None or row['split'] is not None or row['review_status'] != 'pending':
            errors.append('Tự gán nhãn hoặc chốt split khi chưa duyệt.')
    ids = [row['id'] for row in sheet['items']]
    if len(ids) != 30 or len(set(ids)) != 30 or set(ids) != {row['id'] for row in mapping}:
        errors.append('Lượt duyệt thiếu/trùng ID hoặc ánh xạ.')
    for item in sheet['items']:
        row = by_id.get(item['id'])
        if not row or row['proposed_role'] == 'reference_only':
            errors.append('Lượt duyệt chứa mẫu không hợp lệ hoặc tham chiếu trùng.')
            continue
        if item['input_sha256'] != hashlib.sha256(row['text'].encode()).hexdigest():
            errors.append('Phiếu sai hash.')
        if item['review_status'] == 'pending':
            if item['annotation'] is not None or item['reviewer'] is not None:
                errors.append('Phiếu pending không được có xác nhận hoặc đáp án giả.')
            continue
        proposal = proposals.get(item['id'])
        if item['review_status'] != 'human_reviewed' or not item.get('reviewer') or not item.get('reviewed_at') or not item.get('notes') or not proposal:
            errors.append('Thiếu thông tin duyệt hoặc đề xuất.')
            continue
        proposal_hash = hashlib.sha256(json.dumps(proposal, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
        if proposal_hash != item.get('proposal_sha256') or proposal['input_sha256'] != item['input_sha256'] or proposal['decision'] != item.get('decision'):
            errors.append('Quyết định không khớp phiên bản đề xuất đã duyệt.')
        if item.get('training_eligible') is not False:
            errors.append('Chưa được tự đánh dấu sẵn sàng train.')
        annotation = item['annotation']
        if item['decision'] == 'exclude_from_ipi_training':
            if annotation is not None or item.get('retained_role') != 'direct_attack_control_only':
                errors.append('Mẫu direct bị đưa vào nhãn IPI.')
            continue
        if item['decision'] not in ['accept_annotation', 'quarantine_mixed_scope'] or not isinstance(annotation, dict):
            errors.append('Sai quyết định hoặc thiếu annotation.')
            continue
        for key in ['stance', 'addressee', 'framing', 'deviation', 'hasDirective', 'reason', 'language']:
            if annotation.get(key) != proposal.get(key):
                errors.append(f'Nhãn cuối khác đề xuất đã duyệt: {key}')
        if proposal.get('target_quote'):
            if annotation.get('target_quote') != proposal['target_quote'] or proposal['target_quote'] not in row['text']:
                errors.append('Bằng chứng chỉ dẫn không nguyên văn.')
        active = (annotation.get('addressee') == 'assistant' and annotation.get('framing') == 'active'
                  and annotation.get('deviation') not in ['none', 'unclear'] and annotation.get('hasDirective') is True)
        stance = annotation.get('stance')
        if (stance == 'confirmed' and not active) or (stance == 'dismissed' and active):
            errors.append('Stance mâu thuẫn ngữ cảnh.')
        if annotation.get('label') != {'confirmed': 'malicious', 'dismissed': 'benign', 'uncertain': 'uncertain'}.get(stance):
            errors.append('Nhãn và stance không khớp.')
        if item['decision'] == 'quarantine_mixed_scope' and item.get('retained_role') != 'mixed_scope_control_only':
            errors.append('Mẫu mixed chưa được cách ly.')
    for item in mapping:
        if (BASE / item['file']).read_text(encoding='utf-8') != by_id[item['id']]['text']:
            errors.append('Văn bản đầu vào không nguyên vẹn.')
    if report['training_ready'] or report['final_split_created'] or report['independent_holdout']['status'] != 'not_collected':
        errors.append('Trạng thái sẵn sàng/độc lập không có căn cứ.')
    result = {'errors': errors, 'valid_staging_snapshot': not errors,
              'counts': dict(Counter(row['proposed_role'] for row in rows)),
              'review_batch_sources': dict(Counter(by_id[item['id']]['source'] for item in sheet['items'])),
              'group_role_conflicts': len([e for e in errors if 'nhóm' in e]),
              'reviewed': sum(r['review_status'] == 'human_reviewed' for r in sheet['items']),
              'pending': sum(r['review_status'] == 'pending' for r in sheet['items']),
              'decisions': dict(Counter(r.get('decision', 'pending') for r in sheet['items'])),
              'accepted_context_labels': dict(Counter(r['annotation']['stance'] for r in sheet['items'] if r.get('decision') == 'accept_annotation')),
              'human_review_complete': not errors and all(r['review_status'] == 'human_reviewed' for r in sheet['items']),
              'training_ready': False, 'independent_holdout_collected': False}
    (BASE / 'kiem-tra-hang-cho.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
