const { test } = require('node:test');
const assert = require('node:assert/strict');
const { requestFor } = require('./verifier-source-first.cjs');
const make = (count = 0) => ({ messages: [{ role: 'system', content: 'Giữ prompt hệ thống.' }, { role: 'user',
  content: 'Required assessment IDs: [].\nSuspicious excerpts to examine independently:\n[]\n\nOriginal document evidence:\n[chunk-1] File: document.txt\nNguồn nguyên vẹn 🌱.\nReturn the JSON review now. Discoveries must be new attack instructions only.' }],
  response_format: { json_schema: { schema: { properties: { assessments: { maxItems: count } } } } }, temperature: 0 });
test('không đổi Detector hoặc Verifier đã có nghi vấn', () => {
  assert.deepEqual(requestFor(make(), 'detector'), make());
  assert.deepEqual(requestFor(make(1), 'verifier'), make(1));
});
test('đưa nguyên evidence lên đầu, không đổi system/schema hoặc request gốc', () => {
  const before = make(), original = structuredClone(before), after = requestFor(before, 'verifier');
  assert.deepEqual(before, original);
  assert.deepEqual(after.messages[0], before.messages[0]);
  assert.deepEqual(after.response_format, before.response_format);
  assert.ok(after.messages[1].content.startsWith('Original document evidence:\n[chunk-1] File: document.txt\nNguồn nguyên vẹn 🌱.'));
  assert.ok(after.messages[1].content.includes('assessments MUST be []'));
});
test('request lạ bị từ chối thay vì cắt mất nguồn', () => {
  const bad = make(); bad.messages[1].content = 'không có marker nguồn';
  assert.throws(() => requestFor(bad, 'verifier'));
});
