// Phép đo chẩn đoán từng model, chỉ gọi Ollama trên máy, không phải pipeline.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { createHash } = require('node:crypto');
const { cases, fields, requestFor, assess, summarize } = require('./minimal-context-order.cjs');
const root = path.resolve(__dirname, '..');
const models = ['gemma3:1b', 'qwen2.5-coder:1.5b'];
const hash = value => createHash('sha256').update(value).digest('hex');
async function main() {
  const get = async endpoint => {
    const r = await fetch(`http://127.0.0.1:11434${endpoint}`, { signal: AbortSignal.timeout(5000) });
    if (!r.ok) throw new Error(`Ollama HTTP ${r.status}`);
    return r.json();
  };
  const tags = await get('/api/tags');
  for (const model of models) if (!tags.models.some(row => row.name === model)) throw new Error(`Thiếu model ${model}`);
  const files = ['scripts/minimal-context-order.cjs', 'scripts/run-minimal-context-order.cjs', 'scripts/model-context-diagnostics.cjs'];
  const fingerprints = () => Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(path.join(root, file)))]));
  const frozen = fingerprints();
  const dir = fs.mkdtempSync(path.join(root, 'benchmark/results/minimal-context-order-'));
  const calls = []; let maxRss = process.memoryUsage().rss;
  const timer = setInterval(() => { maxRss = Math.max(maxRss, process.memoryUsage().rss); }, 100);
  const plan = { models, profiles: ['baseline', 'context_first'], cases, fields,
    code_sha256: frozen, model_versions: tags, ollama: await get('/api/version'),
    node: process.version, temperature: 0, seed: null, request_timeout_ms: 45000, max_tokens: 500,
    host_ram_bytes: os.totalmem(), independent: false, synthetic: true,
    grouping: 'Bản dịch và ví dụ trích dẫn cùng nhóm, không chia tập trong phép đo này.',
    gate: 'Mỗi model: đủ 6 ca/biến thể; ứng viên đúng cả 5 trường ở mọi ca, nhất quán mọi ca, TP=2 FP=0 FN=0 abstention=0. Không kém baseline, ít nhất một model cải thiện. Chỉ đủ điều kiện nghiên cứu tiếp, không tự bật pipeline.',
    scope: 'Đầu ra context đơn giản, chưa dùng assessments/discoveries hoặc spanId sản phẩm; không đo trích xuất, chunking, pipeline hoặc UI.' };
  fs.writeFileSync(path.join(dir, 'ke-hoach.json'), JSON.stringify(plan, null, 2));
  let complete = false;
  const save = () => {
    const by_model = Object.fromEntries(models.map(model => [model, Object.fromEntries(plan.profiles.map(profile => [profile,
      summarize(calls.filter(row => row.model === model && row.profile === profile))]))]));
    const per_model = Object.fromEntries(models.map(model => {
      const b = by_model[model].baseline, c = by_model[model].context_first;
      return [model, c.total === 6 && b.total === 6 && c.context_exact === 6 && c.consistent === 6 && c.tp === 2 &&
        c.fp === 0 && c.fn === 0 && c.abstain_benign + c.abstain_malicious === 0 && c.context_exact >= b.context_exact];
    }));
    const eligible = complete && Object.values(per_model).every(Boolean) && models.some(model =>
      by_model[model].context_first.context_exact > by_model[model].baseline.context_exact);
    const result = { status: complete ? 'complete' : 'incomplete', by_model, gate_passed: per_model,
      eligible_for_further_study: eligible, runtime_changed: false, pipeline_evaluated: false,
      max_harness_rss_bytes: maxRss,
      limitations: ['6 mẫu tự soạn/2 nhóm, không độc lập và chưa duyệt nhãn cùng người dùng.',
        'Mỗi cấu hình một lượt, không suy ý nghĩa thống kê.', 'Ràng buộc nhất quán không chứng minh hiểu đúng nội dung.',
        'RAM harness là tiến trình Node, không phải RAM model; API ps là snapshot VRAM, không phải peak.',
        'Prompt tiếng Anh giữ nguyên để đo duy nhất thứ tự trường schema; nguồn thử có cả tiếng Việt và tiếng Anh.'] };
    fs.writeFileSync(path.join(dir, 'model-calls.json'), JSON.stringify(calls, null, 2));
    fs.writeFileSync(path.join(dir, 'ket-qua.json'), JSON.stringify(result, null, 2));
  };
  console.log(`Kết quả: ${dir}`);
  try {
    for (const model of models) {
      for (const [index, item] of cases.entries()) {
        for (const profile of index % 2 ? ['context_first', 'baseline'] : ['baseline', 'context_first']) {
          const request = requestFor(item.text, model, profile);
          const start = Date.now();
          const row = { id: item.id, source: 'synthetic-minimal-context', group: item.group, language: item.language,
            gold: item.label, expected: item.expected, model, profile, input_sha256: hash(item.text), request };
          try {
            const response = await fetch('http://127.0.0.1:11434/v1/chat/completions', { method: 'POST',
              headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(request), signal: AbortSignal.timeout(45000) });
            row.http_status = response.status; row.raw = await response.text();
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const body = JSON.parse(row.raw); row.usage = body.usage; row.finish_reason = body.choices?.[0]?.finish_reason;
            row.content = body.choices?.[0]?.message?.content || '';
            row.audit = assess(row.content, item);
          } catch (error) { row.error = error.message; row.audit = { json_valid: false, shape_valid: false, consistent: false, context_exact: false }; }
          row.seconds = (Date.now() - start) / 1000;
          try { row.resource_snapshot = await get('/api/ps'); } catch { row.resource_snapshot = null; }
          calls.push(row); save();
          console.log(`${calls.length}/24 ${model} ${item.id} ${profile}: stance=${row.audit.fields?.stance || 'lỗi'}; đúng ngữ cảnh=${row.audit.context_exact}`);
        }
      }
      await fetch('http://127.0.0.1:11434/api/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, keep_alive: 0 }), signal: AbortSignal.timeout(5000) }).catch(() => {});
    }
    if (JSON.stringify(fingerprints()) !== JSON.stringify(frozen)) throw new Error('Code đã đổi giữa phép đo.');
    complete = true;
  } finally { clearInterval(timer); save(); }
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
