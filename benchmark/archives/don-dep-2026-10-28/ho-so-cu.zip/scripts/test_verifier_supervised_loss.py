"""So loss/gradient thực với Qwen2 nhỏ: kiểm tra lệch causal shift và padding/EOS."""
import copy
import unittest
import torch
from transformers import Qwen2Config, Qwen2ForCausalLM
from verifier_collator import CompletionCollator
from verifier_supervised_loss import completion_loss


class LossTests(unittest.TestCase):
    def test_same_loss_and_all_parameter_gradients_as_dense(self):
        torch.manual_seed(42)
        model = Qwen2ForCausalLM(Qwen2Config(vocab_size=64, hidden_size=32, intermediate_size=64,
            num_hidden_layers=1, num_attention_heads=4, num_key_value_heads=2,
            attention_dropout=0.0, max_position_embeddings=64, use_cache=False))
        other = copy.deepcopy(model)
        # EOS và pad đều bằng 2; completion bắt đầu ở vị trí khác nhau giữa hai hàng.
        batch = CompletionCollator(2, 16)([
            {'input_ids': [1, 9, 5, 8, 2], 'labels': [-100, -100, 5, 8, 2]},
            {'input_ids': [1, 3, 4, 7, 6, 2], 'labels': [-100, -100, -100, -100, 6, 2]}])
        dense = model(**batch).loss
        selected = completion_loss(other, batch)
        torch.testing.assert_close(dense, selected, rtol=1e-5, atol=1e-6)
        dense.backward()
        selected.backward()
        for (name, p), (other_name, q) in zip(model.named_parameters(), other.named_parameters()):
            self.assertEqual(name, other_name)
            self.assertEqual(p.grad is None, q.grad is None)
            if p.grad is not None:
                torch.testing.assert_close(p.grad, q.grad, rtol=1e-4, atol=1e-6, msg=name)

    def test_reject_all_masked_before_forward(self):
        batch = {'input_ids': torch.tensor([[1, 2]]), 'labels': torch.tensor([[-100, -100]])}
        with self.assertRaises(ValueError):
            completion_loss(None, batch)


if __name__ == '__main__':
    unittest.main()
