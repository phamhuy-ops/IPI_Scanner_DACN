const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { summarize } = require('./minimal-context-order.cjs');
const { metrics } = require('./model-context-diagnostics.cjs');
const root = path.resolve(__dirname, '..');
const input = path.resolve(root, process.argv[2] || 'benchmark/results/minimal-context-order-96EmTi');
const read = name => JSON.parse(fs.readFileSync(path.join(input, name), 'utf8'));
const plan = read('ke-hoach.json'), raw = read('ket-qua.json'), calls = read('model-calls.json');
if (raw.status !== 'complete' || calls.length !== 24 || new Set(calls.map(row => `${row.model}/${row.id}/${row.profile}`)).size !== 24) throw new Error('Thiếu hoặc trùng lượt đo.');
const by_model = Object.fromEntries(plan.models.map(model => [model, Object.fromEntries(plan.profiles.map(profile => {
  const rows = calls.filter(row => row.model === model && row.profile === profile);
  return [profile, { accepted: summarize(rows), raw_stance_only: metrics(rows, true),
    by_group: Object.fromEntries([...new Set(rows.map(row => row.group))].map(group => [group, summarize(rows.filter(row => row.group === group))])),
    by_language: Object.fromEntries(['en', 'vi'].map(language => [language, summarize(rows.filter(row => row.language === language))])),
    total_seconds: rows.reduce((sum, row) => sum + row.seconds, 0),
    max_request_seconds: Math.max(...rows.map(row => row.seconds)),
    max_observed_model_vram_bytes: Math.max(0, ...rows.flatMap(row => row.resource_snapshot?.models?.map(m => m.size_vram || 0) || [])) }];
}))]));
const dir = path.join(root, 'benchmark/experiments/minimal-context-order-v1');
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'ke-hoach.json'), JSON.stringify(plan, null, 2) + '\n');
const result = { ...raw, by_model, artifact: path.relative(root, input),
  raw_sha256: Object.fromEntries(['ke-hoach.json', 'ket-qua.json', 'model-calls.json'].map(file => [file,
    createHash('sha256').update(fs.readFileSync(path.join(input, file))).digest('hex')])),
  resource_note: 'VRAM là giá trị lớn nhất giữa các snapshot sau request, không phải peak. Thời gian bao gồm nạp model; chưa có nhiều lượt để so hiệu năng.' };
fs.writeFileSync(path.join(dir, 'ket-qua.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ output: dir, eligible: raw.eligible_for_further_study, gate: raw.gate_passed }, null, 2));
