// Thêm phiên bản ứng viên mới vào registry; không chia tập hoặc xuất SFT.
const fs = require('node:fs');
const path = require('node:path');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const { buildRegistry, groupConstraints } = require('./assess-verifier-split-readiness.cjs');
const { consistencyIssues, roleDecision, poolGaps } = require('./assess-verifier-eligibility.cjs');
const { buildRows } = require('./prepare-verifier-recipient-contrast.cjs');
const root = path.resolve(__dirname, '..');

function newRecord(row, file) {
  if (hash(row.text) !== row.input_sha256 || validateAnnotation(row.text, row.annotation).length ||
      row.training_eligible || row.split !== null || row.human_approved || !row.source_parent_id) throw new Error('Nguồn/nhãn/trạng thái batch mới không hợp lệ.');
  const a = row.annotation;
  return { id: `verifier-recipient-contrast-v1:${row.id}`, parent_id: row.source_parent_id,
    source: row.source, format: row.format, language: row.language, stance: a.stance,
    addressee: a.addressee, framing: a.framing, deviation: a.deviation, hasDirective: a.hasDirective,
    full_record_units: row.text.length, labeled_input_units: row.text.length, selected_window_only: false,
    labeled_scope: row.annotation_scope, effective_input_sha256: row.input_sha256,
    effective_annotation_sha256: hash(JSON.stringify(a)), effective_version: 'original',
    reviewer_scope: 'ai_authored_visible_context', record_file: file, training_eligible: false, split: null,
    annotation_field_consistency: 'passed_technical_check_only', consistency_issues: consistencyIssues(a),
    source_evidence: { kind: 'project_authored_release_not_declared', license_declared: null, files: [], sha256: {},
      training_reuse_approved: false, note: 'Tự soạn, không dùng nguồn ngoài hoặc dữ liệu riêng; chưa phát hành license hoặc chốt vai trò train.' },
  };
}

function main() {
  const out = path.join(root, 'benchmark/experiments/verifier-eligibility-v2');
  if (fs.existsSync(out)) throw new Error('Không ghi đè registry cũ.');
  const inputs = {};
  const bytes = file => { const b = fs.readFileSync(path.join(root, file)); inputs[file] = hash(b); return b; };
  const json = file => JSON.parse(bytes(file));
  const base = buildRegistry();
  Object.assign(inputs, base.inputs);
  const old = bytes('benchmark/experiments/verifier-eligibility-v1/dieu-kien-tung-mau.jsonl').toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
  for (const r of base.records) {
    const previous = old.find(p => p.id === r.id);
    if (!previous || previous.effective_input_sha256 !== r.effective_input_sha256 || previous.effective_annotation_sha256 !== r.effective_annotation_sha256) throw new Error('Registry gốc đã thay đổi.');
    for (const [file, expected] of Object.entries(previous.source_evidence.sha256)) if (hash(bytes(file)) !== expected) throw new Error('Bằng chứng nguồn đã thay đổi.');
  }
  const folder = 'benchmark/data/annotations/verifier-recipient-contrast-v1';
  const manifest = json(folder + '/manifest.json');
  for (const [name, expected] of Object.entries(manifest.assets_sha256)) if (hash(bytes(folder + '/' + name)) !== expected) throw new Error('Batch bị đổi.');
  const rows = bytes(folder + '/mau-cho-duyet.jsonl').toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
  if (JSON.stringify(rows) !== JSON.stringify(buildRows())) throw new Error('Không tái dựng được batch mới.');
  const reviews = json(folder + '/danh-gia-ai.json').reviews;
  for (const row of rows) {
    const review = reviews.find(r => r.id === row.id);
    if (review?.input_sha256 !== row.input_sha256 || review.annotation_sha256 !== hash(JSON.stringify(row.annotation))) throw new Error('Phiếu AI đã cũ.');
  }
  const token = json('benchmark/experiments/verifier-recipient-contrast-tokenizer-v1/ket-qua.json');
  if (token.source_records !== 32 || token.mask_valid !== 64 || token.collator_valid !== 64 || !token.no_model_forward_or_updates) throw new Error('Token/mask/collator chưa đạt.');
  for (const [name, expected] of Object.entries(token.input_sha256)) if (hash(bytes(folder + '/' + name)) !== expected) throw new Error('Audit token đã cũ.');
  const auditFile = 'benchmark/experiments/verifier-corpus-overlap-v11/ket-qua.json';
  const audit = json(auditFile);
  if (audit.candidate_records !== 210 || audit.missing_coverage.length || !audit.inputs_unchanged) throw new Error('Audit corpus chưa đủ.');
  for (const item of audit.inventory) if (hash(bytes(item.file)) !== item.sha256) throw new Error('Đầu vào corpus đã đổi.');
  const baseline = json('benchmark/data/priority-one-dev-v2.json');
  const all = [...old, ...rows.map(row => newRecord(row, folder + '/mau-cho-duyet.jsonl'))];
  const groups = groupConstraints(all, audit.groups, new Set(baseline.cases.map(r => r.original_id)));
  if (new Set(groups.flatMap(g => g.members)).size !== 210) throw new Error('Nhóm không phủ đúng registry mở rộng.');
  const pythonReviews = json('benchmark/experiments/verifier-recipient-contrast-v1/ra-lai-12-mau-python.json');
  for (const review of pythonReviews.reviews) {
    const record = all.find(r => r.id === `verifier-external-context-v1:${review.id}`);
    if (!record || review.input_sha256 !== record.effective_input_sha256 || review.annotation_sha256 !== record.effective_annotation_sha256) throw new Error('Phiếu rà Python đã cũ.');
  }
  for (const row of all) {
    const group = groups.find(g => g.members.includes(row.id));
    row.group_id = group.id;
    row.group_constraint = group.proposed_constraint;
    row.role = roleDecision(group, row.consistency_issues);
    const python = pythonReviews.reviews.find(r => row.id === `verifier-external-context-v1:${r.id}`);
    row.latest_semantic_rereview = python ? { reviewer: 'Codex (AI)', human_approved: false, decision: python.decision, scope: 'visible_fixture_only' } : null;
    row.review_tasks = row.role === 'candidate_pending_source_privacy_and_split_review'
      ? ['source_reuse_decision_not_recorded', ...(python ? [] : ['privacy_and_full_visible_context_review_not_recorded', 'semantic_reason_stance_rereview_before_export']), 'role_assignment_and_group_split_not_final']
      : ['keep_group_out_of_training_or_resolve_quarantine'];
    row.training_eligible = false; row.split = null; row.independently_untouched_verified = false;
  }
  const planPath = 'benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json';
  const planBytes = bytes(planPath), plan = JSON.parse(planBytes);
  const count = key => all.reduce((out, r) => { out[r[key]] = (out[r[key]] || 0) + 1; return out; }, {});
  const result = { version: 'verifier-eligibility-v2', records: all.length, parent_ids: new Set(all.map(r => r.parent_id)).size,
    groups: groups.length, stances: count('stance'), languages: count('language'), roles: count('role'),
    new_records: 32, new_scenarios_not_independent_sources: 8, external_python_rereviewed_records: 12,
    pool_gaps: poolGaps(all, plan), token_mask_parser_examples: 64, token_max: token.token_max,
    training_ready: false, training_eligible_records: 0, final_split_created: false,
    model_called: false, training_started: false, runtime_changed: false, priority_one_complete: false,
    inputs_sha256: inputs, code_sha256: hash(fs.readFileSync(__filename)),
    input_snapshots: { [planPath]: 'ke-hoach-tai-thoi-diem-ra.json' },
    next_action: 'Tiếp tục rà nguồn/quyền dùng cho pool ứng viên và bổ sung bối cảnh/nguồn độc lập; chưa chia tập hoặc train vì tăng số mẫu tự soạn.',
    limitations: ['Nhãn mới do AI soạn và rà, không phải người duyệt độc lập.',
      'Tám bối cảnh mới không tương đương tám nguồn ngoài độc lập.', 'Rà Python chỉ text/cửa sổ đã xem, chưa phê duyệt quyền train.',
      'Ràng buộc nhóm heuristic không loại hết tương đồng ngữ nghĩa.'] };
  fs.mkdirSync(out);
  for (const [name, value] of Object.entries({ 'ket-qua.json': result, 'rang-buoc-nhom.json': { groups, final_split_created: false } })) fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
  fs.writeFileSync(path.join(out, 'registry.jsonl'), all.map(r => JSON.stringify(r)).join('\n') + '\n', { flag: 'wx' });
  fs.writeFileSync(path.join(out, 'ke-hoach-tai-thoi-diem-ra.json'), planBytes, { flag: 'wx' });
  console.log(JSON.stringify({ records: result.records, parents: result.parent_ids, groups: result.groups, roles: result.roles, gaps: result.pool_gaps }, null, 2));
}
if (require.main === module) main();
module.exports = { newRecord };
