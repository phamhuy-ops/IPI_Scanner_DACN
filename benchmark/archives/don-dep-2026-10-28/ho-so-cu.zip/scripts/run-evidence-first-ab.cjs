// Ứng viên trượt cổng đã được lưu riêng, không cho runner cũ âm thầm bật lại.
console.error('evidence-first đã bị loại: mất ca đúng, tăng lỗi và latency. Raw nằm tại benchmark/results/evidence-first-HKzxNe; mã thử ở benchmark/experiments/evidence-first-retired-*. Không gọi model.');
process.exitCode = 1;
