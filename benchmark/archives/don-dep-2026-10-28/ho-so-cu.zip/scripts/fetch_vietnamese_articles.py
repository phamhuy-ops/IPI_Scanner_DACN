"""Lưu bài công khai đúng revision và bản trích đoạn văn; không chạy code nguồn."""
import datetime
import email.utils
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'benchmark/data/raw/vietnamese-wikipedia-v1'
TITLES = ['Quang hợp', 'Thư viện', 'Năng lượng tái tạo', 'Hệ sinh thái', 'Bảo tàng', 'Giao thông công cộng']


class Paragraphs(HTMLParser):
    """Chỉ đoạn văn p; không coi đây là extractor toàn bộ định dạng của scanner."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.blocked = 0
        self.blocks = []
        self.current = []

    def handle_starttag(self, tag, attrs):
        if tag in ['script', 'style', 'table', 'sup', 'figure', 'noscript']:
            self.blocked += 1
        if tag == 'p' and not self.blocked:
            self.depth += 1
            self.current = []

    def handle_endtag(self, tag):
        if tag == 'p' and self.depth:
            text = re.sub(r'\s+', ' ', ''.join(self.current)).strip()
            if text:
                self.blocks.append(text)
            self.depth -= 1
            self.current = []
        if tag in ['script', 'style', 'table', 'sup', 'figure', 'noscript'] and self.blocked:
            self.blocked -= 1

    def handle_data(self, text):
        if self.depth and not self.blocked:
            self.current.append(text)


def api(**params):
    url = 'https://vi.wikipedia.org/w/api.php?' + urllib.parse.urlencode({**params, 'format': 'json', 'formatversion': '2'})
    cache = ROOT / 'benchmark/results/vietnamese-source-download-v1'
    cache.mkdir(parents=True, exist_ok=True)
    cached = cache / (hashlib.sha256(url.encode()).hexdigest() + '.json')
    if cached.exists():
        return json.loads(cached.read_text(encoding='utf-8')), url
    request = urllib.request.Request(url, headers={'User-Agent': 'IPI-Scanner/0.1 (educational local dataset curation)'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                raw = response.read(4 * 1024**2 + 1)
            break
        except urllib.error.HTTPError as error:
            if error.code != 429:
                raise
            header = error.headers.get('Retry-After')
            delay = 15 * (attempt + 1)
            if header:
                if header.isdigit():
                    delay = int(header)
                else:
                    delay = max(1, int((email.utils.parsedate_to_datetime(header) - datetime.datetime.now(datetime.timezone.utc)).total_seconds()) + 1)
            (cache / 'rate-limit-status.json').write_text(json.dumps({'url': url, 'http_status': 429,
                'retry_after_header': header, 'attempt': attempt + 1, 'identity_changed': False}), encoding='utf-8')
            if attempt == 2 or delay > 45:
                raise RuntimeError(f'Giới hạn API 429, Retry-After={header}; dừng để thử sau, không đổi danh tính/endpoint.') from error
            print(f'API 429: chờ {delay} giây theo nhịp cho phép.', flush=True)
            time.sleep(delay)
    if len(raw) > 4 * 1024**2:
        raise ValueError('Phản hồi vượt ngân sách nhỏ của lượt lấy nguồn.')
    result = json.loads(raw)
    if 'error' in result:
        raise ValueError(result['error'])
    cached.write_bytes(raw)
    time.sleep(1.5)
    return result, url


def main():
    if OUT.exists():
        raise ValueError('Không ghi đè snapshot nguồn.')
    documents = []
    assets = {}
    for index, title in enumerate(TITLES, 1):
        info, metadata_url = api(action='query', titles=title, prop='revisions', rvprop='ids|timestamp', redirects='1')
        page = info['query']['pages'][0]
        revision = page['revisions'][0]['revid']
        parsed, parse_url = api(action='parse', oldid=revision, prop='text|revid', disableeditsection='1')
        if parsed['parse']['revid'] != revision:
            raise ValueError('Revision HTML khác metadata.')
        raw_html = parsed['parse']['text']
        parser = Paragraphs()
        parser.feed(raw_html)
        text = '\n'.join(parser.blocks)
        if len(text) < 200:
            raise ValueError(f'Bài {title} thiếu văn bản đủ dùng; không lặp nền để bù.')
        stem = f'wiki-{index:02d}'
        assets[stem + '.html'] = raw_html.encode()
        assets[stem + '.txt'] = text.encode()
        assets[stem + '-metadata.json'] = (json.dumps(info, ensure_ascii=False, indent=2) + '\n').encode()
        documents.append({'id': stem, 'title': page['title'], 'pageid': page['pageid'], 'revision': revision,
            'revision_timestamp': page['revisions'][0]['timestamp'], 'language': 'vi',
            'html_file': stem + '.html', 'text_file': stem + '.txt', 'paragraphs': len(parser.blocks),
            'characters_python': len(text), 'long_at_least_8000_python_chars': len(text) >= 8000,
            'url': f'https://vi.wikipedia.org/w/index.php?oldid={revision}',
            'history_url': 'https://vi.wikipedia.org/w/index.php?' + urllib.parse.urlencode({'title': page['title'], 'action': 'history'}),
            'metadata_url': metadata_url, 'parse_url': parse_url, 'author_attribution': 'Các cộng tác viên Wikipedia tiếng Việt; xem lịch sử bài.',
            'license_declared': 'CC-BY-SA-4.0', 'license_url': 'https://creativecommons.org/licenses/by-sa/4.0/',
            'extraction_changes': 'Trích p, chuẩn hóa khoảng trắng; bỏ bảng/chú thích sup/hình/script/style. HTML gốc được giữ.',
            'full_document_security_label': None, 'article_specific_rights_independently_verified': False})
        print(json.dumps({'id': stem, 'revision': revision, 'paragraphs': len(parser.blocks), 'characters': len(text)}), flush=True)
    OUT.mkdir(parents=True)
    for file, raw in assets.items():
        (OUT / file).write_bytes(raw)
    snapshot = {'source': 'Wikipedia tiếng Việt', 'retrieved_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'documents': documents, 'assets_sha256': {p: hashlib.sha256(raw).hexdigest() for p, raw in assets.items()},
        'license_basis': 'https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use#7._Licensing_of_Content',
        'independent_holdout_verified': False, 'training_ready': False,
        'limitations': ['Chỉ bản trích đoạn văn, không bảo đảm giữ bảng/hình/toán; không thay extractor ứng dụng.',
                       'Không tự gán nhãn sạch cho toàn bộ bài hoặc gọi revision mới là nguồn độc lập.']}
    (OUT / 'snapshot.json').write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (OUT / 'GHI-CONG-VA-GIAY-PHEP.md').write_text('# Ghi công và giấy phép\n\nVăn bản: các cộng tác viên Wikipedia tiếng Việt, CC BY-SA 4.0.\nhttps://creativecommons.org/licenses/by-sa/4.0/\n\n' +
        '\n'.join(f'- {d["title"]}: {d["url"]}; lịch sử tác giả: {d["history_url"]}' for d in documents) +
        '\n\nBản txt đã trích đoạn văn và chuẩn hóa khoảng trắng; HTML đúng revision giữ riêng. Biến thể kiểm thử phải ghi rõ đã sửa, không phải nội dung Wikipedia nguyên bản.\n', encoding='utf-8')


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
