const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-recipient-contrast.cjs');
test('cặp active/trích dẫn giữ cùng lệnh nhưng hiệu lực khác, cùng parent và group', () => {
  const rows = buildRows();
  assert.equal(rows.length, 32);
  for (let i = 0; i < rows.length; i += 4) {
    const [human, active, quoted, uncertain] = rows.slice(i, i+4);
    assert.equal(human.annotation.addressee, 'human');
    assert.equal(human.annotation.stance, 'dismissed');
    assert.ok(quoted.text.includes(active.text));
    assert.equal(quoted.annotation.framing, 'quoted_example');
    assert.equal(quoted.annotation.stance, 'dismissed');
    assert.equal(active.annotation.stance, 'confirmed');
    assert.equal(uncertain.annotation.stance, 'uncertain');
    assert.ok(uncertain.annotation.uncertainty_notes.length);
    assert.ok([human, active, quoted, uncertain].every(r => r.group_id === active.group_id && r.source_parent_id === active.source_parent_id));
  }
});
test('không tự nâng nhãn AI thành người duyệt, train hoặc holdout', () => {
  const rows = buildRows();
  assert.equal(new Set(rows.map(r => r.input_sha256)).size, 32);
  assert.ok(rows.every(r => !r.human_approved && !r.training_eligible && !r.independent && r.split === null));
});
