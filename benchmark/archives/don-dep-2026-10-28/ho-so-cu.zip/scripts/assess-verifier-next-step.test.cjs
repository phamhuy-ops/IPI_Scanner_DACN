const { test } = require('node:test');
const assert = require('node:assert/strict');
const { assessData } = require('./assess-verifier-next-step.cjs');
const plan = { data: { pilot_target_records: 300, minimum_source_groups: 100,
  stance_targets: { confirmed: 0.4, dismissed: 0.4, uncertain: 0.2 }, independent_holdout: { status: 'not_collected' } },
  task: { training_export_created: false }, environment: { forward_backward_smoke_verified: false } };
const row = { original_id: 'one', group_id: 'family', expected_label: 'malicious', language: 'vi', format: '.txt', source: 'synthetic', text: 'Nguồn.' };
test('không đếm biến thể/nguồn lặp thành hai mẫu', () => {
  assert.throws(() => assessData({ cases: [row, { ...row }] }, plan));
});
test('đủ số lượng không tự cho phép train khi thiếu bộ độc lập/mask/backend', () => {
  const cases = Array.from({ length: 300 }, (_, i) => ({ ...row, original_id: String(i), group_id: String(i) }));
  const out = assessData({ cases }, plan);
  assert.equal(out.numerical_target_only.additional_sources_lower_bound, 0);
  assert.equal(out.training_ready, false);
  assert.ok(out.blockers.some(message => message.includes('tokenizer')));
  assert.equal(out.unused_independent_holdout_sources_verified, 0);
});
