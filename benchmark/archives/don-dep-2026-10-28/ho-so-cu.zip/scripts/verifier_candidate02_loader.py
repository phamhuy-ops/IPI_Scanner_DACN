"""Loader candidate-02 chỉ nhận bản train đã khóa và xác minh bản sao E."""
import hashlib
import json
import os
from pathlib import Path
from verifier_data_loader import ROOT, validate_rows
from audit_verifier_tokenizer import completion_example
from verifier_collator import CompletionCollator

LOCK = ROOT / 'benchmark/experiments/verifier-counterfactual-train-v2/giao-thuc.json'
RELEASE = Path(os.environ.get('IPI_TRAINING_ROOT', 'E:/IPI-Training')) / 'data/verifier-counterfactual-train-v2'


def load_role(role):
    if role != 'train':
        raise ValueError('Loader candidate-02 không nhận dev/probe.')
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    if storage.drive.lower() != 'e:' or not RELEASE.resolve().is_relative_to(storage):
        raise ValueError('Dữ liệu train phải ở E.')
    protocol = json.loads(LOCK.read_text(encoding='utf-8'))
    for file, expected in protocol['locked_files_sha256'].items():
        if hashlib.sha256((ROOT / file).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Đầu vào khóa đã đổi: {file}')
    if (RELEASE / 'giao-thuc.json').read_bytes() != LOCK.read_bytes():
        raise ValueError('Khóa C/E khác nhau.')
    key = 'benchmark/experiments/verifier-counterfactual-train-v2/train.preview.jsonl'
    data = (RELEASE / 'train.preview.jsonl').read_bytes()
    if hashlib.sha256(data).hexdigest() != protocol['locked_files_sha256'][key]:
        raise ValueError('Dữ liệu E đã đổi.')
    rows = validate_rows([json.loads(line) for line in data.decode('utf-8').splitlines()], role)
    if len(rows) != 360 or len({r['source_record_id'] for r in rows}) != 180:
        raise ValueError('Sai số mẫu train.')
    return rows


def train_features(tokenizer):
    features = []
    collator = CompletionCollator(tokenizer.pad_token_id, 2048)
    for row in load_role('train'):
        target = json.dumps(row['target'], ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, row['payload']['messages'], target)
        feature = {'input_ids': ids, 'labels': labels}
        batch = collator([feature])
        if any(v != -100 for v in labels[:boundary]):
            raise ValueError('Prompt lọt vào loss.')
        if tokenizer.decode([v for v in labels if v != -100]) != target + tokenizer.eos_token:
            raise ValueError('Loss không khớp JSON/EOS.')
        if any(v != -100 for v, mask in zip(batch['labels'][0].tolist(), batch['attention_mask'][0].tolist()) if not mask):
            raise ValueError('Padding lọt vào loss.')
        features.append(feature)
    return features
