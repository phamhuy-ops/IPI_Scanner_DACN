// Tổng hợp cùng bộ dev đã dùng; không suy kết quả ngoài thực tế hoặc tự triển khai.
const fs = require('node:fs');
const { decide } = require('./decide-verifier-pilot-screen.cjs');
const { hash } = require('./context-annotations.cjs');
function main() {
  const base = 'benchmark/experiments/verifier-candidate02-eval-screen-v1';
  const read = file => JSON.parse(fs.readFileSync(file));
  if (fs.existsSync(`${base}/tong-hop.json`)) throw new Error('Không ghi đè báo cáo.');
  const off = read(`${base}/off/danh-gia-v2.json`), on = read(`${base}/on/danh-gia-v2.json`);
  const prior = read('benchmark/experiments/verifier-pilot-eval-screen-v2/on/danh-gia-v2.json');
  const priorOff = read('benchmark/experiments/verifier-pilot-eval-screen-v2/off/danh-gia-v2.json');
  const training = read('benchmark/experiments/verifier-pilot-candidate-02/ket-qua.json');
  const rawBefore = read('benchmark/experiments/verifier-pilot-eval-screen-v2/off/phan-hoi.json');
  const rawAfter = read(`${base}/off/phan-hoi.json`);
  const offDifferences = rawAfter.filter(r => rawBefore.find(p => p.id === r.id)?.response !== r.response).map(r => r.id);
  const regressionTo01 = on.rows.filter(r => {
    const old = prior.rows.find(p => p.id === r.id);
    if (!old || old.expected !== r.expected) throw new Error('Ca hoặc gold khác candidate-01.');
    return old.correct_stance && !r.correct_stance;
  }).map(r => ({ id: r.id, expected: r.expected, predicted: r.predicted, error: r.error ?? null }));
  const corrected = on.rows.filter(r => r.correct_stance && !prior.rows.find(p => p.id === r.id).correct_stance).map(r => r.id);
  const result = { scope: 'six_reused_dev_sources_24_requests_not_independent',
    decision: decide(off.rows, on.rows), candidate01_on: prior.aggregate, candidate02_off: off.aggregate, candidate02_on: on.aggregate,
    candidate01_off: priorOff.aggregate, off_raw_response_differences: offDifferences,
    corrected_vs_candidate01: corrected, regressions_vs_candidate01: regressionTo01,
    training: { steps: training.global_steps, seconds: training.seconds_total, finite_gradient_steps: training.finite_gradient_steps,
      peak_vram_allocated: training.peak_vram_allocated, peak_vram_reserved: training.peak_vram_reserved },
    evaluation: read(`${base}/ket-qua.json`), latency_on: on.latency_seconds, latency_off: off.latency_seconds,
    default_agent_changed: false, probe_used: false,
    evidence_sha256: Object.fromEntries([`${base}/off/danh-gia-v2.json`, `${base}/on/danh-gia-v2.json`, 'benchmark/experiments/verifier-pilot-candidate-02/ket-qua.json'].map(f => [f, hash(fs.readFileSync(f))])),
    limitations: ['Dev nhỏ đã dùng để chẩn đoán; không phải holdout hoặc toàn pipeline.', 'Hai mode chung nguồn không phải quan sát độc lập.',
      'Chỉ thay gói dữ liệu, không chứng minh riêng cue người nhận hay phê duyệt có hiệu quả.', 'Giữ gold cũ và parser runtime; lỗi không được tính thành sạch.'] };
  fs.writeFileSync(`${base}/tong-hop.json`, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
}
if (require.main === module) main();
