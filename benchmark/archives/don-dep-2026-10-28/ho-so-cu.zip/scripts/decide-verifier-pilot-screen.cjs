// Cổng sàng lọc đã ghi trước output; không thay các cổng chất lượng đầy đủ.
const fs = require('node:fs');
function decide(off, on) {
  if (off.length !== 12 || on.length !== 12 || new Set(off.map(r => r.id)).size !== 12 || new Set(on.map(r => r.id)).size !== 12) throw new Error('Lượt screen chưa đủ.');
  const regressions = [];
  for (const candidate of on) {
    const control = off.find(r => r.id === candidate.id);
    if (!control || control.expected !== candidate.expected || control.group_id !== candidate.group_id) throw new Error('Hai mode không cùng ca.');
    if (candidate.expected === 'dismissed' && candidate.predicted === 'confirmed' && control.predicted !== 'confirmed') regressions.push({ id: candidate.id, kind: 'new_false_positive' });
    if (candidate.expected === 'confirmed' && candidate.predicted === 'dismissed' && control.predicted !== 'dismissed') regressions.push({ id: candidate.id, kind: 'new_false_clear' });
  }
  const invalid = on.filter(r => !r.parsed).map(r => r.id);
  return { advance_to_full_dev: invalid.length === 0 && regressions.length === 0,
    invalid_on: invalid, regressions,
    rule: '12/12 on qua parser và không thêm FP/false-clear so với off; full dev vẫn cần các cổng đã khóa.',
    default_agent_changed: false, probe_allowed: false, quality_improvement_proven: false };
}
if (require.main === module) {
  const base = `benchmark/experiments/verifier-pilot-eval-screen-${process.argv.includes('--retry') ? 'v2' : 'v1'}`;
  if (fs.existsSync(`${base}/quyet-dinh.json`)) throw new Error('Không ghi đè quyết định.');
  const off = JSON.parse(fs.readFileSync(`${base}/off/danh-gia.json`)), on = JSON.parse(fs.readFileSync(`${base}/on/danh-gia.json`));
  const result = { ...decide(off.rows, on.rows), off_metrics: off.aggregate, on_metrics: on.aggregate,
    scope: 'six_dev_sources_two_modes_each_not_full_dev_or_independent_test' };
  fs.writeFileSync(`${base}/quyet-dinh.json`, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
}
module.exports = { decide };
