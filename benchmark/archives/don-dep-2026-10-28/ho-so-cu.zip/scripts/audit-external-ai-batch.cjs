// Tái dựng batch AI và lưu ranh giới nhóm; không gọi model hoặc chia tập.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const { buildRows } = require('./prepare-external-ai-batch.cjs');
const root = path.resolve(__dirname, '..');
const dir = path.join(root, 'benchmark/data/annotations/verifier-external-ai-v1');
const read = p => JSON.parse(fs.readFileSync(p));
async function main() {
  const manifest = read(path.join(dir, 'manifest.json'));
  for (const [name, expected] of Object.entries(manifest.assets_sha256)) if (hash(fs.readFileSync(path.join(dir, name))) !== expected) throw new Error(`Tài sản đổi: ${name}`);
  for (const [name, expected] of Object.entries(manifest.code_sha256)) if (hash(fs.readFileSync(path.join(root, name))) !== expected) throw new Error(`Code đổi: ${name}`);
  const snapshotPath = path.join(root, 'benchmark/data/raw/injecagent/snapshot.json');
  if (hash(fs.readFileSync(snapshotPath)) !== manifest.snapshot_sha256) throw new Error('Snapshot đổi.');
  for (const [name, info] of Object.entries(read(snapshotPath).assets)) if (hash(fs.readFileSync(path.join(root, 'benchmark/data/raw/injecagent', name))) !== info.sha256) throw new Error(`Raw đổi: ${name}`);
  const licenseEvidence = ['benchmark/data/raw/notinject/README.md', 'benchmark/data/raw/injecagent/LICENCE'].map(file => {
    const bytes = fs.readFileSync(path.join(root, file));
    if (!/license:\s*mit|MIT License/i.test(bytes.toString())) throw new Error('Không tìm thấy tuyên bố license dự kiến.');
    return { file, sha256: hash(bytes), declaration: 'MIT', rights_independently_verified: false };
  });
  const rowsFile = path.join(dir, 'mau-cho-duyet.jsonl');
  const rows = fs.readFileSync(rowsFile, 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  if (JSON.stringify(rows) !== JSON.stringify(buildRows())) throw new Error('Không tái dựng được nhãn/span.');
  const reviews = read(path.join(dir, 'danh-gia-ai.json'));
  if (reviews.source_sha256 !== hash(fs.readFileSync(rowsFile)) || reviews.reviews.length !== rows.length) throw new Error('Nhật ký AI không khớp.');
  for (const row of rows) {
    const review = reviews.reviews.find(r => r.id === row.id);
    if (!review || review.input_sha256 !== row.input_sha256 || review.annotation_sha256 !== hash(JSON.stringify(row.annotation)) || row.review_status !== 'ai_reviewed') throw new Error('Sai provenance đánh giá.');
    if (hash(fs.readFileSync(path.join(root, row.provenance.source_file))) !== row.provenance.source_file_sha256) throw new Error('Nguồn đổi.');
  }
  const examples = read(path.join(dir, 'ban-xem-truoc.json')).examples;
  if (examples.length !== 60 || new Set(examples.map(r => r.id)).size !== 60) throw new Error('Sai số lượng/trùng ID.');
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  let valid = 0;
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of rows) {
      const paired = examples.filter(e => e.source_record_id === row.id);
      if (paired.length !== 2 || new Set(paired.map(e => e.mode)).size !== 2) throw new Error('Thiếu cặp chế độ.');
      for (const example of paired) {
        const rebuilt = renderDraft({ text: row.text, format: '.txt', candidate_mode: example.mode }, row.annotation);
        if (!rebuilt.validation.parser_valid || example.training_eligible !== false || JSON.stringify(example.payload) !== JSON.stringify(rebuilt.payload) || JSON.stringify(example.target) !== JSON.stringify(rebuilt.response)) throw new Error('Input/target không khớp.');
        valid++;
      }
    }
  } finally { await server.close(); }
  const corpusFile = path.join(root, 'benchmark/experiments/verifier-corpus-overlap-v6/ket-qua.json');
  const corpus = read(corpusFile);
  if (corpus.missing_coverage.length || !corpus.inputs_unchanged) throw new Error('Audit kho chưa đầy đủ.');
  for (const item of corpus.inventory) if (hash(fs.readFileSync(path.join(root, item.file))) !== item.sha256) throw new Error(`Kho đổi: ${item.file}`);
  const groups = corpus.groups.map(g => ({ ...g, global_group_id: `cg-${hash([...g.members].sort().join('\n')).slice(0, 16)}` }));
  const mapping = rows.map(row => {
    const group = groups.find(g => g.members.includes(`verifier-external-ai-v1:${row.id}`));
    if (!group) throw new Error('Thiếu nhóm.');
    return { id: row.id, source_parent_id: row.source_parent_id, group_id: group.global_group_id,
      constraint: group.constraint, final_split: null, training_eligible: false };
  });
  for (const parent of new Set(mapping.map(r => r.source_parent_id))) if (new Set(mapping.filter(r => r.source_parent_id === parent).map(r => r.group_id)).size !== 1) throw new Error('Biến thể bị tách nhóm.');
  const fresh = groups.filter(g => g.members.some(m => m.startsWith('verifier-external-ai-v1:')));
  const result = { records: rows.length, source_parents: new Set(rows.map(r => r.source_parent_id)).size,
    exact_rebuild_valid: valid, parser_valid: valid, ai_reviews: reviews.reviews.length,
    candidate_records: corpus.candidate_records, candidate_source_parents: 87 + new Set(rows.map(r => r.source_parent_id)).size,
    candidate_groups: groups.filter(g => g.constraint !== 'reference_only').length,
    new_conservative_groups: fresh.length, largest_new_component: Math.max(...fresh.map(g => g.size)),
    bipia_test_lexical_overlap_groups: groups.filter(g => g.flags.includes('overlap_existing_bipia_test')).length,
    mapping, final_split_created: false, training_ready: false, independent_holdout_verified: false,
    license_evidence: licenseEvidence,
    corpus_sha256: hash(fs.readFileSync(corpusFile)), script_sha256: hash(fs.readFileSync(__filename)),
    limitations: ['111 parent ID không chứng minh độc lập ngữ nghĩa.', '18 bản InjecAgent phải giữ chung nhóm, không tăng độ phủ bằng biến thể.', 'Nhãn AI chưa phải đánh giá độc lập hoặc người dùng duyệt.'] };
  fs.writeFileSync(path.join(dir, 'kiem-tra-va-nhom.json'), JSON.stringify(result, null, 2) + '\n');
  const boundaries = path.join(root, 'benchmark/experiments/verifier-corpus-overlap-v6/ranh-gioi-nhom.json');
  const content = JSON.stringify({ audit_sha256: result.corpus_sha256, groups, final_split_created: false }, null, 2) + '\n';
  if (fs.existsSync(boundaries) && fs.readFileSync(boundaries, 'utf8') !== content) throw new Error('Ranh giới nhóm đã có nội dung khác.');
  fs.writeFileSync(boundaries, content);
  console.log(JSON.stringify({ records: result.records, source_parents: result.source_parents,
    parser_valid: valid, candidate_records: result.candidate_records, candidate_parents: result.candidate_source_parents,
    candidate_groups: result.candidate_groups, new_groups: result.new_conservative_groups }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
