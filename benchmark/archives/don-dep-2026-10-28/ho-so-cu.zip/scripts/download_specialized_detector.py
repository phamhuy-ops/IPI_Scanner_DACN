"""Kiểm quyền rồi tải đúng model/commit đã được người dùng cho phép, không train."""
import json
import os
from pathlib import Path
import sys
from huggingface_hub import HfApi, get_token, snapshot_download
import hashlib

MODEL = 'meta-llama/Llama-Prompt-Guard-2-86M'
REVISION = 'a8ded8e697ce7c355e395a0df51f94adb4a2fd27'
REPORT = Path('benchmark/experiments/specialized-detector-download-v1')

def sha_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()



def main():
    REPORT.mkdir(exist_ok=True)
    status = {'model': MODEL, 'revision': REVISION, 'user_authorized_download': True,
              'training_authorized': False, 'training': False, 'downloaded': False}
    def save():
        (REPORT / 'trang-thai.json').write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
    root = Path(os.environ.get('IPI_TRAINING_ROOT', 'E:/IPI-Training')).resolve(strict=True)
    if os.name == 'nt' and root.drive.upper() != 'E:':
        raise ValueError('Chỉ lưu runtime và model trên E.')
    token = get_token()
    if not token:
        status['status'] = 'needs_huggingface_login'
        save()
        print(json.dumps({'status': status['status'], 'downloaded': False}))
        return 3
    try:
        HfApi().auth_check(repo_id=MODEL, repo_type='model', token=token)
    except Exception as error:
        status['status'] = 'access_check_failed'
        status['error_type'] = type(error).__name__
        save()
        print(json.dumps({'status': status['status'], 'error_type': status['error_type'], 'downloaded': False}))
        return 3
    directory = (root / 'weights' / 'prompt-guard-2-86m' / REVISION).resolve()
    if not directory.is_relative_to(root):
        raise ValueError('Đường weights vượt thư mục E đã chỉ định.')
    if directory.exists() and any(directory.iterdir()):
        status['status'] = 'existing_directory_requires_verification'
        save()
        print(json.dumps({'status': status['status'], 'downloaded': False}))
        return 4
    # Chỉ mở Hub trong tiến trình tải đã được người dùng cho phép.
    import huggingface_hub.constants as constants
    constants.HF_HUB_OFFLINE = False
    os.environ['HF_HUB_OFFLINE'] = '0'
    status['status'] = 'downloading'
    save()
    try:
        snapshot_download(repo_id=MODEL, revision=REVISION, token=token, local_dir=directory,
                          allow_patterns=['config.json', 'tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json',
                                          'added_tokens.json', '*.model', 'vocab.txt', 'vocab.json', 'merges.txt',
                                          'model.safetensors', 'model-*.safetensors', 'model.safetensors.index.json', 'README.md', 'LICENSE*'])
        files = sorted(item for item in directory.rglob('*') if item.is_file() and '.cache' not in item.relative_to(directory).parts
                       and item.suffix.lower() in ('.json', '.model', '.txt', '.safetensors'))
        artifacts = {item.relative_to(directory).as_posix(): sha_file(item) for item in files}
        token_files = [name for name in artifacts if not name.endswith('.safetensors') and not name.endswith('.safetensors.index.json')]
        token_hash = hashlib.sha256(json.dumps({name: artifacts[name] for name in sorted(token_files)}, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        config = json.loads((directory / 'config.json').read_text(encoding='utf-8'))
        labels = [str(config['id2label'][str(i)]).casefold() for i in range(len(config['id2label']))]
        if sorted(labels) != ['benign', 'malicious']:
            raise ValueError('Mapping nhãn khác hợp đồng, không tự đoán.')
        tokenizer_config = json.loads((directory / 'tokenizer_config.json').read_text(encoding='utf-8'))
        limits = [value for value in (config.get('max_position_embeddings'), tokenizer_config.get('model_max_length'))
                  if type(value) is int and 0 < value < 1000000]
        if not limits:
            raise ValueError('Chưa xác minh giới hạn token.')
        manifest = {'protocol': 1, 'model': MODEL, 'revision': REVISION, 'tokenizerSha256': token_hash,
                    'labels': labels, 'modelDir': str(directory), 'artifactSha256': artifacts,
                    'tokenizerFiles': token_files, 'maxInputTokens': min(limits)}
        manifest_path = directory.parent / 'local-manifest.json'
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        status.update(status='downloaded_pending_local_validation', downloaded=True, manifest=str(manifest_path),
                      artifact_files=len(artifacts), maxInputTokens=manifest['maxInputTokens'], labels=labels)
        save()
        print(json.dumps({key: status[key] for key in ('status', 'downloaded', 'manifest', 'artifact_files', 'maxInputTokens')}))
        return 0
    except Exception as error:
        status['status'] = 'download_or_manifest_failed'
        status['error_type'] = type(error).__name__
        save()
        print(json.dumps({'status': status['status'], 'error_type': status['error_type']}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
