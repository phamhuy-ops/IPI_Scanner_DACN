const { test } = require('node:test');
const assert = require('node:assert/strict');
const { uniformSample, selectCandidate } = require('./selector-spread-candidate.cjs');
test('rải đều có hai đầu, không trùng và giữ đủ input khi ngân sách đủ', () => {
  const values = Array.from({ length: 22 }, (_, i) => i);
  assert.deepEqual(uniformSample(values, 0), []);
  assert.deepEqual(uniformSample(values, 1), [10]);
  assert.equal(uniformSample(values, 19).at(-1), 21);
  assert.equal(new Set(uniformSample(values, 19)).size, 19);
  assert.deepEqual(uniformSample(values, 24), values);
});
test('không biến nội dung/điểm rủi ro đầu vào thành tín hiệu tùy chỉnh và giữ high-risk trước', () => {
  const chunks = Array.from({ length: 27 }, (_, index) => ({ chunkId: `c${index}`, filePath: 'document.txt',
    index, text: `Thông tin ${index}`, riskScore: index === 25 ? 100 : 0, selectionReasons: [] }));
  const snapshot = JSON.stringify(chunks);
  const selected = selectCandidate(chunks, 12);
  assert.equal(selected[0].chunkId, 'c25');
  assert.equal(selected.length, 12);
  assert.equal(JSON.stringify(chunks), snapshot);
  const reworded = chunks.map(c => ({ ...c, text: 'Một văn bản hoàn toàn khác, không có metadata nhãn.' }));
  assert.deepEqual(selectCandidate(reworded, 12).map(c => c.chunkId), selected.map(c => c.chunkId));
});
