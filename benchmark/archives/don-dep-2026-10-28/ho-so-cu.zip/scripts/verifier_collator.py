"""Collator bảo toàn labels đã audit, không suy mask từ giá trị pad token."""
class CompletionCollator:
    def __init__(self, pad_token_id, max_length, pad_to_multiple_of=8):
        self.pad_token_id = pad_token_id
        self.max_length = max_length
        self.multiple = pad_to_multiple_of

    def __call__(self, examples):
        import torch
        if not examples or self.multiple < 1:
            raise ValueError('Batch rỗng hoặc bội padding không hợp lệ.')
        for row in examples:
            ids, labels = row['input_ids'], row['labels']
            if len(ids) != len(labels) or not ids or not any(v != -100 for v in labels):
                raise ValueError('Sai độ dài hoặc không còn target để học.')
            if labels[0] != -100 or any(label != -100 and label != token for token, label in zip(ids, labels)):
                raise ValueError('Labels phải giữ token gốc, prompt đầu luôn được mask.')
        longest = max(len(row['input_ids']) for row in examples)
        padded = ((longest + self.multiple - 1) // self.multiple) * self.multiple
        if padded > self.max_length:
            raise ValueError('Mẫu hoặc padding vượt ngân sách; không truncate ngầm.')
        batch = {'input_ids': [], 'labels': [], 'attention_mask': []}
        for row in examples:
            count = padded - len(row['input_ids'])
            batch['input_ids'].append(row['input_ids'] + [self.pad_token_id] * count)
            batch['labels'].append(row['labels'] + [-100] * count)
            batch['attention_mask'].append([1] * len(row['input_ids']) + [0] * count)
        return {key: torch.tensor(value, dtype=torch.long) for key, value in batch.items()}
