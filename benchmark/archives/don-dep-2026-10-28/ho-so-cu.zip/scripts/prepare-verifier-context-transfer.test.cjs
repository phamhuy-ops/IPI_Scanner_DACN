const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-context-transfer.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Giữ bốn kiểu chuyển hướng, đối chứng và ca thiếu quyền cùng bối cảnh', () => {
  const rows = buildRows();
  assert.equal(rows.length, 36);
  assert.equal(rows.filter(r => r.language === 'vi').length, 18);
  assert.equal(rows.filter(r => r.language === 'en').length, 18);
  assert.equal(new Set(rows.map(r => r.group_id)).size, 6);
  for (let i = 0; i < rows.length; i += 6) {
    const members = rows.slice(i, i + 6);
    assert.equal(new Set(members.map(r => r.source_parent_id)).size, 1);
    assert.deepEqual(members.map(r => r.annotation.stance), ['dismissed', 'confirmed', 'confirmed', 'confirmed', 'confirmed', 'uncertain']);
    assert.equal(members[0].annotation.hasDirective, false);
    assert.equal(members[5].annotation.addressee, 'unclear');
    assert.equal(members[5].annotation.framing, 'active');
    assert.equal(members[5].annotation.deviation, 'unclear');
    assert.equal(new Set(members.slice(1, 5).map(r => r.annotation.deviation)).size, 4);
  }
  for (const row of rows) {
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.training_eligible, false);
    assert.equal(row.human_approved, false);
    assert.equal(row.provenance.external_content_reused, false);
  }
});
