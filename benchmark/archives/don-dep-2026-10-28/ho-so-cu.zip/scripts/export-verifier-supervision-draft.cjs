// Xuất bản nháp dùng chung; giữ cờ chưa phát hành và xác minh dữ liệu sau ghi.
const fs=require('node:fs');
const {hash}=require('./context-annotations.cjs');
const {verify}=require('./freeze-verifier-pilot.cjs');
async function exportDraft(rows,batch,codeFile,files){
 const out=`benchmark/data/annotations/${batch}`;
 if(!/^verifier-supervision-batch-v\d+$/.test(batch)||fs.existsSync(out))throw new Error('Tên batch sai hoặc đã tồn tại.');
 const lock=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/giao-thuc.json'));verify(lock);
 const examples=[],{createServer}=await import('vite');
 const server=await createServer({configFile:false,server:{middlewareMode:true,hmr:false},appType:'custom'});
 try{const {renderDraft}=await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
  for(const row of rows)for(const mode of ['whole_source','none']){const r=renderDraft({text:row.text,format:row.format,candidate_mode:mode},row.annotation);
   examples.push({id:`${row.id}-${mode}`,source_record_id:row.id,source_parent_id:row.source_parent_id,group_id:row.group_id,mode,
    payload:r.payload,target:r.response,validation:r.validation,training_eligible:false,model_evaluation_allowed:false});}
 }finally{await server.close();}
 const assets={'mau-cho-duyet.jsonl':rows.map(JSON.stringify).join('\n')+'\n',
  'ban-xem-truoc.json':JSON.stringify({training_export:false,examples},null,2),
  'danh-gia-ai.json':JSON.stringify({human_approved:false,independent_review:false,reviews:rows.map(r=>({id:r.id,input_sha256:hash(r.text),
   annotation_sha256:hash(JSON.stringify(r.annotation)),decision:'accept_draft_under_text_only_policy_not_release'}))},null,2)};
 const counts=field=>Object.fromEntries([...new Set(rows.map(field))].map(k=>[k,rows.filter(r=>field(r)===k).length]));
 const manifest={records:rows.length,groups:new Set(rows.map(r=>r.group_id)).size,languages:counts(r=>r.language),stance_counts:counts(r=>r.annotation.stance),
  role:'train_pool_draft_not_released',training_ready:false,model_called:false,model_evaluation_allowed:false,
  assets_sha256:Object.fromEntries(Object.entries(assets).map(([p,b])=>[p,hash(b)])),inputs_sha256:Object.fromEntries(files.map(p=>[p,hash(fs.readFileSync(p))])),
  code_sha256:{[codeFile]:hash(fs.readFileSync(codeFile)),'scripts/export-verifier-supervision-draft.cjs':hash(fs.readFileSync(__filename))},
  limitations:['AI soạn và rà, chưa được duyệt người; không nhập train hoặc dùng chọn model.',
   'Giữ nhóm train cha, không phải dữ liệu kiểm chứng độc lập; còn kiểm tra trùng/token và rà ngữ nghĩa trước phát hành.']};
 fs.mkdirSync(out);
 for(const [name,text]of Object.entries({...assets,'manifest.json':JSON.stringify(manifest,null,2)})){
  const bytes=Buffer.from(text);fs.writeFileSync(`${out}/${name}`,bytes,{flag:'wx'});
  if(!fs.readFileSync(`${out}/${name}`).equals(bytes))throw new Error('Ghi/đọc lại không khớp.');
 }
 verify(lock);console.log(JSON.stringify({batch,records:rows.length,previews:examples.length,stance_counts:manifest.stance_counts,training_ready:false,model_called:false}));
}
module.exports={exportDraft};
