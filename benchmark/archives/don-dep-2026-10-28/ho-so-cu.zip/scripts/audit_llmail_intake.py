"""Rà trùng intake LLMail với text đã kiểm kê; không đọc nhãn/gold để chấm."""
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'benchmark/experiments/llmail-intake-v1'
RAW = ROOT / 'benchmark/data/raw/llmail-intake-v1'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if OUT.exists():
        raise ValueError('Không ghi đè lượt rà đã có.')
    spec = importlib.util.spec_from_file_location('corpus', Path(__file__).with_name('audit-verifier-corpus.py'))
    corpus = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(corpus)
    # Dùng thư viện audit đã có của dự án, không cài thêm dependency.
    dependencies = ROOT / 'benchmark/results/audit-python-deps'
    if dependencies.exists():
        sys.path.insert(0, str(dependencies))
    snapshot = json.loads((RAW / 'snapshot.json').read_text(encoding='utf-8'))
    for file, expected in snapshot['assets'].items():
        if digest((RAW / file).read_bytes()) != expected['sha256']:
            raise ValueError('Snapshot LLMail đã thay đổi.')
    attacks = [json.loads(line) for line in (RAW / 'data/phase2-subset.jsonl').read_text(encoding='utf-8').splitlines()]
    if digest((RAW / 'data/phase2-subset.jsonl').read_bytes()) != snapshot['derived_subset']['sha256']:
        raise ValueError('Subset bị đổi.')
    bank = json.loads((RAW / 'data/emails_for_fp_tests.json').read_text(encoding='utf-8'))
    rows = [{'id': f'llmail-phase2-{r["source_entry_index_1_based"]:03}', 'text': r['text'],
             'source_collection': 'phase2_prefix', 'source_row': r['source_entry_index_1_based']} for r in attacks]
    rows += [{'id': f'llmail-fp-{i:03}', 'text': text, 'source_collection': 'fp_email_bank', 'source_row': i}
             for i, text in enumerate(bank, 1)]
    index = corpus.Index(rows)
    parents = list(range(len(rows)))

    def find(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parents[max(a, b)] = min(a, b)

    internal_pairs = []
    for i, row in enumerate(rows):
        for j, reasons in index.match(row['text']).items():
            if j < i:
                union(i, j)
                internal_pairs.append({'left': rows[j]['id'], 'right': row['id'], 'reasons': sorted(reasons)})
    baseline_path = ROOT / 'benchmark/experiments/verifier-corpus-overlap-v11/ket-qua.json'
    previous = json.loads(baseline_path.read_text(encoding='utf-8'))
    matches = []
    seen = set()
    hit_cache = {}
    inventory = []
    skipped_metadata = []

    def consume(text, file, identifier):
        if not isinstance(text, str) or not text.strip():
            return
        normalized_hash = digest(corpus.lex.normalize(text).encode())
        # Vẫn ghi lần xuất hiện test/dev dù text đã gặp ở raw.
        if normalized_hash not in hit_cache:
            hit_cache[normalized_hash] = index.match(text)
        hits = hit_cache[normalized_hash]
        seen.add(normalized_hash)
        for i, reasons in hits.items():
            matches.append({'candidate_id': rows[i]['id'], 'file': file, 'source_record': identifier,
                            'reasons': sorted(reasons), 'existing_test': file.endswith('ipi-test.jsonl'),
                            'existing_dev': corpus.is_development_fixture(file)})

    for item in previous['inventory']:
        file = item['file']
        target = ROOT / file
        content = target.read_bytes()
        if digest(content) != item['sha256']:
            raise ValueError(f'Đầu vào audit v11 đã đổi: {file}')
        coverage = item['coverage']
        if 'metadata' in coverage or 'license_evidence' in coverage:
            skipped_metadata.append(file)
            continue
        if target.suffix == '.jsonl':
            for i, line in enumerate(content.decode('utf-8-sig').splitlines(), 1):
                if not line.strip():
                    continue
                row = json.loads(line)
                consume(row.get('text', row.get('context', row.get('prompt'))), file, str(row.get('id', i)))
                for window in row.get('windows', []):
                    consume(window.get('text'), file, f'{i}:window:{window.get("id")}')
        elif target.suffix == '.json':
            obj = json.loads(content.decode('utf-8-sig'))
            if isinstance(obj, list):
                for i, row in enumerate(obj, 1):
                    consume(row.get('Tool Response'), file, str(i))
            else:
                for i, row in enumerate(obj.get('cases', []), 1):
                    consume(row.get('text'), file, str(row.get('id', i)))
                    relative = row.get('file') or row.get('file_path')
                    if relative:
                        source = (ROOT / relative).resolve()
                        if not source.is_relative_to(ROOT):
                            raise ValueError('Tham chiếu ngoài workspace.')
                        if source.is_file():
                            consume(source.read_text(encoding='utf-8'), source.relative_to(ROOT).as_posix(), 'referenced_file')
        elif target.suffix == '.parquet':
            import pyarrow.parquet as pq
            table = pq.read_table(target, columns=['prompt'])
            for i, text in enumerate(table.column('prompt').to_pylist(), 1):
                consume(text, file, str(i))
        elif target.suffix == '.csv':
            for i, row in enumerate(csv.DictReader(io.StringIO(content.decode('utf-8-sig'), newline='')), 1):
                consume(row.get('text'), file, str(i))
        elif target.suffix in ['.txt', '.rst', '.md', '.html']:
            consume(content.decode('utf-8-sig'), file, 'whole_text')
        else:
            raise ValueError(f'Chưa hỗ trợ schema: {file}')
        inventory.append({'file': file, 'sha256': item['sha256'], 'coverage': coverage})
    groups = {}
    for i, row in enumerate(rows):
        groups.setdefault(find(i), []).append(row['id'])
    group_rows = [{'group_id': 'llmail-' + digest('\n'.join(sorted(members)).encode())[:12], 'members': members,
                   'size': len(members), 'split': None} for members in groups.values()]
    queue = []
    for row in rows:
        hits = [m for m in matches if m['candidate_id'] == row['id']]
        queue.append({k: v for k, v in row.items() if k != 'text'} | {
            'input_sha256': digest(row['text'].encode()), 'characters_utf16': len(row['text'].encode('utf-16-le'))//2,
            'provisional_group': next(g['group_id'] for g in group_rows if row['id'] in g['members']),
            'existing_match_files': sorted({m['file'] for m in hits}),
            'existing_test_overlap': any(m['existing_test'] for m in hits),
            'existing_dev_overlap': any(m['existing_dev'] for m in hits),
            'security_label': None, 'stance': None, 'review_status': 'pending_context_privacy_review',
            'training_eligible': False, 'split': None, 'independent_holdout_verified': False})
    result = {'status': 'complete', 'source': snapshot['repository'], 'revision': snapshot['revision'],
        'records_in_intake': len(rows), 'phase2_subset_records': len(attacks), 'fp_bank_records': len(bank),
        'provisional_groups': len(group_rows), 'largest_groups': sorted(group_rows, key=lambda g: -g['size'])[:5],
        'candidates_with_existing_matches': len({m['candidate_id'] for m in matches}),
        'candidates_with_existing_test_overlap': len({m['candidate_id'] for m in matches if m['existing_test']}),
        'match_types': dict(Counter(reason for m in matches for reason in m['reasons'])),
        'unique_previous_texts_scanned': len(seen), 'previous_inventory': inventory, 'skipped_metadata_not_model_input': skipped_metadata,
        'annotation_records_added': 0, 'model_called': False, 'training_started': False, 'runtime_changed': False,
        'inputs_sha256': {'snapshot.json': digest((RAW / 'snapshot.json').read_bytes()),
                          'previous_inventory': digest(baseline_path.read_bytes())},
        'code_sha256': {'scripts/audit_llmail_intake.py': digest(Path(__file__).read_bytes()),
                        'scripts/audit-verifier-corpus.py': digest(Path(__file__).with_name('audit-verifier-corpus.py').read_bytes())},
        'limitations': ['Nguồn ngoài mới không tự là holdout độc lập; đã xem phần prefix để chọn nguồn.',
            'Gom exact/NFKC/trigram/shared-12-token chỉ là heuristic; có thể gom boilerplate hoặc bỏ tương đồng ngữ nghĩa.',
            'Chỉ so text trong inventory v11; chưa so ảnh/PDF/DOCX hoặc toàn file phase2 68 MB.',
            'Không đọc source_annotation/judge_answer/nhãn cũ để gán stance hoặc chấm model.',
            'Ngân hàng FP chỉ là provenance của nguồn, không tự gán nhãn sạch.']}
    for item in inventory:
        if digest((ROOT / item['file']).read_bytes()) != item['sha256']:
            raise ValueError('Nguồn đã đổi trong lượt rà.')
    OUT.mkdir(parents=True)
    for name, data in [('ket-qua.json', result), ('nhom-tam.json', group_rows)]:
        (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for name, data in [('hang-cho-ra-soat.jsonl', queue), ('doi-chieu.jsonl', matches), ('trung-noi-bo.jsonl', internal_pairs)]:
        (OUT / name).write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in data), encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['records_in_intake', 'provisional_groups', 'candidates_with_existing_matches', 'candidates_with_existing_test_overlap', 'unique_previous_texts_scanned']}, ensure_ascii=False))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
