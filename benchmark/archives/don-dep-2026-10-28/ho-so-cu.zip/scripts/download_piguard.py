"""Tải PIGuard public đúng commit về E, không chạy custom code upstream hoặc train."""
import hashlib
import json
import os
from pathlib import Path
from huggingface_hub import snapshot_download

MODEL = 'leolee99/PIGuard'
REVISION = 'dd78b24e330193a22d2293ac66922dd4f982f563'
REPORT = Path('benchmark/experiments/piguard-en-screen-v1')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    REPORT.mkdir(exist_ok=True)
    if (REPORT / 'download.json').exists():
        raise ValueError('Không ghi đè trạng thái tải cũ.')
    root = Path(os.environ['IPI_TRAINING_ROOT']).resolve(strict=True)
    if root.drive.upper() != 'E:':
        raise ValueError('Weights phải trên E.')
    directory = (root / 'weights' / 'piguard' / REVISION).resolve()
    if not directory.is_relative_to(root) or directory.exists():
        raise ValueError('Đích tải đã tồn tại hoặc vượt root E.')
    snapshot_download(repo_id=MODEL, revision=REVISION, token=False, local_dir=directory,
                      allow_patterns=['config.json', 'tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json',
                                      'added_tokens.json', 'spm.model', 'model.safetensors', 'README.md'])
    artifacts = {p.relative_to(directory).as_posix(): digest(p) for p in sorted(directory.rglob('*'))
                 if p.is_file() and '.cache' not in p.relative_to(directory).parts
                 and p.suffix.lower() in ('.json', '.model', '.txt', '.safetensors')}
    token_files = [name for name in artifacts if not name.endswith('.safetensors')]
    token_hash = hashlib.sha256(json.dumps({name: artifacts[name] for name in sorted(token_files)}, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    config = json.loads((directory / 'config.json').read_text())
    if config['id2label'] != {'0': 'benign', '1': 'injection'} or config['max_position_embeddings'] != 512:
        raise ValueError('Config khác bản đã rà, không tự đoán.')
    manifest = {'protocol': 1, 'model': MODEL, 'revision': REVISION, 'backend': 'piguard-reviewed-v1',
                'backendCodeSha256': digest(Path('scripts/piguard_local.py')), 'labels': ['benign', 'malicious'],
                'sourceLabels': ['benign', 'injection'], 'labelNormalization': {'injection': 'malicious'},
                'modelDir': str(directory), 'artifactSha256': artifacts, 'tokenizerFiles': token_files,
                'tokenizerSha256': token_hash, 'maxInputTokens': 512}
    manifest_path = directory.parent / 'local-manifest.json'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    report = {'downloaded': True, 'model': MODEL, 'revision': REVISION, 'manifest': str(manifest_path),
              'weightsBytes': (directory / 'model.safetensors').stat().st_size, 'custom_remote_code_executed': False,
              'backend': manifest['backend'], 'training': False, 'device': 'cpu'}
    (REPORT / 'download.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
