const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-vietnamese-workflow.cjs');
const { reviewRows } = require('./review-verifier-vietnamese-workflow.cjs');
const { replaceReviewed } = require('./apply-verifier-workflow-review.cjs');
function fixture() {
  const before = fs.readFileSync('benchmark/experiments/verifier-eligibility-v6/registry.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const original = buildRows(), reviews = reviewRows(original);
  const replacements = original.map((row, i) => ({ ...row, annotation: reviews[i].final_annotation }));
  return { before, reviews, replacements };
}
test('Thay thế phiên bản giữ nguyên số bản, nhóm, vai trò và nguồn văn bản', () => {
  const { before, reviews, replacements } = fixture();
  const after = replaceReviewed(before, replacements, reviews);
  assert.equal(after.length, 267);
  assert.equal(after.filter((r, i) => r.effective_annotation_sha256 !== before[i].effective_annotation_sha256).length, 4);
  for (let i = 0; i < before.length; i++) for (const field of ['id', 'parent_id', 'group_id', 'role', 'stance', 'effective_input_sha256', 'training_eligible', 'split']) {
    assert.deepEqual(after[i][field], before[i][field]);
  }
});
test('Chặn áp nhãn cho nguồn hoặc parent đã đổi', () => {
  let { before, reviews, replacements } = fixture();
  replacements[0].text += ' Nội dung khác.';
  assert.throws(() => replaceReviewed(before, replacements, reviews), /khớp/);
  ({ before, reviews, replacements } = fixture());
  replacements[0].source_parent_id = 'khac';
  assert.throws(() => replaceReviewed(before, replacements, reviews), /khớp/);
});
