// Chỉ tải văn bản nguồn chính thức; không gọi API được mô tả trong ví dụ.
const fs = require('node:fs');
const { hash } = require('./context-annotations.cjs');
async function main() {
  const out = 'benchmark/data/raw/openapi-context-v1';
  if (fs.existsSync(out)) throw new Error('Không ghi đè nguồn.');
  const get = async url => {
    const response = await fetch(url, { headers: { 'User-Agent': 'IPI-Scanner-source-intake' }, signal: AbortSignal.timeout(30000) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = Buffer.from(await response.arrayBuffer());
    if (data.length > 300000) throw new Error('Nguồn vượt ngân sách.');
    return data;
  };
  const commit = JSON.parse(await get('https://api.github.com/repos/OAI/OpenAPI-Specification/commits/3.0.3'));
  if (!/^[0-9a-f]{40}$/.test(commit.sha)) throw new Error('Không xác định commit.');
  const files = ['LICENSE', 'examples/v3.0/petstore.yaml', 'examples/v3.0/petstore-expanded.yaml'];
  const assets = {};
  for (const file of files) {
    const url = `https://raw.githubusercontent.com/OAI/OpenAPI-Specification/${commit.sha}/${file}`;
    const data = await get(url); assets[file] = { url, sha256: hash(data), bytes: data.length, data };
  }
  if (!assets.LICENSE.data.toString('utf8').includes('Apache License')) throw new Error('Chưa thấy license dự kiến.');
  fs.mkdirSync(out, { recursive: true });
  for (const [file, asset] of Object.entries(assets)) {
    fs.mkdirSync(require('node:path').dirname(`${out}/${file}`), { recursive: true });
    fs.writeFileSync(`${out}/${file}`, asset.data, { flag: 'wx' }); delete asset.data;
  }
  fs.writeFileSync(`${out}/snapshot.json`, JSON.stringify({ repository: 'OAI/OpenAPI-Specification', tag: '3.0.3',
    revision: commit.sha, downloaded_at: new Date().toISOString(), assets, license_declared: 'Apache-2.0',
    code_sha256: hash(fs.readFileSync(__filename)) }, null, 2) + '\n');
  fs.writeFileSync(`${out}/GHI-CONG.md`, `# Nguồn ví dụ API\n\nNguồn: OpenAPI Initiative và cộng tác viên, OAI/OpenAPI-Specification, commit ${commit.sha}, tag 3.0.3.\nGiữ LICENSE Apache-2.0 tải cùng phiên bản. Bản raw giữ nguyên byte.\nBatch chú thích sẽ trích các khối YAML; phần chèn/bao khung do AI tự soạn, không phải nội dung hoặc sự chứng thực của tác giả nguồn. Không gọi API trong ví dụ.\n`);
  console.log(JSON.stringify({ revision: commit.sha, files: files.length, bytes: Object.values(assets).reduce((n, a) => n + a.bytes, 0) }));
}
main().catch(e => { console.error(e); process.exitCode = 1; });
