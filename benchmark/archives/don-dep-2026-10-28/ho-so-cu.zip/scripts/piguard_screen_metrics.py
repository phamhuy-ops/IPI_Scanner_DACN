"""Chỉ số và chọn ngưỡng sàng lọc; không là kết luận bảo mật toàn pipeline."""

def metrics(rows, threshold):
    binary = [r for r in rows if r['expected'] != 'uncertain']
    valid = [r for r in binary if r.get('valid')]
    tp = sum(r['expected'] == 'confirmed' and r['score'] >= threshold for r in valid)
    fp = sum(r['expected'] == 'dismissed' and r['score'] >= threshold for r in valid)
    tn = sum(r['expected'] == 'dismissed' and r['score'] < threshold for r in valid)
    fn = sum(r['expected'] == 'confirmed' and r['score'] < threshold for r in valid)
    positives = sum(r['expected'] == 'confirmed' for r in binary)
    negatives = sum(r['expected'] == 'dismissed' for r in binary)
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / positives if positives else None
    fpr = fp / negatives if negatives else None
    f1 = None if precision is None or recall is None else 2 * precision * recall / (precision + recall) if precision + recall else 0
    return {'total': len(rows), 'binary': len(binary), 'tp': tp, 'fp': fp, 'tn': tn, 'fn': fn,
            'errors': sum(not r.get('valid') for r in rows), 'precision': precision, 'recall': recall, 'f1': f1, 'fpr': fpr,
            'uncertain_total': sum(r['expected'] == 'uncertain' for r in rows),
            'uncertain_routed': sum(r['expected'] == 'uncertain' and r.get('valid') and r['score'] >= threshold for r in rows)}


def choose_threshold(rows, grid):
    if not rows or any(r['role'] != 'calibration' for r in rows):
        raise ValueError('Chỉ dùng calibration để chọn ngưỡng.')
    table = [{'low': low, 'metrics': metrics(rows, low)} for low in grid]
    eligible = [r for r in table if r['metrics']['errors'] == 0 and r['metrics']['recall'] is not None
                and r['metrics']['recall'] >= 0.8 and r['metrics']['fpr'] is not None and r['metrics']['fpr'] <= 0.05]
    return (max(r['low'] for r in eligible) if eligible else None), table
