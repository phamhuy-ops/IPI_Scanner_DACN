const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const { buildRows } = require('./prepare-verifier-addressee.cjs');
const root = path.resolve(__dirname, '..');
const dir = path.join(root, 'benchmark/data/annotations/verifier-addressee-context-v1');

async function main() {
  const read = name => JSON.parse(fs.readFileSync(path.join(dir, name)));
  const manifest = read('manifest.json');
  for (const [file, expected] of Object.entries(manifest.assets_sha256)) {
    assert.equal(hash(fs.readFileSync(path.join(dir, file))), expected, `Tài sản đã đổi: ${file}`);
  }
  for (const [file, expected] of Object.entries(manifest.code_sha256)) assert.equal(hash(fs.readFileSync(path.join(root, file))), expected);
  assert.equal(hash(fs.readFileSync(path.join(root, manifest.source_file))), manifest.source_sha256);
  const rows = fs.readFileSync(path.join(dir, 'mau-cho-duyet.jsonl'), 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const rebuilt = buildRows();
  assert.deepEqual(rows, rebuilt.rows);
  assert.deepEqual(fs.readFileSync(path.join(dir, 'cach-ly.jsonl'), 'utf8').trim().split(/\r?\n/).map(JSON.parse), rebuilt.quarantine);
  const reviews = read('danh-gia-ai.json');
  assert.equal(reviews.reviews.length, rows.length); assert.equal(reviews.human_approved, false);
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  let valid = 0;
  try {
    const { normalizeExternal } = await server.ssrLoadModule('/scripts/normalize-reviewed-external.ts');
    for (const example of read('ban-xem-truoc.json').examples) {
      const row = rows.find(row => row.id === example.source_record_id);
      const review = reviews.reviews.find(item => item.id === row.id);
      assert.equal(review.input_sha256, row.input_sha256);
      assert.equal(review.annotation_sha256, hash(JSON.stringify(row.annotation)));
      assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
      assert.equal(example.training_eligible, false); assert.equal(row.training_eligible, false);
      const rendered = normalizeExternal(row.text, { ...row.annotation, language: row.language, target_quote: row.annotation.directive_spans[0]?.quote }, example.mode);
      assert.deepEqual(example.payload, rendered.payload); assert.deepEqual(example.target, rendered.response);
      // So đúng payload tái dựng từ text và chế độ; không thêm metadata/đáp án mới.
      assert.equal(example.payload.messages.length, 2);
      for (const metadata of [row.id, row.group_id, row.source_parent_id, 'training_eligible', 'original_case_id']) {
        assert.equal(example.payload.messages.some(message => message.content.includes(metadata)), false);
      }
      assert.equal(rendered.validation.parser_valid, true); valid++;
    }
  } finally { await server.close(); }
  const result = { records: rows.length, quarantined: rebuilt.quarantine.length, preview_rebuilt_and_parser_valid: valid,
    source_hashes_unchanged: true, metadata_excluded_from_payload: true, human_approval_transferred: false,
    labels: Object.fromEntries(['benign', 'malicious', 'uncertain'].map(label => [label, rows.filter(row => row.annotation.label === label).length])),
    initial_groups: new Set(rows.map(row => row.group_id)).size, training_ready: false, final_split_created: false,
    note: 'Chưa chấm độ đúng ngữ nghĩa độc lập; xem corpus v8 và token audit riêng.',
    code_sha256: hash(fs.readFileSync(__filename)) };
  const out = path.join(root, 'benchmark/experiments/verifier-addressee-context-v1/kiem-tra-tai-dung.json');
  fs.writeFileSync(out, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(result));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
