// Parser chuẩn hóa các trường tham chiếu vào directiveContext, không để ở top-level.
function contextMatches(assessment, annotation) {
  const context = assessment?.directiveContext;
  if (!context) return null;
  return Object.fromEntries(['addressee', 'framing', 'deviation', 'hasDirective'].map(key =>
    [key, (key === 'hasDirective' ? Boolean(context.directive) : context[key]) === annotation[key]]));
}
function directiveCovered(assessment, annotation) {
  if (!assessment?.citation || !annotation.directive_spans.length) return null;
  return annotation.directive_spans.every(span => assessment.citation.quote.includes(span.quote));
}
module.exports = { contextMatches, directiveCovered };
