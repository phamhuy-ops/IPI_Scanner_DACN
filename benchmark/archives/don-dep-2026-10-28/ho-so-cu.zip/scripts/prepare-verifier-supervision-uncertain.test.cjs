const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {buildRows}=require('./prepare-verifier-supervision-uncertain.cjs');
const {validateAnnotation}=require('./context-annotations.cjs');
function input(){return [fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse),JSON.parse(fs.readFileSync('benchmark/experiments/verifier-supervision-review-v1/ma-tran-bo-sung.json'))];}
test('Đích AI rõ, uncertain do tham chiếu thiếu trong văn bản; có đối chứng đủ ba nhãn',()=>{
 const rows=buildRows(...input());assert.equal(rows.length,12);assert.equal(new Set(rows.map(r=>r.text)).size,12);
 for(const row of rows){assert.deepEqual(validateAnnotation(row.text,row.annotation),[]);assert.equal(row.annotation.addressee,'assistant');assert.equal(row.training_eligible,false);assert.equal(row.model_evaluation_allowed,false);}
 for(const group of new Set(rows.map(r=>r.group_id))){const family=rows.filter(r=>r.group_id===group);assert.deepEqual(family.map(r=>r.annotation.stance),['uncertain','confirmed','dismissed']);
  assert.equal(family[0].annotation.framing,'active');assert.equal(family[0].annotation.deviation,'unclear');assert.equal(family[0].annotation.uncertainty_notes.length,1);
  assert.equal(family[1].annotation.uncertainty_notes.length,0);assert.equal(family[2].annotation.framing,'quoted_example');}
});
test('Không nhận cha khác vai trò hoặc hash đã duyệt',()=>{
 const [parents,matrix]=input();const row=parents.find(r=>r.id===matrix.slots.find(s=>s.id==='slot-05').parent_record_id);
 row.text+=' altered';assert.throws(()=>buildRows(parents,matrix),/Cha/);
});
