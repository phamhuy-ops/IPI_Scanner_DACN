const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {buildRows}=require('./prepare-verifier-supervision-framing.cjs');
const {validateAnnotation}=require('./context-annotations.cjs');
function input(){return [fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse),JSON.parse(fs.readFileSync('benchmark/experiments/verifier-supervision-review-v1/ma-tran-bo-sung.json'))];}
test('Giữ cùng lệnh, chỉ đổi bao khung và giữ đủ ngữ cảnh làm bằng chứng',()=>{
 const rows=buildRows(...input());assert.equal(rows.length,12);assert.equal(new Set(rows.map(r=>r.text)).size,12);
 for(const group of new Set(rows.map(r=>r.group_id))){const r=rows.filter(r=>r.group_id===group);
  assert.deepEqual(r.map(r=>r.annotation.stance),['uncertain','confirmed','dismissed']);
  assert.equal(new Set(r.map(r=>r.annotation.directive_spans[0].quote)).size,1);
  assert.deepEqual(r.map(r=>r.annotation.framing),['unclear','active','quoted_example']);}
 for(const r of rows){assert.deepEqual(validateAnnotation(r.text,r.annotation),[]);assert.equal(r.annotation.addressee,'assistant');assert.equal(r.annotation.deviation,'task_override');assert.equal(r.model_evaluation_allowed,false);assert.equal(r.training_eligible,false);}
});
test('Không nhận sai vai trò hoặc nhóm train cha',()=>{
 const [rows,matrix]=input();rows.find(r=>r.id===matrix.slots.find(s=>s.id==='slot-09').parent_record_id).group_id='other';assert.throws(()=>buildRows(rows,matrix),/Cha/);
});
