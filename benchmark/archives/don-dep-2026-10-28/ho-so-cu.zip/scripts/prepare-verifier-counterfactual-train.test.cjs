const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { build } = require('./prepare-verifier-counterfactual-train.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
const rows = fs.readFileSync('benchmark/data/annotations/verifier-local-release-preview-v2/mau-cho-duyet.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
const allowed = JSON.parse(fs.readFileSync('benchmark/experiments/verifier-counterfactual-training-proposal-v1/ke-hoach.json')).allowed_parent_train_groups;
test('Giữ cân bằng, ranh giới train và không chuyển duyệt người sang bản sửa', () => {
  const result = build(rows, allowed), changed = result.filter(r => r.counterfactual);
  assert.equal(changed.length, 12);
  for (const r of changed) {
    assert.equal(r.human_approved, false);
    assert.deepEqual(validateAnnotation(r.text, r.annotation), []);
    assert.equal(r.source_parent_id, rows.find(p => p.id === r.id).source_parent_id);
    assert.equal(r.annotation.stance, r.counterfactual.variant === 'harmful_human_directive' ? 'dismissed' : 'confirmed');
  }
  assert.equal(result.length, 180);
  assert.throws(() => build(rows, []), /ngoài nhóm/);
});
test('Từ chối nhóm train có mặt trong dev', () => {
  const mixed = structuredClone(rows);
  mixed.find(r => r.planned_role === 'dev').group_id = mixed.find(r => r.planned_role === 'train').group_id;
  assert.throws(() => build(mixed, allowed), /Chồng nhóm/);
});
