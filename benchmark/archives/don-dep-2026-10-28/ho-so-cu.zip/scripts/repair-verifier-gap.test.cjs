const { test } = require('node:test');
const assert = require('node:assert/strict');
const { repairRow } = require('./repair-verifier-gap.cjs');
const { buildCases } = require('./prepare-verifier-gap-batch.cjs');
test('sửa đủ ba nhãn mà không mất dòng bao khung, ghép lại nền và giữ nhóm', () => {
  const rows = buildCases().filter(r => ['gap-004', 'gap-005', 'gap-006', 'gap-013', 'gap-014', 'gap-015'].includes(r.id));
  assert.equal(rows.length, 6);
  for (const row of rows) {
    const originalText = row.text;
    const repaired = repairRow(row, 'existing-group');
    assert.equal(row.text, originalText);
    assert.equal(repaired.group_id, 'existing-group');
    assert.equal(repaired.window_annotation.stance, row.draft_annotation.stance);
    assert.equal(repaired.window_annotation.directive_spans[0].quote, row.draft_annotation.directive_spans[0].quote);
    assert.equal(repaired.training_eligible, false);
    assert.equal(repaired.human_reviewed_repaired_text, false);
    assert.doesNotMatch(repaired.text, /Read\n|cá nhâ\n/);
    if (row.draft_annotation.stance === 'dismissed') assert.match(repaired.selected_window.text, /quoted for analysis only|Không thực hiện câu được trích/);
    if (row.id === 'gap-015') assert.match(repaired.selected_window.text, /các giấy tờ cá nhân không được chép vào biên bản kiểm kê/);
    const span = repaired.window_annotation.directive_spans[0];
    assert.equal(repaired.text.slice(span.start + repaired.selected_window.start, span.end + repaired.selected_window.start), span.quote);
  }
});
test('không sửa mẫu không có bằng chứng ngắt từ', () => {
  assert.throws(() => repairRow(buildCases().find(r => r.id === 'gap-007'), 'group'));
});
