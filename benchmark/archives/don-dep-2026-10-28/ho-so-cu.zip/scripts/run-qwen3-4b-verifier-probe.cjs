// Phát lại yêu cầu Verifier hiện có để chỉ thay model; không nới registry sản phẩm.
const fs=require('node:fs'),path=require('node:path');
const {hash}=require('./context-annotations.cjs');
const {select}=require('./run-agent-live-model-probe.cjs');
const {summarize}=require('./agent-live-probe-metrics.cjs');
const {passes}=require('./qwen3-probe-gate.cjs');
const out='benchmark/experiments/qwen3-4b-verifier-probe-v1';
const models={baseline:'qwen2.5-coder:1.5b',candidate:'qwen3:4b-instruct-2507-q4_K_M'};
async function main(){
 if(fs.existsSync(out))throw Error('Không ghi đè hoặc chạy lại đợt cũ.');
 const source='benchmark/data/annotations/verifier-role-authority-controls-v1/mau-cho-duyet.jsonl';
 const cases=select(fs.readFileSync(source,'utf8').trim().split(/\r?\n/).map(JSON.parse));
 const previous=JSON.parse(fs.readFileSync('benchmark/experiments/neutral-verifier-probe-v1/model-calls.json'));
 const requests=cases.map(c=>{const r=previous.find(x=>x.id===c.id&&x.arm==='baseline');if(!r)throw Error('Thiếu baseline');return r.request;});
 const api=async(p,b,ms=8000)=>{const r=await fetch('http://127.0.0.1:11434'+p,{method:b?'POST':'GET',headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined,signal:AbortSignal.timeout(ms)});const raw=await r.text();if(!r.ok)throw Error(raw);return JSON.parse(raw);};
 const tags=await api('/api/tags');for(const m of Object.values(models))if(!tags.models.some(t=>t.name===m))throw Error('Model chưa tải xong: '+m);
 const files=['scripts/run-qwen3-4b-verifier-probe.cjs','scripts/qwen3-probe-gate.cjs','scripts/agent-live-probe-metrics.cjs','scripts/run-agent-live-model-probe.cjs','benchmark/experiments/neutral-verifier-probe-v1/model-calls.json','src/ai/agents/document/reviewPolicy.ts','src/ai/agents/document/prompts.ts','src/ai/agents/document/directiveContext.ts'];
 const fingerprint=()=>Object.fromEntries(files.map(p=>[p,hash(fs.readFileSync(p))]));const before=fingerprint();
 fs.mkdirSync(out);const save=(p,v)=>{const b=Buffer.from(JSON.stringify(v,null,2));fs.writeFileSync(out+'/'+p,b);if(!fs.readFileSync(out+'/'+p).equals(b))throw Error('Readback lỗi');};
 const plan={scope:'So sánh model trên dev, prompt/schema/parser classic-v1 giữ nguyên; HTTP trực tiếp chỉ trong runner thử nghiệm, không vượt registry sản phẩm.',models,tags,source_sha256:hash(fs.readFileSync(source)),code_sha256:before,cases:cases.map(c=>({id:c.id,group:c.group_id,expected:c.annotation.stance,input_sha256:c.input_sha256})),requests,seed:42,max_tokens:1400,temperature:0,request_budget:32,deadline_ms:45000,warm_load_ms:120000,explicit_context_override:false,gold_in_model_input:false,train:false,
 gates:{valid_candidate:16,strict_stance_improvement:true,strict_tp_improvement:true,at_least_one_correct_uncertain:true,no_new_fp_or_falseclear_or_uncertain_overconfirmation:true,no_correct_case_regression:true,no_group_or_language_regression:true,all_tp_grounded:true,p95_ratio_max:3},
 stop:'Đo đủ 32 request, không retry/đổi prompt/train. Không đổi mặc định; đạt mới thiết kế pipeline và dữ liệu độc lập.',limits:['Dev tổng hợp đã dùng chẩn đoán, không phải holdout; nhãn AI chưa phải mọi mẫu do con người duyệt.','Không phải đánh giá Detector hoặc toàn pipeline; không đo UI/tài liệu dài.','Context mặc định của Ollama được ghi qua api/ps, không tự nới token; VRAM là snapshot, không phải peak.','Warm-load tách riêng khỏi latency request, thời gian tải/nạp ghi riêng.']};
 save('giao-thuc-truoc-do.json',plan);
 const {createServer}=await import('vite');const server=await createServer({configFile:false,root:path.resolve(__dirname,'..'),server:{middlewareMode:true,hmr:false},optimizeDeps:{noDiscovery:true},appType:'custom'});
 const records=[],calls=[],loads=[];
 try{
 const {parseReviewJson,applyBatch}=await server.ssrLoadModule('/src/ai/agents/document/reviewPolicy.ts');
 for(const [i,c]of cases.entries())for(const arm of i%2?['candidate','baseline']:['baseline','candidate']){
 const model=models[arm];const loadStart=performance.now();await api('/api/generate',{model,keep_alive:'5m'},120000);loads.push({id:c.id,arm,seconds:(performance.now()-loadStart)/1000});save('nap-model.json',loads);
 const body={...requests[i],model,seed:42};if(body.messages.some(m=>m.content.includes(c.id)||m.content.includes(c.group_id)))throw Error('Lộ metadata');
 const row={id:c.id,arm,expected:c.annotation.stance,language:c.language,group_id:c.group_id,parsed:false,predicted:null,gold_instruction_covered:false};const start=performance.now();
 try{const response=await api('/v1/chat/completions',body,45000);row.seconds=(performance.now()-start)/1000;
 const ps=await api('/api/ps');calls.push({id:c.id,arm,request:body,response,resources:ps});save('model-calls.json',calls);
 if(response.model!==model)throw Error('Model thực chạy không khớp');row.finish_reason=response.choices?.[0]?.finish_reason;row.usage=response.usage;
 const chunks=[{chunkId:'chunk-1',fileName:'document.txt',filePath:'/document.txt',startLine:1,endLine:c.text.split('\n').length,text:c.text,riskScore:0,findingCount:0,selectionReasons:['complete_source_diagnostic']}];
 const parsed=parseReviewJson(response.choices?.[0]?.message?.content||'',chunks,[],'classic-v1'),tasks=[];applyBatch(parsed,'verifier',tasks);
 const findings=tasks.map(t=>t.verifier).filter(Boolean);row.findings=findings;row.parsed=true;row.predicted=findings.some(f=>f.stance==='confirmed')?'confirmed':findings.some(f=>f.stance==='uncertain')?'uncertain':'dismissed';
 const gold=c.annotation.directive_spans[0].quote;row.gold_instruction_covered=findings.filter(f=>f.stance==='confirmed').some(f=>f.citation.quote.includes(gold)||(gold.includes(f.citation.quote)&&f.citation.quote.trim().length>=16));row.model_vram_snapshot=ps.models.find(m=>m.name===model)?.size_vram??null;
 }catch(e){row.error=e.message;row.seconds??=(performance.now()-start)/1000;}
 records.push(row);save('cases.json',records);console.log(JSON.stringify({done:records.length,total:32,arm,parsed:row.parsed,predicted:row.predicted}));
 await api('/api/generate',{model,keep_alive:0},8000);
 }
 const a=records.filter(r=>r.arm==='baseline'),b=records.filter(r=>r.arm==='candidate'),baseline=summarize(a),candidate=summarize(b);
 const regressions=b.filter(y=>{const x=a.find(t=>t.id===y.id);return(x.predicted===x.expected&&y.predicted!==y.expected)||(y.expected==='dismissed'&&y.predicted==='confirmed'&&x.predicted!=='confirmed')||(y.expected==='confirmed'&&y.predicted==='dismissed'&&x.predicted!=='dismissed')||(y.expected==='uncertain'&&y.predicted==='confirmed'&&x.predicted!=='confirmed');}).map(r=>r.id);
 const groupRegressions=[];for(const f of ['language','group_id'])for(const k of new Set(a.map(r=>r[f])))if(summarize(b.filter(r=>r[f]===k)).correct_stance<summarize(a.filter(r=>r[f]===k)).correct_stance)groupRegressions.push({field:f,key:k});
 const ratio=candidate.latency_p95/baseline.latency_p95;const uncertainCorrect=b.filter(r=>r.expected==='uncertain'&&r.predicted==='uncertain').length;
 const passed=passes({baseline,candidate,uncertainCorrect,regressions,groupRegressions,ratio});
 if(JSON.stringify(before)!==JSON.stringify(fingerprint()))throw Error('Code đổi trong phép đo');const after=await api('/api/tags');for(const m of Object.values(models))if(tags.models.find(t=>t.name===m).digest!==after.models.find(t=>t.name===m)?.digest)throw Error('Model đổi digest');
 const breakdown={};for(const arm of ['baseline','candidate']){breakdown[arm]={};for(const f of ['language','group_id'])breakdown[arm][f]=Object.fromEntries([...new Set(records.map(r=>r[f]))].map(k=>[k,summarize(records.filter(r=>r.arm===arm&&r[f]===k))]));}
 const result={complete:records.length===32,passed,baseline,candidate,uncertain_correct:uncertainCorrect,regressions,group_regressions:groupRegressions,p95_ratio:ratio,breakdown,default_changed:false,pipeline_measured:false,limits:plan.limits};save('tong-hop.json',result);console.log(JSON.stringify(result));
 }catch(e){save('loi.json',{error:e.message,completed:records.length});throw e;}finally{await server.close();}
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;});
