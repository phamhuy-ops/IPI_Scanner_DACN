"""Pilot một ứng viên/1 epoch trên train-only; adapter thử nghiệm chưa triển khai."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

from verifier_candidate02_loader import ROOT, LOCK, RELEASE, load_role, train_features


def main():
    out = ROOT / 'benchmark/experiments/verifier-pilot-candidate-02'
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    checkpoints = storage / 'checkpoints/verifier-pilot-v1/candidate-02'
    adapter = storage / 'adapters/verifier-pilot-v1/candidate-02'
    if storage.drive.lower() != 'e:' or any(p.exists() or not p.resolve().is_relative_to(storage) for p in [checkpoints, adapter]):
        raise ValueError('Đích E đã có hoặc vượt phạm vi; không ghi đè.')
    if out.exists():
        raise ValueError('Không ghi đè ứng viên.')
    protocol = json.loads(LOCK.read_text(encoding='utf-8'))
    baseline = json.loads((ROOT / 'benchmark/experiments/verifier-hf-base-dev-v1/tong-hop.json').read_text(encoding='utf-8'))
    if not baseline['baseline_complete'] or baseline['requests'] != 168:
        raise ValueError('Chưa đủ baseline trước train.')
    rows = load_role('train')
    if len(rows) != 360 or len({r['source_record_id'] for r in rows}) != 180:
        raise ValueError('Sai phạm vi train.')
    out.mkdir()
    execution = {'candidate': 'candidate-02', 'scope': 'local_pilot_only_not_product_or_public_release',
        'source_records': 180, 'examples': 360, 'epochs': 1, 'expected_optimizer_steps': 45,
        'learning_rate': .0001, 'seed': 42, 'micro_batch': 1, 'gradient_accumulation': 8,
        'sequence_budget': 2048, 'packing': False, 'train_data_only': True,
        'dev_or_probe_used_for_updates': False, 'validation_during_training': False,
        'selection': 'Đo checkpoint cuối epoch trên dev; không chọn theo train loss, không thử probe.',
        'authorization_scope': 'Yêu cầu tiếp tục pilot Verifier của người dùng; chỉ thí nghiệm nội bộ, không đổi mặc định Agent.',
        'release_flags': 'Bản preview vẫn không tự được mọi Trainer nạp; runner này kiểm tra khóa và chỉ lấy train.',
        'lock_sha256': hashlib.sha256(LOCK.read_bytes()).hexdigest(),
        'train_file_sha256': hashlib.sha256((RELEASE / 'train.preview.jsonl').read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'checkpoint_path': str(checkpoints), 'adapter_path': str(adapter)}
    (out / 'ke-hoach-thuc-thi.json').write_text(json.dumps(execution, ensure_ascii=False, indent=2), encoding='utf-8')
    result = {'status': 'preparing', 'pilot_training_started': False, 'runtime_changed': False,
              'dev_or_probe_used_for_updates': False, 'adapter_path': str(adapter)}
    started = time.perf_counter()
    try:
        import torch
        import psutil
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, TrainingArguments, TrainerCallback
        from peft import LoraConfig, get_peft_model, get_peft_model_state_dict, prepare_model_for_kbit_training
        from verifier_trainer import VerifierTrainer
        from verifier_collator import CompletionCollator
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA không khả dụng; không tự đổi backend.')
        assets = json.loads((ROOT / 'benchmark/experiments/verifier-gpu-assets-v1/ket-qua.json').read_text(encoding='utf-8'))
        local = Path(assets['snapshot']).resolve()
        if not local.is_relative_to(storage) or assets['revision'] != protocol['revision']:
            raise ValueError('Sai snapshot model.')
        torch.manual_seed(42)
        torch.cuda.set_per_process_memory_fraction(.8)
        tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False)
        features = train_features(tokenizer)
        model = AutoModelForCausalLM.from_pretrained(local, local_files_only=True, trust_remote_code=False,
            quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4', bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.float16), device_map={'': 0}, torch_dtype=torch.float16, attn_implementation='sdpa')
        model.config.use_cache = False
        model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True,
            gradient_checkpointing_kwargs={'use_reentrant': False})
        model = get_peft_model(model, LoraConfig(r=8, lora_alpha=16, lora_dropout=.05,
            target_modules=['q_proj', 'v_proj'], bias='none', task_type='CAUSAL_LM'))
        if any('lora_' not in name for name, p in model.named_parameters() if p.requires_grad):
            raise ValueError('Base weights không được cập nhật.')
        initial = {k: v.detach().cpu().clone() for k, v in get_peft_model_state_dict(model).items()}
        result['trainable_parameters'] = sum(p.numel() for p in model.parameters() if p.requires_grad)

        class Monitor(TrainerCallback):
            checked = 0

            def on_pre_optimizer_step(self, args, state, control, **kwargs):
                grads = [p.grad for p in kwargs['model'].parameters() if p.requires_grad and p.grad is not None]
                if not grads or not all(torch.isfinite(g).all() for g in grads):
                    raise FloatingPointError('Gradient thiếu hoặc không hữu hạn.')
                self.checked += 1

            def on_step_end(self, args, state, control, **kwargs):
                progress = {'step': state.global_step, 'total_steps': state.max_steps,
                            'seconds': time.perf_counter() - started, 'training_started': True}
                (out / 'tien-do.json').write_text(json.dumps(progress), encoding='utf-8')
                print(json.dumps(progress), flush=True)

        callback = Monitor()
        args = TrainingArguments(output_dir=str(checkpoints), per_device_train_batch_size=1,
            gradient_accumulation_steps=8, num_train_epochs=1, learning_rate=.0001,
            fp16=True, gradient_checkpointing=True, gradient_checkpointing_kwargs={'use_reentrant': False},
            max_grad_norm=1., optim='adamw_torch', lr_scheduler_type='constant', weight_decay=0,
            save_strategy='steps', save_steps=15, save_total_limit=2, logging_steps=5,
            report_to=[], disable_tqdm=True, dataloader_pin_memory=False, dataloader_num_workers=0,
            remove_unused_columns=False, label_names=['labels'], seed=42, data_seed=42)
        trainer = VerifierTrainer(model=model, args=args, train_dataset=features,
            data_collator=CompletionCollator(tokenizer.pad_token_id, 2048), callbacks=[callback])
        trainer.accelerator.scaler = torch.amp.GradScaler('cuda', init_scale=1024)
        result['pilot_training_started'] = True
        (out / 'ket-qua.json').write_text(json.dumps(result), encoding='utf-8')
        trainer.train()
        torch.cuda.synchronize()
        if trainer.state.global_step != 45 or callback.checked != 45 or len(trainer.loss_observations) != 360:
            raise ValueError('Không đủ bước/microbatch đã khóa.')
        for start in range(0, 360, 8):
            group = trainer.loss_observations[start:start + 8]
            if any(x['normalizer_tokens'] != sum(g['supervised_tokens'] for g in group) for x in group):
                raise ValueError('Sai denominator accumulation.')
        current = get_peft_model_state_dict(model)
        if not any(not torch.equal(value, current[key].detach().cpu()) for key, value in initial.items()):
            raise ValueError('Adapter chưa thay đổi.')
        trainer.save_model(str(adapter))
        tokenizer.save_pretrained(str(adapter))
        (adapter / 'CHUA-TRIEN-KHAI.json').write_text(json.dumps({'local_pilot_only': True, 'quality_validated': False}), encoding='utf-8')
        result.update(status='trained_not_quality_validated', global_steps=45, micro_batches=360,
            finite_gradient_steps=callback.checked, adapter_updated=True, loss_observations=trainer.loss_observations,
            trainer_log_history=trainer.state.log_history,
            adapter_files_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in adapter.iterdir() if p.is_file()},
            peak_vram_allocated=torch.cuda.max_memory_allocated(), peak_vram_reserved=torch.cuda.max_memory_reserved(),
            rss_bytes=psutil.Process().memory_info().rss)
    except Exception as error:
        result.update(status='failed', error=str(error), traceback=traceback.format_exc())
    finally:
        result.update(seconds_total=time.perf_counter() - started,
            limitations=['Một epoch/ứng viên trên 180 nguồn có nhiều nhãn AI; chưa kiểm chứng độc lập.',
                'Train loss giảm không chứng minh nhận diện tốt hơn; cần đo dev cùng PEFT model adapter off/on.',
                'Không dùng adapter kỹ thuật cũ, không thay model Ollama hoặc Agent mặc định.'])
        (out / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({k: result.get(k) for k in ['status', 'global_steps', 'seconds_total', 'error']}), flush=True)
    return 0 if result['status'] == 'trained_not_quality_validated' else 1


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
