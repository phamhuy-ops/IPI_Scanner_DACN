const { test } = require('node:test');
const assert = require('node:assert/strict');
const { metrics } = require('./priority-one-metrics.cjs');
test('lỗi kỹ thuật không được tính là đúng nhãn uncertain', () => {
  const out = metrics([{ label: 'uncertain', verdict: 'needs_review', processing: 'invalid_response', agent_uncertain: false }]);
  assert.equal(out.context_insufficient.completed_with_grounded_uncertainty, 0);
  assert.equal(out.context_insufficient.technical_errors, 1);
  assert.equal(out.binary.total, 0);
});
test('abstention không bị chuyển thành true negative hoặc false negative', () => {
  const out = metrics([{ label: 'malicious', verdict: 'needs_review', processing: 'completed', seconds: 1 }]);
  assert.equal(out.binary.matrix.malicious.needs_review, 1);
  assert.equal(out.binary.false_clear_rate_on_attacks, 0);
  assert.equal(out.binary.confirmed_attack_recall, 0);
  assert.equal(out.binary.precision_of_alerts, null);
});
test('phát hiện kết luận sạch khi chưa bao phủ đủ hoặc có lỗi', () => {
  const out = metrics([{ label: 'benign', verdict: 'not_detected', processing: 'completed', coverage_limited: true, seconds: 1 }]);
  assert.equal(out.forbidden_clean_with_incomplete_review, 1);
});
