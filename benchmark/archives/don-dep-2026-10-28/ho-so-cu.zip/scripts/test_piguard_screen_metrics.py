"""Kiểm cổng score và kiến trúc local; không inference model tải về."""
import unittest
from piguard_screen_metrics import choose_threshold, metrics


class MetricTests(unittest.TestCase):
    def rows(self):
        return [{'role': 'calibration', 'expected': 'confirmed', 'valid': True, 'score': 0.8},
                {'role': 'calibration', 'expected': 'dismissed', 'valid': True, 'score': 0.1}]

    def test_select_only_calibration_and_highest_eligible(self):
        self.assertEqual(choose_threshold(self.rows(), [0.2, 0.5, 0.9])[0], 0.5)
        rows = self.rows()
        rows[0]['role'] = 'reserved_diagnostic'
        with self.assertRaises(ValueError):
            choose_threshold(rows, [0.5])

    def test_invalid_response_never_becomes_true_negative(self):
        rows = self.rows()
        rows[1]['valid'] = False
        self.assertEqual(metrics(rows, 0.5)['tn'], 0)
        self.assertIsNone(choose_threshold(rows, [0.5])[0])

    def test_uncertain_not_binary_and_empty_metrics_undefined(self):
        rows = self.rows() + [{'role': 'calibration', 'expected': 'uncertain', 'valid': True, 'score': 0.9}]
        self.assertEqual(metrics(rows, 0.5)['binary'], 2)
        self.assertEqual(metrics(rows, 0.5)['uncertain_routed'], 1)
        self.assertIsNone(metrics([], 0.5)['fpr'])
        self.assertIsNone(metrics([], 0.5)['precision'])


if __name__ == '__main__':
    unittest.main()
