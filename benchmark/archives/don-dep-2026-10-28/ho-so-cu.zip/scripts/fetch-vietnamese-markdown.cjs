// Chỉ tải văn bản nguồn và license, không chạy Jekyll hoặc lệnh trong tài liệu.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const repository = 'OEVIETNAM/markdown-vietnamese';
const revision = '9dc578935b93ab0de69051d65be837b9e08cb572';
async function get(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(30000) });
  if (!response.ok || Number(response.headers.get('content-length')) > 1024*1024) throw new Error('Nguồn lỗi hoặc vượt giới hạn 1 MiB.');
  const chunks = []; let count = 0;
  const reader = response.body.getReader();
  while (true) { const { done, value } = await reader.read(); if (done) break; count += value.length;
    if (count > 1024*1024) { await reader.cancel(); throw new Error('Vượt ngân sách tải.'); } chunks.push(Buffer.from(value)); }
  return Buffer.concat(chunks);
}
async function main() {
  const out = path.join(root, 'benchmark/data/raw/vietnamese-markdown-v1');
  if (fs.existsSync(out)) throw new Error('Snapshot đã có; không ghi đè.');
  const files = ['README.md', 'LICENSE', 'LICENSE-CODE', 'TRANSLATION_STATUS.md',
    ...['headings', 'code', 'links', 'blockquotes', 'escaping-characters', 'html'].map(s => `_basic-syntax/${s}.md`)];
  const metadata = await get(`https://api.github.com/repos/${repository}/git/trees/${revision}?recursive=1`);
  const tree = JSON.parse(metadata);
  if (tree.sha !== revision || tree.truncated) throw new Error('Không xác minh được tree commit.');
  const assets = new Map([['tree.json', metadata]]), inventory = {};
  for (const file of files) {
    const url = `https://raw.githubusercontent.com/${repository}/${revision}/${file}`;
    const bytes = await get(url), entry = tree.tree.find(e => e.path === file && e.type === 'blob');
    if (!entry || entry.size !== bytes.length) throw new Error('Kích thước khác tree nguồn.');
    assets.set(file, bytes); inventory[file] = { url, bytes: bytes.length, sha256: hash(bytes), git_blob_sha: entry.sha };
  }
  const readme = assets.get('README.md').toString('utf8');
  if (!readme.includes('Creative Commons Attribution-ShareAlike 4.0') || !assets.get('LICENSE').toString().includes('Attribution-ShareAlike 4.0')) throw new Error('Thiếu bằng chứng license nội dung.');
  const attribution = `# Ghi công nguồn Markdown tiếng Việt\n\nNguồn: https://github.com/${repository}/tree/${revision}\n\nBản dịch cộng đồng của Markdown Guide; nguồn gốc upstream: Matt Cone và\ncác cộng tác viên Markdown Guide (https://www.markdownguide.org/).\nLịch sử đóng góp bản dịch: https://github.com/${repository}/commits/${revision}/\n\nNội dung: CC BY-SA 4.0 theo README và LICENSE đã lưu. LICENSE-CODE (MIT)\nchỉ dành cho mã hiển thị, không thay license của văn bản. Giữ thông báo\nlicense/ghi công khi tạo bản trích hoặc biến thể; ghi riêng phần thêm/sửa.\nKhông ngụ ý tác giả gốc bảo trợ hoặc đã xác nhận mẫu IPI của dự án.\n\nĐây là snapshot sáu file hướng dẫn, không phải bản dịch chính thức được\nxác nhận bởi tác giả upstream. Chưa gán sạch toàn file, chưa train hoặc\nxác minh độc lập ngữ nghĩa. Ảnh/liên kết ngoài không được tải hoặc thực thi.\n`;
  assets.set('GHI-CONG.md', Buffer.from(attribution));
  const snapshot = { repository: `https://github.com/${repository}`, revision,
    retrieved_at: new Date().toISOString(), upstream: 'https://github.com/mattcone/markdown-guide',
    community_translation_not_official_endorsement: true, text_license_declared: 'CC-BY-SA-4.0',
    code_license_separate: 'MIT', license_evidence: ['README.md', 'LICENSE', 'LICENSE-CODE'],
    attribution_file: 'GHI-CONG.md', assets: inventory,
    bytes_saved: [...assets.values()].reduce((n, b) => n+b.length, 0), training_eligible: false,
    independent_holdout_verified: false, source_code_executed: false, model_called: false,
    code_sha256: hash(fs.readFileSync(__filename)) };
  fs.mkdirSync(out, { recursive: true });
  for (const [file, bytes] of assets) { const target = path.join(out, file); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, bytes, { flag: 'wx' }); }
  fs.writeFileSync(path.join(out, 'snapshot.json'), JSON.stringify(snapshot, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ files: files.length, revision, bytes: snapshot.bytes_saved }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
