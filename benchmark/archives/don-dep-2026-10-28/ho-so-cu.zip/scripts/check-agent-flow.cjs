// Đo luồng sản phẩm với model local và dữ liệu dev hiện có; không sửa cấu hình theo kết quả.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const { metrics } = require('./priority-one-metrics.cjs');
const { checkCitations } = require('./round-one-metrics.cjs');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');
const root = path.resolve(__dirname, '..');
const load = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
const lines = file => fs.readFileSync(path.join(root, file), 'utf8').trim().split(/\r?\n/).map(JSON.parse);
async function main() {
  const get = async endpoint => {
    const response = await fetch('http://127.0.0.1:11434' + endpoint, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw Error(`Ollama HTTP ${response.status}`);
    return response.json();
  };
  const models = ['gemma3:1b', 'qwen2.5-coder:1.5b'];
  const tags = await get('/api/tags'), version = await get('/api/version');
  for (const model of models) if (!tags.models.some(row => row.name === model)) throw Error(`Thiếu ${model}`);
  const cases = [];
  for (const row of load('benchmark/kiem-thu/01-mau-nhanh/doi-chieu.json').records) cases.push({
    source: 'local-fixtures', group_id: row.source, language: row.source.includes('/vi-') ? 'vi' : 'en', label: row.expected_label,
    text: fs.readFileSync(path.join(root, 'benchmark/kiem-thu', row.file), 'utf8'), format: path.extname(row.file), original: row.source });
  const realistic = 'benchmark/data/processed/realistic-prompt-injections/realistic-prompt-injections.jsonl';
  for (const row of lines(realistic).filter(row => ['ipi', 'benign_control'].includes(row.attack_scope))) cases.push({
    source: 'realistic-prompt-injections', group_id: row.id, language: 'en', label: row.label, text: row.text, format: '.txt', original: row.id });
  const notinject = 'benchmark/data/processed/notinject/notinject.jsonl';
  for (const row of lines(notinject).slice(0, 4)) cases.push({ source: 'notinject', group_id: row.id, language: 'en',
    label: row.label, text: row.text, format: '.txt', original: row.id });
  const dev = load('benchmark/data/priority-one-dev-v2.json');
  for (const language of ['vi', 'en']) for (const label of ['benign', 'malicious', 'uncertain']) {
    const row = dev.cases.find(row => row.language === language && row.expected_label === label);
    if (row) cases.push({ source: 'priority-one-dev', group_id: row.group_id, language, label, text: row.text,
      format: row.format, original: row.original_id });
  }
  cases.forEach((row, index) => { row.id = `case-${String(index + 1).padStart(3, '0')}`; row.input_sha256 = hash(Buffer.from(row.text)); });
  const files = ['scripts/check-agent-flow.cjs', 'scripts/priority-one-metrics.cjs', 'scripts/round-one-metrics.cjs',
    'src/types.ts', 'src/ai/agents/slmClient.ts', 'src/ai/agents/slmCatalog.ts', realistic, notinject,
    'benchmark/data/priority-one-dev-v2.json', 'benchmark/kiem-thu/01-mau-nhanh/doi-chieu.json',
    ...fs.readdirSync(path.join(root, 'src/ai/agents/document')).filter(name => name.endsWith('.ts')).map(name => `src/ai/agents/document/${name}`)];
  for (const folder of ['engine/scanner', 'engine/document', 'engine/prefilter', 'engine/config']) {
    for (const file of fs.readdirSync(path.join(root, folder), { recursive: true })) if (file.endsWith('.js')) files.push(`${folder}/${file.replaceAll('\\', '/')}`);
  }
  const fingerprints = () => Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(path.join(root, file)))]));
  const frozen = fingerprints();
  const out = fs.mkdtempSync(path.join(root, 'benchmark/results/agent-flow-'));
  const save = (name, value) => fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2));
  const plan = { created_at: new Date().toISOString(), command: 'node scripts/check-agent-flow.cjs', cases,
    models: tags, ollama: version, node: process.version, code_sha256: frozen,
    configuration: { reviewContract: 'classic-v1', verifierOutput: 'standard', scanProfile: 'balanced', analysisTimeoutMs: 180000, requestTimeoutMs: 45000, seed: 42, temperature: 0 },
    selection: '6 fixture + strict IPI/benign Realistic + 4 NotInject đầu + ca đầu theo language/label trong dev72; chọn trước suy luận, không chọn lại theo kết quả.',
    budget: { maximum_chat_requests: 140, training_runs: 0, downloads: 0, retries: 0 },
    limits: ['Dev/fixture đã dùng, không phải holdout độc lập.', 'Chỉ text của sample được gửi qua file tên trung tính, không gửi ID/nhãn/đáp án.',
      'Model qua HTTP local, chưa UI/native IPC.', 'PDF/DOCX dài chỉ kiểm extraction/selection, không đo model toàn bộ.',
      'Không kiểm đúng ngữ cảnh bằng JSON hoặc exact quote đơn thuần.'] };
  save('giao-thuc.json', plan);
  const calls = [], rows = [];
  let active = null;
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, optimizeDeps: { noDiscovery: true }, appType: 'custom' });
  const summarize = status => ({ status, total: cases.length, completed: rows.length, calls: calls.length,
    metrics: metrics(rows), by_source: Object.fromEntries([...new Set(rows.map(row => row.source))].map(source => [source, metrics(rows.filter(row => row.source === source))])),
    by_group: Object.fromEntries([...new Set(rows.map(row => row.group_id))].map(group => [group, metrics(rows.filter(row => row.group_id === group))])),
    by_language: Object.fromEntries([...new Set(rows.map(row => row.language))].map(language => [language, metrics(rows.filter(row => row.language === language))])),
    source_code_unchanged: JSON.stringify(frozen) === JSON.stringify(fingerprints()),
    pipeline_seconds_p95: rows.length ? rows.map(row => row.seconds).sort((a,b) => a-b)[Math.ceil(rows.length*.95)-1] : null,
    harness_rss_bytes: process.memoryUsage().rss, resource_note: 'RSS là snapshot Node; Ollama ps từng call không phải peak GPU.',
    limits: plan.limits, priority_one_complete: false });
  const saveProgress = status => { save('cases.json', rows); save('model-calls.json', calls); save('tong-hop.json', summarize(status)); };
  try {
    const { runIpiDocumentPipeline } = await server.ssrLoadModule('/src/ai/agents/document/ipiPipeline.ts');
    globalThis.owaspWorkbench = {
      scanIpiDoc: (files, scanProfile) => runIpiDocScan(files, { scanProfile }),
      aiFetch: async payload => {
        if (new URL(payload.url).origin !== 'http://127.0.0.1:11434') throw Error('Chỉ local Ollama.');
        const body = JSON.parse(payload.body), chat = payload.url.includes('/chat/completions');
        if (chat) {
          if (calls.length >= 140 || !models.includes(body.model)) throw Error('Vượt ngân sách/model đã khóa.');
          body.seed = 42;
        }
        const start = performance.now();
        try {
          const response = await fetch(payload.url, { method: payload.method || 'POST', headers: payload.headers,
            body: JSON.stringify(body), signal: AbortSignal.timeout(payload.timeoutMs || 45000) });
          const raw = await response.text();
          if (chat) calls.push({ case_id: active.id, model: body.model, request: body, response: raw, status: response.status,
            seconds: (performance.now() - start)/1000, resources: await get('/api/ps').catch(() => null) });
          return { ok: response.ok, status: response.status, body: raw };
        } catch (error) {
          if (chat) calls.push({ case_id: active.id, model: body.model, request: body, error: error.message, seconds: (performance.now()-start)/1000 });
          return { ok: false, status: 0, body: '', error: error.message };
        }
      },
    };
    fs.mkdirSync(path.join(out, 'input'));
    console.log(JSON.stringify({ output: out, cases: cases.length }));
    for (const item of cases) {
      active = item;
      const file = path.join(out, 'input', 'document' + item.format);
      fs.writeFileSync(file, item.text);
      const start = performance.now();
      const state = await runIpiDocumentPipeline({ filePaths: [file], fixModel: models[0], checkModel: models[1], ...plan.configuration });
      const progress = state.reviewProgress;
      const complete = progress && progress.selectedChunkIds.every(id => progress.detectorReviewedChunkIds.includes(id) && progress.verifierReviewedChunkIds.includes(id));
      rows.push({ id: item.id, source: item.source, group_id: item.group_id, language: item.language, label: item.label,
        verdict: state.check?.verdict, processing: state.processingStatus, coverage_limited: state.scanResult?.metadata.coverage?.coverageLimited !== false || !complete,
        agent_uncertain: state.suspicions.some(row => row.detector?.stance === 'uncertain' || row.verifier?.stance === 'uncertain'),
        seconds: (performance.now()-start)/1000, citations: checkCitations(state), state });
      saveProgress('running');
      console.log(JSON.stringify({ done: rows.length, total: cases.length, id: item.id, source: item.source, expected: item.label,
        verdict: state.check?.verdict, processing: state.processingStatus, failures: state.batchFailures?.length || 0 }));
    }
    const documents = load('benchmark/kiem-thu/03-pdf-docx/doi-chieu.json').records;
    const extraction = [];
    for (const row of documents) {
      const start = performance.now();
      const scan = await runIpiDocScan([path.join(root, 'benchmark/kiem-thu', row.file)], { scanProfile: 'deep' });
      extraction.push({ file: row.file, expected_label: null, seconds: (performance.now()-start)/1000, scan });
    }
    const combined = await runIpiDocScan(documents.map(row => path.join(root, 'benchmark/kiem-thu', row.file)), { scanProfile: 'deep' });
    save('extraction-documents.json', { individual: extraction, combined, model_review_performed: false });
    const after = await get('/api/tags');
    if (models.some(name => tags.models.find(row => row.name === name).digest !== after.models.find(row => row.name === name)?.digest)) throw Error('Model digest đã đổi trong phép đo.');
    if (JSON.stringify(frozen) !== JSON.stringify(fingerprints())) throw Error('Code/nguồn đã đổi trong phép đo.');
    saveProgress('complete');
    console.log(JSON.stringify({ complete: true, output: out, calls: calls.length }));
  } catch (error) {
    saveProgress('failed'); save('loi.json', { error: error.message }); throw error;
  } finally { delete globalThis.owaspWorkbench; await server.close(); }
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
