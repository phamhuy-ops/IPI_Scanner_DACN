const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { resolveRecord, checkRoles } = require('./prepare-verifier-split-preview.cjs');
const load = () => fs.readFileSync('benchmark/experiments/verifier-eligibility-v12/registry.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
const ledger = () => JSON.parse(fs.readFileSync('benchmark/experiments/verifier-split-proposal-v1/dieu-kien-tung-nhom.json'));
test('Tìm đúng nhãn hiệu lực cả bản người duyệt và bản AI hiệu chỉnh', () => {
  const rows = load();
  for (const record of [rows.find(r => r.reviewer_scope === 'human_visible_source'), rows.find(r => r.effective_version === 'external_uncertain_semantic_rereview_v1')]) {
    const result = resolveRecord(record, file => fs.readFileSync(file));
    assert.equal(result.annotation.stance, record.stance);
  }
  const bad = { ...rows[0], effective_annotation_sha256: 'stale' };
  assert.throws(() => resolveRecord(bad, file => fs.readFileSync(file)), /khớp/);
});
test('Không cho đổi vai trò dev hoặc tách nhóm khi dựng bản xuất', () => {
  const rows = load(), good = ledger();
  assert.equal(checkRoles(rows, good).size, 123);
  const bad = ledger(); bad.groups.find(g => g.proposed_role === 'dev').proposed_role = 'train';
  assert.throws(() => checkRoles(rows, bad), /lọt/);
  const partial = ledger(); partial.groups[0].member_ids.pop();
  assert.throws(() => checkRoles(rows, partial), /bị tách/);
});
