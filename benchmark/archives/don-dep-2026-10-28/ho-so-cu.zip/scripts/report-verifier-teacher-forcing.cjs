// Điểm token có tiền tố gold không được trình bày thành độ đúng phân loại.
const fs = require('node:fs');
const base = 'benchmark/experiments/verifier-teacher-forcing-v1';
function main() {
  if (fs.existsSync(`${base}/chan-doan.json`)) throw new Error('Không ghi đè chẩn đoán.');
  const result = JSON.parse(fs.readFileSync(`${base}/ket-qua.json`));
  const generation = JSON.parse(fs.readFileSync('benchmark/experiments/verifier-candidate02-eval-screen-v1/tong-hop.json'));
  const rows = [];
  for (const role of ['train', 'dev_screen']) {
    const off = result.summaries.off[role], on = result.summaries.on[role];
    rows.push({ role, reason_token_fraction: on.reason.tokens / on.all.tokens,
      reason_nll_fraction_off: off.reason.nll_sum / off.all.nll_sum,
      reason_nll_fraction_on: on.reason.nll_sum / on.all.nll_sum,
      fields: Object.fromEntries(['all', 'structure_or_eos', 'addressee', 'framing', 'deviation', 'stance', 'reason'].map(k => [k, {
        tokens: on[k].tokens, off_mean_nll: off[k].mean_nll, on_mean_nll: on[k].mean_nll,
        off_gold_prefix_token_accuracy: off[k].gold_prefix_token_accuracy, on_gold_prefix_token_accuracy: on[k].gold_prefix_token_accuracy,
      }])) });
  }
  const report = { diagnostic: rows, generation_screen: generation.candidate02_on,
    claims_not_supported: ['Chưa thể kết luận overfit từ hai tập khác phân bố.', 'Không dùng token accuracy làm stance accuracy.',
      'Không suy rằng giảm loss lý do sẽ cải thiện bảo mật hoặc tăng epoch sẽ giải quyết lỗi.',
      'Gold trước stance đã chứa người nhận/ngữ cảnh/độ lệch đúng; điểm stance có điều kiện không chứng minh tự nhận diện được các trường này.'],
    recommended_next: 'Đo đối chứng trên cùng dev nhỏ: cung cấp các trường ngữ cảnh gold để kiểm tra ánh xạ stance, và so với cấu hình tự suy các trường. Chỉ là diagnostic có oracle, không tích hợp hoặc báo như hiệu quả sản phẩm; chưa train ứng viên thứ ba.',
    runtime_changed: false, training_started: false, independent_validation_complete: false };
  fs.writeFileSync(`${base}/chan-doan.json`, JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
}
if (require.main === module) main();
