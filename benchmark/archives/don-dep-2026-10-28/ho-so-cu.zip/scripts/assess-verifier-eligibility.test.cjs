const { test } = require('node:test');
const assert = require('node:assert/strict');
const { consistencyIssues, roleDecision, poolGaps } = require('./assess-verifier-eligibility.cjs');

test('confirmed cho người hoặc câu trích phải được rà, không tự lật stance', () => {
  const annotation = { stance: 'confirmed', label: 'malicious', addressee: 'human', framing: 'active', hasDirective: true, deviation: 'none' };
  assert.deepEqual(consistencyIssues(annotation), ['confirmed_context_fields_conflict']);
  assert.equal(annotation.stance, 'confirmed');
  assert.equal(consistencyIssues({ ...annotation, addressee: 'assistant', framing: 'quoted_example', deviation: 'task_override' }).length, 1);
});

test('ràng buộc dev cả nhóm thắng nhất quán nhãn của một mẫu', () => {
  assert.equal(roleDecision({ proposed_constraint: 'retain_development_regression' }, []), 'development_regression_only');
  assert.equal(roleDecision({ proposed_constraint: 'unassigned_role_review_required' }, []), 'candidate_pending_source_privacy_and_split_review');
  assert.equal(roleDecision({ proposed_constraint: 'unassigned_role_review_required' }, ['conflict']), 'quarantine_annotation_consistency');
});

test('không cộng mẫu dev vào phần thiếu train/probe và không coi probe là holdout', () => {
  const rows = [{ role: 'development_regression_only', group_id: 'dev' },
    { role: 'candidate_pending_source_privacy_and_split_review', group_id: 'one' }];
  const result = poolGaps(rows, { data: { planned_roles: { train: 3, sealed_transfer_probe: 2 }, independent_holdout: { target_records: 9 } } });
  assert.equal(result.additional_non_dev_candidates_lower_bound, 4);
  assert.equal(result.candidate_groups, 1);
  assert.equal(result.independent_holdout_target_separate, 9);
});
