// Sửa lỗi chèn giữa dòng trong fixture tự soạn; không sửa nguồn v1 hoặc detector.
const fs = require('node:fs');
const path = require('node:path');
const { hash, span, validateAnnotation } = require('./context-annotations.cjs');
const { makeWindows } = require('./normalize-verifier-gap.cjs');
const root = path.resolve(__dirname, '..');
function repairRow(row, globalGroupId) {
  const original = row.text, focus = row.draft_annotation.directive_spans[0];
  if (validateAnnotation(original, row.draft_annotation).length) throw new Error('Sai bằng chứng nguồn.');
  const lines = original.split('\n');
  const index = focus.start_line - 1;
  if (focus.start_line !== focus.end_line || !lines[index]?.includes(focus.quote) || index < 1 || index >= lines.length - 1) throw new Error('Không xác định được dòng bị chèn.');
  const previous = lines[index - 1], following = lines[index + 1], inserted = lines[index];
  if (!/[\p{L}\p{N}]$/u.test(previous) || !/^[\p{L}\p{N}]/u.test(following)) throw new Error('Không có dấu hiệu ngắt giữa từ, cần rà riêng.');
  const repairedLines = [...lines];
  repairedLines.splice(index - 1, 3, previous + following, inserted);
  const text = repairedLines.join('\n');
  const annotation = { ...row.draft_annotation, directive_spans: [span(text, focus.quote)], context_spans: [span(text, text)] };
  if (validateAnnotation(text, annotation).length) throw new Error('Sai span sau sửa.');
  // So toàn bộ văn bản nền và nguyên dòng bao khung, không chỉ so từ trọng tâm.
  const expectedBackground = [...lines.slice(0, index - 1), previous + following, ...lines.slice(index + 2)].join('\n');
  const newIndex = annotation.directive_spans[0].start_line - 1;
  if (repairedLines[newIndex] !== inserted || repairedLines.filter((_, i) => i !== newIndex).join('\n') !== expectedBackground) throw new Error('Sửa làm đổi nội dung ngoài phép chuyển dòng.');
  const offsets = []; let cursor = 0;
  for (const line of repairedLines) { offsets.push(cursor); cursor += line.length + 1; }
  const first = Math.max(0, newIndex - 1), last = Math.min(repairedLines.length - 1, newIndex + 1);
  const start = offsets[first], end = offsets[last] + repairedLines[last].length;
  const selected = { start, end, text: text.slice(start, end), start_line: first + 1, end_line: last + 1 };
  if (selected.text.length > 900) throw new Error('Ngữ cảnh trước/sau vượt ngân sách, không cắt ngầm.');
  const local = { ...annotation, directive_spans: [span(selected.text, focus.quote)], context_spans: [span(selected.text, selected.text)] };
  if (validateAnnotation(selected.text, local).length) throw new Error('Sai span cửa sổ mới.');
  return { id: row.id, text, format: row.format, language: row.language, group_id: globalGroupId,
    parent_source_id: `verifier-gap-v1:${row.id}`, parent_source_sha256: row.input_sha256,
    input_sha256: hash(Buffer.from(text)), annotation_original: annotation, window_annotation: local,
    selected_window: selected, selected_window_id: 'context-window-1', windows: makeWindows(text),
    semantic_review_origin: 'ai', original_stance_review_origin: 'human_on_parent_version',
    human_reviewed_repaired_text: false, training_eligible: false, split: null,
    provenance: { ...row.provenance, source: 'authored_gap_repair_v1', independent: false, parent_source_id: `verifier-gap-v1:${row.id}` },
    repair: { method: 'join_background_halves_move_unchanged_focus_line_after_completed_paragraph',
      background_content_preserved: true, focus_and_framing_line_unchanged: true, original_label_unchanged: true,
      neighboring_lines_preserved_in_selected_window: true } };
}
async function main() {
  const oldDir = path.join(root, 'benchmark/data/annotations/verifier-gap-normalized-v1');
  const originalFile = path.join(root, 'benchmark/data/annotations/verifier-gap-v1/mau-cho-duyet.jsonl');
  const output = path.join(root, 'benchmark/data/annotations/verifier-gap-repair-v1');
  if (fs.existsSync(output)) throw new Error('Không ghi đè bản sửa đã tồn tại.');
  const quality = JSON.parse(fs.readFileSync(path.join(oldDir, 'canh-bao-chat-luong.json')));
  const groups = JSON.parse(fs.readFileSync(path.join(oldDir, 'tong-ket-nhom.json'))).source_window_groups;
  const originals = fs.readFileSync(originalFile, 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const rows = quality.affected_source_ids.map(id => {
    const original = originals.find(r => r.id === id), group = groups.find(g => g.source_record_id === id);
    if (!original || !group) throw new Error('Thiếu nguồn/nhóm gốc.');
    return repairRow(original, group.global_group_id);
  });
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  const examples = [];
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of rows) for (const mode of ['whole_source', 'none']) {
      const result = renderDraft({ text: row.selected_window.text, format: row.format, candidate_mode: mode }, row.window_annotation);
      examples.push({ id: `${row.id}-${mode}`, source_record_id: row.id, group_id: row.group_id, window_id: row.selected_window_id,
        mode, payload: result.payload, target: result.response, validation: result.validation, training_eligible: false });
    }
  } finally { await server.close(); }
  const assets = new Map([
    ['nhan-va-cua-so.jsonl', rows.map(row => JSON.stringify(row)).join('\n') + '\n'],
    ['ban-xem-truoc.json', JSON.stringify({ training_export: false, examples }, null, 2) + '\n'],
  ]);
  for (const row of rows) assets.set(`van-ban/${row.id}${row.format}`, row.text);
  const manifest = { source_versions: rows.length, additional_independent_sources: 0, contract_examples: examples.length,
    parser_valid: examples.filter(e => e.validation.parser_valid).length, review_origin: 'ai',
    parent_human_review_applies_to_original_version_only: true, training_ready: false, final_split_created: false,
    source_sha256: { original_rows: hash(fs.readFileSync(originalFile)), quality: hash(fs.readFileSync(path.join(oldDir, 'canh-bao-chat-luong.json'))), groups: hash(fs.readFileSync(path.join(oldDir, 'tong-ket-nhom.json'))) },
    code_sha256: Object.fromEntries(['scripts/repair-verifier-gap.cjs', 'scripts/normalize-verifier-gap.cjs', 'scripts/verifier-batch-renderer.ts'].map(p => [p, hash(fs.readFileSync(path.join(root, p)))])),
    assets_sha256: Object.fromEntries([...assets].map(([p, value]) => [p, hash(Buffer.from(value))])),
    limitations: ['Bản sửa tự soạn được AI đánh giá, không phải nhãn người dùng mới hoặc nguồn độc lập.',
      'Cửa sổ chọn theo bằng chứng đã biết; chưa phải đo selector hoặc model.', 'Chưa kiểm tra collator/backend hoặc nguồn holdout.'] };
  assets.set('manifest.json', JSON.stringify(manifest, null, 2) + '\n');
  for (const [file, content] of assets) { const p = path.join(output, file); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, content); }
  console.log(JSON.stringify({ source_versions: rows.length, parser_valid: manifest.parser_valid, additional_independent_sources: 0 }));
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { repairRow };
