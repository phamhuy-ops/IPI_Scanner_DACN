const fs = require('node:fs');
const assert = require('node:assert/strict');
const { test } = require('node:test');
const { buildReview } = require('./review-verifier-authored-pool.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
const load = () => fs.readFileSync('benchmark/experiments/verifier-eligibility-v7/registry.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
test('Rà đúng 47 ứng viên, giữ stance và nhóm, sửa riêng 13 framing', () => {
  const registry = load(), before = JSON.stringify(registry);
  const { rows, reviews } = buildReview(registry);
  assert.equal(JSON.stringify(registry), before);
  assert.equal(rows.length, 47);
  assert.equal(reviews.filter(r => r.decision === 'revise_framing_only').length, 13);
  for (const row of rows) {
    const old = registry.find(r => r.id === row.id);
    assert.equal(row.annotation.stance, old.stance);
    assert.equal(row.group_id, old.group_id);
    assert.equal(row.input_sha256, old.effective_input_sha256);
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.training_eligible, false);
    assert.equal(row.split, null);
  }
  assert.ok(reviews.every(r => !r.independent_review && !r.human_approved));
});
test('Từ chối nhãn nền sai hash hoặc thiếu phạm vi đã đọc', () => {
  const rows = load();
  rows.find(r => r.source === 'verifier-gap-v1').effective_annotation_sha256 = 'stale';
  assert.throws(() => buildReview(rows), /nguồn\/nhãn/);
  assert.throws(() => buildReview(load().filter(r => r.source !== 'verifier-gap-v1')), /47/);
});
