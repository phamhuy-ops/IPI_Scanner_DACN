"""Chuẩn bị hàng chờ nhãn và bản chia dự kiến; không xuất train hoặc gọi model."""
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'benchmark/data/annotations/verifier-expansion-v1'
SEED = 42


def digest(value):
    return hashlib.sha256(value).hexdigest()


def normalized(text):
    return ' '.join(unicodedata.normalize('NFKC', text).casefold().split())


def shingles(text):
    tokens = re.findall(r'[^\W_]+', normalized(text), re.UNICODE)
    return set(zip(tokens, tokens[1:], tokens[2:]))


def cluster(records):
    """Gom nhóm đã biết, trùng chuẩn hóa và Jaccard trigram >= 0.8."""
    parents = list(range(len(records)))

    def find(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parents[max(a, b)] = min(a, b)

    exact, known = {}, {}
    edges = []
    grams = [shingles(row['text']) for row in records]
    for i, row in enumerate(records):
        key = normalized(row['text'])
        if key in exact:
            union(i, exact[key]); edges.append([exact[key], i, 'normalized_exact'])
        else:
            exact[key] = i
        key = row.get('known_group')
        if key:
            if key in known:
                union(i, known[key]); edges.append([known[key], i, 'known_family'])
            else:
                known[key] = i
        for j in range(i):
            a, b = grams[i], grams[j]
            if min(len(a), len(b)) < 4 or min(len(a), len(b)) < 0.8 * max(len(a), len(b)):
                continue
            score = len(a & b) / len(a | b)
            if score >= 0.8:
                union(i, j); edges.append([j, i, 'trigram_jaccard', round(score, 6)])
    components = defaultdict(list)
    for i in range(len(records)):
        components[find(i)].append(i)
    groups = []
    for members in components.values():
        key = '\n'.join(sorted(records[i]['id'] for i in members))
        group = 'vg-' + digest(key.encode())[:16]
        has_legacy = any(records[i]['role'] == 'legacy_reference' for i in members)
        has_reviewed = any(records[i]['role'] == 'reviewed_pilot_dev' for i in members)
        bucket = int(digest(f'{SEED}:{group}'.encode())[:8], 16) % 100
        proposal = 'reference_only' if has_legacy else 'dev_regression_only' if has_reviewed else (
            'train_candidate' if bucket < 60 else 'dev_candidate' if bucket < 80 else 'transfer_probe_candidate')
        for i in members:
            records[i]['group_id'] = group
            records[i]['proposed_role'] = proposal
        groups.append({'id': group, 'members': [records[i]['id'] for i in members], 'size': len(members),
                       'proposed_role': proposal, 'contains_legacy': has_legacy, 'contains_reviewed_pilot': has_reviewed})
    return groups, edges


def read_jsonl(file):
    raw = file.read_bytes()
    if raw.startswith(b'version https://git-lfs.github.com/spec/v1'):
        raise ValueError(f'Chưa tải nội dung Git LFS: {file}')
    return [json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]


def main():
    if OUT.exists():
        raise ValueError('Thư mục đã tồn tại; không ghi đè hàng chờ hoặc quyết định.')
    files = {}

    def track(relative):
        file = ROOT / relative
        files[relative] = digest(file.read_bytes())
        return file

    records = []
    for folder, role in [('ngu-canh-v1', 'legacy_reference'), ('verifier-batch-v1', 'reviewed_pilot_dev')]:
        prefix = f'benchmark/data/annotations/{folder}/'
        for row in read_jsonl(track(prefix + 'mau-cho-duyet.jsonl')):
            records.append({'id': f'{folder}:{row["id"]}', 'text': row['text'], 'role': role,
                            'known_group': f'{folder}:{row["group_id"]}', 'source': row['provenance']['source'],
                            'source_id': row['id'], 'language': row.get('language'), 'source_label': None,
                            'annotation': None, 'review_status': 'existing_reference_do_not_relabel', 'split': None})
    overlap = json.loads(track('benchmark/data/audits/cross-source-overlap.json').read_text(encoding='utf-8'))
    sources = [('notinject', 'notinject/notinject.jsonl', 'notinject-audit.json'),
               ('realistic', 'realistic-prompt-injections/realistic-prompt-injections.jsonl', 'realistic-prompt-injections-audit.json')]
    for key, relative, audit_name in sources:
        relative = 'benchmark/data/processed/' + relative
        file = track(relative)
        expected = overlap['input_files'][key]
        if files[relative] != expected['sha256']:
            raise ValueError(f'Nguồn chuẩn hóa khác audit: {relative}')
        audit = json.loads(track('benchmark/data/audits/' + audit_name).read_text(encoding='utf-8'))
        source_rows = read_jsonl(file)
        if len(source_rows) != expected['rows']:
            raise ValueError('Số hàng không khớp audit.')
        for row in source_rows:
            if not isinstance(row.get('text'), str) or not row['text'].strip():
                raise ValueError('Nguồn có văn bản rỗng.')
            raw_file = row['source_file']
            if raw_file not in files:
                track(raw_file)
            if files[raw_file] != row['source_file_sha256']:
                raise ValueError('Raw khác provenance trong dữ liệu chuẩn hóa.')
            records.append({'id': f'exp-{key}-{row["source_row"]:04d}-' + digest(row['id'].encode())[:8],
                            'source_id': row['id'], 'text': row['text'], 'source': row['source'],
                            'role': 'annotation_candidate_from_existing_dev', 'known_group': None,
                            'language': None, 'source_label': row['label'], 'annotation': None,
                            'review_status': 'pending', 'split': None,
                            'provenance': {'source_file': raw_file, 'source_file_sha256': row['source_file_sha256'],
                                           'source_row': row['source_row'], 'normalized_file': relative,
                                           'license_declared': audit['license_declared_in_local_card'],
                                           'attack_scope': row['attack_scope'],
                                           'prior_use': 'development_probe_not_independent',
                                           'label_basis': row['metadata']['label_basis']}})
    if len({row['id'] for row in records}) != len(records):
        raise ValueError('ID trùng.')
    groups, edges = cluster(records)
    candidates = [r for r in records if r['role'] == 'annotation_candidate_from_existing_dev']
    # Chọn lượt duyệt đầu trải đều nguồn; không chọn theo kết quả scanner/model.
    queues = {source: sorted([r for r in candidates if r['source'] == source and r['proposed_role'] != 'reference_only'],
                           key=lambda r: digest(f'{SEED}:{r["id"]}'.encode())) for source in {r['source'] for r in candidates}}
    selected = []
    while len(selected) < 30 and any(queues.values()):
        for source in sorted(queues):
            if queues[source] and len(selected) < 30:
                selected.append(queues[source].pop(0))
    report = {'version': 1, 'seed': SEED, 'script_sha256': digest(Path(__file__).read_bytes()), 'inputs_sha256': files, 'all_records': len(records),
              'new_annotation_candidates': len(candidates), 'known_reference_records': len(records) - len(candidates),
              'candidate_source_labels': dict(Counter(r['source_label'] for r in candidates)),
              'groups': len(groups), 'largest_groups': sorted(groups, key=lambda g: (-g['size'], g['id']))[:10],
              'grouping_edges': len(edges), 'duplicate_edges': dict(Counter(e[2] for e in edges)),
              'proposed_candidate_roles': dict(Counter(r['proposed_role'] for r in candidates)),
              'first_review_batch': len(selected), 'final_split_created': False, 'training_ready': False,
              'independent_holdout': {'status': 'not_collected', 'required_independent_source_families': 2},
              'limitations': ['Các nguồn bổ sung đã dùng làm dev, không phải dữ liệu độc lập.',
                             'Nhãn nguồn nhị phân không chuyển tự động thành nhãn stance/ngữ cảnh.',
                             'Chưa duyệt nguồn mới; chưa kiểm tra ngôn ngữ, chỉ tiêu tiếng Việt và cân bằng nhãn.',
                             'Gom theo nhóm đã biết, trùng NFKC/casefold/whitespace và trigram Jaccard>=0.8; chưa so ngữ nghĩa/bản dịch mới.',
                             'Chỉ kiểm tra trùng giữa 356 ứng viên và 50 mẫu tham chiếu, chưa rà toàn bộ BIPIA/dev/test/fixture.',
                             'Chia role dự kiến theo hash nhóm 60/20/20, không phải tập train/dev/test được phép dùng.',
                             'Nhóm gần trùng suy ra bằng từ vựng, chưa xác minh đầy đủ provenance tài liệu gốc.',
                             'Dữ liệu mới thiên về nhãn nguồn benign và tiếng Anh; chưa đạt kế hoạch pilot.']}
    OUT.mkdir(parents=True)
    write = lambda name, data: (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (OUT / 'hang-cho-gan-nhan.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in candidates), encoding='utf-8')
    write('bao-cao-chuan-bi.json', report)
    write('nhom-va-chia-du-kien.json', {'groups': groups, 'edges': [
        {'left': records[e[0]]['id'], 'right': records[e[1]]['id'], 'method': e[2], 'score': e[3] if len(e) > 3 else None} for e in edges]})
    write('luot-duyet-02.json', {'status': 'pending', 'items': [{'id': r['id'], 'input_sha256': digest(r['text'].encode()),
          'review_status': 'pending', 'annotation': None, 'reviewer': None, 'reviewed_at': None} for r in selected]})
    # Input thuần không có nhãn/ID nguồn; chưa tạo prompt hoặc completion huấn luyện.
    inputs = OUT / 'van-ban'; inputs.mkdir()
    for i, row in enumerate(selected, 1):
        (inputs / f'mau-{i:03d}.txt').write_text(row['text'], encoding='utf-8')
    write('anh-xa-luot-duyet-02.json', [{'file': f'van-ban/mau-{i:03d}.txt', 'id': r['id']} for i, r in enumerate(selected, 1)])
    print(json.dumps({k: report[k] for k in ['all_records', 'new_annotation_candidates', 'groups', 'duplicate_edges', 'proposed_candidate_roles', 'training_ready']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
