"""Đo token và kiểm tra mask trên bản xem trước; không train hoặc tải weights."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
MODEL = 'Qwen/Qwen2.5-1.5B-Instruct'
REVISION = '989aa7980e4cf806f80c7fef2b1adb7bc71aa306'


def completion_example(tokenizer, messages, target):
    # Kiểm tra tiền tố token thực tế; không tìm chuỗi assistant trong nguồn không tin cậy.
    if [m['role'] for m in messages] != ['system', 'user']:
        raise ValueError('Chỉ hỗ trợ một lượt system/user/assistant đã kiểm tra.')
    prefix = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
    ids = tokenizer.apply_chat_template(messages + [{'role': 'assistant', 'content': target}],
                                        tokenize=True, add_generation_prompt=False)
    if ids[:len(prefix)] != prefix:
        raise ValueError('Ranh giới prompt/completion không trùng token; không mask theo độ dài ký tự.')
    tail = ids[len(prefix):]
    if tokenizer.decode(tail, skip_special_tokens=False) != target + tokenizer.eos_token + '\n':
        raise ValueError('Template hoặc đuôi assistant khác dự kiến; cần audit lại.')
    eos_positions = [i for i, token in enumerate(tail) if token == tokenizer.eos_token_id]
    if len(eos_positions) != 1:
        raise ValueError('Đầu ra chứa thêm token điều khiển hoặc thiếu EOS.')
    end = len(prefix) + eos_positions[0] + 1
    labels = [-100] * len(prefix) + ids[len(prefix):end] + [-100] * (len(ids) - end)
    if tokenizer.decode([v for v in labels if v != -100], skip_special_tokens=False) != target + tokenizer.eos_token:
        raise ValueError('Mask không khôi phục đúng toàn bộ JSON và EOS.')
    return ids, labels, len(prefix), end


def pad_example(ids, labels, size, pad_id):
    if size < len(ids):
        raise ValueError('Không được cắt ngầm mẫu vượt ngân sách.')
    count = size - len(ids)
    return ids + [pad_id] * count, labels + [-100] * count, [1] * len(ids) + [0] * count


def main():
    from huggingface_hub import snapshot_download
    from transformers import AutoTokenizer
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    if storage.drive.lower() != 'e:':
        raise ValueError('Audit này yêu cầu môi trường/cache trên E.')
    local = Path(snapshot_download(MODEL, revision=REVISION,
        allow_patterns=['tokenizer.json', 'tokenizer_config.json', 'vocab.json', 'merges.txt'],
        cache_dir=os.environ['HF_HUB_CACHE']))
    tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False)
    source = ROOT / 'benchmark/data/annotations/verifier-external-normalized-v1'
    examples_path = source / 'bien-the-kiem-tra.json'
    examples = json.loads(examples_path.read_text(encoding='utf-8'))
    assets = {str(examples_path.relative_to(ROOT)): hashlib.sha256(examples_path.read_bytes()).hexdigest()}
    preview_path = ROOT / 'benchmark/experiments/verifier-tokenizer-v1/ban-xem-truoc/mau.json'
    preview = json.loads(preview_path.read_text(encoding='utf-8'))
    assets[str(preview_path.relative_to(ROOT))] = hashlib.sha256(preview_path.read_bytes()).hexdigest()
    # Chỉ số corpus ở ngoài messages; không thêm ID/nhóm/nhãn vào input model.
    prepared = []
    for example in examples:
        paths = [source / example[key] for key in ['input_file', 'target_file']]
        for p in paths:
            assets[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
        payload, response = [json.loads(p.read_text(encoding='utf-8')) for p in paths]
        prepared.append((example, payload, response))
    for example in preview['examples']:
        if not example['parser_valid']:
            raise ValueError('Bản xem trước chưa qua parser.')
        prepared.append((example, example['payload'], example['target']))
    rows = []
    for example, payload, response in prepared:
        target = json.dumps(response, ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, payload['messages'], target)
        _, padded_labels, attention = pad_example(ids, labels, len(ids) + 7, tokenizer.pad_token_id)
        assert all(v == -100 for v in labels[:boundary])
        assert padded_labels[-7:] == [-100] * 7 and attention[-7:] == [0] * 7
        rows.append({'id': example['id'], 'source_record_id': example['source_record_id'],
            'group_id': example['group_id'], 'mode': example['mode'], 'tokens': len(ids),
            'prompt_tokens_masked': boundary, 'loss_tokens_json_and_eos': end - boundary,
            'over_1024': len(ids) > 1024, 'mask_valid': True})
    installed = {d.metadata['Name']: d.version for d in importlib.metadata.distributions()}
    output = ROOT / 'benchmark/experiments/verifier-tokenizer-v1'
    output.mkdir(exist_ok=True, parents=True)
    result = {'model': MODEL, 'revision': REVISION, 'tokenizer_snapshot': str(local),
        'tokenizer_assets_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in local.iterdir() if p.is_file()},
        'chat_template_sha256': hashlib.sha256(tokenizer.chat_template.encode()).hexdigest(),
        'template_has_generation_blocks': '{% generation' in tokenizer.chat_template,
        'mask_method': 'verified_token_prefix_then_JSON_and_single_EOS; prompt/header/trailing_newline/padding=-100',
        'schema_note': 'response_format là ràng buộc runtime riêng; audit messages không giả định model học được schema ngoài prompt.',
        'contract_examples': len(rows), 'unique_sources': len({r['source_record_id'] for r in rows}),
        'token_min': min(r['tokens'] for r in rows), 'token_max': max(r['tokens'] for r in rows),
        'over_1024': sum(r['over_1024'] for r in rows), 'mask_valid': sum(r['mask_valid'] for r in rows),
        'no_truncation_performed': True, 'rows': rows, 'input_sha256': assets,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'dependencies': installed, 'python': sys.version, 'weights_downloaded': False,
        'training_started': False, 'training_ready': False,
        'limitations': ['144 biểu diễn của 72 nguồn đã duyệt; chưa audit mẫu mới chờ duyệt hoặc trainer thật.',
            'Mask đúng về token chưa chứng minh nhãn/span đúng ngữ nghĩa.',
            'Mẫu vượt ngân sách phải được xử lý trước train, không truncate ngầm.']}
    (output / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (output / 'phu-thuoc.txt').write_text('\n'.join(f'{k}=={v}' for k, v in sorted(installed.items())) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['contract_examples', 'unique_sources', 'token_min', 'token_max',
        'over_1024', 'mask_valid', 'template_has_generation_blocks', 'training_ready']}, ensure_ascii=False))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
