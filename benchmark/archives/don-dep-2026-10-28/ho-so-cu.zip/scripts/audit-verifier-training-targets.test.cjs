const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {analyze}=require('./audit-verifier-training-targets.cjs');
function data(){const b='benchmark/experiments/verifier-counterfactual-train-v2/';const read=f=>fs.readFileSync(b+f,'utf8').trim().split(/\r?\n/).map(JSON.parse);return [read('mau-cho-duyet.jsonl'),read('train.preview.jsonl')];}
test('Không đánh target rỗng hợp lệ thành lỗi nhãn hoặc leak enum trong system',()=>{
 const [rows,examples]=data();const r=analyze(rows,examples);
 assert.equal(r.structural_errors.length,0);assert.equal(r.metadata_leaks.length,0);assert.ok(r.empty_targets>0);
 assert.equal(r.with_explicit_context_fields+r.empty_targets,360);
});
test('Bắt mâu thuẫn target và metadata thật trong input',()=>{
 const [rows,examples]=data();const e=examples.find(e=>e.target.assessments.some(a=>a.stance==='confirmed'));
 e.target.assessments[0].addressee='human';e.payload.messages[1].content+=' '+e.source_record_id;
 const r=analyze(rows,examples);assert.ok(r.structural_errors.some(r=>r.error.includes('mâu thuẫn')));assert.ok(r.metadata_leaks.length>0);
});
