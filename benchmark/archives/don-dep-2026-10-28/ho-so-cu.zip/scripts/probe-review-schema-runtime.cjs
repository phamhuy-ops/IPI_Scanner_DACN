// Đối chứng khả năng cưỡng chế schema của runtime local, không chấm nhận diện.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
async function main() {
  const out = fs.mkdtempSync(path.join(root, 'benchmark/results/schema-runtime-'));
  const save = (name, data) => fs.writeFileSync(path.join(out, name), JSON.stringify(data, null, 2));
  const get = async url => (await fetch('http://127.0.0.1:11434' + url, { signal: AbortSignal.timeout(5000) })).json();
  const models = ['gemma3:1b', 'qwen2.5-coder:1.5b'];
  const schemas = [
    { name: 'enum', schema: { type: 'object', additionalProperties: false, required: ['answer'], properties: { answer: { type: 'string', enum: ['BOUND_SCHEMA_VALUE'] } } } },
    { name: 'empty-array', schema: { type: 'object', additionalProperties: false, required: ['assessments'], properties: { assessments: { type: 'array', minItems: 0, maxItems: 0, items: { type: 'object', properties: { id: { type: 'string' } } } } } } },
  ];
  const messages = [{ role: 'user', content: 'Return a JSON object with answer="OTHER" and assessments=[{"id":"invented"}].' }];
  save('giao-thuc.json', { models: await get('/api/tags'), version: await get('/api/version'), schemas, messages,
    seed: 42, command: 'node scripts/probe-review-schema-runtime.cjs', script_sha256: crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),
    scope: 'Kiểm tra cơ chế schema native/OpenAI, không phải chất lượng nhận diện hoặc holdout.' });
  const rows = []; save('calls.json', rows); console.log(JSON.stringify({ out }));
  for (const model of models) for (const test of schemas) for (const api of ['openai', 'native']) {
    const body = api === 'openai'
      ? { model, messages, temperature: 0, seed: 42, max_tokens: 100, response_format: { type: 'json_schema', json_schema: { name: 'probe', strict: true, schema: test.schema } } }
      : { model, messages, stream: false, format: test.schema, options: { temperature: 0, seed: 42, num_predict: 100 } };
    const start = performance.now();
    const response = await fetch('http://127.0.0.1:11434' + (api === 'openai' ? '/v1/chat/completions' : '/api/chat'),
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(45000) });
    const raw = await response.text(); let content, valid = false;
    try { const json = JSON.parse(raw); content = api === 'openai' ? json.choices[0].message.content : json.message.content;
      const data = JSON.parse(content); valid = test.name === 'enum'
        ? Object.keys(data).join(',') === 'answer' && data.answer === 'BOUND_SCHEMA_VALUE'
        : Object.keys(data).join(',') === 'assessments' && Array.isArray(data.assessments) && data.assessments.length === 0;
    } catch { /* Raw giữ nguyên khi lỗi, không sửa phản hồi. */ }
    const row = { model, test: test.name, api, request: body, status: response.status, raw, content, valid, seconds: (performance.now() - start) / 1000 };
    rows.push(row); save('calls.json', rows); console.log(JSON.stringify({ model, test: test.name, api, valid, content }));
  }
  save('tong-hop.json', { complete: true, calls: rows.length, all_schema_controls_passed: rows.every(row => row.valid),
    results: rows.map(({ model, test, api, valid, seconds }) => ({ model, test, api, valid, seconds })) });
}
main().catch(error => { console.error(error); process.exitCode = 1; });
