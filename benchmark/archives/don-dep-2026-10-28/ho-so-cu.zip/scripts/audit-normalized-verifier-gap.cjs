// Kiểm tra tái dựng span/cửa sổ/parser mà không gọi model và không sửa nguồn.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const { normalizeRow } = require('./normalize-verifier-gap.cjs');
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'benchmark/data/annotations/verifier-gap-v1');
const output = path.join(root, 'benchmark/data/annotations/verifier-gap-normalized-v1');
const load = file => JSON.parse(fs.readFileSync(file));
async function main() {
  const manifest = load(path.join(output, 'manifest.json'));
  for (const [name, digest] of Object.entries(manifest.assets_sha256)) {
    if (hash(fs.readFileSync(path.join(output, name))) !== digest) throw new Error(`Tài sản đổi: ${name}`);
  }
  for (const [file, digest] of Object.entries(manifest.code_sha256)) {
    if (hash(fs.readFileSync(path.join(root, file))) !== digest) throw new Error(`Code đổi: ${file}`);
  }
  for (const [key, file] of Object.entries({ rows: 'mau-cho-duyet.jsonl', reviews: 'ket-qua-ra-soat.json' })) {
    if (hash(fs.readFileSync(path.join(source, file))) !== manifest.source_sha256[key]) throw new Error(`Nguồn đổi: ${file}`);
  }
  const readRows = p => fs.readFileSync(p, 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const originals = readRows(path.join(source, 'mau-cho-duyet.jsonl'));
  const normalized = readRows(path.join(output, 'nhan-va-cua-so.jsonl'));
  const reviews = load(path.join(source, 'ket-qua-ra-soat.json')).reviews;
  const examples = load(path.join(output, 'ban-xem-truoc.json')).examples;
  if (originals.length !== 15 || normalized.length !== 15 || examples.length !== 30 || new Set(examples.map(e => e.id)).size !== 30) throw new Error('Sai số lượng/trùng ID.');
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  let rebuilt = 0;
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of normalized) {
      const original = originals.find(r => r.id === row.id);
      const expected = normalizeRow(original, reviews.find(r => r.id === row.id));
      if (JSON.stringify(row) !== JSON.stringify(expected) || row.split !== null || row.training_eligible !== false) throw new Error('Chuẩn hóa không tái lập hoặc tự đổi vai trò dữ liệu.');
      const paired = examples.filter(e => e.source_record_id === row.id);
      if (paired.length !== 2 || new Set(paired.map(e => e.mode)).size !== 2) throw new Error('Thiếu cặp chế độ.');
      for (const example of paired) {
        if (example.group_id !== row.group_id || example.training_eligible !== false) throw new Error('Sai nhóm hoặc vai trò.');
        const result = renderDraft({ text: row.selected_window.text, format: row.format, candidate_mode: example.mode }, row.window_annotation);
        if (JSON.stringify(example.payload) !== JSON.stringify(result.payload) || JSON.stringify(example.target) !== JSON.stringify(result.response) || !result.validation.parser_valid) throw new Error('Input/target khác tái dựng.');
        rebuilt++;
      }
    }
  } finally { await server.close(); }
  const result = { sources: normalized.length, exact_rebuild_valid: rebuilt,
    windows: normalized.reduce((sum, r) => sum + r.windows.length, 0), parser_valid: rebuilt,
    original_source_and_labels_unchanged: true, original_to_window_utf16_mapping_valid: true,
    whole_line_context_preserved: true, source_group_preserved: true, unlabeled_windows_not_assumed_benign: true,
    human_window_span_review_complete: false, training_ready: false, runtime_changed: false,
    audit_script_sha256: hash(fs.readFileSync(__filename)) };
  fs.writeFileSync(path.join(output, 'kiem-tra-chuan-hoa.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
