const test=require('node:test'),assert=require('node:assert/strict');
const {passes}=require('./qwen3-probe-gate.cjs');
const good=()=>({baseline:{correct_stance:7,tp:0},candidate:{examples:16,parsed:16,correct_stance:12,tp:3,gold_instruction_covered_tps:3},uncertainCorrect:2,regressions:[],groupRegressions:[],ratio:2});
test('JSON tăng nhưng TP bằng không phải trượt',()=>{const x=good();x.candidate.tp=0;x.candidate.gold_instruction_covered_tps=0;assert.equal(passes(x),false);});
test('Đòi nhận diện uncertain và bằng chứng, không chấp nhận hồi quy',()=>{assert.equal(passes(good()),true);for(const key of ['uncertainCorrect','regressions','groupRegressions']){const x=good();x[key]=key==='uncertainCorrect'?0:['ca-loi'];assert.equal(passes(x),false);}const x=good();x.candidate.gold_instruction_covered_tps=2;assert.equal(passes(x),false);});
test('Không chấp nhận lỗi hoặc tỷ lệ thời gian không hợp lệ',()=>{for(const ratio of [NaN,Infinity,3.01])assert.equal(passes({...good(),ratio}),false);const x=good();x.candidate.parsed=15;assert.equal(passes(x),false);});
