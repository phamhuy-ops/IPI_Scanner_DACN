// Chỉ tạo nháp gán nhãn; không gọi model, không xuất train và không ghi đè.
const fs = require('node:fs');
const path = require('node:path');
const { buildCases } = require('./verifier-vietnamese-cases.cjs');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const dir = path.join(root, 'benchmark/data/annotations/verifier-vietnamese-v1');
const json = value => JSON.stringify(value, null, 2) + '\n';
async function main() {
  if (fs.existsSync(dir)) throw new Error('Thư mục đã tồn tại; không ghi đè phiếu.');
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true }, appType: 'custom' });
  const assets = new Map(); const rows = buildCases();
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of rows) {
      const errors = validateAnnotation(row.text, row.draft_annotation);
      if (errors.length) throw new Error(`${row.id}: ${errors.join('; ')}`);
      const output = renderDraft(row, row.draft_annotation);
      row.draft_response = output.response;
      row.validation = output.validation;
      assets.set(`van-ban/${row.id}.txt`, row.text);
      assets.set(`dau-vao/${row.id}.json`, json(output.payload));
      assets.set(`dap-an-nhap/${row.id}.json`, json(row.draft_response));
    }
  } finally { await server.close(); }
  assets.set('mau-cho-duyet.jsonl', rows.map(row => JSON.stringify(row)).join('\n') + '\n');
  assets.set('ket-qua-ra-soat.json', json({ version: 1, status: 'pending', reviews: rows.map(row => ({ id: row.id,
    input_sha256: row.input_sha256,
    draft_sha256: hash(Buffer.from(json({ annotation: row.draft_annotation, response: row.draft_response }))),
    status: 'pending', decision: null, reviewer: null, reviewed_at: null, final_annotation: null, final_response: null, notes: '' })) }));
  const counts = { total: rows.length, groups: new Set(rows.map(row => row.group_id)).size,
    labels: Object.fromEntries(['benign', 'malicious', 'uncertain'].map(label => [label, rows.filter(row => row.draft_annotation.label === label).length])),
    parser_valid: rows.length, pending: rows.length };
  assets.set('manifest.json', json({ version: 1, seed: 73, counts, human_review_complete: false,
    fine_tuning_ready: false, independent: false, training_export_created: false,
    limitations: ['Mẫu tự soạn ngắn, chưa phải tài liệu thực tế hoặc holdout.', 'Đáp án là nháp chờ người dùng duyệt; parser hợp lệ chưa chứng minh nhãn đúng.',
      'Candidate mô phỏng theo dòng; chưa gọi Detector hoặc Verifier.', 'Chưa có tài liệu dài hoặc file PDF/DOCX.',
      'Cần kiểm tra gần trùng trước khi phân bổ nhóm; chưa chia train/dev.'],
    code_sha256: Object.fromEntries(['scripts/verifier-vietnamese-cases.cjs', 'scripts/prepare-vietnamese-verifier-batch.cjs',
      'scripts/verifier-batch-renderer.ts', 'src/ai/agents/document/sourceReferences.ts', 'src/ai/agents/document/compactVerifier.ts']
      .map(file => [file, hash(fs.readFileSync(path.join(root, file)))])),
    asset_sha256: Object.fromEntries([...assets].map(([file, content]) => [file, hash(Buffer.from(content))])) }));
  for (const [file, content] of assets) {
    fs.mkdirSync(path.dirname(path.join(dir, file)), { recursive: true });
    fs.writeFileSync(path.join(dir, file), content, 'utf8');
  }
  console.log(json({ output: dir, counts, fine_tuning_ready: false }));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
