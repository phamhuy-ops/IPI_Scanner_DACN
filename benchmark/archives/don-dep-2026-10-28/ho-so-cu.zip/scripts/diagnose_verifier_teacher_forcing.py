"""Chẩn đoán likelihood đầu ra chuẩn; chỉ inference, không thay generation hoặc huấn luyện."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
from collections import defaultdict

from verifier_data_loader import ROOT, load_role as old_role
from verifier_candidate02_loader import load_role as train_role
from audit_verifier_tokenizer import completion_example


def categories(tokenizer, messages, target, ids, boundary, end):
    # Dùng offset của tokenizer thật trên toàn chat; không ước lượng ranh giới bằng số token của chuỗi con.
    prefix = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    full = tokenizer.apply_chat_template(messages + [{'role': 'assistant', 'content': target}], tokenize=False, add_generation_prompt=False)
    encoded = tokenizer(full, add_special_tokens=False, return_offsets_mapping=True)
    if encoded['input_ids'] != ids or full[len(prefix):len(prefix) + len(target)] != target:
        raise ValueError('Offset token không khớp chat template.')
    spans = []
    for match in re.finditer(r'"([A-Za-z]+)":("(?:[^"\\]|\\.)*"|true|false)', target):
        key = match.group(1)
        kind = key if key in {'stance', 'addressee', 'framing', 'deviation', 'hasDirective', 'reason', 'spanId', 'id'} else 'other_value'
        spans.append((len(prefix) + match.start(2), len(prefix) + match.end(2), kind))
    result = []
    for pos in range(boundary, end):
        start, stop = encoded['offset_mapping'][pos]
        kinds = {kind for lo, hi, kind in spans if start < hi and stop > lo}
        result.append(next(iter(kinds)) if len(kinds) == 1 else 'mixed' if kinds else 'structure_or_eos')
    return result


def summarize(rows):
    totals = defaultdict(lambda: {'tokens': 0, 'nll_sum': 0., 'correct': 0})
    for row in rows:
        for key, values in row['fields'].items():
            for name in ['tokens', 'nll_sum', 'correct']:
                totals[key][name] += values[name]
    return {key: {**v, 'mean_nll': v['nll_sum'] / v['tokens'], 'gold_prefix_token_accuracy': v['correct'] / v['tokens']} for key, v in totals.items()}


def main():
    import torch
    import torch.nn.functional as F
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import PeftModel, prepare_model_for_kbit_training
    out = ROOT / 'benchmark/experiments/verifier-teacher-forcing-v1'
    if out.exists():
        raise ValueError('Không ghi đè chẩn đoán.')
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    if storage.drive.lower() != 'e:':
        raise ValueError('Weights/cache phải trên E.')
    train = train_role('train')
    selected = json.loads((ROOT / 'benchmark/experiments/verifier-hf-base-screen-v1/ke-hoach-truoc-do.json').read_text(encoding='utf-8'))['selected_source_ids']
    dev = [r for r in old_role('dev') if r['source_record_id'] in selected]
    if len(train) != 360 or len(dev) != 12:
        raise ValueError('Sai phạm vi train/screen.')
    candidate = json.loads((ROOT / 'benchmark/experiments/verifier-pilot-candidate-02/ket-qua.json').read_text(encoding='utf-8'))
    adapter = Path(candidate['adapter_path']).resolve()
    if not adapter.is_relative_to(storage):
        raise ValueError('Adapter ngoài E.')
    for file, expected in candidate['adapter_files_sha256'].items():
        if hashlib.sha256((adapter / file).read_bytes()).hexdigest() != expected:
            raise ValueError('Adapter thay đổi.')
    out.mkdir()
    plan = {'train_examples': 360, 'dev_screen_examples': 12, 'modes': ['off', 'on'], 'candidate': 'candidate-02',
            'scope': 'teacher_forcing_diagnostic_not_generation_or_full_dev', 'seed': 42,
            'training': False, 'probe_used': False, 'runtime_changed': False,
            'code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'adapter_sha256': candidate['adapter_files_sha256'],
            'limitations': ['Mỗi token được cho tiền tố gold; độ đúng token không phải độ đúng stance khi tự sinh.',
              'Train và 6 nguồn dev khác phân bố; không suy overfit chỉ từ chênh lệch loss trung bình.',
              'Các giá trị enum có nhiều token; đây là điểm token có điều kiện, không phải accuracy phân loại.',
              'Không dùng teacher-forcing như đường inference sản phẩm; gold không được truyền vào scanner.',
              'Không gọi probe, không thay gold/parser và không mở lại cổng generation đã trượt.']}
    (out / 'ke-hoach.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    assets = json.loads((ROOT / 'benchmark/experiments/verifier-gpu-assets-v1/ket-qua.json').read_text(encoding='utf-8'))
    local = Path(assets['snapshot']).resolve()
    if not local.is_relative_to(storage):
        raise ValueError('Base ngoài E.')
    torch.manual_seed(42)
    torch.cuda.set_per_process_memory_fraction(.8)
    tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False)
    prepared = []
    for role, rows in [('train', train), ('dev_screen', dev)]:
        for row in rows:
            target = json.dumps(row['target'], ensure_ascii=False, separators=(',', ':'))
            ids, labels, boundary, end = completion_example(tokenizer, row['payload']['messages'], target)
            prepared.append((role, row, ids, labels, boundary, end, categories(tokenizer, row['payload']['messages'], target, ids, boundary, end)))
    base = AutoModelForCausalLM.from_pretrained(local, local_files_only=True, trust_remote_code=False,
        quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4', bnb_4bit_use_double_quant=True,
                                             bnb_4bit_compute_dtype=torch.float16),
        device_map={'': 0}, torch_dtype=torch.float16, attn_implementation='sdpa')
    base = prepare_model_for_kbit_training(base, use_gradient_checkpointing=False)
    model = PeftModel.from_pretrained(base, adapter, is_trainable=False, local_files_only=True)
    model.eval()
    results = []
    started = time.perf_counter()
    for mode in ['off', 'on']:
        manager = model.disable_adapter() if mode == 'off' else contextlib.nullcontext()
        with manager:
            for p in model.parameters():
                p.requires_grad_(False)
            for index, (role, row, ids, labels, boundary, end, kinds) in enumerate(prepared):
                began = time.perf_counter()
                input_ids = torch.tensor([ids], device='cuda')
                positions = torch.arange(boundary - 1, end - 1, device='cuda')
                gold = torch.tensor(labels[boundary:end], device='cuda')
                with torch.inference_mode():
                    logits = model(input_ids=input_ids, attention_mask=torch.ones_like(input_ids), logits_to_keep=positions, use_cache=False).logits[0].float()
                    nll = F.cross_entropy(logits, gold, reduction='none').cpu().tolist()
                    correct = logits.argmax(-1).eq(gold).cpu().tolist()
                fields = defaultdict(lambda: {'tokens': 0, 'nll_sum': 0., 'correct': 0})
                for kind, loss, hit in zip(kinds, nll, correct):
                    for key in ['all', kind]:
                        fields[key]['tokens'] += 1
                        fields[key]['nll_sum'] += loss
                        fields[key]['correct'] += int(hit)
                results.append({'id': row['id'], 'source_record_id': row['source_record_id'], 'group_id': row['group_id'],
                    'role': role, 'mode': mode, 'candidate_mode': row['mode'], 'fields': dict(fields), 'seconds': time.perf_counter() - began})
                del logits, input_ids, positions, gold
                if (index + 1) % 24 == 0 or index + 1 == len(prepared):
                    progress = {'mode': mode, 'done': index + 1, 'total_per_mode': len(prepared)}
                    (out / 'tien-do.json').write_text(json.dumps(progress), encoding='utf-8')
                    print(json.dumps(progress), flush=True)
        (out / f'{mode}.json').write_text(json.dumps([r for r in results if r['mode'] == mode], ensure_ascii=False), encoding='utf-8')
    for p in model.parameters():
        p.requires_grad_(False)
    for file, expected in candidate['adapter_files_sha256'].items():
        if hashlib.sha256((adapter / file).read_bytes()).hexdigest() != expected:
            raise ValueError('Adapter thay đổi sau đo.')
    summary = {'summaries': {mode: {role: summarize([r for r in results if r['mode'] == mode and r['role'] == role]) for role in ['train', 'dev_screen']} for mode in ['off', 'on']},
        'examples_per_mode': len(prepared), 'seconds': time.perf_counter() - started,
        'peak_vram_allocated': torch.cuda.max_memory_allocated(), 'peak_vram_reserved': torch.cuda.max_memory_reserved(),
        'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
        'training_started': False, 'probe_used': False, 'adapter_unchanged': True, 'runtime_changed': False,
        'limitations': plan['limitations']}
    (out / 'ket-qua.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in summary.items() if k not in {'summaries', 'limitations'}}))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
