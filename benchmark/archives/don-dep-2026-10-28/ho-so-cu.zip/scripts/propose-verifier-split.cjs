// Phương án theo nhóm để kiểm tra trước export; không tạo bài học hoặc niêm phong probe.
const fs = require('node:fs');
const { hash } = require('./context-annotations.cjs');
const { subset } = require('./check-verifier-group-budget.cjs');
const registryFile = 'benchmark/experiments/verifier-eligibility-v12/registry.jsonl';
const out = 'benchmark/experiments/verifier-split-proposal-v1';
const family = source => source.startsWith('project_authored') || source === 'verifier-gap-v1' ? 'project_authored' : source.split('+')[0];
function groups(rows) {
  const map = new Map();
  for (const row of rows) {
    if (!map.has(row.group_id)) map.set(row.group_id, []);
    map.get(row.group_id).push(row);
  }
  return [...map].sort(([a], [b]) => a.localeCompare(b)).map(([id, members]) => ({ id, members,
    vector: ['confirmed', 'dismissed', 'uncertain'].map(s => members.filter(r => r.stance === s).length) }));
}
function shuffle(items, seed) {
  const copy = [...items]; let state = seed >>> 0;
  for (let i = copy.length - 1; i > 0; i--) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    const j = state % (i + 1); [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}
function summary(selected) {
  const rows = selected.flatMap(g => g.members);
  const count = key => rows.reduce((a, r) => { const k = typeof key === 'function' ? key(r) : r[key]; a[k] = (a[k] || 0) + 1; return a; }, {});
  return { records: rows.length, groups: selected.length, stances: count('stance'), languages: count('language'),
    families: count(r => family(r.source)), sources: count('source'), largest_group: Math.max(0, ...selected.map(g => g.members.length)) };
}
function balance(selected) {
  const s = summary(selected), n = s.records;
  return { summary: s, language_vi_40: (s.languages.vi || 0) >= Math.ceil(n * .4),
    language_en_40: (s.languages.en || 0) >= Math.ceil(n * .4),
    at_least_3_families: Object.keys(s.families).length >= 3,
    largest_family_share: n ? Math.max(...Object.values(s.families)) / n : null };
}
function propose(rows, attempts = 128) {
  const candidate = groups(rows.filter(r => r.role === 'candidate_pending_source_privacy_and_split_review'));
  const dev = groups(rows.filter(r => r.role === 'development_regression_only'));
  const totals = candidate.reduce((a, g) => a.map((n, i) => n + g.vector[i]), [0, 0, 0]);
  const excess = totals.map((n, i) => n - [96, 96, 48][i]);
  if (excess.some(n => n < 0)) throw new Error('Thiếu mẫu theo kịch bản nhãn.');
  for (let attempt = 0; attempt < attempts; attempt++) {
    const seed = 42 + attempt, ordered = shuffle(candidate, seed);
    const drop = subset(ordered.map(g => g.vector), excess);
    if (!drop) continue;
    const retained = ordered.filter((_, i) => !drop.includes(i));
    const pi = subset(retained.map(g => g.vector), [24, 24, 12]);
    if (!pi) continue;
    const probe = retained.filter((_, i) => pi.includes(i)), train = retained.filter((_, i) => !pi.includes(i));
    // Giữ toàn bộ dev đã tiếp xúc, không loại ca hồi quy chỉ để ép đúng 60.
    const selectedDev = dev;
    const checks = { train: balance(train), dev: balance(selectedDev), probe: balance(probe) };
    if (!Object.values(checks).every(c => c.language_vi_40 && c.language_en_40 && c.at_least_3_families && c.largest_family_share <= .5)) continue;
    const assigned = { train, dev: selectedDev, probe, unused_candidates: ordered.filter((_, i) => drop.includes(i)),
      dev_regression_extra: [] };
    validateAssignments(rows, assigned);
    return { seed, attempt: attempt + 1, assigned, checks };
  }
  throw new Error('Chưa tìm được phương án đạt các điều kiện trong ngân sách; không suy mọi phân bổ đều bất khả thi.');
}
function validateAssignments(rows, assigned) {
  const seen = new Set();
  for (const [role, selected] of Object.entries(assigned)) for (const group of selected) {
    if (seen.has(group.id)) throw new Error('Nhóm xuất hiện ở nhiều vai trò.');
    seen.add(group.id);
    const originals = rows.filter(r => r.group_id === group.id);
    if (originals.length !== group.members.length || originals.some(r => !group.members.some(m => m.id === r.id))) throw new Error('Nhóm bị tách.');
    if (['train', 'probe', 'unused_candidates'].includes(role) && originals.some(r => r.role !== 'candidate_pending_source_privacy_and_split_review')) throw new Error('Dev/test/reference bị đưa vào pool mới.');
    if (['dev', 'dev_regression_extra'].includes(role) && originals.some(r => r.role !== 'development_regression_only')) throw new Error('Ứng viên bị đổi thành dev ngầm.');
  }
  if (seen.size !== new Set(rows.map(r => r.group_id)).size) throw new Error('Thiếu phủ nhóm.');
}
function main() {
  if (fs.existsSync(out)) throw new Error('Không ghi đè phương án.');
  const bytes = fs.readFileSync(registryFile), rows = bytes.toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
  const inputs = { [registryFile]: hash(bytes) };
  for (const row of rows) for (const [file, expected] of Object.entries(row.source_evidence?.sha256 || {})) {
    const actual = hash(fs.readFileSync(file)); if (actual !== expected) throw new Error('Bằng chứng nguồn đã đổi.'); inputs[file] = actual;
  }
  const proposal = propose(rows);
  const ledger = Object.entries(proposal.assigned).flatMap(([role, selected]) => selected.map(g => ({ group_id: g.id,
    proposed_role: role, member_ids: g.members.map(r => r.id), ...summary([g]),
    source_evidence_kinds: [...new Set(g.members.map(r => r.source_evidence.kind))],
    evidence_hashes_verified: true,
    local_preparation_status: g.members.every(r => r.source_evidence.kind === 'project_authored_release_not_declared')
      ? 'own_authored_no_external_license_blocker' : 'source_evidence_present_conditions_retained',
    remaining_before_training_export: ['Đối chiếu ghi công/notice theo nguồn trong bản xuất.', 'Chốt phạm vi riêng tư và phiên bản nhãn hiệu lực của từng thành viên.', 'Kiểm tra payload/target và token trên đúng bản xuất; không suy từ việc đủ số lượng.'],
    training_eligible: false, final_split: null })));
  const result = { version: 'verifier-split-proposal-v1', seed: proposal.seed, attempts_used: proposal.attempt,
    checks: proposal.checks, other_roles: { unused_candidates: summary(proposal.assigned.unused_candidates), dev_regression_extra: summary(proposal.assigned.dev_regression_extra) },
    planning_constraints: { records: { train: 180, dev: 84, probe: 60 }, train_probe_stance_fraction: [0.4, 0.4, 0.2],
      vi_min: .4, en_min: .4, family_min: 3, family_share_max: .5,
      note: 'Đề xuất giữ cả 84 dev đã tiếp xúc thay mốc dự kiến 60; dev giữ phân bố gốc, không ép 40/40/20. Điều kiện lập phương án không phải ngưỡng bảo mật; source cùng họ vẫn có thể xuất hiện ở nhiều vai trò.' },
    group_integrity_verified: true, no_dev_in_train_or_probe: true, model_called: false,
    inputs_sha256: inputs, code_sha256: hash(fs.readFileSync(__filename)),
    command: 'node scripts/propose-verifier-split.cjs', final_split_created: false, training_export_created: false,
    training_ready: false, probe_sealed: false, independent_holdout_verified: false,
    limitations: ['Phương án đã được phân tích metadata, không coi probe là holdout độc lập chưa chạm.',
      'Cân bằng họ nguồn không chứng minh độc lập ngữ nghĩa; grouping hiện vẫn là heuristic.',
      'AI tự soạn/rà nhiều nhãn; còn thiếu tài liệu dài đa định dạng và đo toàn pipeline.'] };
  fs.mkdirSync(out);
  fs.writeFileSync(`${out}/ket-qua.json`, JSON.stringify(result, null, 2) + '\n');
  fs.writeFileSync(`${out}/dieu-kien-tung-nhom.json`, JSON.stringify({ groups: ledger, training_ready: false }, null, 2) + '\n');
  console.log(JSON.stringify({ seed: result.seed, checks: result.checks, final_split_created: false }));
}
if (require.main === module) main();
module.exports = { groups, summary, propose, validateAssignments };
