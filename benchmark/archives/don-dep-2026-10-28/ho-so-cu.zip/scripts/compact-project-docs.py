"""Gộp tài liệu đang dùng; lưu snapshot và kiểm tra hash trước khi dọn."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
from urllib.parse import unquote
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'docs'
ARCHIVE = ROOT / 'benchmark/archives/docs-truoc-rut-gon-2026-10-26.zip'
MANIFEST = ARCHIVE.with_suffix('.json')
if ARCHIVE.exists() or MANIFEST.exists():
    raise SystemExit('Đã có bản lưu; không chạy lại hoặc ghi đè.')
files = sorted(p for p in DOCS.rglob('*') if p.is_file())
keep = {
    'README.md', 'architecture/pham-vi-va-kien-truc-du-an.md',
    'guides/huong-dan-gan-nhan-ngu-canh.md', 'guides/luu-tru-huan-luyen-tren-o-e.md',
    'guides/mo-rong-du-lieu-ngu-canh-verifier.md', 'guides/tu-danh-gia-du-lieu-verifier.md',
    'planning/cong-hoan-thanh-uu-tien-1.md', 'planning/cong-viec-can-lam.md',
    'planning/tien-do-uu-tien-1.md', 'planning/ke-hoach-thu-fine-tuning-verifier.md',
    'planning/tieu-chi-them-vong-phan-bien.md',
}
removed = {p.resolve() for p in files if p.relative_to(DOCS).as_posix() not in keep}
summary = DOCS / 'reports/tong-hop-hien-trang.md'
gate = DOCS / 'planning/cong-hoan-thanh-uu-tien-1.md'
gate_hash = hashlib.sha256(gate.read_bytes()).hexdigest()
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
snapshots = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for p in files:
        archive.write(p, p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    for name, digest in snapshots.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest

content = {
    'README.md': '''# Tài liệu dự án

Điểm vào ngắn gọn, cập nhật 2026-10-26.

| Cần xem gì? | Tài liệu |
| --- | --- |
| Dự án làm gì, cách chạy | [README dự án](../README.md) |
| Luồng và thành phần kỹ thuật | [Phạm vi và kiến trúc](architecture/pham-vi-va-kien-truc-du-an.md) — tài liệu cũ giữ nguyên ngôn ngữ |
| Kết quả quan trọng, trạng thái và giới hạn | [Bảng tổng hợp hiện trạng](reports/tong-hop-hien-trang.md) |
| Làm gì tiếp theo | [Việc cần làm](planning/cong-viec-can-lam.md) |
| Ưu tiên 1 đã xong chưa | [Tiến độ](planning/tien-do-uu-tien-1.md), [tiêu chí đã khóa](planning/cong-hoan-thanh-uu-tien-1.md) |
| Chuẩn bị học một Verifier | [Kế hoạch pilot](planning/ke-hoach-thu-fine-tuning-verifier.md) |
| Khi nào thêm phản biện | [Điều kiện](planning/tieu-chi-them-vong-phan-bien.md) |
| Cách gán nhãn, mở rộng và AI rà dữ liệu | [Gán nhãn](guides/huong-dan-gan-nhan-ngu-canh.md), [mở rộng](guides/mo-rong-du-lieu-ngu-canh-verifier.md), [AI tự rà](guides/tu-danh-gia-du-lieu-verifier.md) |
| Python/cache/model trên ổ E | [Hướng dẫn lưu trữ](guides/luu-tru-huan-luyen-tren-o-e.md) |

## Quy ước tài liệu từ bây giờ

- Chỉ duy trì giới thiệu, hướng dẫn, việc cần làm và báo cáo quan trọng dạng tóm tắt bằng tiếng Việt.
- Cập nhật bảng tổng hợp và việc cần làm khi trạng thái đổi; không tạo một báo cáo/kế hoạch mới cho từng lượt chạy.
- Báo cáo ngắn ghi kết quả, giới hạn và đường dẫn bằng chứng; số liệu chi tiết, hash, lệnh và log nằm trong `benchmark/experiments/` hoặc `benchmark/results/`.
- Tách việc đã triển khai với thử nghiệm; không tính test kỹ thuật là cải thiện bảo mật.
- Chỉ tạo tài liệu riêng khi có quy trình mới cần dùng lại hoặc thay đổi kiến trúc quan trọng.

## Lịch sử đã thu gọn

Báo cáo trung gian và kế hoạch thử cũ đã rời thư mục docs. Snapshot trước
dọn nằm trong [ZIP lịch sử](../benchmark/archives/docs-truoc-rut-gon-2026-10-26.zip),
kèm [danh mục/hash](../benchmark/archives/docs-truoc-rut-gon-2026-10-26.json).
Đường dẫn docs cũ trong artifact bất biến được tra qua danh mục này; không
viết lại kết quả lịch sử. Dữ liệu và baseline không bị xóa.
''',
    'reports/tong-hop-hien-trang.md': '''# Tổng hợp hiện trạng dự án

Cập nhật 2026-10-26. **Ưu tiên 1 chưa hoàn thành. Chưa fine-tune model hoặc bật vòng phản biện.**

| Hạng mục | Trạng thái | Kết quả và phần còn thiếu |
| --- | --- | --- |
| Chính sách kết luận | Đã triển khai | Rule tạo nghi vấn; hai model đối chiếu nguồn. Có phát hiện/chưa phát hiện/cần xem xét; lỗi và thiếu coverage có lý do riêng. Chất lượng kết luận vẫn phụ thuộc model. |
| Trích xuất HTML | Đã sửa lỗi đã chứng minh | Giữ raw HTML và text projection, nguồn và cảnh báo coverage; không suy hiệu quả cho mọi định dạng. |
| Tiến độ model/UI | Đã tích hợp | Phân biệt đoạn được chọn và đoạn từng model xử lý thành công, giữ tiến độ khi lỗi. Lượt tích hợp trước đạt 221 kiểm thử; không phải bằng chứng tăng khả năng nhận diện. |
| Chất lượng Agent | Chưa đạt | Baseline dev 72 ca: TP=3, FP=1, TN=13, FN=7 trên 61 nhãn nhị phân; 37/61 cần xem xét. 15/72 ca lỗi phản hồi. Hai model còn đồng thuận sai ở ngữ cảnh dành cho con người. |
| Chỉ số baseline | Chỉ là dev | Precision 75%, recall 13,64%, F1 23,08%, FPR 2,56%, tỷ lệ kết luận nhị phân 39,34%. Các mẫu cần xem xét không bị biến thành TN hoặc false clear. Không phải holdout độc lập. |
| Các ứng viên prompt/selector/đọc tiếp | Chưa được chọn | Chưa chứng minh cải thiện đủ điều kiện; giữ cấu hình mặc định. Giảm lỗi JSON không đồng nghĩa tăng nhận diện. |
| Dữ liệu Verifier | Đang chuẩn bị | 178 bản ghi/131 parent ID/71 nhóm heuristic ngoài legacy. Chưa chia train/dev, chưa xác minh holdout độc lập, chưa có bản được phê duyệt train. Nhãn AI và người duyệt được phân biệt. |
| Backend huấn luyện | Đạt smoke kỹ thuật | Token/mask/collator và QLoRA thử kỹ thuật đã đo; GPU 4 GB còn ít dư địa. Chưa tích hợp/chạy pilot trainer hoàn chỉnh. |
| Lưu trữ | Đã cấu hình | Code ở C; Python, cache, weights, adapter/checkpoint ở E; kho Ollama ở E. Không xóa dữ liệu gốc/baseline. |
| Tài liệu Việt gốc | Incoming, chưa phê duyệt | 2 PDF + 2 DOCX. Hash/text khớp; quyền train/tái phân phối chưa xác minh. Ảnh DOCX có tên/tài khoản cần rà/làm sạch riêng. |
| Bao phủ tài liệu dài | Chưa đạt | 4 file có 161 chunk, quét chung Deep chọn 24. PDF có chữ trong ảnh bị extractor bỏ qua; đã xác nhận bằng xem trang. Chưa OCR hoặc đo đầy đủ qua model/UI/native IPC. |
| Kiểm chứng độc lập | Chưa hoàn tất | Cần nhóm nguồn, quyền dùng, nhãn và cấu hình được khóa trước đo; mẫu đã dùng thiết kế không được coi là holdout chưa chạm. |

## Bằng chứng chính

- [Baseline 72 ca và chỉ số](../../benchmark/experiments/priority-one-baseline-v1/ket-qua.json).
- [Chẩn đoán trích dẫn/ngữ cảnh](../../benchmark/experiments/citation-context-controls-v1/mau-da-khoa.json).
- [Tiến độ model đã tích hợp](../../benchmark/experiments/production-review-progress-v1/ket-qua.json).
- [Registry/ràng buộc chia nhóm](../../benchmark/experiments/verifier-split-readiness-v1/ket-qua.json).
- [Nguồn PDF/DOCX](../../benchmark/experiments/public-vi-native-intake-v1/ket-qua.json), [đo extraction/selection](../../benchmark/experiments/public-vi-native-audit-v1/ket-qua.json), [rà ảnh/metadata có mục tiêu](../../benchmark/experiments/public-vi-native-visual-v1/ket-qua-ra-soat.json).
- [Kế hoạch model/dữ liệu máy đọc](../../benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json).

Không có phần trăm tiến độ vì chưa có thước đo phù hợp. Bước kế tiếp và
điều kiện hoàn thành nằm ở [việc cần làm](../planning/cong-viec-can-lam.md).
Chi tiết các lượt cũ có trong ZIP lịch sử được dẫn từ [mục lục](../README.md).
''',
    'planning/cong-viec-can-lam.md': '''# Việc cần làm

Cập nhật 2026-10-26. **Ưu tiên 1 vẫn mở.**

| Thứ tự | Việc cần làm | Điều kiện chốt |
| --- | --- | --- |
| 1 | Chuẩn bị đối chứng PDF/DOCX tự soạn: sạch, hướng dẫn cho người, attack trích dẫn, attack có hiệu lực; vị trí đầu/giữa/cuối, chữ thật/chữ trong ảnh | Có nhãn/span, nguồn cha/nhóm, hash; nhãn không đi vào scanner/model. |
| 2 | Đo extraction, selection và trạng thái thiếu dữ liệu trên cùng đối chứng | Biết phần chữ mất, đoạn không chọn, lỗi thực; không kết luận sạch khi biết thiếu phạm vi theo chính sách. |
| 3 | Đo Detector + Verifier và toàn pipeline; chọn một sửa đổi có căn cứ | Baseline trước/sau, đối chứng gần giống, biến thể chưa dùng chọn cấu hình; ghi lỗi, coverage, latency và tài nguyên. |
| 4 | Hoàn thiện dữ liệu cho một Verifier | Bổ sung nguồn/nhóm còn thiếu; quyền dùng, riêng tư, span/context, trùng lặp, token/mask được kiểm tra; chia theo nhóm. |
| 5 | Chạy pilot fine-tuning khi đủ điều kiện | Trainer/gradient accumulation/save-reload đạt; train/dev được chốt, holdout độc lập tách riêng. So sánh cùng base/backend có và không adapter. |
| 6 | Kiểm chứng cuối và cân nhắc vòng phản biện | Đạt tiêu chí đã khóa; đo cấu hình cố định trên holdout mới và luồng sản phẩm. Phản biện tối đa 2–3 vòng cần phép đo riêng. |

Nguồn công khai 2 PDF/2 DOCX hiện chỉ ở incoming; chưa duyệt quyền train,
ảnh và metadata toàn bộ. Không cần người dùng tải lại. Chưa cần cài thêm
phần mềm cho bước tạo/đo đối chứng; nếu phát sinh phụ thuộc sẽ thông báo.

Nguyên tắc: lỗi chứng minh được → đối chứng sạch/tấn công → dữ liệu độc lập
→ toàn pipeline. Không nới citation/schema để làm đẹp số đo. Giữ log và
baseline, không nhân bản nhóm để đủ số lượng.

Xem [bảng hiện trạng](../reports/tong-hop-hien-trang.md),
[cổng Ưu tiên 1 đã khóa](cong-hoan-thanh-uu-tien-1.md),
[kế hoạch Verifier](ke-hoach-thu-fine-tuning-verifier.md).
''',
    'planning/tien-do-uu-tien-1.md': '''# Tiến độ Ưu tiên 1

Cập nhật 2026-10-26. **Chưa hoàn thành.**

- Đã triển khai chính sách kết luận/lỗi và tiến độ từng model trong UI/pipeline.
- Chưa đạt chất lượng nhận diện/ngữ cảnh của Agent.
- Chưa hoàn tất tài liệu dài/đa định dạng qua toàn pipeline và holdout độc lập.
- Chưa fine-tune và chưa thêm vòng phản biện; smoke kỹ thuật không phải pilot huấn luyện.

Số liệu dùng chung tại [bảng tổng hợp](../reports/tong-hop-hien-trang.md),
bước tiếp tại [việc cần làm](cong-viec-can-lam.md). Không nối thêm nhật ký
lặp vào trang này. [Tiêu chí hoàn thành đã khóa](cong-hoan-thanh-uu-tien-1.md)
được giữ nguyên để đối chiếu baseline.
''',
    'planning/ke-hoach-thu-fine-tuning-verifier.md': '''# Kế hoạch thử fine-tuning một Verifier

Cập nhật 2026-10-26. **Chưa train, chưa đủ điều kiện mở pilot.**

- Chỉ học một Verifier, không huấn luyện Rule Prefilter. Base HF: `Qwen/Qwen2.5-1.5B-Instruct`, revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`.
- Đích học: phân biệt người/AI, attack có hiệu lực/trích dẫn/không đủ ngữ cảnh; stance và bằng chứng đúng nguồn, JSON hợp lệ.
- Model Verifier Ollama mặc định là `qwen2.5-coder:1.5b`; không coi là cùng checkpoint với base HF. Không tự triển khai adapter smoke.
- Weights/tokenizer đã ở E; Python và backend QLoRA đã có smoke kỹ thuật. 2048 token là ứng viên có giới hạn tài nguyên đã đo; chưa chứng minh trainer đầy đủ hoặc dư địa đủ cho mọi batch.
- Dữ liệu còn phải hoàn thiện quyền dùng, riêng tư, nhãn/span/context, trùng lặp và chia nhóm. 178 bản ứng viên không phải 178 bản đã đủ điều kiện train.
- Chỉ mở pilot sau khi khóa train/dev và tập kiểm chứng độc lập, kiểm tra trainer/mask/gradient accumulation/save-reload. Bộ tham chiếu và mẫu đã dùng chọn cấu hình không tự làm test cuối.
- Đo cùng base/backend trước và sau adapter; giữ các thành phần khác để so sánh. Báo cáo precision/recall/F1/FPR, confusion counts, abstention, lỗi, latency và RAM/VRAM; sau đó đo toàn pipeline.
- NF4 huấn luyện và GGUF quantization triển khai là hai bước khác nhau, cần đo tương ứng.

[Kế hoạch máy đọc](../../benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json)
giữ chi tiết tái lập; [lưu trữ ổ E](../guides/luu-tru-huan-luyen-tren-o-e.md)
giữ lệnh sử dụng. Các mốc cũ được lưu trong ZIP lịch sử, không trộn vào
trạng thái hiện tại. Xem [việc cần làm](cong-viec-can-lam.md).
''',
    'planning/tieu-chi-them-vong-phan-bien.md': '''# Điều kiện thêm vòng phản biện

Cập nhật 2026-10-26. **Chưa đủ điều kiện bật mặc định.**

- Có baseline một vòng đáng tin và bộ đối chứng đa nguồn, gồm ca bất đồng, đồng thuận sai và cùng bỏ sót.
- Phản hồi model có schema/citation hợp lệ đủ theo cổng đã khóa; không nới validator để vượt cổng.
- Chỉ thử phản biện khi bất đồng/chưa rõ; tổng tối đa 2–3 vòng, có deadline, ngân sách và lưu bằng chứng từng vòng.
- Hết ngân sách, model lỗi, thiếu coverage hoặc chưa giải quyết được phải hiển thị lý do và chuyển cần xem xét theo chính sách.
- So sánh một vòng/nhiều vòng trên cùng dữ liệu, ghi chất lượng, lỗi, latency và tài nguyên; khóa cấu hình trước kiểm chứng độc lập.

Phản biện không tự sửa chữ bị mất, quote bịa hoặc hai model đồng thuận sai.
Các ứng viên prompt trước chưa chứng minh đủ hiệu quả; xem [hiện trạng](../reports/tong-hop-hien-trang.md)
và [cổng hoàn thành Ưu tiên 1](cong-hoan-thanh-uu-tien-1.md).
''',
}
for relative, text in content.items():
    destination = DOCS / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding='utf-8')

# Chỉ xóa file trong docs đã được xác minh có bản lưu khớp hash.
for file in sorted(removed):
    assert file.is_relative_to(DOCS.resolve())
    assert hashlib.sha256(file.read_bytes()).hexdigest() == snapshots[file.relative_to(ROOT).as_posix()]
    file.unlink()

# Cập nhật link ở các tài liệu đang đọc, không sửa artifact benchmark bất biến.
live = list(DOCS.rglob('*.md')) + [ROOT / 'README.md'] + list((ROOT / 'kế hoạch - nhật ký tuần').rglob('*.md'))
rewritten = []
pattern = re.compile(r'\[([^\]\n]+)\]\(([^)\n]+)\)')
for file in live:
    if file == gate:
        continue
    text = file.read_text(encoding='utf-8-sig')
    def replace(match):
        target = match.group(2).strip('<>')
        if re.match(r'\w+://', target):
            return match.group(0)
        resolved = (file.parent / unquote(target.split('#')[0])).resolve()
        if resolved in removed:
            relative = Path(os.path.relpath(summary, file.parent)).as_posix()
            return f'[{match.group(1)} — tổng hợp]({relative})'
        return match.group(0)
    updated = pattern.sub(replace, text)
    if updated != text:
        file.write_text(updated, encoding='utf-8')
        rewritten.append(file.relative_to(ROOT).as_posix())
assert hashlib.sha256(gate.read_bytes()).hexdigest() == gate_hash
manifest = {'date': '2026-10-26', 'original_files': len(files),
    'remaining_docs_files': len(list(DOCS.rglob('*.md'))),
    'archive_sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
    'snapshot_sha256': snapshots, 'removed_from_docs': sorted(p.relative_to(ROOT).as_posix() for p in removed),
    'summary': summary.relative_to(ROOT).as_posix(), 'rewritten_link_files': rewritten,
    'frozen_completion_gate_sha256': gate_hash,
    'note': 'Giữ nguyên dữ liệu/log/baseline. Đường dẫn cũ trong artifact lịch sử tra trong snapshot ZIP; không coi là tài liệu đang dùng.'}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: manifest[k] for k in ['original_files', 'remaining_docs_files', 'rewritten_link_files']}, ensure_ascii=False))
