"""Tải snapshot dữ liệu công khai; không chạy code hoặc chỉ dẫn từ nguồn."""
import datetime
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'benchmark/data/raw/injecagent'
if OUT.exists():
    raise ValueError('Không ghi đè snapshot nguồn đã tồn tại.')


def get(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'IPI-Scanner-data-provenance'})
    with urllib.request.urlopen(request, timeout=45) as response:
        content = response.read(8 * 1024**2 + 1)
    if len(content) > 8 * 1024**2:
        raise ValueError('Tệp vượt ngân sách tải của snapshot nhỏ.')
    return content


commit = json.loads(get('https://api.github.com/repos/uiuc-kang-lab/InjecAgent/commits/main'))
revision = commit['sha']
if len(revision) != 40 or any(c not in '0123456789abcdef' for c in revision):
    raise ValueError('Revision không hợp lệ.')
assets = {}
for file in ['LICENCE', 'README.md', 'data/test_cases_dh_base.json', 'data/test_cases_ds_base.json',
             'data/test_cases_dh_enhanced.json', 'data/test_cases_ds_enhanced.json']:
    url = f'https://raw.githubusercontent.com/uiuc-kang-lab/InjecAgent/{revision}/{file}'
    raw = get(url)
    if file.endswith('.json') and not isinstance(json.loads(raw), list):
        raise ValueError('Sai định dạng dữ liệu.')
    assets[file] = (raw, url)
if b'MIT License' not in assets['LICENCE'][0]:
    raise ValueError('Chưa xác minh được license dự kiến.')
OUT.mkdir(parents=True)
for file, (raw, _) in assets.items():
    target = OUT / file
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
manifest = {'repository': 'https://github.com/uiuc-kang-lab/InjecAgent', 'revision': revision,
    'retrieved_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'license_declared': 'MIT',
    'license_file': 'LICENCE', 'independence_verified': False, 'training_ready': False,
    'assets': {file: {'url': url, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
               for file, (raw, url) in assets.items()},
    'note': 'Đây là benchmark nguồn; phần được xem/chọn làm dev không được gọi là holdout chưa dùng.'}
(OUT / 'snapshot.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'revision': revision, 'files': len(assets), 'bytes': sum(len(v[0]) for v in assets.values())}))
