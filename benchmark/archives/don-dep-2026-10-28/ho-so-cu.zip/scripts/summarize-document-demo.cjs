// Tổng hợp lượt chẩn đoán đã lưu; không gọi model hoặc tự thay kết quả.
const fs = require('node:fs');
const path = require('node:path');
const { summarize } = require('./round-one-metrics.cjs');
const root = path.resolve(__dirname, '..');
const pairs = [
  { id: 'clean', label: 'benign', group: 'workshop-human', baseline: 'X1lA4i', candidate: 'Yi5L23' },
  { id: 'attack', label: 'malicious', group: 'workshop-directive', baseline: '5V7RE2', candidate: 'pdzZ9a' },
  { id: 'quoted', label: 'benign', group: 'workshop-directive', baseline: 'nLFBNr', candidate: 'JpEL5z' },
];
function load(id) {
  const dir = path.join(root, `benchmark/results/document-demo-${id}`);
  const data = JSON.parse(fs.readFileSync(path.join(dir, 'ket-qua.json'), 'utf8'));
  const calls = JSON.parse(fs.readFileSync(path.join(dir, 'model-calls.json'), 'utf8'));
  return { ...data, artifact: path.relative(root, dir), model_call_ms: calls.reduce((sum, call) => sum + call.elapsed_ms, 0) };
}
const rows = pairs.flatMap(pair => ['baseline', 'candidate'].map(variant => {
  const data = load(pair[variant]);
  if (data.bounded_experiment !== (variant === 'candidate')) throw new Error('Sai biến thể đo.');
  return { id: pair.id, label: pair.label, group: pair.group, variant, artifact: data.artifact,
    input_sha256: data.file_sha256, verdict: data.check.verdict, processing: data.processingStatus,
    seconds: data.model_call_ms / 1000, coverage: data.coverage };
}));
const metrics = list => {
  const data = summarize(list);
  const p = data.precision_of_alerts, r = data.confirmed_attack_recall;
  return { ...data, f1_alert_recall: p === null || r === null ? null : p + r ? 2 * p * r / (p + r) : 0,
    latency_basis: 'Tổng thời gian các HTTP model call đã nhận phản hồi; không phải toàn bộ UI hay đo tài nguyên GPU.' };
};
const result = { version: 1, decision: 'reject_candidate_keep_runtime_unchanged',
  candidate: 'Giới hạn analysis và reason ở 240 ký tự trong prompt/schema, giữ nguyên kiểm tra trích dẫn.',
  scope: 'Dev rất nhỏ tự soạn, 3 mẫu thuộc 2 nhóm; không độc lập, không chứng minh chất lượng bảo mật.',
  rows, metrics: Object.fromEntries(['baseline', 'candidate'].map(variant => {
    const selected = rows.filter(row => row.variant === variant);
    return [variant, { overall: metrics(selected), per_group: Object.fromEntries([...new Set(selected.map(r => r.group))]
      .map(group => [group, metrics(selected.filter(row => row.group === group))])) }];
  })),
  document_runs: ['7srbhU', 'G1v4HO', 'hO3MNi', 'R7OeVe'].map(id => {
    const data = load(id);
    return { artifact: data.artifact, bounded: data.bounded_experiment || false,
      profile: data.configuration?.scanProfile || data.coverage.scanProfile, processing: data.processingStatus,
      verdict: data.check.verdict, model_call_ms: data.model_call_ms, coverage: data.coverage };
  }),
  excluded_run: { artifact: 'benchmark/results/document-demo-SqzAIh', reason: 'Bridge cũ truyền sai scanProfile; gắn deep nhưng thực tế chỉ chọn 12 đoạn. Không dùng làm phép đo Deep Scan.' },
  limitations: ['Chưa kiểm thử UI/Electron hoặc nguồn độc lập.', 'Không có nhãn toàn tài liệu Word được duyệt; chỉ dùng để chẩn đoán lỗi xử lý.',
    'Mỗi cấu hình chỉ một lượt; không suy độ ổn định hoặc ý nghĩa thống kê.', 'Chưa đo peak VRAM/RAM; các lượt cũ chưa ghi đủ model digest/code hash.',
    'needs_review là abstention, tách khỏi TP/FP/TN/FN. Recall tính trên mọi mẫu malicious; FPR tính trên mọi mẫu benign.',
    'Thời gian model call không tính cuộc gọi thất bại trước khi có HTTP response.'] };
const dir = path.join(root, 'benchmark/experiments/document-output-budget-v1');
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'ket-qua.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ decision: result.decision, metrics: result.metrics }, null, 2));
