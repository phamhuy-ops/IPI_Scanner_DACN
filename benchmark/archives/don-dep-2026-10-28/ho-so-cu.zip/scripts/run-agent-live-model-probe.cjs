// Đo model thực qua Verifier/pipeline hiện tại; không dùng mẫu đang dự kiến train.
const fs=require('node:fs'),path=require('node:path');
const {hash}=require('./context-annotations.cjs');
const {summarize,compare}=require('./agent-live-probe-metrics.cjs');
const {metrics}=require('./priority-one-metrics.cjs');
const {runIpiDocScan}=require('../engine/scanner/ipi-doc-scan');
const root=path.resolve(__dirname,'..'),out='benchmark/experiments/agent-live-model-probe-v1';
const models={baseline:'qwen2.5-coder:1.5b',candidate:'qwen2.5:1.5b-instruct'};
function select(rows){
 const result=rows.filter(r=>['human','assistant','missing_recipient','quoted_assistant'].includes(r.variant_kind));
 if(result.length!==16||new Set(result.map(r=>r.group_id)).size!==4||result.some(r=>r.never_use_for_training!==true))throw new Error('Bộ đo không đúng 16 nguồn dev ngoài train.');
 return result;
}
async function main(){
 if(fs.existsSync(out))throw new Error('Không ghi đè hoặc tự đo lại.');
 const source='benchmark/data/annotations/verifier-role-authority-controls-v1/mau-cho-duyet.jsonl';
 const cases=select(fs.readFileSync(source,'utf8').trim().split(/\r?\n/).map(JSON.parse));
 const corpus=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-corpus-overlap-v21/ket-qua.json'));
 for(const r of cases){const component=corpus.groups.find(g=>g.members.includes(`verifier-role-authority-controls-v1:${r.id}`));
  if(!component||component.members.some(m=>!m.startsWith('verifier-role-authority-controls-v1:')))throw new Error('Dev có liên kết corpus ngoài nhóm được rà.');}
 const get=async endpoint=>{const r=await fetch('http://127.0.0.1:11434'+endpoint,{signal:AbortSignal.timeout(8000)});if(!r.ok)throw new Error(`Ollama ${r.status}`);return r.json();};
 const tags=await get('/api/tags');for(const name of [...Object.values(models),'gemma3:1b'])if(!tags.models.some(r=>r.name===name))throw new Error(`Thiếu model local ${name}`);
 const codeFiles=['scripts/run-agent-live-model-probe.cjs','scripts/agent-live-probe-metrics.cjs','src/ai/agents/slmClient.ts','src/ai/agents/slmCatalog.ts',
  'engine/scanner/ipi-doc-scan.js','engine/document/chunking/semantic-chunker.js','engine/prefilter/document-prefilter.js',
  ...fs.readdirSync('src/ai/agents/document').filter(n=>n.endsWith('.ts')).map(n=>'src/ai/agents/document/'+n)];
 const fingerprints=()=>Object.fromEntries(codeFiles.map(p=>[p,hash(fs.readFileSync(p))]));const before=fingerprints();
 const pipelineCases=cases.filter(r=>cases.slice(0,8).some(a=>a.id===r.id)&&['human','assistant'].includes(r.variant_kind));
 if(pipelineCases.length!==4)throw new Error('Sai đối chứng pipeline.');
 const plan={scope:'development_model_comparison_independent_of_training_pool_not_final_holdout',cases:cases.map(r=>({id:r.id,text:r.text,group:r.group_id,language:r.language,expected:r.annotation.stance,variant:r.variant_kind,directive:r.annotation.directive_spans[0].quote})),
  source_sha256:hash(fs.readFileSync(source)),code_sha256:before,models,model_tags:tags,
  direct_configuration:{reviewContract:'classic-v1',outputFormat:'standard',supplied_suspicions:0,all_source_in_one_chunk:true,max_tokens:1400,request_timeout_ms:45000,seed:42,temperature:0},
  pipeline_configuration:{detector:'gemma3:1b',baseline_verifier:models.baseline,profile:'deep',reviewContract:'classic-v1',outputFormat:'standard',deadline_ms:90000,cases:pipelineCases.map(r=>r.id)},
  budgets:{direct_requests:32,baseline_pipeline_runs:4,conditional_candidate_pipeline_runs:4,training_runs:0,prompt_changes:0},
  selection_gate:'Chỉ chạy pipeline ứng viên nếu cả 16 phản hồi hợp lệ, stance đúng tăng, không hồi quy ca đúng hoặc thêm FP/false-clear/xác nhận gold uncertain, mọi TP có trích đoạn trúng lệnh. Không tự đổi mặc định sau dev.',
  limitations:['Bộ dev đã từng dùng chẩn đoán, không phải holdout mới; audit từ vựng không chứng minh độc lập ngữ nghĩa.',
   'Classic không xuất enum ngữ cảnh; đánh giá ngữ cảnh phải đọc reason, không bịa accuracy addressee/framing.',
   'Direct chỉ là Verifier tìm lệnh không được cấp suspicion; pipeline TXT ngắn mới đo riêng bên dưới, không đại diện PDF/DOCX dài/UI.',
   'VRAM là snapshot /api/ps của model, không phải peak GPU; RSS chỉ harness, chưa đo RAM server.',
   'Không dùng 48 mẫu nháp train để chọn model; không train hoặc đổi prompt/parser.']};
 fs.mkdirSync(out);const save=(name,value)=>{const bytes=Buffer.from(JSON.stringify(value,null,2));fs.writeFileSync(`${out}/${name}`,bytes);if(!fs.readFileSync(`${out}/${name}`).equals(bytes))throw new Error('Readback lỗi');};
 save('giao-thuc-truoc-do.json',plan);
 const {createServer}=await import('vite');const server=await createServer({configFile:false,root,server:{middlewareMode:true,hmr:false},appType:'custom'});
 const calls=[],direct=[],pipelines=[];let phase='direct',activeCase,arm;
 try{
  const {runVerifierAgent}=await server.ssrLoadModule('/src/ai/agents/document/verifierAgent.ts');
  const {releaseSlmModel}=await server.ssrLoadModule('/src/ai/agents/slmClient.ts');
  const {runIpiDocumentPipeline}=await server.ssrLoadModule('/src/ai/agents/document/ipiPipeline.ts');
  globalThis.owaspWorkbench={scanIpiDoc:(paths,profile)=>runIpiDocScan(paths,{scanProfile:profile}),aiFetch:async payload=>{
   if(new URL(payload.url).origin!=='http://127.0.0.1:11434')throw new Error('Chỉ Ollama local.');
   const body=JSON.parse(payload.body),chat=payload.url.includes('/chat/completions');
   if(chat){const expected=phase==='direct'?[models[arm]]:['gemma3:1b',models[arm]];
    if(!expected.includes(body.model))throw new Error('Model thực chạy khác cấu hình đã khóa.');
    if(body.messages.some(m=>m.content.includes(activeCase.id)||m.content.includes(activeCase.group_id)))throw new Error('Corpus metadata lọt vào model.');body.seed=42;}
   const started=performance.now();
   try{const r=await fetch(payload.url,{method:payload.method,headers:payload.headers,body:JSON.stringify(body),signal:AbortSignal.timeout(payload.timeoutMs)});const raw=await r.text();
    if(chat){calls.push({phase,case_id:activeCase.id,arm,actual_requested_model:body.model,request:body,status:r.status,response:raw,seconds:(performance.now()-started)/1000,resources:await get('/api/ps').catch(()=>null)});save('model-calls.json',calls);}
    return {ok:r.ok,status:r.status,body:raw};
   }catch(error){if(chat){calls.push({phase,case_id:activeCase.id,arm,actual_requested_model:body.model,error:error.message,seconds:(performance.now()-started)/1000});save('model-calls.json',calls);}return {ok:false,status:0,body:'',error:error.message};}
  }};
  for(const [index,item]of cases.entries())for(arm of index%2?['candidate','baseline']:['baseline','candidate']){
   activeCase=item;const started=performance.now(),suspicions=[];
   const row={id:item.id,arm,group_id:item.group_id,language:item.language,expected:item.annotation.stance,model:models[arm],parsed:false,predicted:null,gold_instruction_covered:false};
   try{const chunks=[{chunkId:'chunk-1',fileName:'document.txt',filePath:'/document.txt',startLine:1,endLine:item.text.split('\n').length,text:item.text,riskScore:0,findingCount:0,selectionReasons:['complete_source_diagnostic']}];
    const result=await runVerifierAgent({chunks,suspicions,detectorReview:{model:'not_called',batchCount:0,suspiciousBatchCount:0,semanticAnalysis:'',reviewedChunkIds:[]},model:models[arm],deadline:Date.now()+45000,reviewContract:'classic-v1'});
    if(result.modelUsed!==models[arm])throw new Error('Model được báo cáo khác cấu hình.');
    const findings=suspicions.map(r=>r.verifier).filter(Boolean);row.parsed=true;
    row.predicted=findings.some(f=>f.stance==='confirmed')?'confirmed':findings.some(f=>f.stance==='uncertain')?'uncertain':'dismissed';
    row.findings=findings;const gold=item.annotation.directive_spans[0].quote;
    row.gold_instruction_covered=findings.filter(f=>f.stance==='confirmed').some(f=>f.citation.quote.includes(gold)||(gold.includes(f.citation.quote)&&f.citation.quote.trim().length>=16));
    row.model_vram_snapshot=calls.at(-1)?.resources?.models?.find(m=>m.name===models[arm])?.size_vram??null;
   }catch(error){row.error=error.message;}
   row.seconds=(performance.now()-started)/1000;direct.push(row);save('verifier-cases.json',direct);
   console.log(JSON.stringify({phase:'verifier',done:direct.length,total:32,model:models[arm],parsed:row.parsed,predicted:row.predicted}));
   await releaseSlmModel(models[arm]);
  }
  const comparison=compare(direct.filter(r=>r.arm==='baseline'),direct.filter(r=>r.arm==='candidate'));save('so-sanh-verifier.json',comparison);
  phase='pipeline';fs.mkdirSync(`${out}/input`);const file=path.resolve(out,'input/document.txt');
  for(const item of pipelineCases)for(arm of comparison.eligible_for_candidate_pipeline?['baseline','candidate']:['baseline']){
   activeCase=item;fs.writeFileSync(file,item.text);const started=performance.now();
   const state=await runIpiDocumentPipeline({filePaths:[file],scanProfile:'deep',reviewContract:'classic-v1',verifierOutput:'standard',fixModel:'gemma3:1b',checkModel:models[arm],analysisTimeoutMs:90000});
   const row={id:item.id,arm,label:item.annotation.label,source:item.source,group_id:item.group_id,language:item.language,
    verdict:state.check.verdict,processing:state.processingStatus,coverage_limited:state.scanResult?.metadata.coverage?.coverageLimited??true,
    seconds:(performance.now()-started)/1000,error:state.error,state};pipelines.push(row);save('pipeline-cases.json',pipelines);
   console.log(JSON.stringify({phase:'pipeline',done:pipelines.length,id:item.id,verdict:row.verdict,processing:row.processing}));
  }
  if(JSON.stringify(before)!==JSON.stringify(fingerprints()))throw new Error('Code đổi trong phép đo.');
  const after=await get('/api/tags');for(const name of [...Object.values(models),'gemma3:1b'])if(tags.models.find(r=>r.name===name).digest!==after.models.find(r=>r.name===name)?.digest)throw new Error('Digest model thay đổi.');
  const breakdown={};for(const a of ['baseline','candidate']){const rows=direct.filter(r=>r.arm===a);breakdown[a]={};for(const field of ['group_id','language'])breakdown[a][field]=Object.fromEntries([...new Set(rows.map(r=>r[field]))].map(k=>[k,summarize(rows.filter(r=>r[field]===k))]));}
  save('tong-hop.json',{complete:true,comparison,breakdown,pipeline:Object.fromEntries([...new Set(pipelines.map(r=>r.arm))].map(a=>[a,metrics(pipelines.filter(r=>r.arm===a))])),
   actual_chat_requests:calls.length,max_harness_rss:process.memoryUsage().rss,default_model_changed:false,model_selection_bug_fixed:true,
   model_trained:false,train_pool_48_used:false,limits:plan.limitations});
  console.log(JSON.stringify({complete:true,comparison,pipeline_runs:pipelines.length,calls:calls.length}));
 }catch(error){save('loi.json',{error:error.message,stack:error.stack,direct_completed:direct.length,pipeline_completed:pipelines.length});throw error;}
 finally{delete globalThis.owaspWorkbench;await server.close();}
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;});
module.exports={select};
