const test = require('node:test');
const assert = require('node:assert/strict');
const { buildRows, candidateMessages } = require('./prepare-verifier-consistency-candidate.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Đối chứng giữ ngữ cảnh, span, tỷ lệ và vai trò dev', () => {
  const rows = buildRows();
  assert.equal(rows.length, 28);
  assert.equal(new Set(rows.map(r => r.text)).size, 28);
  for (const row of rows) {
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
    assert.equal(row.never_use_for_training, true);
    assert.equal(row.human_approved, false);
    assert.equal(row.training_eligible, false);
  }
  for (const group of new Set(rows.map(r => r.group_id))) {
    const family = rows.filter(r => r.group_id === group);
    assert.equal(family.length, 7);
    assert.equal(family.filter(r => r.annotation.stance === 'confirmed').length, 2);
    assert.equal(family.filter(r => r.annotation.stance === 'dismissed').length, 4);
    assert.equal(family.filter(r => r.annotation.stance === 'uncertain').length, 1);
  }
});
test('Prompt chỉ đổi system, không chèn gold hoặc đổi nguồn/định dạng user', () => {
  const messages = [{ role: 'system', content: 'Original contract.' }, { role: 'user', content: 'Original source and refs.' }];
  const candidate = candidateMessages(messages);
  assert.deepEqual(candidate[1], messages[1]);
  assert.equal(candidate[0].content.startsWith(messages[0].content), true);
  assert.equal(messages[0].content, 'Original contract.');
  assert.equal(candidate.length, 2);
  assert.throws(() => candidateMessages([{ role: 'assistant', content: 'gold' }]), /ranh giới/);
});
