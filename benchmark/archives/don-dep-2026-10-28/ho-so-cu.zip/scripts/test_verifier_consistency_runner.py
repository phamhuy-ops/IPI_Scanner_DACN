"""Kiểm tra input đúng ngân sách và khác biệt duy nhất giữa hai prompt."""
import copy
import json
import unittest
from eval_verifier_consistency import ROOT, build_requests


class ConsistencyRunnerTests(unittest.TestCase):
    def data(self):
        old = [json.loads(line) for line in (ROOT / 'benchmark/experiments/verifier-local-release-v2/dev.preview.jsonl').read_text(encoding='utf-8').splitlines()]
        new = json.loads((ROOT / 'benchmark/data/annotations/verifier-consistency-controls-v1/ban-xem-truoc.json').read_text(encoding='utf-8'))['examples']
        selected = json.loads((ROOT / 'benchmark/experiments/verifier-hf-base-screen-v1/ke-hoach-truoc-do.json').read_text(encoding='utf-8'))['selected_source_ids']
        suffix = json.loads((ROOT / 'benchmark/experiments/verifier-consistency-candidate-v1/ung-vien.json').read_text(encoding='utf-8'))['suffix']
        return old, new, selected, suffix

    def test_exact_scope_and_source_preserved(self):
        result = build_requests(*self.data())
        self.assertEqual(len(result['baseline']), 68)
        self.assertEqual(len(result['candidate']), 68)
        for config in result:
            for row in result[config]:
                self.assertEqual(set(row), {'id', 'source_record_id', 'mode', 'cohort', 'messages'})
                self.assertEqual([m['role'] for m in row['messages']], ['system', 'user'])
                self.assertNotIn('target', row)

    def test_reject_source_change_or_missing_case(self):
        old, new, selected, suffix = self.data()
        tampered = copy.deepcopy(new)
        next(r for r in tampered if r['configuration'] == 'candidate')['payload']['messages'][1]['content'] += 'ALTERED'
        with self.assertRaises(ValueError):
            build_requests(old, tampered, selected, suffix)
        with self.assertRaises(ValueError):
            build_requests(old, new[:-1], selected, suffix)


if __name__ == '__main__':
    unittest.main()
