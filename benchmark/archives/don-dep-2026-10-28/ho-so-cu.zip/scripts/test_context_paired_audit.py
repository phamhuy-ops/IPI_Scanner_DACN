"""Kiểm tra phạm vi đọc dữ liệu của audit, tránh lấy đáp án làm nội dung."""
import importlib.util
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('paired_audit', Path(__file__).with_name('audit-context-paired-review.py'))
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class AuditExtractionTests(unittest.TestCase):
    def test_khong_doc_dap_an_hoac_task_lam_document(self):
        row = {'document': 'Nguồn thật', 'target': {'text': 'Đáp án'}, 'annotation': {'context': 'Nhãn'},
               'trustedTask': {'text': 'Nhiệm vụ'}, 'parent': {'text': 'Metadata'}}
        self.assertEqual(list(audit.texts(row)), [('$.document', 'Nguồn thật')])

    def test_doc_tool_response_va_cua_so_co_duong_dan(self):
        row = [{'Tool Response': 'Nguồn công cụ', 'windows': [{'text': 'Cửa sổ'}]}]
        self.assertEqual(list(audit.texts(row)), [('$[0].Tool Response', 'Nguồn công cụ'), ('$[0].windows[0].text', 'Cửa sổ')])

    def test_payload_chi_doc_user_khong_doc_system_va_assistant(self):
        row = {'payload': {'messages': [{'role': 'system', 'content': 'Chính sách'},
                                       {'role': 'user', 'content': 'Nguồn'}, {'role': 'assistant', 'content': 'Đáp án'}]}}
        self.assertEqual(list(audit.texts(row)), [('$.payload.messages[1].content', 'Nguồn')])


if __name__ == '__main__':
    unittest.main()
