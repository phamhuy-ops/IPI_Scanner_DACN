// Sổ điều kiện trước chia tập: tách nguồn, ngữ cảnh, dev exposure và quyền dùng.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const { buildRegistry, groupConstraints } = require('./assess-verifier-split-readiness.cjs');
const root = path.resolve(__dirname, '..');
const count = (rows, key) => rows.reduce((out, r) => { const k = typeof key === 'function' ? key(r) : r[key]; out[k] = (out[k] || 0) + 1; return out; }, {});

function consistencyIssues(a) {
  const issues = [];
  if (a.stance === 'confirmed' && (a.label !== 'malicious' || a.addressee !== 'assistant' || a.framing !== 'active' ||
      !a.hasDirective || ['none', 'unclear'].includes(a.deviation))) issues.push('confirmed_context_fields_conflict');
  if (a.stance === 'dismissed' && a.label !== 'benign') issues.push('dismissed_label_conflict');
  if (a.stance === 'uncertain' && a.label !== 'uncertain') issues.push('uncertain_label_conflict');
  if (a.stance === 'uncertain' && ![a.addressee, a.framing, a.deviation].includes('unclear') && !a.uncertainty_notes?.length) issues.push('uncertainty_basis_not_recorded');
  return issues;
}

function roleDecision(group, issues) {
  // Cờ test/reference/dev áp dụng cả nhóm, không tách mẫu tốt ra để né ràng buộc.
  if (group.proposed_constraint === 'retain_reference_only') return 'reference_only';
  if (group.proposed_constraint === 'quarantine_existing_test_overlap') return 'quarantine_test_overlap';
  if (group.proposed_constraint === 'retain_development_regression') return 'development_regression_only';
  if (issues.length) return 'quarantine_annotation_consistency';
  return 'candidate_pending_source_privacy_and_split_review';
}

function poolGaps(rows, plan) {
  const candidates = rows.filter(r => r.role === 'candidate_pending_source_privacy_and_split_review');
  const required = plan.data.planned_roles.train + plan.data.planned_roles.sealed_transfer_probe;
  return { candidate_records: candidates.length, candidate_groups: new Set(candidates.map(r => r.group_id)).size,
    requested_train: plan.data.planned_roles.train, requested_probe: plan.data.planned_roles.sealed_transfer_probe,
    additional_non_dev_candidates_lower_bound: Math.max(0, required - candidates.length),
    independent_holdout_target_separate: plan.data.independent_holdout.target_records,
    note: 'Chỉ giới hạn dưới nếu mọi ứng viên đều đạt. Probe chưa phải holdout độc lập; không cộng dev vào pool train/probe.' };
}

function main() {
  const out = path.join(root, 'benchmark/experiments/verifier-eligibility-v1');
  if (fs.existsSync(out)) throw new Error('Đã có lượt rà; không ghi đè.');
  const built = buildRegistry();
  const inputs = { ...built.inputs };
  const load = file => { const bytes = fs.readFileSync(path.join(root, file)); inputs[file] = hash(bytes); return JSON.parse(bytes); };
  const auditFile = 'benchmark/experiments/verifier-corpus-overlap-v10/ket-qua.json';
  const audit = load(auditFile);
  if (audit.missing_coverage.length || !audit.inputs_unchanged) throw new Error('Audit mới thiếu phạm vi hoặc đầu vào đã đổi.');
  for (const item of audit.inventory) if (hash(fs.readFileSync(path.join(root, item.file))) !== item.sha256) throw new Error(`Audit đã cũ: ${item.file}`);
  const baseline = load('benchmark/data/priority-one-dev-v2.json');
  const plan = load('benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json');
  const groups = groupConstraints(built.records, audit.groups, new Set(baseline.cases.map(c => c.original_id)));
  if (groups.flatMap(g => g.members).length !== 178) throw new Error('Nhóm không phủ đủ registry.');
  const sourceCache = new Map();
  const sourceRows = file => {
    if (!sourceCache.has(file)) sourceCache.set(file, fs.readFileSync(path.join(root, file), 'utf8').trim().split(/\r?\n/).map(JSON.parse));
    return sourceCache.get(file);
  };
  const sourceEvidence = source => {
    if (source.includes('python/cpython')) return { kind: 'pinned_external_license_document', license_declared: 'PSF-2.0 with retained notices', files: ['benchmark/data/raw/python-context-docs-v1/LICENSE', 'benchmark/data/raw/python-context-docs-v1/snapshot.json'] };
    if (source.includes('InjecAgent')) return { kind: 'pinned_external_license_document', license_declared: 'MIT', files: ['benchmark/data/raw/injecagent/LICENCE', 'benchmark/data/raw/injecagent/snapshot.json'] };
    if (source.includes('NotInject')) return { kind: 'dataset_card_declaration', license_declared: 'MIT', files: ['benchmark/data/raw/notinject/README.md'] };
    if (source.includes('wikipedia')) return { kind: 'article_attribution_declared_not_article_specific_clearance', license_declared: 'CC-BY-SA-4.0', files: ['benchmark/data/raw/vietnamese-wikipedia-v1/GHI-CONG-VA-GIAY-PHEP.md'] };
    if (source.includes('realistic')) return { kind: 'source_provenance_review_required', license_declared: null, files: [] };
    return { kind: 'project_authored_release_not_declared', license_declared: null, files: [] };
  };
  const resultRows = built.records.map(record => {
    const source = sourceRows(record.record_file).find(row => hash(row.selected_window?.text ?? row.text) === record.effective_input_sha256);
    if (!source) throw new Error(`Không tìm đúng phiên bản: ${record.id}`);
    const possible = [source.window_annotation, source.annotation, source.draft_annotation].filter(Boolean);
    // Quyết định revise của người dùng được tìm từ phiếu gốc, không dùng nháp đã bị thay.
    if (record.reviewer_scope === 'human_visible_source') {
      const file = path.posix.dirname(record.record_file) + '/ket-qua-ra-soat.json';
      const review = load(file).reviews.find(r => r.id === source.id);
      if (review?.final_annotation) possible.push(review.final_annotation);
    }
    const annotation = possible.find(a => hash(JSON.stringify(a)) === record.effective_annotation_sha256);
    if (!annotation) throw new Error(`Không tìm đúng annotation đang dùng: ${record.id}`);
    const issues = consistencyIssues(annotation);
    const group = groups.find(g => g.members.includes(record.id));
    if (!group) throw new Error('Thiếu group.');
    const evidence = sourceEvidence(record.source);
    const evidenceHashes = Object.fromEntries(evidence.files.map(file => {
      const bytes = fs.readFileSync(path.join(root, file)); inputs[file] = hash(bytes); return [file, hash(bytes)];
    }));
    const role = roleDecision(group, issues);
    return { ...record, group_id: group.id, role, group_constraint: group.proposed_constraint,
      annotation_field_consistency: issues.length ? 'needs_review' : 'passed_technical_check_only', consistency_issues: issues,
      source_evidence: { ...evidence, sha256: evidenceHashes, training_reuse_approved: false,
        note: 'Ghi bằng chứng trong snapshot, không suy quyền train từ tên license hoặc nguồn công khai.' },
      review_tasks: role === 'candidate_pending_source_privacy_and_split_review' ? [
        'source_reuse_decision_not_recorded', 'privacy_and_full_visible_context_review_not_recorded',
        'semantic_reason_stance_rereview_before_export', 'role_assignment_and_group_split_not_final',
      ] : ['keep_group_out_of_training_or_resolve_quarantine'],
      training_eligible: false, split: null, independently_untouched_verified: false };
  });
  const before = load('benchmark/experiments/verifier-split-readiness-v1/rang-buoc-nhom.json').groups;
  const unchangedMembership = JSON.stringify(groups.map(g => g.members.slice().sort()).sort()) === JSON.stringify(before.map(g => g.members.slice().sort()).sort());
  const summary = { version: 'verifier-eligibility-v1', status: 'complete', records: resultRows.length, groups: groups.length,
    membership_unchanged_from_prior: unchangedMembership, roles: count(resultRows, 'role'),
    group_constraints: count(groups, 'proposed_constraint'),
    technical_consistency: count(resultRows, 'annotation_field_consistency'),
    by_source: Object.fromEntries([...new Set(resultRows.map(r => r.source))].map(source => {
      const rows = resultRows.filter(r => r.source === source);
      return [source, { total: rows.length, roles: count(rows, 'role'), source_evidence_kind: rows[0].source_evidence.kind }];
    })),
    pool_gaps: poolGaps(resultRows, plan), training_eligible_records: 0, final_split_created: false,
    training_started: false, new_annotation_records: 0, runtime_changed: false, priority_one_complete: false,
    inputs_sha256: inputs, code_sha256: hash(fs.readFileSync(__filename)),
    next_action: 'Rà 94 ứng viên theo nhóm: chốt source/privacy/context và bổ sung ít nhất 146 ứng viên ngoài dev theo mục tiêu train/probe; chưa xuất SFT hoặc chia holdout.',
    limitations: ['Không có cờ dev không chứng minh chưa từng xem hoặc chưa từng đo.',
      'Nhất quán enum không chứng minh lý do đúng hoặc nhãn có chất lượng ngữ nghĩa.',
      'Bằng chứng license cục bộ không phải phê duyệt quyền dùng lại; không đưa ra kết luận pháp lý.',
      'Audit v10 chỉ text đã liệt kê, chưa so ảnh/PDF/DOCX hoặc embedding/ngữ nghĩa.'],
  };
  fs.mkdirSync(out);
  fs.writeFileSync(path.join(out, 'ket-qua.json'), JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
  fs.writeFileSync(path.join(out, 'dieu-kien-tung-mau.jsonl'), resultRows.map(r => JSON.stringify(r)).join('\n') + '\n', { flag: 'wx' });
  fs.writeFileSync(path.join(out, 'rang-buoc-nhom.json'), JSON.stringify({ groups, final_split_created: false }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ roles: summary.roles, groups: groups.length, consistency: summary.technical_consistency, gaps: summary.pool_gaps }, null, 2));
}
if (require.main === module) main();
module.exports = { consistencyIssues, roleDecision, poolGaps };
