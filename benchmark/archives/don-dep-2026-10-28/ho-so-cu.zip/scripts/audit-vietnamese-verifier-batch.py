"""Kiểm tra nguyên vẹn nháp và gom gần trùng với kho 406 mẫu đã chuẩn bị."""
import importlib.util
import json
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('expansion', Path(__file__).with_name('prepare-verifier-expansion.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
BASE = ROOT / 'benchmark/data/annotations/verifier-vietnamese-v1'


def rows(file):
    return [json.loads(line) for line in file.read_text(encoding='utf-8').splitlines() if line.strip()]


def main():
    manifest = json.loads((BASE / 'manifest.json').read_text(encoding='utf-8'))
    errors = []
    for name, expected in manifest['asset_sha256'].items():
        if name == 'ket-qua-ra-soat.json':
            continue  # Quyết định thay đổi khi duyệt; kiểm tra bằng audit sau duyệt riêng.
        if module.digest((BASE / name).read_bytes()) != expected:
            errors.append(f'Tài sản nháp đã thay đổi: {name}')
    previous_groups = json.loads((ROOT / 'benchmark/data/annotations/verifier-expansion-v1/nhom-va-chia-du-kien.json').read_text(encoding='utf-8'))['groups']
    group_for = {member: group['id'] for group in previous_groups for member in group['members']}
    records = []
    files = {}
    for folder, role in [('ngu-canh-v1', 'legacy_reference'), ('verifier-batch-v1', 'reviewed_pilot_dev')]:
        file = ROOT / f'benchmark/data/annotations/{folder}/mau-cho-duyet.jsonl'
        files[file.relative_to(ROOT).as_posix()] = module.digest(file.read_bytes())
        for row in rows(file):
            identifier = f'{folder}:{row["id"]}'
            records.append({'id': identifier, 'text': row['text'], 'role': role, 'known_group': group_for[identifier]})
    file = ROOT / 'benchmark/data/annotations/verifier-expansion-v1/hang-cho-gan-nhan.jsonl'
    files[file.relative_to(ROOT).as_posix()] = module.digest(file.read_bytes())
    for row in rows(file):
        records.append({'id': row['id'], 'text': row['text'], 'role': row['role'], 'known_group': group_for[row['id']]})
    existing_count = len(records)
    new_file = BASE / 'mau-cho-duyet.jsonl'
    files[new_file.relative_to(ROOT).as_posix()] = module.digest(new_file.read_bytes())
    new_rows = rows(new_file)
    for row in new_rows:
        records.append({'id': row['id'], 'text': row['text'], 'role': 'new_vietnamese_batch', 'known_group': row['group_id']})
    groups, edges = module.cluster(records)
    cross = [{'left': records[e[0]]['id'], 'right': records[e[1]]['id'], 'method': e[2], 'score': e[3] if len(e) > 3 else None}
             for e in edges if e[0] < existing_count <= e[1] and e[2] != 'known_family']
    new_ids = {row['id'] for row in new_rows}
    new_groups = [group for group in groups if any(member in new_ids for member in group['members'])]
    if len(new_rows) != 15 or len(new_ids) != 15:
        errors.append('Sai số hàng hoặc ID trùng.')
    if cross:
        errors.append('Có gần trùng với mẫu cũ; phải xem xét nhóm trước khi phân bổ.')
    reviews = json.loads((BASE / 'ket-qua-ra-soat.json').read_text(encoding='utf-8'))['reviews']
    if len(reviews) != 15 or len({r['id'] for r in reviews}) != 15 or {r['id'] for r in reviews} != new_ids:
        errors.append('Thiếu hoặc trùng phiếu duyệt.')
    report = {'version': 1, 'inputs_sha256': files, 'method': 'Nhóm đã biết + NFKC/casefold/whitespace + Jaccard token trigram >=0.8',
              'prior_records': existing_count, 'new_records': len(new_rows), 'cross_matches': cross, 'new_groups': new_groups,
              'errors': errors, 'valid_source_group_audit': not errors, 'final_split_created': False,
              'training_ready': False, 'independent': False,
              'limitations': ['Không so ngữ nghĩa, không tự phát hiện bản dịch khác chữ.',
                             'Chỉ so với 406 mẫu trong hàng chờ/tham chiếu, chưa toàn bộ BIPIA/dev/test/fixture.',
                             'Các mẫu mới tự soạn theo lỗi dev; không phải nguồn kiểm chứng độc lập.',
                             'Audit này chỉ kiểm tra nguồn và nhóm; kết quả nhãn/parser xem tong-ket-ra-soat.json.',
                             'Chưa có tài liệu dài hoặc kiểm tra trích xuất PDF/DOCX.']}
    (BASE / 'kiem-tra-trung-va-nhom.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'prior_records': existing_count, 'new_records': len(new_rows), 'new_groups': len(new_groups),
                      'cross_matches': len(cross), 'errors': errors, 'training_ready': False}, ensure_ascii=False))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
