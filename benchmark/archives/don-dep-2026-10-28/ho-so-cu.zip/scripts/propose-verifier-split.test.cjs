const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { propose, validateAssignments } = require('./propose-verifier-split.cjs');
const load = () => fs.readFileSync('benchmark/experiments/verifier-eligibility-v12/registry.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
test('Tái tạo phương án cố định, giữ đủ dev và nhóm, cân bằng Việt/Anh', () => {
  const rows = load(), result = propose(rows);
  assert.equal(result.seed, 65);
  assert.equal(result.checks.train.summary.records, 180);
  assert.equal(result.checks.dev.summary.records, 84);
  assert.equal(result.checks.probe.summary.records, 60);
  assert.ok(Object.values(result.checks).every(c => c.language_vi_40 && c.language_en_40));
  assert.equal(result.assigned.unused_candidates.flatMap(g => g.members).length, 14);
  validateAssignments(rows, result.assigned);
  assert.ok(result.assigned.train.flatMap(g => g.members).every(r => r.training_eligible === false && r.split === null));
});
test('Chặn nhóm trùng, nhóm bị tách và dev lẫn vào train', () => {
  const rows = load(), { assigned } = propose(rows);
  let bad = structuredClone(assigned);
  bad.train.push(bad.probe[0]);
  assert.throws(() => validateAssignments(rows, bad), /nhiều vai trò/);
  bad = structuredClone(assigned);
  const large = bad.train.find(g => g.members.length > 1); large.members.pop();
  assert.throws(() => validateAssignments(rows, bad), /bị tách/);
  bad = structuredClone(assigned);
  bad.train.push(bad.dev.pop());
  assert.throws(() => validateAssignments(rows, bad), /Dev\/test\/reference/);
});
