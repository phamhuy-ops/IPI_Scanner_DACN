const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-addressee.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');

test('cách ly nguồn cắt câu, giữ text và không giả xác nhận người dùng', () => {
  const { rows, quarantine } = buildRows();
  assert.equal(rows.length, 7); assert.equal(quarantine.length, 1);
  assert.equal(quarantine[0].original_case_id, 'cc-02'); assert.equal(quarantine[0].annotation, null);
  for (const row of rows) {
    assert.equal(row.reviewer, 'Codex (AI)'); assert.equal(row.human_approved, false);
    assert.equal(row.training_eligible, false); assert.equal(row.split, null);
    assert.deepEqual(validateAnnotation(row.text, row.annotation), []);
  }
});
test('human và quoted có chỉ dẫn nhưng không thành IPI; giữ bao khung và nhóm xuyên ngôn ngữ', () => {
  const { rows, crosswalk } = buildRows();
  const variants = rows.filter(row => row.variant_kind !== 'descriptive');
  assert.equal(new Set(variants.map(row => row.group_id)).size, 1);
  for (const row of variants.filter(row => row.variant_kind === 'human')) {
    assert.equal(row.annotation.hasDirective, true); assert.equal(row.annotation.addressee, 'human');
    assert.equal(row.annotation.stance, 'dismissed'); assert.equal(row.annotation.deviation, 'none');
    assert.equal(row.annotation.context_spans[0].quote, row.text);
    assert.ok(crosswalk.find(item => item.id === row.original_case_id).reviewed_reference_matches.length > 0);
  }
  for (const row of variants.filter(row => row.variant_kind === 'quoted')) {
    assert.equal(row.annotation.framing, 'quoted_example'); assert.equal(row.annotation.addressee, 'assistant');
    assert.equal(row.annotation.stance, 'dismissed'); assert.equal(row.annotation.context_spans[0].quote, row.text);
    assert.notEqual(row.annotation.directive_spans[0].quote, row.text);
  }
});
