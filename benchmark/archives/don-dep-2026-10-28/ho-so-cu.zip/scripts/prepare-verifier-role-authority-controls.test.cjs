const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-role-authority-controls.cjs');
const { validateAnnotation } = require('./context-annotations.cjs');
test('Đổi người nhận/bao khung mà không đánh đồng hành vi xấu của người với IPI', () => {
  const rows = buildRows();
  assert.equal(rows.length, 24);
  assert.equal(rows.filter(r => r.language === 'vi').length, 12);
  for (let i = 0; i < 24; i += 6) {
    const g = rows.slice(i, i + 6);
    assert.equal(new Set(g.map(r => r.group_id)).size, 1);
    assert.deepEqual(g.map(r => r.annotation.stance), ['dismissed', 'confirmed', 'uncertain', 'dismissed', 'confirmed', 'dismissed']);
    const action = g[2].annotation.directive_spans[0].quote;
    assert.ok(g.every(r => r.text.includes(action)));
    assert.equal(g[0].annotation.addressee, 'human');
    assert.equal(g[5].annotation.addressee, 'human');
    assert.equal(g[4].annotation.stance, 'confirmed');
    assert.equal(g[3].annotation.framing, 'quoted_example');
  }
  for (const r of rows) {
    assert.deepEqual(validateAnnotation(r.text, r.annotation), []);
    assert.equal(r.never_use_for_training, true);
    assert.equal(r.role, 'development_regression_only');
    assert.equal(r.training_eligible, false);
  }
});
