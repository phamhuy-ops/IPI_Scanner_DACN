"""Tính causal cross entropy ở vị trí có target, giữ nguyên attention toàn nguồn."""
import torch
import torch.nn.functional as F


def completion_loss(model, batch):
    labels = batch['labels']
    if labels.ndim != 2 or labels.shape != batch['input_ids'].shape or torch.any(labels[:, 0] != -100):
        raise ValueError('Sai shape hoặc chưa mask token đầu.')
    # Logit tại t dự đoán label tại t+1; không dịch thêm trong collator.
    targets = labels[:, 1:]
    positions = torch.nonzero((targets != -100).any(dim=0), as_tuple=False).flatten()
    if positions.numel() == 0:
        raise ValueError('Không còn target để tính loss.')
    output = model(input_ids=batch['input_ids'], attention_mask=batch['attention_mask'],
                   logits_to_keep=positions, use_cache=False)
    selected = targets.index_select(1, positions)
    logits = output.logits.float()
    return F.cross_entropy(logits.reshape(-1, logits.shape[-1]), selected.reshape(-1), ignore_index=-100)
