const { test } = require('node:test');
const assert = require('node:assert/strict');
const { subset, check } = require('./check-verifier-group-budget.cjs');
test('Không tách nhóm hoặc dùng lại một nhóm để đạt ngân sách', () => {
  assert.equal(subset([[30, 0, 0]], [24, 0, 0]), null);
  assert.equal(subset([[1, 0, 0]], [2, 0, 0]), null);
  const groups = [[2, 1, 1], [1, 2, 1], [5, 0, 0]];
  const result = subset(groups, [3, 3, 2]);
  assert.deepEqual(result, [0, 1]);
});
test('Loại dev khỏi phép tính và không nâng kết quả số học thành đủ điều kiện train', () => {
  const result = check([{ role: 'development_regression_only', group_id: 'dev', stance: 'confirmed' }]);
  assert.equal(result.candidate_records, 0);
  assert.equal(result.count_only_witness_found, false);
  assert.equal(result.training_ready, false);
  assert.equal(result.final_split_created, false);
});
