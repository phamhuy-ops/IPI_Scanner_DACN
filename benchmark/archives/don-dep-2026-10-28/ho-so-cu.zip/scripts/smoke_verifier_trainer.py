"""Tích hợp Trainer QLoRA trên fixture riêng; adapter kỹ thuật không triển khai."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'benchmark/experiments/verifier-trainer-smoke-v1'


def main():
    if OUTPUT.exists():
        raise ValueError('Không ghi đè lượt Trainer cũ.')
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    if storage.drive.lower() != 'e:':
        raise ValueError('Trainer/cache/checkpoint phải ở E.')
    destination = storage / 'checkpoints/technical-trainer-v1'
    if destination.exists() or not destination.resolve().is_relative_to(storage):
        raise ValueError('Thư mục checkpoint đã có hoặc vượt storage.')
    OUTPUT.mkdir(parents=True)
    result = {'status': 'running', 'pilot_training_started': False, 'training_ready': False,
        'dev_or_holdout_used_for_updates': False, 'runtime_changed': False,
        'fixture': 'fresh_synthetic_resource_only', 'sequence_tokens': 2048,
        'target_tokens': [11, 256], 'gradient_accumulation_steps': 8,
        'micro_batch_size': 1, 'optimizer_steps_requested': 2,
        'checkpoint_path': str(destination), 'resume_verified': False}
    try:
        import torch
        import psutil
        from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig, TrainingArguments, TrainerCallback
        from peft import LoraConfig, get_peft_model, get_peft_model_state_dict, prepare_model_for_kbit_training
        from audit_verifier_tokenizer import MODEL, REVISION
        from smoke_verifier_gpu import fixture
        from verifier_collator import CompletionCollator
        from verifier_trainer import VerifierTrainer
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA không khả dụng; không tự chuyển CPU.')
        assets_path = ROOT / 'benchmark/experiments/verifier-gpu-assets-v1/ket-qua.json'
        assets = json.loads(assets_path.read_text(encoding='utf-8'))
        if assets['model'] != MODEL or assets['revision'] != REVISION:
            raise ValueError('Base model không khớp phiên bản đã audit.')
        local = Path(assets['snapshot']).resolve()
        if not local.is_relative_to(storage):
            raise ValueError('Weights ngoài E/storage đã cấu hình.')
        result['assets_manifest_sha256'] = hashlib.sha256(assets_path.read_bytes()).hexdigest()
        result['model'] = MODEL
        result['revision'] = REVISION
        result['versions'] = {p: importlib.metadata.version(p) for p in ['torch', 'transformers', 'peft', 'bitsandbytes', 'accelerate']}
        result['gpu'] = {'name': torch.cuda.get_device_name(0), 'total_bytes': torch.cuda.get_device_properties(0).total_memory,
                         'free_before_load': torch.cuda.mem_get_info()[0]}
        torch.manual_seed(42)
        tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False)
        data = [fixture(tokenizer, 2048, 11 if i % 2 == 0 else 256) for i in range(16)]
        result['fixture_sha256'] = hashlib.sha256(json.dumps(data).encode()).hexdigest()
        model = AutoModelForCausalLM.from_pretrained(local, local_files_only=True, trust_remote_code=False,
            quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4',
                bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.float16),
            device_map={'': 0}, torch_dtype=torch.float16, attn_implementation='sdpa')
        model.config.use_cache = False
        model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True,
            gradient_checkpointing_kwargs={'use_reentrant': False})
        model = get_peft_model(model, LoraConfig(r=8, lora_alpha=16, lora_dropout=.05,
            target_modules=['q_proj', 'v_proj'], bias='none', task_type='CAUSAL_LM'))
        assert all('lora_' in name for name, p in model.named_parameters() if p.requires_grad)
        result['trainable_parameters'] = sum(p.numel() for p in model.parameters() if p.requires_grad)
        assert all(str(v) in ['0', 'cuda:0'] for v in model.hf_device_map.values())
        result['cpu_offload'] = False
        initial = {k: v.detach().cpu().clone() for k, v in get_peft_model_state_dict(model).items()}

        class FiniteGradients(TrainerCallback):
            def __init__(self):
                self.checked_steps = 0

            def on_pre_optimizer_step(self, args, state, control, **kwargs):
                grads = [p.grad for p in kwargs['model'].parameters() if p.requires_grad and p.grad is not None]
                if not grads or not all(torch.isfinite(g).all() for g in grads):
                    raise FloatingPointError('Gradient thiếu hoặc không hữu hạn.')
                self.checked_steps += 1

        def make_trainer(folder):
            args = TrainingArguments(output_dir=str(folder), per_device_train_batch_size=1,
                gradient_accumulation_steps=8, max_steps=2, learning_rate=.0001,
                fp16=True, gradient_checkpointing=True, gradient_checkpointing_kwargs={'use_reentrant': False},
                max_grad_norm=1.0, optim='adamw_torch', lr_scheduler_type='constant', weight_decay=0,
                save_strategy='steps', save_steps=1, save_total_limit=2, logging_steps=1,
                report_to=[], disable_tqdm=True, dataloader_pin_memory=False, dataloader_num_workers=0,
                remove_unused_columns=False, label_names=['labels'], seed=42, data_seed=42)
            callback = FiniteGradients()
            trainer = VerifierTrainer(model=model, args=args, train_dataset=data,
                data_collator=CompletionCollator(tokenizer.pad_token_id, 2048), callbacks=[callback])
            # Dùng cùng initial scale đã qua smoke thủ công để tránh overflow bước đầu.
            trainer.accelerator.scaler = torch.amp.GradScaler('cuda', init_scale=1024)
            return trainer, callback

        trainer, callback = make_trainer(destination)
        torch.cuda.reset_peak_memory_stats()
        started = time.perf_counter()
        trainer.train()
        torch.cuda.synchronize()
        result['train_seconds'] = time.perf_counter() - started
        result['global_steps'] = trainer.state.global_step
        result['finite_gradient_steps'] = callback.checked_steps
        result['loss_observations'] = trainer.loss_observations
        assert trainer.state.global_step == 2 and callback.checked_steps == 2
        assert len(trainer.loss_observations) == 16
        for start in [0, 8]:
            batch = trainer.loss_observations[start:start+8]
            assert all(o['normalizer_tokens'] == sum(b['supervised_tokens'] for b in batch) for o in batch)
        expected = {k: v.detach().cpu().clone() for k, v in get_peft_model_state_dict(model).items()}
        assert any(not torch.equal(v, expected[k]) for k, v in initial.items()), 'Adapter chưa cập nhật.'
        result['adapter_updated'] = True
        trainer.save_model(str(destination / 'adapter-final'))
        for checkpoint in [destination, destination / 'checkpoint-1', destination / 'checkpoint-2', destination / 'adapter-final']:
            (checkpoint / 'KHONG-DUNG-TRIEN-KHAI.json').write_text('{"technical_fixture_only":true}', encoding='utf-8')
        del trainer
        torch.cuda.empty_cache()
        resumed, resumed_callback = make_trainer(destination / 'resume-verification')
        resumed.train(resume_from_checkpoint=str(destination / 'checkpoint-1'))
        actual = get_peft_model_state_dict(model)
        differences = {k: float((value - actual[k].detach().cpu()).abs().max()) for k, value in expected.items()}
        result['max_adapter_difference_after_resume'] = max(differences.values())
        assert resumed.state.global_step == 2 and resumed_callback.checked_steps == 1
        assert len(resumed.loss_observations) == 8
        for k, value in expected.items():
            torch.testing.assert_close(value, actual[k].detach().cpu(), rtol=1e-4, atol=1e-6)
        result['resume_verified'] = True
        result['resume_micro_batches'] = len(resumed.loss_observations)
        result['resume_final_step'] = resumed.state.global_step
        (destination / 'resume-verification/KHONG-DUNG-TRIEN-KHAI.json').write_text('{"technical_fixture_only":true}', encoding='utf-8')
        result['peak_torch_allocated_bytes'] = torch.cuda.max_memory_allocated()
        result['peak_torch_reserved_bytes'] = torch.cuda.max_memory_reserved()
        result['gpu_free_after'] = torch.cuda.mem_get_info()[0]
        result['process_memory'] = psutil.Process().memory_info()._asdict()
        result['status'] = 'passed_technical_only'
    except Exception as error:
        import traceback
        result.update(status='failed', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        if 'torch' in locals() and torch.cuda.is_available():
            result['peak_torch_allocated_bytes'] = torch.cuda.max_memory_allocated()
            result['peak_torch_reserved_bytes'] = torch.cuda.max_memory_reserved()
    finally:
        result['code_sha256'] = {n: hashlib.sha256((ROOT / 'scripts' / n).read_bytes()).hexdigest() for n in
            ['smoke_verifier_trainer.py', 'verifier_trainer.py', 'verifier_supervised_loss.py', 'verifier_collator.py', 'smoke_verifier_gpu.py']}
        result['limitations'] = ['Fixture kỹ thuật tự soạn, không đo chất lượng IPI hoặc độ ổn định train dài.',
            'Chỉ hỗ trợ một thiết bị và phiên bản thư viện đã khóa.', 'Peak PyTorch không phải peak toàn GPU.',
            'Không thay thế dữ liệu đủ điều kiện và kiểm chứng độc lập trước pilot.']
        result['command'] = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/python-verifier.ps1 scripts/smoke_verifier_trainer.py'
        (OUTPUT / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({k: result.get(k) for k in ['status', 'global_steps', 'resume_verified', 'peak_torch_allocated_bytes', 'error']}, ensure_ascii=False), flush=True)
    return 0 if result['status'] == 'passed_technical_only' else 1


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
