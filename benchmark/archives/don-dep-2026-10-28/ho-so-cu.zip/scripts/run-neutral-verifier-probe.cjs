// A/B cùng Verifier: tìm discovery tự do so với task kiểm tra toàn đoạn, không dùng gold.
const fs=require('node:fs'),path=require('node:path');
const {hash}=require('./context-annotations.cjs');
const {select}=require('./run-agent-live-model-probe.cjs');
const {summarize,compare}=require('./agent-live-probe-metrics.cjs');
const out='benchmark/experiments/neutral-verifier-probe-v1',model='qwen2.5-coder:1.5b';
async function main(){
 if(fs.existsSync(out))throw new Error('Không ghi đè hoặc tự chạy lại.');
 const source='benchmark/data/annotations/verifier-role-authority-controls-v1/mau-cho-duyet.jsonl';
 const cases=select(fs.readFileSync(source,'utf8').trim().split(/\r?\n/).map(JSON.parse));
 const old=JSON.parse(fs.readFileSync('benchmark/experiments/agent-live-model-probe-v1/giao-thuc-truoc-do.json'));
 if(hash(fs.readFileSync(source))!==old.source_sha256)throw new Error('Bộ đo thay đổi.');
 const get=async endpoint=>{const r=await fetch('http://127.0.0.1:11434'+endpoint,{signal:AbortSignal.timeout(8000)});if(!r.ok)throw new Error('Ollama không khả dụng');return r.json();};
 const tags=await get('/api/tags');if(tags.models.find(r=>r.name===model)?.digest!==old.model_tags.models.find(r=>r.name===model)?.digest)throw new Error('Model đổi so với baseline.');
 const files=['scripts/run-neutral-verifier-probe.cjs','scripts/agent-live-probe-metrics.cjs','src/ai/experiments/neutralVerifierTasks.ts',
 'src/ai/agents/slmClient.ts','src/ai/agents/slmCatalog.ts','src/ai/agents/document/verifierAgent.ts','src/ai/agents/document/reviewPolicy.ts','src/ai/agents/document/prompts.ts','src/ai/agents/document/evidence.ts'];
 const fingerprint=()=>Object.fromEntries(files.map(p=>[p,hash(fs.readFileSync(p))]));const before=fingerprint();
 fs.mkdirSync(out);const save=(name,value)=>{const b=Buffer.from(JSON.stringify(value,null,2));fs.writeFileSync(`${out}/${name}`,b);if(!fs.readFileSync(`${out}/${name}`).equals(b))throw new Error('Readback lỗi');};
 const plan={scope:'dev_ab_verifier_task_assignment_only',cases:cases.map(r=>({id:r.id,group:r.group_id,expected:r.annotation.stance,input_sha256:r.input_sha256})),
 model,model_digest:tags.models.find(r=>r.name===model).digest,code_sha256:before,seed:42,temperature:0,max_tokens:1400,deadline_ms:45000,
 baseline:'Không suspicion, giữ nguyên Verifier classic-v1.',candidate:'Giao toàn chunk làm task trung lập do Verifier tạo, source=verifier, không có Detector stance/reason; buffer riêng chỉ cho phép đo.',
 neutral_tasks_are_not_findings:true,gold_in_input:false,prompt_or_parser_changes:0,request_budget:32,training_runs:0,
 gates:{all_16_candidate_valid:true,strict_correct_stance_improvement:true,no_new_fp_falseclear_uncertain_overconfirmation:true,no_correct_case_regression:true,
 no_language_or_group_correct_count_regression:true,every_tp_source_grounded:true,p95_ratio_max:2,vram_snapshot_ratio_max:1.1},
 stop:'Chỉ đo 32 lượt, nếu trượt thì đóng đợt; không thêm task/prompt hoặc nhập vào pipeline. Nếu đạt, mới thiết kế tích hợp có kiểm chứng trước khi bật mặc định.',
 limitations:['Dev đã dùng trước, không phải holdout mới; tách khỏi 48 bản nháp train.',
 'Task mượn schema suspicion, nhưng không giả finding của Detector/rule và không đưa task chưa kết luận vào policy.',
 'Candidate quote được ràng buộc toàn chunk; đây là kiểm tra phân loại đoạn, không chứng minh model tự định vị span.',
 'Source=verifier và expected IDs là phần của một thay đổi giao việc, không tách riêng ảnh hưởng của từng trường.',
 'Classic không có enum ngữ cảnh; vẫn cần đọc reason khi kết luận sai. Chưa đo UI/tài liệu dài hoặc pipeline ứng viên.']};
 save('giao-thuc-truoc-do.json',plan);
 const {createServer}=await import('vite');const server=await createServer({configFile:false,root:path.resolve(__dirname,'..'),server:{middlewareMode:true,hmr:false},optimizeDeps:{noDiscovery:true},appType:'custom'});
 const records=[],calls=[];let active,arm;
 try{
 const {neutralVerifierTasks}=await server.ssrLoadModule('/src/ai/experiments/neutralVerifierTasks.ts');
 const {runVerifierAgent}=await server.ssrLoadModule('/src/ai/agents/document/verifierAgent.ts');
 const {releaseSlmModel}=await server.ssrLoadModule('/src/ai/agents/slmClient.ts');
 globalThis.owaspWorkbench={aiFetch:async payload=>{
  if(new URL(payload.url).origin!=='http://127.0.0.1:11434')throw new Error('Chỉ local.');const body=JSON.parse(payload.body),chat=payload.url.includes('/chat/completions');
  if(chat){if(body.model!==model)throw new Error('Đổi model ngoài kế hoạch.');if(body.messages.some(m=>m.content.includes(active.id)||m.content.includes(active.group_id)))throw new Error('Lộ metadata.');body.seed=42;}
  const start=performance.now();
  try{const response=await fetch(payload.url,{method:payload.method,headers:payload.headers,body:JSON.stringify(body),signal:AbortSignal.timeout(payload.timeoutMs)});const raw=await response.text();
   if(chat){calls.push({id:active.id,arm,request:body,status:response.status,response:raw,seconds:(performance.now()-start)/1000,resources:await get('/api/ps').catch(()=>null)});save('model-calls.json',calls);}
   return{ok:response.ok,status:response.status,body:raw};
  }catch(error){if(chat){calls.push({id:active.id,arm,error:error.message,seconds:(performance.now()-start)/1000});save('model-calls.json',calls);}return{ok:false,status:0,body:'',error:error.message};}
 }};
 for(const [index,item]of cases.entries())for(arm of index%2?['candidate','baseline']:['baseline','candidate']){
  active=item;const start=performance.now(),chunks=[{chunkId:'chunk-1',fileName:'document.txt',filePath:'/document.txt',startLine:1,endLine:item.text.split('\n').length,text:item.text,riskScore:0,findingCount:0,selectionReasons:['complete_source_diagnostic']}];
  const tasks=arm==='candidate'?neutralVerifierTasks(chunks):[];
  const row={id:item.id,arm,expected:item.annotation.stance,group_id:item.group_id,language:item.language,parsed:false,predicted:null,gold_instruction_covered:false};
  try{const result=await runVerifierAgent({chunks,suspicions:tasks,detectorReview:{model:'not_called',batchCount:0,suspiciousBatchCount:0,semanticAnalysis:'',reviewedChunkIds:[]},model,deadline:Date.now()+45000,reviewContract:'classic-v1'});
   if(result.modelUsed!==model)throw new Error('Model thực chạy không khớp.');const findings=tasks.map(t=>t.verifier).filter(Boolean);
   row.parsed=true;row.predicted=findings.some(f=>f.stance==='confirmed')?'confirmed':findings.some(f=>f.stance==='uncertain')?'uncertain':'dismissed';
   row.findings=findings;const gold=item.annotation.directive_spans[0].quote;
   row.gold_instruction_covered=findings.filter(f=>f.stance==='confirmed').some(f=>f.citation.quote.includes(gold)||(gold.includes(f.citation.quote)&&f.citation.quote.trim().length>=16));
   row.model_vram_snapshot=calls.at(-1)?.resources?.models?.find(m=>m.name===model)?.size_vram??null;
  }catch(error){row.error=error.message;}
  row.seconds=(performance.now()-start)/1000;records.push(row);save('cases.json',records);console.log(JSON.stringify({done:records.length,total:32,arm,parsed:row.parsed,predicted:row.predicted}));await releaseSlmModel(model);
 }
 const baseline=records.filter(r=>r.arm==='baseline'),candidate=records.filter(r=>r.arm==='candidate'),decision=compare(baseline,candidate);
 const groupRegressions=[];for(const field of ['language','group_id'])for(const key of new Set(baseline.map(r=>r[field])))if(summarize(candidate.filter(r=>r[field]===key)).correct_stance<summarize(baseline.filter(r=>r[field]===key)).correct_stance)groupRegressions.push({field,key});
 const ratio=decision.baseline.latency_p95?decision.candidate.latency_p95/decision.baseline.latency_p95:null;
 const vramRatio=decision.baseline.max_model_vram_snapshot?decision.candidate.max_model_vram_snapshot/decision.baseline.max_model_vram_snapshot:null;
 const passed=decision.eligible_for_candidate_pipeline&&groupRegressions.length===0&&ratio!==null&&ratio<=2&&vramRatio!==null&&vramRatio<=1.1;
 const breakdown={};for(const a of ['baseline','candidate']){breakdown[a]={};for(const field of ['language','group_id'])breakdown[a][field]=Object.fromEntries([...new Set(records.map(r=>r[field]))].map(k=>[k,summarize(records.filter(r=>r.arm===a&&r[field]===k))]));}
 if(JSON.stringify(before)!==JSON.stringify(fingerprint()))throw new Error('Code thay đổi trong phép đo.');
 if((await get('/api/tags')).models.find(r=>r.name===model)?.digest!==plan.model_digest)throw new Error('Model đổi digest.');
 const previous=JSON.parse(fs.readFileSync('benchmark/experiments/agent-live-model-probe-v1/model-calls.json'));
 const baselineDrift=calls.filter(c=>c.arm==='baseline').filter(c=>{const old=previous.find(p=>p.phase==='direct'&&p.arm==='baseline'&&p.case_id===c.id);return old?.response!==c.response;}).map(c=>c.id);
 save('tong-hop.json',{complete:records.length===32,passed,decision,group_regressions:groupRegressions,latency_ratio:ratio,vram_snapshot_ratio:vramRatio,breakdown,baseline_raw_response_differences:baselineDrift,
 actual_chat_requests:calls.length,pipeline_changed:false,default_model_changed:false,model_trained:false,train_pool_48_used:false,limits:plan.limitations});
 console.log(JSON.stringify({complete:true,passed,decision,groupRegressions,latency_ratio:ratio}));
 }catch(error){save('loi.json',{error:error.message,stack:error.stack,completed:records.length});throw error;}
 finally{delete globalThis.owaspWorkbench;await server.close();}
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;});
