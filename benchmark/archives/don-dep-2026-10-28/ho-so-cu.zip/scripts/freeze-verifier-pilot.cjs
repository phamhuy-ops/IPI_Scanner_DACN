// Khóa đầu vào/phép đo cho preflight; không huấn luyện hoặc cấp quyền triển khai.
const fs = require('node:fs');
const { hash } = require('./context-annotations.cjs');
const out = 'benchmark/experiments/verifier-pilot-freeze-v1';
function verify(manifest, read = file => fs.readFileSync(file)) {
  for (const [file, expected] of Object.entries(manifest.locked_files_sha256)) if (hash(read(file)) !== expected) throw new Error(`Bản khóa đã đổi: ${file}`);
  return true;
}
function main() {
  if (process.argv[2] === '--check') {
    verify(JSON.parse(fs.readFileSync(`${out}/giao-thuc.json`)));
    console.log(JSON.stringify({ locked_inputs_unchanged: true, training_started: false })); return;
  }
  if (fs.existsSync(out)) throw new Error('Không ghi đè phiên bản khóa.');
  const base = 'benchmark/experiments/verifier-local-release-v2', source = 'benchmark/data/annotations/verifier-local-release-preview-v2';
  const tokenFile = 'benchmark/experiments/verifier-local-release-tokenizer-v2/ket-qua.json';
  const token = JSON.parse(fs.readFileSync(tokenFile));
  if (token.source_records !== 324 || token.mask_valid !== 648 || token.collator_valid !== 648 || !token.no_model_forward_or_updates) throw new Error('Token/mask bản mới chưa đạt.');
  const release = JSON.parse(fs.readFileSync(`${base}/manifest.json`));
  for (const [file, expected] of Object.entries(release.role_files_sha256)) if (hash(fs.readFileSync(`${base}/${file}`)) !== expected) throw new Error('File vai trò đã đổi.');
  for (const [file, expected] of Object.entries(token.input_sha256)) if (hash(fs.readFileSync(`${source}/${file}`)) !== expected) throw new Error('Token audit đã cũ.');
  const planFile = 'benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json', planBytes = fs.readFileSync(planFile), plan = JSON.parse(planBytes);
  const files = [`${base}/manifest.json`, `${base}/ghi-cong-va-pham-vi.json`, ...Object.keys(release.role_files_sha256).map(f => `${base}/${f}`),
    `${source}/manifest.json`, `${source}/mau-cho-duyet.jsonl`, tokenFile,
    'benchmark/experiments/verifier-email-semantic-review-v1/ket-qua.json',
    'scripts/verifier-batch-renderer.ts', 'scripts/verifier_collator.py', 'scripts/verifier_supervised_loss.py',
    'scripts/verifier_trainer.py', 'src/ai/agents/document/compactVerifier.ts', 'src/ai/agents/document/sourceReferences.ts',
    'docs/planning/cong-hoan-thanh-uu-tien-1.md'];
  const notice = JSON.parse(fs.readFileSync(`${base}/ghi-cong-va-pham-vi.json`));
  for (const [file, entry] of Object.entries(notice.notices)) {
    if (hash(fs.readFileSync(`${base}/${file}`)) !== entry.sha256) throw new Error('Notice đã đổi.');
    files.push(`${base}/${file}`);
  }
  const locked = Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(file))]));
  locked[`${out}/ke-hoach-tai-thoi-diem-khoa.json`] = hash(planBytes);
  const protocol = { version: 'verifier-pilot-freeze-v1', status: 'frozen_for_preflight_not_training_enabled',
    base_model: plan.base_model.huggingface_id, revision: plan.base_model.revision,
    seed: 42, model_backend: 'HF Qwen base NF4; so adapter off/on cùng một backend',
    source_records: { train: 180, dev: 84, probe: 60 }, rendered_examples: { train: 360, dev: 168, probe: 120 },
    training: { method: 'QLoRA NF4', max_sequence_tokens: 2048, micro_batch: 1, accumulation: 8,
      epochs_max: 2, learning_rate_candidates: [0.0001, 0.00005], candidate_budget: 2,
      loss: 'Chỉ completion JSON; source/system/user mask -100; không packing hoặc truncate ngầm.',
      adapter_location: plan.training_proposal.output_locations.adapter,
      checkpoint_location: plan.training_proposal.output_locations.trainer_output_dir },
    comparison: { temperature: 0, do_sample: false, max_new_tokens: 256,
      input_policy: 'Giữ nguyên source/reference/schema/prompt giữa base và adapter; không cắt input. Đo hai mode nhưng gom theo source/group.',
      selection: 'Chỉ chọn ứng viên theo dev; không theo training loss hoặc probe.',
      stages: ['Kiểm tra loader chỉ lấy train và mask thực tế.', 'Đo baseline HF base trên dev trước train.',
        'Huấn luyện tối đa ngân sách đã khóa khi loader và điều kiện nội bộ đạt.', 'Đo lại dev cùng base/backend, giữ lỗi và abstention.',
        'Nếu đạt mới khóa ứng viên và đo probe một lượt; probe hiện không phải holdout độc lập.', 'Holdout mới và toàn pipeline là các bước riêng trước kết luận nâng cấp.'],
      required_metrics: plan.evaluation.metrics, acceptance_gates: plan.evaluation.gates,
      original_data_control: 'Báo riêng dữ liệu nguyên gốc và bản thay email, giữ group; không gọi bản thay là benchmark gốc.',
      failure_policy: 'Ghi OOM/timeout/JSON lỗi; không bỏ ca để tăng metric. Ngừng nếu OOM/NaN hoặc rò dev/probe vào loss.' },
    locked_files_sha256: locked, code_sha256: hash(fs.readFileSync(__filename)),
    command: 'node scripts/freeze-verifier-pilot.cjs', verification_command: 'node scripts/freeze-verifier-pilot.cjs --check',
    training_enabled: false, training_started: false, probe_sealed: false, independent_holdout_verified: false,
    priority_one_complete: false,
    limitations: ['Khóa dữ liệu/phép đo không chứng minh model nhận diện tốt hơn; chưa có adapter IPI.',
      'Tên, URL và mã hóa chưa được ẩn danh đầy đủ; chỉ dùng nội bộ, không công bố tự động.',
      'Probe đã qua đọc/rà nhãn và cùng một số họ nguồn; không coi là holdout độc lập chưa chạm.'] };
  fs.mkdirSync(out);
  fs.writeFileSync(`${out}/ke-hoach-tai-thoi-diem-khoa.json`, planBytes, { flag: 'wx' });
  fs.writeFileSync(`${out}/giao-thuc.json`, JSON.stringify(protocol, null, 2) + '\n', { flag: 'wx' });
  verify(protocol);
  console.log(JSON.stringify({ files_locked: Object.keys(locked).length, training_enabled: false, ready_for_loader_preflight: true }));
}
if (require.main === module) main();
module.exports = { verify };
