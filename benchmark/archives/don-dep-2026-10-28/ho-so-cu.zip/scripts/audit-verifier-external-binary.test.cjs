const fs = require('node:fs');
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { audit } = require('./audit-verifier-external-binary.cjs');
const load = () => fs.readFileSync('benchmark/experiments/verifier-eligibility-v9/registry.jsonl', 'utf8').trim().split(/\r?\n/).map(JSON.parse);
test('Phủ đúng 102 ca, không tăng quyền train hoặc nhận là nhãn độc lập', () => {
  const rows = load(), before = JSON.stringify(rows), result = audit(rows);
  assert.equal(JSON.stringify(rows), before);
  assert.equal(result.records, 102);
  assert.deepEqual(result.stances, { dismissed: 59, confirmed: 43 });
  assert.ok(result.reviews.every(r => !r.independent_review && !r.human_approved && !r.training_eligible));
  assert.equal(result.registry_changed, false);
});
test('Từ chối annotation sai hash hoặc tập đã đổi phạm vi', () => {
  const rows = load();
  rows.find(r => r.id === 'verifier-external-ai-v1:ext3-001').effective_annotation_sha256 = 'stale';
  assert.throws(() => audit(rows), /khớp/);
  assert.throws(() => audit(load().filter(r => r.id !== 'verifier-external-ai-v1:ext3-001')), /102/);
});
