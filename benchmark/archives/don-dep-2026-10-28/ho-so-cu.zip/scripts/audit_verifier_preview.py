"""Audit token/mask/collator dùng chung cho batch bản xem trước, chạy offline."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from audit_verifier_tokenizer import MODEL, REVISION, completion_example
from verifier_collator import CompletionCollator

ROOT = Path(__file__).resolve().parents[1]


def main():
    from transformers import AutoTokenizer
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    if not all(re.fullmatch(r'verifier-[a-z0-9-]+', name) for name in [args.source, args.output]):
        raise ValueError('Tên batch/audit không hợp lệ.')
    source = ROOT / 'benchmark/data/annotations' / args.source
    output = ROOT / 'benchmark/experiments' / args.output
    if output.exists():
        raise ValueError('Không ghi đè audit đã có.')
    manifest = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest['assets_sha256'].items():
        p = (source / name).resolve()
        if not p.is_relative_to(source.resolve()) or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
            raise ValueError('Tài sản vượt phạm vi hoặc hash đã đổi.')
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, cache_dir=os.environ['HF_HUB_CACHE'],
                                             local_files_only=True, trust_remote_code=False)
    preview = json.loads((source / 'ban-xem-truoc.json').read_text(encoding='utf-8'))['examples']
    collator = CompletionCollator(tokenizer.pad_token_id, 2048)
    rows = []
    for example in preview:
        if not example['validation']['parser_valid'] or example['training_eligible']:
            raise ValueError('Bản xem trước không hợp lệ.')
        target = json.dumps(example['target'], ensure_ascii=False, separators=(',', ':'))
        ids, labels, boundary, end = completion_example(tokenizer, example['payload']['messages'], target)
        padded = (len(ids) + 7) // 8 * 8
        valid = False
        if padded <= 2048:
            batch = collator([{'input_ids': ids, 'labels': labels}])
            kept = batch['labels'][0].tolist()
            assert kept[:boundary] == [-100] * boundary
            assert tokenizer.decode([v for v in kept if v != -100]) == target + tokenizer.eos_token
            assert all(v == -100 for v, mask in zip(kept, batch['attention_mask'][0].tolist()) if mask == 0)
            valid = True
        rows.append({'id': example['id'], 'source_record_id': example['source_record_id'],
            'source_parent_id': example.get('source_parent_id', example['source_record_id']),
            'mode': example['mode'], 'tokens': len(ids), 'padded_tokens': padded,
            'supervised_tokens': end - boundary, 'mask_valid': True, 'collator_valid': valid})
    result = {'source': args.source, 'model': MODEL, 'revision': REVISION, 'offline': True,
        'examples': len(rows), 'source_records': len({r['source_record_id'] for r in rows}),
        'source_parents': len({r['source_parent_id'] for r in rows}),
        'mask_valid': sum(r['mask_valid'] for r in rows), 'collator_valid': sum(r['collator_valid'] for r in rows),
        'token_min': min(r['tokens'] for r in rows), 'token_max': max(r['tokens'] for r in rows),
        'target_max': max(r['supervised_tokens'] for r in rows),
        'over_budget': {str(n): sum(r['padded_tokens'] > n for r in rows) for n in [1024, 1536, 2048]},
        'rows': rows, 'input_sha256': {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
            for name in ['manifest.json', 'ban-xem-truoc.json']},
        'code_sha256': {name: hashlib.sha256((ROOT / 'scripts' / name).read_bytes()).hexdigest()
            for name in ['audit_verifier_preview.py', 'audit_verifier_tokenizer.py', 'verifier_collator.py']},
        'training_ready': False, 'no_model_forward_or_updates': True, 'runtime_changed': False,
        'limitations': ['Token/mask/parser đúng không chứng minh nhãn AI đúng hoặc độc lập ngữ nghĩa.',
                       'Không truncate; bản vượt 2048 bị đánh dấu collator_valid=false, chưa tạo bài học.']}
    output.mkdir(parents=True)
    (output / 'ket-qua.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['examples', 'source_records', 'source_parents', 'mask_valid', 'collator_valid', 'token_max', 'target_max', 'over_budget']}))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
