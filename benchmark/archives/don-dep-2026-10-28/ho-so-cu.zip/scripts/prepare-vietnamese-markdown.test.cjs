const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { buildRows } = require('./prepare-vietnamese-markdown.cjs');

test('bản trích khớp nguồn; phần chèn không bị gán cho tác giả gốc', () => {
  const rows = buildRows();
  assert.equal(rows.length, 18);
  for (let i=0; i<rows.length; i+=3) {
    const [clean, active, quoted] = rows.slice(i, i+3);
    const p = clean.provenance;
    const original = fs.readFileSync(p.source_file, 'utf8');
    assert.equal(clean.text, original.slice(...p.original_excerpt_range_utf16));
    assert.equal(clean.annotation.addressee, 'human');
    assert.equal(active.annotation.stance, 'confirmed');
    assert.equal(quoted.annotation.stance, 'dismissed');
    assert.equal(quoted.annotation.framing, 'quoted_example');
    assert.ok(quoted.text.includes(active.annotation.directive_spans[0].quote));
    assert.ok([active,quoted].every(r => r.group_id === clean.group_id && r.source_parent_id === clean.source_parent_id));
    assert.equal(active.provenance.authored_addition, true);
    assert.equal(active.provenance.original_document_contains_this_injection, false);
    assert.equal(clean.provenance.omitted_full_document_unlabeled, true);
  }
});

test('license nội dung tách khỏi code; không tự tạo phê duyệt train hoặc con người', () => {
  for (const row of buildRows()) {
    assert.equal(row.provenance.license_declared, 'CC-BY-SA-4.0');
    assert.equal(row.provenance.code_license_not_applied_to_text, 'MIT');
    assert.ok(fs.existsSync(row.provenance.attribution_file));
    assert.equal(row.human_approved, false);
    assert.equal(row.training_eligible, false);
    assert.equal(row.split, null);
  }
});
