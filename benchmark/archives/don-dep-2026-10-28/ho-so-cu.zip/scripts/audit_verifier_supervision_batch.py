"""Kiểm tra liên kết nhóm của batch train nháp với bản split và đối chứng dev; không gọi model."""
import hashlib
import argparse
import importlib.util
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    spec=importlib.util.spec_from_file_location('lex',Path(__file__).with_name('audit-cross-source-overlap.py'))
    lex=importlib.util.module_from_spec(spec);spec.loader.exec_module(lex)
    parser=argparse.ArgumentParser()
    parser.add_argument('--batch',default='verifier-supervision-batch-v1')
    parser.add_argument('--output',default='verifier-supervision-batch-audit-v1')
    parser.add_argument('--include-batch',action='append',default=[])
    args=parser.parse_args()
    if not re.fullmatch(r'verifier-supervision-batch-v[1-9][0-9]*',args.batch) or not re.fullmatch(r'verifier-supervision-batch-audit-v[1-9][0-9]*',args.output) or any(not re.fullmatch(r'verifier-supervision-batch-v[1-9][0-9]*',name) or name==args.batch for name in args.include_batch):
        raise ValueError('Tên batch hoặc audit không hợp lệ.')
    base=ROOT/'benchmark/data/annotations'/args.batch
    output=ROOT/'benchmark/experiments'/args.output
    if output.exists():
        raise ValueError('Không ghi đè audit.')
    batch_file=base/'mau-cho-duyet.jsonl'
    rows=[json.loads(line) for line in batch_file.read_text(encoding='utf-8').splitlines()]
    hashes={str(batch_file.relative_to(ROOT)):hashlib.sha256(batch_file.read_bytes()).hexdigest()}
    references=[]
    for name,role in [('verifier-local-release-preview-v2',None),('verifier-role-authority-controls-v1','dev_diagnostic'),('verifier-consistency-controls-v1','dev_selection')]+[(name,'train_draft') for name in args.include_batch]:
        file=ROOT/f'benchmark/data/annotations/{name}/mau-cho-duyet.jsonl'
        hashes[str(file.relative_to(ROOT))]=hashlib.sha256(file.read_bytes()).hexdigest()
        for line in file.read_text(encoding='utf-8').splitlines():
            ref=json.loads(line);references.append({**ref,'audit_role':role or ref['planned_role'],'audit_source':name})
    matches=[];issues=[]
    normalized=[lex.normalize(r['text']) for r in rows]
    if len(set(normalized))!=len(rows):
        issues.append('Batch có mẫu trùng sau chuẩn hóa.')
    for row in rows:
        parent=next((r for r in references if r['id']==row['parent_record_id'] and r['audit_source']=='verifier-local-release-preview-v2'),None)
        if not parent or parent['audit_role']!='train' or parent['group_id']!=row['group_id'] or parent['source_parent_id']!=row['source_parent_id']:
            issues.append(f'{row["id"]}: cha hoặc nhóm không khớp train.')
        if any(r['group_id']==row['group_id'] and r['audit_role'] not in {'train','train_draft'} for r in references):
            issues.append(f'{row["id"]}: nhóm cha có vai trò bảo vệ.')
        tokens=lex.tokenize(row['text']);tri=lex.shingles(tokens,3);passages=lex.shingles(tokens,12)
        for ref in references:
            other=lex.tokenize(ref['text']);grams=lex.shingles(other,3);reasons=[]
            if lex.normalize(row['text'])==lex.normalize(ref['text']):reasons.append('normalized_exact')
            if tri and grams and len(tri&grams)/len(tri|grams)>=.8:reasons.append('trigram_jaccard_0.8')
            if passages&lex.shingles(other,12):reasons.append('shared_12_token_passage')
            if reasons:matches.append({'id':row['id'],'reference_id':ref['id'],'reference_role':ref['audit_role'],
                'same_parent_group':row['group_id']==ref['group_id'],'reasons':reasons})
    protected=[r for r in matches if r['reference_role'] not in {'train','train_draft'}]
    cross_train=[r for r in matches if r['reference_role'] in {'train','train_draft'} and not r['same_parent_group']]
    result={'records':len(rows),'reference_records':len(references),'parent_group_issues':issues,'matches':matches,
        'protected_matches':protected,'cross_group_train_matches':cross_train,'normalized_duplicate_count':len(rows)-len(set(normalized)),
        'input_sha256':hashes,'model_called':False,'training_started':False,'training_ready':False,
        'included_train_draft_batches':args.include_batch,
        'limitations':['Đối chiếu 324 nguồn split, 52 đối chứng dev và các batch nháp đã chỉ định; chưa thay audit toàn raw hoặc tương đồng ngữ nghĩa.',
            'Giữ nhóm train cha dù từ vựng mới; không tính là nhóm độc lập hoặc chuyển vai trò vì không match.']}
    output.mkdir();(output/'ket-qua.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'records':len(rows),'references':len(references),'parent_group_issues':len(issues),'protected_matches':len(protected),'cross_group_train_matches':len(cross_train),'matches':len(matches)}))
    if issues or protected or cross_train:
        raise ValueError('Cần rà nhóm trước khi cân nhắc phát hành.')


if __name__=='__main__':
    main()
