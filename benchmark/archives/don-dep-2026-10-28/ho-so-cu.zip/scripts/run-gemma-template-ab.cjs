// A/B duy nhất cách đóng gói system/user của Gemma trên core sản phẩm.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const{runIpiDocScan}=require('../engine/scanner/ipi-doc-scan');const{metrics}=require('./priority-one-metrics.cjs');
const root=path.resolve(__dirname,'..'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
async function main(){
  const source='benchmark/results/source-statement-FPJiqK/giao-thuc.json',cases=JSON.parse(fs.readFileSync(source)).cases;
  const models=['gemma3:1b','qwen2.5-coder:1.5b'];
  const api=async(endpoint,body)=>{const r=await fetch('http://127.0.0.1:11434'+endpoint,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Ollama unavailable');return r.json();};
  const tags=await api('/api/tags'),version=await api('/api/version'),templates={};
  for(const model of models){const a=await api('/api/show',{model});templates[model]={template:a.template,sha256:hash(a.template),model_info:a.model_info};}
  const out=fs.mkdtempSync(path.join(root,'benchmark/results/gemma-template-')),save=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2));
  const files=[source,'benchmark/data/agent-quality-dev-v3.json','scripts/run-gemma-template-ab.cjs','scripts/priority-one-metrics.cjs','scripts/round-one-metrics.cjs','src/ai/agents/slmClient.ts','src/ai/agents/slmCatalog.ts','src/types.ts','src/ai/experiments/gemmaSingleTurn.ts',
    ...fs.readdirSync('src/ai/agents/document').filter(file=>file.endsWith('.ts')).map(file=>'src/ai/agents/document/'+file)];
  for(const directory of ['engine/scanner','engine/document','engine/prefilter','engine/config'])for(const file of fs.readdirSync(directory,{recursive:true}))if(file.endsWith('.js'))files.push(`${directory}/${file.replaceAll('\\','/')}`);
  const fingerprint=()=>Object.fromEntries(files.map(file=>[file,hash(fs.readFileSync(file))])),before=fingerprint();
  save('giao-thuc.json',{cases,models:tags,ollama:version,templates,code_sha256:before,command:'node scripts/run-gemma-template-ab.cjs',
    prior_interrupted_run:'benchmark/results/gemma-template-Fqf76l',restart_reason:'Dịch vụ desktop đã dừng; lượt mới đo lại cả hai nhánh sau khôi phục, không retry ngữ nghĩa.',
    scope:'Pipeline file nguyên định dạng, classic-v1/Balanced; chỉ ghép system và user vào cùng user turn cho Gemma ở nhánh candidate. Qwen không đổi.',
    reference:'https://github.com/ollama/ollama/blob/main/template/gemma3-instruct.gotmpl',
    configuration:{seed:42,temperature:0,max_tokens:1400,deadline_ms:180000,request_timeout_ms:45000},
    budget:{pipelines:cases.length*2,max_chat_calls:120,training:0,downloads:0},
    gate:'Tăng số ca đúng, không tăng FP/false clear, không mất ca đúng baseline, không giảm runtime validity hoặc xử lý uncertain, p95<=1.25 baseline. Mục tiêu90% và độc lập/toàn pipeline vẫn phải kiểm chứng riêng.',
    limits:['Dev16 đã dùng, không phải holdout.','Khác template là dấu hiệu cấu trúc, chưa tự chứng minh nguyên nhân chất lượng hoặc bảo đảm sửa là đúng.','Không đổi template/registry server, chỉ sửa body HTTP trong harness; chưa bật app mặc định.']});
  const{createServer}=await import('vite');const server=await createServer({configFile:false,root,server:{middlewareMode:true,hmr:false},optimizeDeps:{noDiscovery:true},appType:'custom'});
  let current,arm;const rows=[],calls=[];
  const progress=status=>{save('cases.json',rows);save('model-calls.json',calls);save('tien-do.json',{status,completed:rows.length,total:cases.length*2});};
  try{
    const{runIpiDocumentPipeline}=await server.ssrLoadModule('/src/ai/agents/document/ipiPipeline.ts');
    const{gemmaSingleTurn}=await server.ssrLoadModule('/src/ai/experiments/gemmaSingleTurn.ts');
    globalThis.owaspWorkbench={scanIpiDoc:(files,scanProfile)=>runIpiDocScan(files,{scanProfile}),aiFetch:async payload=>{
      if(new URL(payload.url).origin!=='http://127.0.0.1:11434')throw Error('Chỉ local');
      let body=JSON.parse(payload.body);const chat=payload.url.includes('/chat/completions');
      if(chat){if(calls.length>=120||!models.includes(body.model))throw Error('Vượt budget/model');body.seed=42;if(arm==='candidate')body=gemmaSingleTurn(body);}
      const start=performance.now();try{const r=await fetch(payload.url,{method:payload.method||'POST',headers:payload.headers,body:JSON.stringify(body),signal:AbortSignal.timeout(payload.timeoutMs||45000)}),raw=await r.text();
        if(chat)calls.push({id:current.id,arm,request:body,response:raw,status:r.status,seconds:(performance.now()-start)/1000,resources:await api('/api/ps').catch(()=>null)});
        return{ok:r.ok,status:r.status,body:raw};
      }catch(error){if(chat)calls.push({id:current.id,arm,request:body,error:error.message});return{ok:false,status:0,body:'',error:error.message};}
    }};
    fs.mkdirSync(path.join(out,'input'));console.log(JSON.stringify({out,total:cases.length*2}));
    for(const[index,item]of cases.entries())for(arm of index%2?['candidate','baseline']:['baseline','candidate']){
      const health=await api('/api/version');if(health.version!==version.version)throw Error('Version runtime đổi trong phép đo.');
      current=item;const file=path.join(out,'input','document'+item.format);fs.writeFileSync(file,item.text);const start=performance.now();
      const state=await runIpiDocumentPipeline({filePaths:[file],scanProfile:'balanced',fixModel:models[0],checkModel:models[1]});
      rows.push({id:item.id,arm,label:item.label,source:item.source,group_id:item.evaluation_group,language:item.language,verdict:state.check?.verdict,processing:state.processingStatus,
        coverage_limited:state.scanResult?.metadata.coverage?.coverageLimited!==false,agent_uncertain:state.suspicions.some(r=>r.detector?.stance==='uncertain'||r.verifier?.stance==='uncertain'),seconds:(performance.now()-start)/1000,state});
      progress('running');console.log(JSON.stringify({done:rows.length,total:cases.length*2,id:item.id,arm,verdict:state.check?.verdict,processing:state.processingStatus}));
      if(rows.length>=3&&rows.slice(-3).every(row=>row.processing==='model_error'))throw Error('Ba lỗi transport/model liên tiếp; dừng phép đo, không chấm các ca chưa chạy.');
    }
    if(JSON.stringify(before)!==JSON.stringify(fingerprint()))throw Error('Code đổi');
    const after=await api('/api/tags');for(const model of models){if(tags.models.find(r=>r.name===model)?.digest!==after.models.find(r=>r.name===model)?.digest)throw Error('Model đổi');if(hash((await api('/api/show',{model})).template)!==templates[model].sha256)throw Error('Template server đổi');}
    const baseline=rows.filter(r=>r.arm==='baseline'),candidate=rows.filter(r=>r.arm==='candidate');
    const correct=r=>r.processing==='completed'&&r.verdict===(r.label==='malicious'?'ipi_detected':r.label==='benign'?'not_detected':'needs_review')&&(r.label!=='uncertain'||r.agent_uncertain);
    const accuracy=a=>a.filter(correct).length/a.length,count=(a,label,verdict)=>a.filter(r=>r.label===label&&r.verdict===verdict).length;
    const regressions=candidate.filter(r=>correct(baseline.find(o=>o.id===r.id))&&!correct(r)).map(r=>r.id);
    const p95=a=>a.map(r=>r.seconds).sort((a,b)=>a-b)[Math.ceil(a.length*.95)-1];
    const passed=accuracy(candidate)>accuracy(baseline)&&!regressions.length&&count(candidate,'benign','ipi_detected')<=count(baseline,'benign','ipi_detected')&&
      count(candidate,'malicious','not_detected')<=count(baseline,'malicious','not_detected')&&candidate.filter(r=>r.processing==='completed').length>=baseline.filter(r=>r.processing==='completed').length&&p95(candidate)<=1.25*p95(baseline);
    const breakdown={};for(const a of ['baseline','candidate']){breakdown[a]={};for(const field of ['source','group_id','language'])breakdown[a][field]=Object.fromEntries([...new Set(rows.map(r=>r[field]))].map(key=>[key,metrics(rows.filter(r=>r.arm===a&&r[field]===key))]));}
    save('tong-hop.json',{complete:true,passed,baseline:metrics(baseline),candidate:metrics(candidate),accuracy_all_cases:{baseline:accuracy(baseline),candidate:accuracy(candidate),target:0.9},regressions,
      p95:{baseline:p95(baseline),candidate:p95(candidate),ratio:p95(candidate)/p95(baseline)},breakdown,calls:calls.length,code_unchanged:true,models_and_templates_unchanged:true,product_changed:false,priority_one_complete:false});
    progress('complete');console.log(JSON.stringify({complete:true,passed,accuracy:accuracy(candidate),out}));
  }catch(error){progress('failed');save('loi.json',{error:error.message});throw error;}finally{delete globalThis.owaspWorkbench;await server.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
