// Tổng hợp chứng cứ và kiểm tra tiền đề dữ liệu, không chạy model hoặc bắt đầu huấn luyện.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const count = (rows, key) => rows.reduce((out, row) => ({ ...out, [row[key]]: (out[row[key]] || 0) + 1 }), {});
function assessData(manifest, plan) {
  const rows = manifest.cases;
  if (new Set(rows.map(row => row.original_id)).size !== rows.length) throw new Error('Nguồn bị đếm lặp.');
  const labels = count(rows, 'expected_label'), languages = count(rows, 'language');
  const groupCount = new Set(rows.map(row => row.group_id)).size;
  const target = plan.data.pilot_target_records;
  const desired = Object.fromEntries(Object.entries({ malicious: plan.data.stance_targets.confirmed,
    benign: plan.data.stance_targets.dismissed, uncertain: plan.data.stance_targets.uncertain }).map(([label, fraction]) => [label, Math.round(target * fraction)]));
  const blockers = [];
  if (rows.length < target) blockers.push('Chưa đủ mục tiêu số nguồn của kế hoạch pilot.');
  if (groupCount < plan.data.minimum_source_groups) blockers.push('Chưa đủ nhóm nguồn sau gom, không bù bằng nhân bản biến thể.');
  if (plan.data.independent_holdout.status !== 'collected_and_verified') blockers.push('Chưa có bộ kiểm chứng độc lập được thu thập và xác minh.');
  if (!plan.task.training_export_created) blockers.push('Chưa xuất dữ liệu train với vai trò tập đã khóa.');
  if (!plan.environment.forward_backward_smoke_verified) blockers.push('Chưa kiểm tra backend train/save-reload trên phần cứng.');
  blockers.push('Chưa có audit tokenizer/chat template/completion mask thực tế.');
  return { unique_reviewed_sources: rows.length, source_groups: groupCount, labels, languages,
    formats: count(rows, 'format'), by_source: count(rows, 'source'),
    synthetic_sources: rows.filter(row => ['verifier-batch-v1', 'verifier-vietnamese-v1'].includes(row.source)).length,
    long_sources_at_least_8000_utf16_units: rows.filter(row => row.text.length >= 8000).length,
    language_label_cells: Object.fromEntries(Object.keys(languages).map(language => [language, count(rows.filter(row => row.language === language), 'expected_label')])),
    numerical_target_only: { sources: target, minimum_groups: plan.data.minimum_source_groups,
      additional_sources_lower_bound: Math.max(0, target - rows.length), additional_groups_lower_bound: Math.max(0, plan.data.minimum_source_groups - groupCount),
      desired_labels: desired, additional_label_counts: Object.fromEntries(Object.keys(desired).map(label => [label, Math.max(0, desired[label] - (labels[label] || 0))])) },
    final_train_dev_locked: false, unused_independent_holdout_sources_verified: 0, blockers,
    training_ready: false, note: 'Mục tiêu ngân sách cũ, không phải chứng minh chỉ cần đủ số lượng; mọi nguồn hiện tại đã dùng làm dev.' };
}
function main() {
  const inputs = {};
  const read = relative => { const bytes = fs.readFileSync(path.join(root, relative)); inputs[relative] = hash(bytes); return JSON.parse(bytes); };
  const manifest = read('benchmark/data/priority-one-dev-v2.json');
  const plan = read('benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json');
  const recognition = read('benchmark/experiments/model-context-v1/ket-qua.json');
  const stance = read('benchmark/experiments/stance-clarity-v1/ket-qua.json');
  const replacement = read('benchmark/experiments/verifier-candidate-v1/ket-qua.json');
  const order = read('benchmark/experiments/minimal-context-order-v1/ket-qua.json');
  const small = read('benchmark/experiments/single-chunk-reference-v1/ket-qua.json');
  const budget = read('benchmark/experiments/document-output-budget-v1/ket-qua.json');
  const sourceFirst = read('benchmark/experiments/verifier-source-first-v1/ket-qua.json');
  const baseline = read('benchmark/experiments/priority-one-baseline-v1/ket-qua.json');
  const evidence = [
    { id: 'direct-recognition-vs-context', scope: '12 ca dev; không so trực tiếp metric với bộ 72 khác dữ liệu/hợp đồng.',
      models: Object.fromEntries(Object.entries(recognition.summary.by_model).map(([model, modes]) => [model,
        Object.fromEntries(Object.entries(modes).map(([mode, data]) => [mode, data.accepted]))])),
      conclusion: 'Nhận diện trực tiếp và gán ngữ cảnh là hai việc khác nhau; JSON hợp lệ không chứng minh ngữ nghĩa đúng.' },
    { id: 'stance-clarification', decision: stance.decision, gate: stance.summary.gates },
    { id: 'verifier-model-replacement', decision: replacement.decision, gate: replacement.gate },
    { id: 'context-first-field-order', eligible: order.eligible_for_further_study,
      models: Object.fromEntries(Object.entries(order.by_model).map(([model, profiles]) => [model,
        Object.fromEntries(Object.entries(profiles).map(([profile, data]) => [profile,
          { total: data.accepted.total, context_exact: data.accepted.context_exact, consistent: data.accepted.consistent }]))])) },
    { id: 'one-chunk-and-source-reference', decision: small.decision,
      document: small.runs.filter(row => row.id === 'private-word').map(row => ({ variant: row.variant, processing: row.processing, elapsed_ms: row.elapsed_ms })) },
    { id: 'bounded-output', decision: budget.decision, scope: budget.scope },
    { id: 'source-first-empty-suspicions', decision: sourceFirst.decision, gate: sourceFirst.gate,
      scope: '6 ca dev chọn theo lỗi, 3 tấn công vẫn bị bỏ sót; không chạy biến thể hoặc full72 ứng viên.' },
    { id: 'full-pipeline-reviewed72', metrics: baseline.metrics, gate: baseline.gate_checks },
  ];
  const result = { version: 1, evidence, data_readiness: assessData(manifest, plan), inputs_sha256: inputs,
    decision: 'stop_layout_only_trials_prepare_verifier_learning_prerequisites',
    conclusions: ['Chưa có ứng viên qua cổng; không đổi mặc định, không thêm phản biện để che lỗi vòng đầu.',
      'Đã thấy lỗi nhận diện và lỗi liên kết stance/ngữ cảnh bên cạnh lỗi trích dẫn; chưa chứng minh nguyên nhân duy nhất là thiếu fine-tuning.',
      'Model thay thế đã thử cũng chưa đạt; không tự suy mọi model lớn hơn sẽ giải quyết được.',
      'Không cộng số ca/lượt từ các thí nghiệm khác nhau thành accuracy chung.',
      'Ưu tiên kiểm tra cách biểu diễn dữ liệu/tokenizer/mask cho một Verifier và bổ sung nhóm còn thiếu, chưa bắt đầu train.'],
    next_concrete_step: { task: 'Audit tokenizer/chat template/completion mask trên bản preview đã kiểm tra, dùng model base và revision đã chốt.',
      base_model: plan.base_model.huggingface_id, revision: plan.base_model.revision,
      storage: plan.environment.training_storage_root, install_or_download_performed: false, weights_required_for_tokenizer_audit: false,
      training_allowed_now: false, requirement: 'Phải dùng tokenizer thật; không đoán token từ số ký tự hoặc coi metadata là token audit.' },
    priority_one_complete: false, training_started: false, runtime_changed: false,
    limitations: ['Bằng chứng chủ yếu là dev nhỏ lặp lại; chưa có đánh giá độc lập.',
      'Có tương quan giữa họ model, dữ liệu và các thử nghiệm; không diễn giải đây là ablation nhân quả đầy đủ.',
      'Readiness là kiểm tra tiền đề, không phải bằng chứng fine-tuning sẽ cải thiện bảo mật.'] };
  const dir = path.join(root, 'benchmark/experiments/verifier-next-step-v1');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'ket-qua.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ output: dir, decision: result.decision, data: result.data_readiness }, null, 2));
}
if (require.main === module) main();
module.exports = { assessData };
