const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');

async function main() {
  if (process.argv.length > 3 || (process.argv[2] && process.argv[2] !== '--serve')) throw new Error('Dùng không tham số hoặc --serve để kiểm tra giao diện.');
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { host: '127.0.0.1', port: 0 }, appType: 'spa' });
  const output = fs.mkdtempSync(path.join(root, 'benchmark/results/production-progress-'));
  const save = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n');
  let keepServing = false;
  try {
    const { runIpiDocumentPipeline } = await server.ssrLoadModule('/src/ai/agents/document/ipiPipeline.ts');
    const { reviewProgressCounts } = await server.ssrLoadModule('/src/ai/agents/document/reviewProgress.ts');
    const attack = JSON.parse(fs.readFileSync(path.join(root, 'benchmark/data/selector-spread-screen-v1.json'))).cases.find(row => row.id === 'document-5').text;
    const long = Array.from({ length: 180 }, (_, i) => `Dan Evans ghi nhận ${i} phiếu công khai trong đợt kiểm kê; nhân viên đối chiếu số lượng trên giấy trước buổi họp.`).join('\n');
    const cases = [
      { id: 'clean', label: 'Mẫu sạch', text: 'Dan Evans ghi nhận số liệu năng lượng mặt trời trong báo cáo công khai.' },
      { id: 'attack', label: 'Tấn công giả lập đồng thuận', text: attack },
      { id: 'detector-error', label: 'Detector lỗi sau batch thành công', text: long },
      { id: 'verifier-error', label: 'Verifier lỗi sau batch thành công', text: long },
    ];
    const records = [];
    for (const item of cases) {
      const file = path.join(output, `${item.id}.txt`); fs.writeFileSync(file, item.text);
      let detectorCalls = 0, verifierCalls = 0;
      globalThis.owaspWorkbench = {
        scanIpiDoc: (files, scanProfile) => runIpiDocScan(files, { scanProfile }),
        aiFetch: async payload => {
          if (payload.url.endsWith('/api/generate')) return { ok: true, status: 200, body: '{}' };
          const request = JSON.parse(payload.body), detector = request.model === 'gemma3:1b';
          if (detector) detectorCalls++; else verifierCalls++;
          const invalid = (item.id === 'detector-error' && detector && detectorCalls === 2) || (item.id === 'verifier-error' && !detector && verifierCalls === 2);
          const schema = request.response_format.json_schema.schema;
          const expected = schema.properties.assessments.items.anyOf || [];
          const reason = 'Đây là phản hồi giả lập để kiểm tra tiến độ và policy, không đo khả năng model.';
          const assessments = expected.map(shape => ({ id: shape.properties.id.enum[0], stance: 'confirmed', reason,
            chunkId: shape.properties.chunkId.enum[0], quote: shape.properties.quote.enum[0] }));
          const discoveries = item.id === 'attack' && detector ? [{ stance: 'confirmed', reason,
            chunkId: schema.properties.discoveries.items.properties.chunkId.enum[0], quote: item.text }] : [];
          const content = invalid ? '{oops' : JSON.stringify({ analysis: reason, assessments, discoveries });
          return { ok: true, status: 200, body: JSON.stringify({ choices: [{ message: { content } }] }) };
        },
      };
      const snapshots = [];
      const state = await runIpiDocumentPipeline({ filePaths: [file], onEvent: (_event, value) => snapshots.push(value.reviewProgress) });
      const counts = reviewProgressCounts(state.reviewProgress);
      if (item.id === 'clean') { assert.equal(state.check.verdict, 'not_detected'); assert.equal(counts.completed, counts.total); }
      if (item.id === 'attack') { assert.equal(state.check.verdict, 'ipi_detected'); assert.equal(counts.completed, counts.total); }
      if (item.id === 'detector-error') { assert.equal(state.processingStatus, 'invalid_response'); assert.equal(counts.detector, 3); assert.equal(counts.verifier, 0); }
      if (item.id === 'verifier-error') { assert.equal(state.processingStatus, 'invalid_response'); assert.equal(counts.detector, counts.selected); assert.ok(counts.verifier > 0 && counts.verifier < counts.selected); }
      if (item.id.endsWith('-error')) assert.equal(state.check.verdict, 'needs_review');
      records.push({ id: item.id, label: item.label, counts, state, snapshots });
      console.log(JSON.stringify({ id: item.id, counts, verdict: state.check.verdict }));
    }
    save('cases.json', records);
    save('summary.json', { status: 'complete', cases: records.length, endpoint_simulated: true,
      limitations: ['Scanner/client/parser/pipeline thật; endpoint giả lập, không đo nhận diện.', 'Trang preview dùng panel thật, chưa kiểm tra Electron IPC.'] });
    const relative = '/' + path.relative(root, output).replaceAll('\\', '/');
    fs.writeFileSync(path.join(output, 'index.html'), '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kiểm tra tiến độ pipeline</title></head><body><div id="root"></div><script type="module" src="' + relative + '/preview.tsx"></script></body></html>');
    fs.writeFileSync(path.join(output, 'preview.tsx'), `import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { IpiAgentPanelView } from '/src/components/IpiAgentPanel';
import '/src/index.css';
import records from './cases.json';
function Preview() { const [index, setIndex] = useState(0); return <main style={{maxWidth: 1000, margin:'24px auto', padding:16}}>
<h1>Kiểm tra tiến độ — endpoint giả lập</h1><p>Scanner và panel thật; không đo chất lượng nhận diện.</p>
<nav style={{display:'flex',gap:12,flexWrap:'wrap'}}>{records.map((row, i) => <button key={row.id} onClick={() => setIndex(i)}>{row.label}</button>)}</nav>
<IpiAgentPanelView ipiRun={records[index].state} ipiRunning={false} locale="vi" /></main>; }
createRoot(document.getElementById('root')!).render(<Preview />);
`);
    console.log(`Kết quả: ${path.relative(root, output)}`);
    if (process.argv[2] === '--serve') {
      await server.listen(); keepServing = true;
      console.log(`Giao diện kiểm tra: ${server.resolvedUrls.local[0].replace(/\/$/, '')}${relative}/index.html`);
    }
  } finally { delete globalThis.owaspWorkbench; if (!keepServing) await server.close(); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
