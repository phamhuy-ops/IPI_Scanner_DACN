const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {summarize,compare}=require('./agent-live-probe-metrics.cjs');
const {select}=require('./run-agent-live-model-probe.cjs');
test('Bộ đo là dev đã giữ ngoài train, không lấy batch 48 nháp',()=>{
 const rows=fs.readFileSync('benchmark/data/annotations/verifier-role-authority-controls-v1/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
 const chosen=select(rows);assert.equal(chosen.length,16);assert.ok(chosen.every(r=>r.never_use_for_training));
 chosen[0].never_use_for_training=false;assert.throws(()=>select(rows),/train/);
});
test('Lỗi không thành TN và không chọn model chỉ vì hợp lệ JSON',()=>{
 const a=Array.from({length:16},(_,i)=>({id:String(i),expected:'confirmed',predicted:null,parsed:false,seconds:1}));
 const b=a.map(r=>({...r,parsed:true,predicted:'confirmed',gold_instruction_covered:true}));
 assert.equal(compare(a,b).eligible_for_candidate_pipeline,true);
 b[0].gold_instruction_covered=false;assert.equal(compare(a,b).eligible_for_candidate_pipeline,false);
 const s=summarize([{expected:'dismissed',predicted:null,parsed:false,seconds:1}]);assert.equal(s.tn,0);assert.equal(s.precision,null);
});
