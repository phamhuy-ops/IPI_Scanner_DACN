// Phân tích ca oracle như chẩn đoán có đáp án ngữ cảnh, không như nâng cấp bảo mật.
const fs = require('node:fs');
const base = 'benchmark/experiments/verifier-runtime-oracle-v1';
function main() {
  if (fs.existsSync(`${base}/chan-doan.json`)) throw new Error('Không ghi đè chẩn đoán.');
  const read = p => JSON.parse(fs.readFileSync(p));
  const infer = read(`${base}/infer/danh-gia-v2.json`), oracle = read(`${base}/oracle/danh-gia-v2.json`);
  const old = read('benchmark/experiments/verifier-candidate02-eval-screen-v1/on/phan-hoi.json');
  const rawInfer = read(`${base}/infer/phan-hoi.json`);
  const pairs = infer.rows.map(row => {
    const other = oracle.rows.find(r => r.id === row.id);
    if (!other || other.expected !== row.expected) throw new Error('Hai nhánh không cùng ca/gold.');
    return { id: row.id, group_id: row.group_id, language: row.language, expected: row.expected,
      infer: { predicted: row.predicted, parsed: row.parsed, field_matches: row.field_matches, error: row.error ?? null },
      oracle: { predicted: other.predicted, parsed: other.parsed, field_matches: other.field_matches, error: other.error ?? null },
      corrected: !row.correct_stance && Boolean(other.correct_stance), regressed: Boolean(row.correct_stance) && !other.correct_stance };
  });
  const report = { scope: 'original_compact_task_diagnostic_oracle_not_product', infer_metrics: infer.aggregate, oracle_metrics: oracle.aggregate,
    infer_raw_differences_from_prior: rawInfer.filter(r => old.find(p => p.id === r.id)?.response !== r.response).map(r => r.id),
    corrected: pairs.filter(p => p.corrected).map(p => p.id), regressed: pairs.filter(p => p.regressed).map(p => p.id), pairs,
    by_language: { infer: infer.by_language, oracle: oracle.by_language }, by_group: { infer: infer.by_group, oracle: oracle.by_group },
    latency: { infer: infer.latency_seconds, oracle: oracle.latency_seconds }, resources: read(`${base}/ket-qua.json`),
    stance_only_diagnostic: read('benchmark/experiments/verifier-oracle-context-v1/ket-qua.json').summaries,
    training_started: false, probe_used: false, runtime_changed: false,
    limitations: ['Oracle cố ý cung cấp ngữ cảnh liên quan đáp án; tuyệt đối không dùng số này làm hiệu quả Agent.',
      'Stance-only đổi định dạng và sụp về dismissed nên không cô lập được lỗi pipeline gốc.',
      'Không tăng với oracle có thể do model không sử dụng oracle; không đủ quy nguyên nhân duy nhất.',
      'Giữ gold cũ, trong đó vf-002/vf-008 còn đề xuất rà framing chưa áp dụng. Dev chỉ 6 nguồn đã dùng nhiều lần.'] };
  fs.writeFileSync(`${base}/chan-doan.json`, JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ infer: report.infer_metrics, oracle: report.oracle_metrics, corrected: report.corrected, regressed: report.regressed, pairs }));
}
if (require.main === module) main();
