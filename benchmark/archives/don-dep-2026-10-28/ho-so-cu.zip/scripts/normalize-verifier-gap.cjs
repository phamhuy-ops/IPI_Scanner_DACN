// Chuẩn hóa và chia cửa sổ cơ học; không thay nhãn hay thay chunker ứng dụng.
const fs = require('node:fs');
const path = require('node:path');
const { hash, span, validateAnnotation } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const inputDir = path.join(root, 'benchmark/data/annotations/verifier-gap-v1');
const outputDir = path.join(root, 'benchmark/data/annotations/verifier-gap-normalized-v1');

function lineRanges(text) {
  const lines = [];
  for (const match of text.matchAll(/[^\r\n]*(?:\r\n|\r|\n|$)/g)) {
    if (match[0]) lines.push({ start: match.index, end: match.index + match[0].length });
  }
  return lines;
}

function makeWindows(text, maxUnits = 900) {
  if (!text || maxUnits < 1) throw new Error('Nguồn hoặc ngân sách cửa sổ không hợp lệ.');
  const lines = lineRanges(text), windows = [];
  let first = 0;
  while (first < lines.length) {
    let last = first;
    while (last + 1 < lines.length && lines[last + 1].end - lines[first].start <= maxUnits) last++;
    const start = lines[first].start, end = lines[last].end;
    if (end - start > maxUnits) throw new Error('Một dòng vượt ngân sách; cần xử lý riêng, không cắt giữa dòng.');
    windows.push({ start, end, start_line: first + 1, end_line: last + 1, text: text.slice(start, end) });
    if (last === lines.length - 1) break;
    // Chồng một dòng khi có thể, luôn tiến tới để không treo vòng lặp.
    first = last > first ? last : first + 1;
  }
  let covered = 0;
  for (const window of windows) {
    if (window.start > covered || text.slice(window.start, window.end) !== window.text) throw new Error('Hở nguồn hoặc sai tọa độ.');
    covered = Math.max(covered, window.end);
  }
  if (covered !== text.length) throw new Error('Chưa phủ hết văn bản nguồn.');
  return windows;
}

function normalizeRow(row, review) {
  if (review?.status !== 'human_reviewed' || review.decision !== 'accept' ||
      review.input_sha256 !== hash(Buffer.from(row.text)) ||
      review.draft_sha256 !== hash(JSON.stringify(row.draft_annotation))) throw new Error('Nhãn chưa duyệt hoặc nguồn đã đổi.');
  const errors = validateAnnotation(row.text, row.draft_annotation);
  if (errors.length) throw new Error(errors.join('; '));
  const windows = makeWindows(row.text);
  const directives = row.draft_annotation.directive_spans;
  const lines = lineRanges(row.text);
  // Bảo toàn trọn dòng chứa câu và các từ bao khung trích dẫn/phủ định của nó.
  const enclosing = lines.filter(line => directives.some(d => line.start < d.end && line.end > d.start));
  const contextStart = Math.min(...enclosing.map(line => line.start));
  const contextEnd = Math.max(...enclosing.map(line => line.end));
  const candidates = windows.filter(w => w.start <= contextStart && w.end >= contextEnd);
  if (!candidates.length) throw new Error('Không có cửa sổ giữ đủ dòng bằng chứng/ngữ cảnh; cách ly, không rút gọn gold.');
  // Chọn bản dài nhất trong giới hạn để giữ thêm nền; chỉ dùng chuẩn bị nhãn, không là selector runtime.
  const selectedRange = [...candidates].sort((a, b) => b.text.length - a.text.length || a.start - b.start)[0];
  // Chunker bỏ khoảng trắng ngoài; ánh xạ lại tọa độ, không thay nội dung bên trong.
  const leading = selectedRange.text.length - selectedRange.text.trimStart().length;
  const trailing = selectedRange.text.length - selectedRange.text.trimEnd().length;
  const selected = { ...selectedRange, start: selectedRange.start + leading,
    end: selectedRange.end - trailing, text: selectedRange.text.trim() };
  const localAnnotation = { ...row.draft_annotation,
    directive_spans: directives.map(d => {
      const local = span(selected.text, d.quote);
      if (local.start + selected.start !== d.start || local.end + selected.start !== d.end) throw new Error('Sai ánh xạ span UTF-16.');
      return local;
    }), context_spans: [span(selected.text, selected.text)] };
  if (validateAnnotation(selected.text, localAnnotation).length) throw new Error('Nhãn cửa sổ không hợp lệ.');
  return { id: row.id, group_id: row.group_id, text: row.text, format: row.format, language: row.language,
    input_sha256: row.input_sha256, review_sha256: hash(JSON.stringify(review)), provenance: row.provenance,
    annotation_original: row.draft_annotation, windows: windows.map((w, i) => ({ ...w, id: `window-${i + 1}`,
      group_id: row.group_id, annotation_status: w === selectedRange ? 'mechanically_mapped_pending_span_review' : 'unlabeled_not_a_benign_target' })),
    selected_window_id: `window-${windows.indexOf(selectedRange) + 1}`, selected_window: selected,
    window_annotation: localAnnotation, original_context_line_span: { start: contextStart, end: contextEnd, quote: row.text.slice(contextStart, contextEnd) },
    all_source_units_covered: true, annotation_guided_window_selection: true,
    semantic_context_preservation_human_verified: false, split: null, training_eligible: false };
}

async function main() {
  if (fs.existsSync(outputDir)) throw new Error('Không ghi đè bản chuẩn hóa đã tồn tại.');
  const rowsPath = path.join(inputDir, 'mau-cho-duyet.jsonl'), reviewsPath = path.join(inputDir, 'ket-qua-ra-soat.json');
  const rows = fs.readFileSync(rowsPath, 'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const reviews = JSON.parse(fs.readFileSync(reviewsPath)).reviews;
  const normalized = rows.map(row => normalizeRow(row, reviews.find(r => r.id === row.id)));
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  const examples = [];
  try {
    const { renderDraft } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of normalized) for (const mode of ['whole_source', 'none']) {
      const result = renderDraft({ text: row.selected_window.text, format: row.format, candidate_mode: mode }, row.window_annotation);
      examples.push({ id: `${row.id}-${mode}`, source_record_id: row.id, group_id: row.group_id,
        window_id: row.selected_window_id, mode, payload: result.payload, target: result.response,
        validation: result.validation, training_eligible: false });
    }
  } finally { await server.close(); }
  const assets = new Map([
    ['nhan-va-cua-so.jsonl', normalized.map(r => JSON.stringify(r)).join('\n') + '\n'],
    ['ban-xem-truoc.json', JSON.stringify({ training_export: false, examples }, null, 2) + '\n'],
  ]);
  const manifest = { sources: rows.length, long_sources: rows.filter(r => r.text.length >= 8000).length,
    proposed_groups: new Set(rows.map(r => r.group_id)).size, windows: normalized.reduce((n, r) => n + r.windows.length, 0),
    selected_annotated_windows: normalized.length, contract_examples: examples.length, parser_valid: examples.filter(r => r.validation.parser_valid).length,
    full_source_window_coverage: true, window_selection: 'annotation_guided_preparation_only_not_runtime_or_end_to_end_evaluation',
    span_mapping: 'UTF16_half_open_offsets_and_1_based_lines', context_rule: 'whole_enclosing_lines_plus_available_background_within_900_UTF16',
    other_windows_labeled_benign: false, training_ready: false, final_split_created: false, independent: false,
    human_span_review_complete: false, source_sha256: { rows: hash(fs.readFileSync(rowsPath)), reviews: hash(fs.readFileSync(reviewsPath)) },
    code_sha256: Object.fromEntries(['scripts/normalize-verifier-gap.cjs', 'scripts/verifier-batch-renderer.ts'].map(p => [p, hash(fs.readFileSync(path.join(root, p)))])),
    assets_sha256: Object.fromEntries([...assets].map(([p, v]) => [p, hash(Buffer.from(v))])),
    limitations: ['Cửa sổ dựa vào nhãn chỉ để chuẩn bị dữ liệu; không chứng minh selector tìm được bằng chứng trong tài liệu gốc.',
      'Giữ nguyên dòng bao khung không bảo đảm mọi phụ thuộc ngữ nghĩa xa; cần duyệt riêng cửa sổ/span.',
      'Các cửa sổ không có nhãn không tự được coi là sạch; chưa xuất train.'] };
  assets.set('manifest.json', JSON.stringify(manifest, null, 2) + '\n');
  for (const [p, value] of assets) { fs.mkdirSync(outputDir, { recursive: true }); fs.writeFileSync(path.join(outputDir, p), value); }
  console.log(JSON.stringify({ ...manifest, code_sha256: '[đã lưu]', assets_sha256: '[đã lưu]' }));
}
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { makeWindows, normalizeRow };
