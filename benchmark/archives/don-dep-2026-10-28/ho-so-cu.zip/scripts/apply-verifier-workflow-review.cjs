// Áp nhãn hiệu chỉnh theo phiên bản; không thêm mẫu, đổi nhóm hoặc cấp quyền train.
const fs = require('node:fs');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const { consistencyIssues } = require('./assess-verifier-eligibility.cjs');
const base = 'benchmark/experiments/verifier-eligibility-v6';
const reviewed = 'benchmark/data/annotations/verifier-vietnamese-workflow-reviewed-v1';
const tokenFile = 'benchmark/experiments/verifier-vietnamese-workflow-reviewed-tokenizer-v1/ket-qua.json';
const out = 'benchmark/experiments/verifier-eligibility-v7';
function replaceReviewed(rows, replacements, reviews) {
  const seen = new Set();
  const result = rows.map(row => {
    if (row.record_file !== 'benchmark/data/annotations/verifier-vietnamese-workflow-v1/mau-cho-duyet.jsonl') return row;
    const id = row.id.split(':').at(-1), next = replacements.find(r => r.id === id), review = reviews.find(r => r.id === id);
    if (!next || !review || seen.has(id) || hash(next.text) !== row.effective_input_sha256 ||
        review.original_annotation_sha256 !== row.effective_annotation_sha256 ||
        review.final_annotation_sha256 !== hash(JSON.stringify(next.annotation)) ||
        next.source_parent_id !== row.parent_id || next.annotation.stance !== row.stance ||
        validateAnnotation(next.text, next.annotation).length || consistencyIssues(next.annotation).length) throw new Error('Bản rà không khớp registry nền.');
    seen.add(id);
    return { ...row, framing: next.annotation.framing, effective_annotation_sha256: review.final_annotation_sha256,
      effective_version: 'ai_workflow_rereview_v1', record_file: `${reviewed}/mau-cho-duyet.jsonl`,
      latest_semantic_rereview: { file: `${reviewed}/danh-gia-ai.json`, decision: review.decision,
        independent: false, human_approved: false }, training_eligible: false, split: null };
  });
  if (seen.size !== 16 || replacements.length !== 16 || reviews.length !== 16) throw new Error('Không phủ đủ 16 bản thay thế.');
  return result;
}
function main() {
  if (fs.existsSync(out)) throw new Error('Không ghi đè registry.');
  const inputs = {}, read = file => { const bytes = fs.readFileSync(file); inputs[file] = hash(bytes); return bytes; };
  const json = file => JSON.parse(read(file));
  const jsonl = file => read(file).toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
  const previous = json(`${base}/ket-qua.json`);
  for (const [file, expected] of Object.entries(previous.inputs_sha256)) {
    const physical = previous.input_snapshots?.[file] ? `${base}/${previous.input_snapshots[file]}` : file;
    if (hash(read(physical)) !== expected) throw new Error(`Đầu vào nền đã đổi: ${file}`);
  }
  const manifest = json(`${reviewed}/manifest.json`);
  for (const [file, expected] of Object.entries(manifest.assets_sha256)) {
    if (!/^[a-z-]+\.(json|jsonl)$/.test(file) || hash(read(`${reviewed}/${file}`)) !== expected) throw new Error('Tài sản bản rà đã đổi.');
  }
  const token = json(tokenFile);
  if (token.source_records !== 16 || token.mask_valid !== 32 || token.collator_valid !== 32 || !token.no_model_forward_or_updates) throw new Error('Token audit chưa đạt.');
  for (const [file, expected] of Object.entries(token.input_sha256)) if (hash(read(`${reviewed}/${file}`)) !== expected) throw new Error('Token audit đã cũ.');
  const rows = replaceReviewed(jsonl(`${base}/registry.jsonl`), jsonl(`${reviewed}/mau-cho-duyet.jsonl`), json(`${reviewed}/danh-gia-ai.json`).reviews);
  const groups = read(`${base}/rang-buoc-nhom.json`);
  const planPath = 'benchmark/experiments/verifier-finetune-pilot-v1/ke-hoach.json', plan = read(planPath);
  const result = { ...previous, version: 'verifier-eligibility-v7', new_records: 0, replaced_records: 16,
    revised_annotation_records: 4, source_texts_unchanged: true, group_memberships_unchanged: true,
    corpus_text_audit_reused: 'benchmark/experiments/verifier-corpus-overlap-v15/ket-qua.json',
    corpus_audit_reuse_reason: 'Cả 16 hash văn bản và parent giữ nguyên; chỉ hiệu chỉnh nhãn, không thêm nguồn hoặc thay văn bản.',
    inputs_sha256: inputs, input_snapshots: { [planPath]: 'ke-hoach-tai-thoi-diem-ra.json' },
    code_sha256: hash(fs.readFileSync(__filename)), command: 'node scripts/apply-verifier-workflow-review.cjs',
    training_eligible_records: 0, training_ready: false, model_called: false, training_started: false,
    runtime_changed: false, final_split_created: false, priority_one_complete: false };
  fs.mkdirSync(out);
  fs.writeFileSync(`${out}/registry.jsonl`, rows.map(r => JSON.stringify(r)).join('\n') + '\n', { flag: 'wx' });
  fs.writeFileSync(`${out}/rang-buoc-nhom.json`, groups, { flag: 'wx' });
  fs.writeFileSync(`${out}/ke-hoach-tai-thoi-diem-ra.json`, plan, { flag: 'wx' });
  fs.writeFileSync(`${out}/ket-qua.json`, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ records: rows.length, replaced: 16, revised: 4, new_records: 0, groups_unchanged: true }));
}
if (require.main === module) main();
module.exports = { replaceReviewed };
