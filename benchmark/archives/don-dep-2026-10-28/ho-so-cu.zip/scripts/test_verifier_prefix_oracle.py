"""Kiểm tra oracle chỉ cấp tiền tố, không chứa đáp án stance hoặc lý do."""
import unittest
from diagnose_verifier_prefix_oracle import gold_prefix, prepare_tokens


class PrefixOracleTests(unittest.TestCase):
    def test_no_stance_or_reason_leak_into_prefix(self):
        target = {'assessments': [{'id': 'suspicion-1', 'spanId': 'ref-2', 'addressee': 'human',
            'framing': 'active', 'deviation': 'none', 'hasDirective': True, 'stance': 'dismissed', 'reason': 'SECRET_REASON'}], 'discoveries': []}
        prefix = gold_prefix(target)
        self.assertTrue(prefix.endswith('"stance":"'))
        self.assertNotIn('dismissed', prefix)
        self.assertNotIn('SECRET_REASON', prefix)
        self.assertIn('"addressee":"human"', prefix)

    def test_reject_ambiguous_or_pregiven_reason(self):
        with self.assertRaises(ValueError):
            gold_prefix({'assessments': [], 'discoveries': []})
        with self.assertRaises(ValueError):
            gold_prefix({'reason': 'not allowed before decision', 'stance': 'confirmed'})
        with self.assertRaises(ValueError):
            gold_prefix({'assessments': [{'stance': 'confirmed'}, {'stance': 'dismissed'}]})

    def test_reject_token_boundary_mismatch_before_model_call(self):
        class MismatchedTokenizer:
            def apply_chat_template(self, *args, **kwargs):
                return 'P'

            def encode(self, text, **kwargs):
                return [1, 2] if text.endswith('"stance":"') else [1, 3, 4]
        with self.assertRaisesRegex(ValueError, 'ranh giới token'):
            prepare_tokens(MismatchedTokenizer(), {'payload': {'messages': []}, 'target': {'stance': 'confirmed'}})


if __name__ == '__main__':
    unittest.main()
