// Kiểm toán cấu trúc và phân bố target; không tự phán nhãn ngữ nghĩa hoặc sửa dữ liệu.
const fs = require('node:fs');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const { verify } = require('./freeze-verifier-pilot.cjs');
const folder = 'benchmark/experiments/verifier-counterfactual-train-v2';
const out = 'benchmark/experiments/verifier-training-target-audit-v1';
function analyze(rows, examples) {
  const structural = [], leaks = [], reasonMap = new Map(), cells = new Map();
  const ids = new Set(rows.map(r=>r.id));
  if (ids.size !== rows.length) structural.push({ error: 'Trùng ID nguồn.' });
  for (const row of rows) {
    for (const error of validateAnnotation(row.text,row.annotation)) structural.push({ id:row.id,error });
    const key=[row.annotation.stance,row.annotation.addressee,row.annotation.framing,row.annotation.deviation].join('|');
    if (!cells.has(key)) cells.set(key,[]);
    cells.get(key).push(row.id);
  }
  const empty = [], nonempty = [], modes = {};
  for (const e of examples) {
    const row=rows.find(r=>r.id===e.source_record_id);
    if (!row) { structural.push({id:e.id,error:'Không tìm thấy nguồn.'}); continue; }
    if (e.planned_role!=='train') structural.push({id:e.id,error:'Sai vai trò train.'});
    const messages=e.payload.messages;
    if (messages.length!==2||messages[0].role!=='system'||messages[1].role!=='user') structural.push({id:e.id,error:'Sai ranh giới hội thoại.'});
    for (const marker of [row.id,row.group_id,row.source_parent_id].filter(Boolean)) if(messages.some(m=>m.content.includes(marker)))leaks.push({id:e.id,marker});
    const findings=[...e.target.assessments,...e.target.discoveries];
    const key=`${row.annotation.stance}|${e.mode}`;
    modes[key]??={examples:0,with_context_fields:0,empty_targets:0};
    modes[key].examples++;
    if(findings.length){nonempty.push(e.id);modes[key].with_context_fields++;}else{empty.push(e.id);modes[key].empty_targets++;}
    for(const f of findings){
      if(typeof f.reason!=='string'||Array.from(f.reason).length<20||Array.from(f.reason).length>240)structural.push({id:e.id,error:'Reason ngoài hợp đồng.'});
      if(f.stance==='confirmed'&&(f.addressee!=='assistant'||f.framing!=='active'||f.deviation==='none'||f.deviation==='unclear'||!f.hasDirective))structural.push({id:e.id,error:'Target confirmed mâu thuẫn ngữ cảnh.'});
      const norm=f.reason.normalize('NFKC').trim().replace(/\s+/g,' ');
      if(!reasonMap.has(norm))reasonMap.set(norm,{reason:norm,sources:new Set(),groups:new Set(),stances:new Set(),examples:0});
      const item=reasonMap.get(norm);item.sources.add(row.id);item.groups.add(row.group_id);item.stances.add(f.stance);item.examples++;
    }
  }
  const reasons=[...reasonMap.values()].map(r=>({...r,sources:[...r.sources],groups:[...r.groups],stances:[...r.stances]})).sort((a,b)=>b.sources.length-a.sources.length);
  return {source_records:rows.length,examples:examples.length,structural_errors:structural,metadata_leaks:leaks,
    with_explicit_context_fields:nonempty.length,empty_targets:empty.length,empty_target_ids:empty,by_stance_mode:modes,
    context_cells:[...cells].map(([key,sources])=>({key,count:sources.length,source_ids:sources})),
    unique_reason_texts:reasons.length,repeated_reason_templates:reasons.filter(r=>r.groups.length>=3),
    review_note:'Lý do lặp qua nhiều nhóm là tín hiệu cần rà mức bám bằng chứng, không tự chứng minh sai nhãn. Target rỗng cho benign/none là đúng hợp đồng hiện tại, không phải lỗi export.'};
}
async function main(){
  if(fs.existsSync(out))throw new Error('Không ghi đè audit.');
  const lock=JSON.parse(fs.readFileSync(`${folder}/giao-thuc.json`));verify(lock);
  const sourceFile=`${folder}/mau-cho-duyet.jsonl`,targetFile=`${folder}/train.preview.jsonl`;
  const rows=fs.readFileSync(sourceFile,'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const examples=fs.readFileSync(targetFile,'utf8').trim().split(/\r?\n/).map(JSON.parse);
  const result=analyze(rows,examples),parserErrors=[];
  const {createServer}=await import('vite');
  const server=await createServer({configFile:false,server:{middlewareMode:true,hmr:false},appType:'custom'});
  try{
    const {buildVerifierInput}=await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    const {parseCompactVerifierJson}=await server.ssrLoadModule('/src/ai/agents/document/compactVerifier.ts');
    for(const e of examples){const row=rows.find(r=>r.id===e.source_record_id);const input=buildVerifierInput({text:row.text,format:row.format,candidate_mode:e.mode});
      try{parseCompactVerifierJson(JSON.stringify(e.target),input.chunks,input.expected);}catch(error){parserErrors.push({id:e.id,error:error.message});}}
  }finally{await server.close();}
  const teacher=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-teacher-forcing-v1/chan-doan.json'));
  result.parser_valid=examples.length-parserErrors.length;result.parser_errors=parserErrors;
  result.teacher_forcing_reference=teacher.diagnostic.map(r=>({role:r.role,reason_token_fraction:r.reason_token_fraction,reason_nll_fraction_on:r.reason_nll_fraction_on}));
  result.input_sha256=Object.fromEntries([sourceFile,targetFile].map(p=>[p,hash(fs.readFileSync(p))]));
  result.code_sha256=hash(fs.readFileSync(__filename));
  result.model_called=false;result.training_started=false;result.data_changed=false;result.runtime_changed=false;
  result.limitations=['Không tự kiểm chứng ngữ nghĩa, quyền sử dụng hoặc đúng/sai từng lý do từ phép thống kê.',
    'Đây là kiểm toán bộ train đã dùng; không tạo thêm train/dev/holdout hoặc nhập đối chứng dev vào train.',
    'NLL lý do lớn không đồng nghĩa gradient cùng tỷ lệ hoặc cắt reason sẽ tăng chất lượng.'];
  verify(lock);fs.mkdirSync(out);fs.writeFileSync(`${out}/ket-qua.json`,JSON.stringify(result,null,2));
  console.log(JSON.stringify({source_records:result.source_records,examples:result.examples,parser_valid:result.parser_valid,
    structural_errors:result.structural_errors.length,metadata_leaks:result.metadata_leaks.length,empty_targets:result.empty_targets,
    unique_reasons:result.unique_reason_texts,repeated_templates:result.repeated_reason_templates.length,by_stance_mode:result.by_stance_mode,
    top_templates:result.repeated_reason_templates.slice(0,4).map(r=>({reason:r.reason,sources:r.sources.length,groups:r.groups.length}))}));
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;});
module.exports={analyze};
