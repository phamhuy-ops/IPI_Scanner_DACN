const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {prepare}=require('./prepare-verifier-supervision-review.cjs');
const load=()=>fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
test('Ma trận chỉ dùng cha train, đề xuất giữ nguyên bản nguồn và nhãn',()=>{
 const rows=load(),before=JSON.stringify(rows);const {slots,reviews}=prepare(rows);
 assert.equal(slots.length,16);assert.equal(reviews.length,12);assert.equal(JSON.stringify(rows),before);
 for(const r of reviews){const source=rows.find(s=>s.id===r.id);assert.equal(source.text.slice(r.evidence.start,r.evidence.end),r.evidence.quote);assert.equal(r.applied,false);assert.equal(r.human_approved,false);}
});
test('Không dùng nhầm cha dev cho ma trận train',()=>{
 const rows=load();rows.find(r=>r.id.endsWith('rc-005')).planned_role='dev';assert.throws(()=>prepare(rows),/train/);
});
