const { test } = require('node:test');
const assert = require('node:assert/strict');
const { decide } = require('./decide-verifier-pilot-screen.cjs');
const fixture = () => Array.from({ length: 12 }, (_, i) => ({ id: `a-${i}`, group_id: `g-${i}`, expected: i % 2 ? 'confirmed' : 'dismissed', parsed: true, predicted: 'uncertain' }));
test('JSON hợp lệ không che được báo nhầm hoặc false-clear mới', () => {
  const off = fixture(), on = fixture();
  on[0].predicted = 'confirmed'; on[1].predicted = 'dismissed';
  const result = decide(off, on);
  assert.equal(result.advance_to_full_dev, false);
  assert.deepEqual(result.regressions.map(r => r.kind), ['new_false_positive', 'new_false_clear']);
});
test('Không cho lỗi parser hoặc thiếu ca tiến vào lượt đo tiếp', () => {
  const off = fixture(), on = fixture(); on[0].parsed = false;
  assert.equal(decide(off, on).advance_to_full_dev, false);
  assert.throws(() => decide(off.slice(1), on), /chưa đủ/);
  const passed = decide(fixture(), fixture());
  assert.equal(passed.advance_to_full_dev, true);
  assert.equal(passed.quality_improvement_proven, false);
  assert.equal(passed.probe_allowed, false);
});
