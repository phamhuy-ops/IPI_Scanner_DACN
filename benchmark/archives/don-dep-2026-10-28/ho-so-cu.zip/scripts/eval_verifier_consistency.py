"""Đo đúng hai prompt đã khóa, cùng model/adapter; không huấn luyện hoặc triển khai."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
from verifier_data_loader import ROOT, load_role

DESIGN = ROOT / 'benchmark/experiments/verifier-consistency-candidate-v1'
OUT = ROOT / 'benchmark/experiments/verifier-consistency-eval-v1'


def build_requests(old, new, selected, suffix):
    result = {'baseline': [], 'candidate': []}
    for r in old:
        if r['source_record_id'] not in selected:
            continue
        for config in result:
            messages = copy.deepcopy(r['payload']['messages'])
            if config == 'candidate':
                messages[0]['content'] += suffix
            result[config].append({'id': r['id'], 'source_record_id': r['source_record_id'], 'mode': r['mode'], 'cohort': 'old_screen', 'messages': messages})
    for r in new:
        config = r['configuration']
        if config not in result or r['training_eligible'] is not False:
            raise ValueError('Sai vai trò hoặc cấu hình đối chứng.')
        result[config].append({'id': f"{r['source_record_id']}-{r['mode']}", 'source_record_id': r['source_record_id'],
                               'mode': r['mode'], 'cohort': 'new_controls', 'messages': copy.deepcopy(r['payload']['messages'])})
    for config, rows in result.items():
        if len(rows) != 68 or len({r['id'] for r in rows}) != 68:
            raise ValueError('Thiếu/trùng ca trong mỗi prompt.')
        for row in rows:
            if [m['role'] for m in row['messages']] != ['system', 'user']:
                raise ValueError('Sai ranh giới input; không truyền gold hoặc assistant prefix.')
    for a, b in zip(result['baseline'], result['candidate']):
        if a['id'] != b['id'] or a['messages'][1] != b['messages'][1] or b['messages'][0]['content'] != a['messages'][0]['content'] + suffix:
            raise ValueError('Hai cấu hình khác ngoài suffix system.')
    return result


def verify_lock(lock):
    for name, expected in lock['locked_files_sha256'].items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f'File đã khóa thay đổi: {name}')


def main():
    if OUT.exists():
        raise ValueError('Không ghi đè phép đo hoặc tự chạy lại.')
    lock = json.loads((DESIGN / 'giao-thuc-da-khoa.json').read_text(encoding='utf-8'))
    verify_lock(lock)
    plan = json.loads((DESIGN / 'ung-vien.json').read_text(encoding='utf-8'))
    old = load_role('dev')
    selected = json.loads((ROOT / 'benchmark/experiments/verifier-hf-base-screen-v1/ke-hoach-truoc-do.json').read_text(encoding='utf-8'))['selected_source_ids']
    new = json.loads((ROOT / 'benchmark/data/annotations/verifier-consistency-controls-v1/ban-xem-truoc.json').read_text(encoding='utf-8'))['examples']
    requests = build_requests(old, new, selected, plan['suffix'])
    storage = Path(os.environ['IPI_TRAINING_ROOT']).resolve()
    trained = json.loads((ROOT / 'benchmark/experiments/verifier-pilot-candidate-02/ket-qua.json').read_text(encoding='utf-8'))
    assets = json.loads((ROOT / 'benchmark/experiments/verifier-gpu-assets-v1/ket-qua.json').read_text(encoding='utf-8'))
    adapter = Path(trained['adapter_path']).resolve(); local = Path(assets['snapshot']).resolve()
    if storage.drive.lower() != 'e:' or not all(p.is_relative_to(storage) for p in [adapter, local]) or assets['revision'] != plan['fixed']['base_revision']:
        raise ValueError('Sai đích E hoặc revision.')
    def verify_adapter():
        for name, expected in trained['adapter_files_sha256'].items():
            if hashlib.sha256((adapter / name).read_bytes()).hexdigest() != expected:
                raise ValueError('Adapter đã thay đổi.')
    verify_adapter()
    OUT.mkdir()
    for config in requests:
        (OUT / config).mkdir()
    execution = {'scope': 'frozen_prompt_candidate_development_only', 'requests_per_prompt': 68, 'total_requests': 136,
        'request_ids': [r['id'] for r in requests['baseline']], 'same_model_instance': True, 'adapter_on_both': True,
        'order': 'Xen kẽ hai prompt theo ca, đảo prompt đầu ở ca lẻ; không warmup hoặc retry.',
        'fixed': plan['fixed'], 'gates': plan['selection_gates'],
        'design_lock_sha256': hashlib.sha256((DESIGN / 'giao-thuc-da-khoa.json').read_bytes()).hexdigest(),
        'adapter_sha256': trained['adapter_files_sha256'],
        'implementation_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in [
            'scripts/eval_verifier_consistency.py', 'scripts/verifier-consistency-metrics.cjs', 'scripts/score-verifier-consistency.cjs',
            'scripts/test_verifier_consistency_runner.py', 'scripts/verifier-consistency-metrics.test.cjs']},
        'metric_definition': 'Lỗi không thành TN; kiểm tra tăng stance mới, mọi ca candidate hợp lệ, không hồi quy từng ca/ngôn ngữ/nhóm gốc/nhóm từ vựng; TP mới cần đúng cả span và context.',
        'memory_definition': 'Reset peak CUDA trước mỗi request; so max allocated của mỗi prompt, tách peak load chung. Latency gồm token hóa và generation, đồng bộ CUDA trước kết thúc.',
        'training_started': False, 'probe_used': False, 'runtime_changed': False}
    (OUT / 'ke-hoach-thuc-thi.json').write_text(json.dumps(execution, ensure_ascii=False, indent=2), encoding='utf-8')
    responses = {config: [] for config in requests}
    started = time.perf_counter()
    try:
        import torch
        import psutil
        from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
        from peft import PeftModel, prepare_model_for_kbit_training
        torch.manual_seed(42); torch.cuda.set_per_process_memory_fraction(.8)
        tokenizer = AutoTokenizer.from_pretrained(local, local_files_only=True, trust_remote_code=False)
        # Kiểm tra đủ mọi input trước khi load weights, không cắt ngầm.
        tokenized = {c: [tokenizer.apply_chat_template(r['messages'], tokenize=True, add_generation_prompt=True) for r in rows] for c, rows in requests.items()}
        base = AutoModelForCausalLM.from_pretrained(local, local_files_only=True, trust_remote_code=False,
            quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4', bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.float16),
            device_map={'': 0}, torch_dtype=torch.float16, attn_implementation='sdpa')
        base = prepare_model_for_kbit_training(base, use_gradient_checkpointing=False)
        model = PeftModel.from_pretrained(base, adapter, is_trainable=False, local_files_only=True)
        model.eval(); model.config.use_cache = True
        for p in model.parameters():
            p.requires_grad_(False)
        if any(len(ids) + 256 > model.config.max_position_embeddings for values in tokenized.values() for ids in values):
            raise ValueError('Vượt context, không cắt nguồn.')
        load_peak = torch.cuda.max_memory_allocated()
        for index in range(68):
            for config in (['baseline', 'candidate'] if index % 2 == 0 else ['candidate', 'baseline']):
                row = requests[config][index]
                began = time.perf_counter(); torch.cuda.reset_peak_memory_stats()
                item = {k: v for k, v in row.items() if k != 'messages'}
                try:
                    ids = torch.tensor([tokenized[config][index]], device='cuda')
                    with torch.inference_mode():
                        generated = model.generate(ids, attention_mask=torch.ones_like(ids), do_sample=False, max_new_tokens=256,
                            pad_token_id=tokenizer.pad_token_id, eos_token_id=tokenizer.eos_token_id)[0, ids.shape[-1]:]
                    item.update(status='completed', response=tokenizer.decode(generated, skip_special_tokens=True),
                        input_tokens=ids.shape[-1], generated_tokens=len(generated), hit_token_limit=len(generated) >= 256)
                    torch.cuda.synchronize()
                    item.update(seconds=time.perf_counter() - began, peak_vram_allocated=torch.cuda.max_memory_allocated(),
                        peak_vram_reserved=torch.cuda.max_memory_reserved(), rss_bytes=psutil.Process().memory_info().rss)
                    del ids, generated
                except Exception as error:
                    item.update(status='error', error=str(error), seconds=time.perf_counter() - began)
                responses[config].append(item)
                (OUT / config / 'phan-hoi.json').write_text(json.dumps(responses[config], ensure_ascii=False, indent=2), encoding='utf-8')
                progress = {'configuration': config, 'done_per_prompt': len(responses[config]), 'total_per_prompt': 68,
                            'completed_total': sum(map(len, responses.values())), 'total': 136, 'seconds': time.perf_counter() - started}
                (OUT / 'tien-do.json').write_text(json.dumps(progress), encoding='utf-8')
                print(json.dumps(progress), flush=True)
                if item['status'] == 'error':
                    raise RuntimeError(item['error'])
        verify_adapter(); verify_lock(lock)
        summary = {'completed': True, 'requests': 136, 'seconds': time.perf_counter() - started,
            'load_peak_vram_allocated': load_peak, 'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
            'same_model_instance': True, 'adapter_on_both': True, 'adapter_unchanged': True,
            'training_started': False, 'probe_used': False, 'runtime_changed': False}
        (OUT / 'ket-qua.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
        print(json.dumps(summary), flush=True)
    except BaseException as error:
        (OUT / 'loi.json').write_text(json.dumps({'error': str(error), 'traceback': traceback.format_exc(),
            'completed_total': sum(map(len, responses.values())), 'training_started': False}, ensure_ascii=False, indent=2), encoding='utf-8')
        raise


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
