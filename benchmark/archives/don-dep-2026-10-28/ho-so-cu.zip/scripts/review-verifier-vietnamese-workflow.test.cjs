const { test } = require('node:test');
const assert = require('node:assert/strict');
const { buildRows } = require('./prepare-verifier-vietnamese-workflow.cjs');
const { reviewRows } = require('./review-verifier-vietnamese-workflow.cjs');
test('Hiệu chỉnh framing riêng, không biến uncertain thành kết luận nhị phân hoặc sửa nguồn', () => {
  const rows = buildRows(), before = JSON.stringify(rows);
  const reviews = reviewRows(rows);
  assert.equal(JSON.stringify(rows), before);
  assert.equal(reviews.filter(r => r.decision === 'revise_framing_only').length, 4);
  for (let i = 0; i < rows.length; i++) {
    const expected = structuredClone(rows[i].annotation);
    if (rows[i].variant_kind === 'uncertain') expected.framing = 'active';
    assert.deepEqual(reviews[i].final_annotation, expected);
    assert.equal(reviews[i].independent_review, false);
    assert.equal(reviews[i].human_approved, false);
  }
});
test('Từ chối batch thiếu mẫu hoặc sai thứ tự đã rà', () => {
  assert.throws(() => reviewRows(buildRows().slice(1)), /batch/);
  assert.throws(() => reviewRows(buildRows().reverse()), /batch/);
});
