// Kiểm tra đáp án sau duyệt; không ghi đè nguồn, nháp hoặc quyết định người dùng.
const fs = require('node:fs');
const path = require('node:path');
const { hash, validateAnnotation } = require('./context-annotations.cjs');
const root = path.resolve(__dirname, '..');
const dir = path.resolve(root, process.argv[2] || 'benchmark/data/annotations/verifier-batch-v1');
async function main() {
  const read = name => fs.readFileSync(path.join(dir, name), 'utf8');
  const rows = read('mau-cho-duyet.jsonl').trim().split(/\r?\n/).map(JSON.parse);
  const sheet = JSON.parse(read('ket-qua-ra-soat.json'));
  const manifest = JSON.parse(read('manifest.json'));
  const errors = [], counts = { total: rows.length, accepted: 0, revised: 0, pending: 0, parser_valid: 0,
    labels: {}, languages: {}, groups: new Set() };
  const ids = new Set(rows.map(row => row.id));
  if (!Number.isSafeInteger(manifest.counts.total) || rows.length !== manifest.counts.total || ids.size !== rows.length || sheet.reviews.length !== rows.length ||
    new Set(sheet.reviews.map(row => row.id)).size !== rows.length || sheet.reviews.some(row => !ids.has(row.id))) errors.push('Thiếu hoặc trùng ID/phiếu.');
  // Manifest gốc là snapshot lúc tạo nháp. Chỉ phiếu và thẻ duyệt được phép thay đổi.
  for (const [file, expected] of Object.entries(manifest.asset_sha256)) {
    if (['ket-qua-ra-soat.json', 'phieu-ra-soat.md'].includes(file)) continue;
    if (hash(fs.readFileSync(path.join(dir, file))) !== expected) errors.push(`Tài sản nháp/nguồn thay đổi: ${file}`);
  }
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  try {
    const { validateDraftResponse } = await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    for (const row of rows) {
      const review = sheet.reviews.find(item => item.id === row.id);
      if (!review) continue;
      const add = message => errors.push(`${row.id}: ${message}`);
      if (hash(Buffer.from(row.text)) !== review.input_sha256 || row.input_sha256 !== review.input_sha256 ||
        hash(Buffer.from(JSON.stringify({ annotation: row.draft_annotation, response: row.draft_response }, null, 2) + '\n')) !== review.draft_sha256) add('Phiếu không khớp nguồn/nháp.');
      if (review.status === 'pending') { counts.pending++; continue; }
      if (review.status !== 'human_reviewed' || !review.reviewer?.trim() || !Number.isFinite(Date.parse(review.reviewed_at)) || !review.notes?.trim()) add('Thiếu thông tin người duyệt hoặc quyết định.');
      let annotation, response;
      if (review.decision === 'accept') {
        counts.accepted++;
        if (review.final_annotation !== null || review.final_response !== null) add('accept không được sửa ngầm.');
        annotation = row.draft_annotation; response = row.draft_response;
      } else if (review.decision === 'revise') {
        counts.revised++; annotation = review.final_annotation; response = review.final_response;
        if (!annotation || !response) { add('Thiếu đáp án đã sửa.'); continue; }
      } else { add('Quyết định không được hỗ trợ trong đợt duyệt này.'); continue; }
      for (const message of validateAnnotation(row.text, annotation)) add(message);
      try { validateDraftResponse(row, response, annotation); counts.parser_valid++; }
      catch (error) { add(error.message); }
      counts.labels[annotation.label] = (counts.labels[annotation.label] || 0) + 1;
      counts.languages[row.language] = (counts.languages[row.language] || 0) + 1;
      counts.groups.add(row.group_id);
    }
  } finally { await server.close(); }
  counts.groups = counts.groups.size;
  const result = { version: 1, counts, errors, structurally_valid: errors.length === 0,
    human_review_complete: errors.length === 0 && rows.length > 0 && counts.pending === 0 && counts.accepted + counts.revised === rows.length,
    fine_tuning_ready: false, training_export_created: false,
    sha256: Object.fromEntries(['mau-cho-duyet.jsonl', 'ket-qua-ra-soat.json', 'phieu-ra-soat.md', 'manifest.json']
      .filter(name => name !== 'phieu-ra-soat.md' || fs.existsSync(path.join(dir, name)))
      .map(name => [name, hash(fs.readFileSync(path.join(dir, name)))])),
    review_scope: 'Một người dùng rà soát trong cuộc trò chuyện có hướng dẫn của AI, đã trình bày toàn bộ nguồn từng mẫu; chưa đánh giá đa người gán nhãn.',
    limitations: [`${rows.length} mẫu ngắn tự soạn thuộc ${counts.groups} nhóm, không phải nguồn độc lập hoặc holdout.`,
      'Nguồn/nháp giữ nguyên; đáp án sửa chỉ lưu tại final_annotation/final_response.',
      'Manifest gốc và validation trong hàng nháp là snapshot trước duyệt, không phải trạng thái cuối.',
      'Chưa chia tập, chưa rà gần trùng toàn kho, chưa tokenizer/mask audit và chưa huấn luyện.',
      'Parser hợp lệ không chứng minh model nhận diện tốt; chưa thay đổi runtime.'] };
  fs.writeFileSync(path.join(dir, 'tong-ket-ra-soat.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result, null, 2));
  if (errors.length || !result.human_review_complete) process.exitCode = 1;
}
main().catch(error => { console.error(error); process.exitCode = 1; });
