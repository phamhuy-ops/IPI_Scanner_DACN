const test=require('node:test'),assert=require('node:assert/strict');const{prior,adjust}=require('./calibrate-native-source.cjs');
test('prior chỉ từ vector content-free, không cần nhãn hoặc dataset ID',()=>{
  const bias=prior([{A:-1,B:-2,C:-3},{A:-1,B:-2,C:-3},{A:-1,B:-2,C:-3}]);
  assert.ok(Math.abs(Object.values(bias).reduce((s,v)=>s+Math.exp(v),0)-1)<1e-9);
  assert.equal(adjust({A:-3,B:-1,C:-4},bias).kind,'ordinary');
});
test('thiếu calibration hoặc score phải báo lỗi',()=>{assert.throws(()=>prior([]));assert.throws(()=>adjust({A:-1,B:-2},{A:-1,B:-1,C:-1}));});
