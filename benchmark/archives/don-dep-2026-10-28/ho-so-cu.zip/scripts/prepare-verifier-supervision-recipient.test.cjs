const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {buildRows}=require('./prepare-verifier-supervision-recipient.cjs');
const {validateAnnotation}=require('./context-annotations.cjs');
function input(){return [fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse),JSON.parse(fs.readFileSync('benchmark/experiments/verifier-supervision-review-v1/ma-tran-bo-sung.json'))];}
test('Giữ cùng thao tác, chỉ phân định người nhận; hành vi xấu không tự thành IPI',()=>{
 const rows=buildRows(...input());assert.equal(rows.length,12);assert.equal(new Set(rows.map(r=>r.text)).size,12);
 for(const group of new Set(rows.map(r=>r.group_id))){const r=rows.filter(r=>r.group_id===group);const action=r[0].annotation.directive_spans[0].quote;
  assert.ok(r.every(r=>r.annotation.directive_spans[0].quote.endsWith(action)));
  assert.deepEqual(r.map(r=>r.annotation.stance),['uncertain','confirmed','dismissed']);
  assert.deepEqual(r.map(r=>r.annotation.addressee),['unclear','assistant','human']);
  assert.equal(r[0].annotation.deviation,'tool_misuse');assert.equal(r[2].annotation.deviation,'none');}
 for(const r of rows){assert.deepEqual(validateAnnotation(r.text,r.annotation),[]);assert.equal(r.training_eligible,false);assert.equal(r.model_evaluation_allowed,false);}
});
test('Không nhận cha dev thay cho train',()=>{const [rows,matrix]=input();rows.find(r=>r.id===matrix.slots.find(s=>s.id==='slot-13').parent_record_id).planned_role='dev';assert.throws(()=>buildRows(rows,matrix),/Cha/);});
