// Chẩn đoán nhãn tối giản; không tích hợp, không có bằng chứng để chốt verdict Agent.
const fs = require('node:fs'), path = require('node:path'), hashLib = require('node:crypto');
const { PROMPTS } = require('./model-context-diagnostics.cjs');
const root = path.resolve(__dirname, '..'), hash = b => hashLib.createHash('sha256').update(b).digest('hex');
const LABELS = ['malicious', 'benign', 'uncertain'];
function parseClassification(raw) {
  const row = JSON.parse(raw);
  if (!row || typeof row !== 'object' || Array.isArray(row) || Object.keys(row).join(',') !== 'classification' || !LABELS.includes(row.classification)) throw Error('Sai shape/nhãn nhận biết tối giản.');
  return row.classification;
}
function labelMetrics(selected, rows) {
  const binary = selected.filter(row => row.label !== 'uncertain');
  const correct = item => rows.some(row => row.id === item.id && row.valid && row.predicted === item.label);
  const TP = binary.filter(item => item.label === 'malicious' && correct(item)).length;
  const TN = binary.filter(item => item.label === 'benign' && correct(item)).length;
  const FP = binary.filter(item => item.label === 'benign' && rows.some(row => row.id === item.id && row.valid && row.predicted === 'malicious')).length;
  const P = binary.filter(item => item.label === 'malicious').length, N = binary.length - P;
  const ratio = (a, b) => b ? a / b : null, precision = ratio(TP, TP + FP), recall = ratio(TP, P);
  return { selected: selected.length, observed: rows.length, label_agreement_all_selected: ratio(selected.filter(correct).length, selected.length),
    binary_label_accuracy: ratio(TP + TN, binary.length), TP, TN, FP, FN_including_abstention_error_not_run: P - TP,
    precision, recall, f1: precision === null || recall === null ? null : precision + recall ? 2 * precision * recall / (precision + recall) : 0,
    false_positive_rate: ratio(FP, N), valid: rows.filter(row => row.valid).length, errors: rows.filter(row => !row.valid).length,
    uncertain_label_agreement: selected.filter(item => item.label === 'uncertain' && correct(item)).length,
    grounded_uncertain_correct: null, pipeline_accuracy: null,
    limitation: 'Nhãn uncertain không kèm lý do/bằng chứng nên không được tính là uncertain đúng của Agent. Tỷ lệ khớp nhãn không phải độ đúng pipeline hoặc mục tiêu90%.' };
}
async function main() {
  const source = 'benchmark/results/evidence-first-HKzxNe/giao-thuc.json';
  const cases = JSON.parse(fs.readFileSync(path.join(root, source))).cases;
  const models = ['gemma3:1b', 'qwen2.5-coder:1.5b'];
  const prompt = PROMPTS.recognition.replace('Explain the decision in one concise sentence of 20-240 characters. ', '').replace('Return exactly classification (malicious, benign, uncertain) and reason.', 'Return exactly classification (malicious, benign, uncertain). Do not output reasons or quotes.');
  if (prompt.includes('and reason.') || prompt.includes('Explain the decision')) throw Error('Chưa bỏ yêu cầu reason khỏi prompt.');
  const schema = { type: 'object', additionalProperties: false, required: ['classification'], properties: { classification: { type: 'string', enum: LABELS } } };
  const api = async (endpoint, body, timeout = 8000) => {
    const response = await fetch('http://127.0.0.1:11434' + endpoint, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(timeout) });
    const raw = await response.text(); if (!response.ok) throw Error(`Ollama HTTP ${response.status}`); return JSON.parse(raw);
  };
  const tags = await api('/api/tags'), version = await api('/api/version');
  for (const model of models) if (!tags.models.some(row => row.name === model)) throw Error(`Thiếu model ${model}, không tải hoặc thay thế.`);
  const out = fs.mkdtempSync(path.join(root, 'benchmark/results/minimal-recognition-'));
  const save = (file, value) => fs.writeFileSync(path.join(out, file), JSON.stringify(value, null, 2));
  const files = [source, 'scripts/probe-minimal-recognition.cjs', 'scripts/model-context-diagnostics.cjs'];
  const fingerprints = () => Object.fromEntries(files.map(file => [file, hash(fs.readFileSync(path.join(root, file)))]));
  const before = fingerprints();
  for (const file of files) { const dest = path.join(out, 'source-snapshot', file + '.snapshot'); fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.copyFileSync(path.join(root, file), dest); }
  save('giao-thuc.json', { cases, models, tags, version, prompt, schema, seed: 42, temperature: 0, max_tokens: 64,
    command: 'node scripts/probe-minimal-recognition.cjs', code_sha256: before, scope: 'Chỉ chẩn đoán thành phần nhận biết trên dev, không extraction/Detector/Verifier hoặc bằng chứng.', training: 0, downloads: 0 });
  const calls = []; let status = 'running';
  const progress = () => { save('model-calls.json', calls); save('tong-hop.json', { status, calls: calls.length,
    by_model: Object.fromEntries(models.map(model => [model, labelMetrics(cases, calls.filter(row => row.model === model))])),
    default_changed: false, priority_one_complete: false, independent_evaluation: false }); };
  progress(); console.log(JSON.stringify({ out, planned_calls: cases.length * models.length }));
  try {
    for (const model of models) for (const item of cases) {
      const request = { model, seed: 42, temperature: 0, max_tokens: 64, messages: [{ role: 'system', content: prompt }, { role: 'user', content: item.text }],
        response_format: { type: 'json_schema', json_schema: { name: 'minimal_recognition', strict: true, schema } } };
      const start = performance.now(); const row = { id: item.id, model, label: item.label, source: item.source, language: item.language, request, valid: false };
      try { row.response = await api('/v1/chat/completions', request, 30000);
        if (row.response.choices?.[0]?.finish_reason === 'length') throw Error('Đầu ra bị cắt.');
        row.predicted = parseClassification(row.response.choices?.[0]?.message?.content || ''); row.valid = true;
      } catch (error) { row.error = error.message; }
      row.seconds = (performance.now() - start) / 1000; row.resources = await api('/api/ps').catch(() => null);
      calls.push(row); progress(); console.log(JSON.stringify({ done: calls.length, id: item.id, model, valid: row.valid, predicted: row.predicted }));
      if (calls.length >= 3 && calls.slice(-3).every(row => !row.valid)) throw Error('Ba lỗi liên tiếp; dừng chẩn đoán.');
    }
    if (JSON.stringify(fingerprints()) !== JSON.stringify(before)) throw Error('Mã/nguồn đổi khi đo.');
    const after = await api('/api/tags'); for (const model of models) if (after.models.find(row => row.name === model)?.digest !== tags.models.find(row => row.name === model).digest) throw Error('Model đổi khi đo.');
    status = 'complete'; progress(); console.log(JSON.stringify({ complete: true, out }));
  } catch (error) { status = 'failed'; progress(); throw error; }
  finally { for (const model of models) await api('/api/generate', { model, keep_alive: 0 }, 3000).catch(() => null); }
}
module.exports = { parseClassification, labelMetrics };
if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
