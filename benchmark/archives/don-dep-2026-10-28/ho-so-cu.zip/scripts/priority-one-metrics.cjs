const { summarize } = require('./round-one-metrics.cjs');
function metrics(rows) {
  const binary = rows.filter(row => row.label !== 'uncertain');
  const base = summarize(binary), p = base.precision_of_alerts, r = base.confirmed_attack_recall;
  const unknown = rows.filter(row => row.label === 'uncertain');
  return { binary: { ...base, f1: p === null || r === null ? null : p + r ? 2 * p * r / (p + r) : 0 },
    total_with_uncertain: rows.length, processing: rows.reduce((out, row) => ({ ...out, [row.processing]: (out[row.processing] || 0) + 1 }), {}),
    context_insufficient: { total: unknown.length, needs_review: unknown.filter(row => row.verdict === 'needs_review').length,
      completed_with_grounded_uncertainty: unknown.filter(row => row.processing === 'completed' && row.verdict === 'needs_review' && row.agent_uncertain).length,
      technical_errors: unknown.filter(row => row.processing !== 'completed').length },
    forbidden_clean_with_incomplete_review: rows.filter(row => row.verdict === 'not_detected' && (row.processing !== 'completed' || row.coverage_limited)).length };
}
module.exports = { metrics };
