// Baseline dev qua core sản phẩm; không đổi prompt, model hoặc chính sách kết luận.
const fs = require('node:fs');
const path = require('node:path');
const { hash } = require('./context-annotations.cjs');
const { metrics } = require('./priority-one-metrics.cjs');
const { checkCitations } = require('./round-one-metrics.cjs');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');
const root = path.resolve(__dirname, '..');
const manifestFile = 'benchmark/data/priority-one-dev-v2.json';
const codeFiles = ['scripts/run-priority-one-baseline.cjs', 'scripts/priority-one-metrics.cjs', 'scripts/round-one-metrics.cjs',
  'docs/planning/cong-hoan-thanh-uu-tien-1.md',
  'src/ai/agents/document/ipiPipeline.ts', 'src/ai/agents/document/reviewPolicy.ts', 'src/ai/agents/document/prompts.ts',
  'src/ai/agents/document/detectorAgent.ts', 'src/ai/agents/document/verifierAgent.ts', 'src/ai/agents/document/evidence.ts',
  'src/ai/agents/slmClient.ts', 'src/ai/agents/slmCatalog.ts', 'engine/scanner/ipi-doc-scan.js',
  'engine/prefilter/document-prefilter.js', 'engine/prefilter/rules/ipi-document-rules.js', 'engine/models/finding.js',
  'engine/document/extractors/document-text-extractor.js', 'engine/document/extractors/html-source.js',
  'engine/document/chunking/semantic-chunker.js', 'engine/config/document-scan-config.js'];
async function main() {
  const bytes = fs.readFileSync(path.join(root, manifestFile)), manifest = JSON.parse(bytes);
  const fingerprints = () => Object.fromEntries([...codeFiles, manifestFile, ...Object.keys(manifest.source_inputs)]
    .map(file => [file, hash(fs.readFileSync(path.join(root, file)))]));
  for (const item of Object.values(manifest.source_inputs)) if (hash(fs.readFileSync(path.join(root, item.file))) !== item.sha256) throw new Error('Nguồn manifest đã đổi.');
  const frozen = fingerprints();
  const get = async endpoint => {
    const response = await fetch(`http://127.0.0.1:11434${endpoint}`, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error(`Ollama HTTP ${response.status}`);
    return response.json();
  };
  const modelVersions = await get('/api/tags'), ollama = await get('/api/version');
  for (const model of [manifest.configuration.detector, manifest.configuration.verifier]) if (!modelVersions.models.some(row => row.name === model)) throw new Error(`Thiếu ${model}`);
  const dir = fs.mkdtempSync(path.join(root, 'benchmark/results/priority-one-baseline-'));
  const { createServer } = await import('vite');
  const server = await createServer({ configFile: false, root, server: { middlewareMode: true, hmr: false }, appType: 'custom' });
  fs.writeFileSync(path.join(dir, 'manifest.json'), bytes);
  const records = [], calls = []; let currentCase = '', role = 'detector', maxRss = process.memoryUsage().rss;
  const timer = setInterval(() => { maxRss = Math.max(maxRss, process.memoryUsage().rss); }, 100);
  let status = 'running';
  const summarize = () => ({ status, configuration: manifest.configuration, manifest_sha256: hash(bytes), code_sha256: frozen,
    models: modelVersions, ollama, node: process.version, cases_completed: records.length, cases_total: manifest.cases.length,
    metrics: metrics(records), by_source: Object.fromEntries([...new Set(records.map(row => row.source))].map(source => [source, metrics(records.filter(row => row.source === source))])),
    by_group: Object.fromEntries([...new Set(records.map(row => row.group_id))].map(group => [group, metrics(records.filter(row => row.group_id === group))])),
    by_language: Object.fromEntries([...new Set(records.map(row => row.language))].map(language => [language, metrics(records.filter(row => row.language === language))])),
    stages: Object.fromEntries(['rule', 'detector', 'verifier'].map(stage => [stage, {
      executed: records.filter(row => row.stages[stage].executed).length,
      metrics: metrics(records.filter(row => row.stages[stage].executed).map(row => ({ ...row, verdict: row.stages[stage].verdict,
        processing: row.stages[stage].complete ? 'completed' : 'incomplete' }))) }])),
    calls: calls.length, model_response_valid: calls.filter(call => call.runtime_schema_valid).length,
    max_harness_rss_bytes: maxRss, priority_one_complete: false,
    limitations: ['Dev đã dùng để chẩn đoán, không phải holdout độc lập.', 'Bridge headless, chưa kiểm tra Electron/UI.',
      'Không suy độ đúng ngữ nghĩa chỉ từ exact quote hoặc overlap gold rộng.', 'Classic-v1 không sinh các trường framing/deviation có cấu trúc; không có metric từng trường cho baseline này.',
      'Snapshot model không phải peak VRAM; RSS chỉ tiến trình Node.', 'Không coi technical needs_review là nhận diện đúng thiếu ngữ cảnh.',
      'Bộ 72 mẫu chủ yếu ngắn; chưa chứng minh chất lượng tài liệu dài hoặc mọi định dạng.'] });
  const save = () => {
    fs.writeFileSync(path.join(dir, 'cases.json'), JSON.stringify(records, null, 2));
    fs.writeFileSync(path.join(dir, 'model-calls.json'), JSON.stringify(calls, null, 2));
    fs.writeFileSync(path.join(dir, 'summary.json'), JSON.stringify(summarize(), null, 2));
    fs.mkdirSync(path.join(root, 'benchmark/experiments/priority-one-progress-v1'), { recursive: true });
    fs.writeFileSync(path.join(root, 'benchmark/experiments/priority-one-progress-v1/tien-do.json'), JSON.stringify({
      priority: 1, complete: false, baseline_status: status, completed: records.length, total: manifest.cases.length,
      artifact: path.relative(root, dir), last_case: records.at(-1)?.id || null,
      next: status === 'complete' ? 'Phân tích lỗi baseline, chọn một lỗi để thử sửa; chưa phản biện/fine-tune.' : 'Đang đo baseline, không đổi cấu hình giữa lượt.' }, null, 2));
  };
  globalThis.owaspWorkbench = {
    scanIpiDoc: (files, scanProfile) => runIpiDocScan(files, { scanProfile }),
    aiFetch: async payload => {
      if (new URL(payload.url).origin !== 'http://127.0.0.1:11434') throw new Error('Chỉ cho phép Ollama cục bộ.');
      const chat = payload.url.includes('/chat/completions'), start = Date.now();
      const call = { case_id: currentCase, role, request: chat ? JSON.parse(payload.body) : null };
      try {
        const response = await fetch(payload.url, { method: payload.method || 'POST', headers: payload.headers,
          body: payload.body, signal: AbortSignal.timeout(payload.timeoutMs || 45000) });
        const body = await response.text();
        if (chat) {
          Object.assign(call, { status: response.status, seconds: (Date.now() - start) / 1000, response: body });
          try { call.resource_snapshot = await get('/api/ps'); } catch { call.resource_snapshot = null; }
          calls.push(call);
        }
        return { ok: response.ok, status: response.status, body };
      } catch (error) {
        if (chat) calls.push({ ...call, status: 0, seconds: (Date.now() - start) / 1000, transport_error: error.message });
        return { ok: false, status: 0, body: '', error: error.message };
      }
    },
  };
  console.log(`Baseline: ${dir}`); save();
  try {
    const { runIpiDocumentPipeline } = await server.ssrLoadModule('/src/ai/agents/document/ipiPipeline.ts');
    const { parseReviewJson } = await server.ssrLoadModule('/src/ai/agents/document/reviewPolicy.ts');
    for (const item of manifest.cases) {
      if (JSON.stringify(fingerprints()) !== JSON.stringify(frozen)) throw new Error('Code/dữ liệu đổi trong lượt đo.');
      if (hash(Buffer.from(item.text)) !== item.input_sha256) throw new Error('Hash ca sai.');
      currentCase = item.id; role = 'detector';
      const file = path.join(dir, item.id + item.format); fs.writeFileSync(file, item.text);
      const start = Date.now();
      const state = await runIpiDocumentPipeline({ filePaths: [file], scanProfile: manifest.configuration.scanProfile,
        fixModel: manifest.configuration.detector, checkModel: manifest.configuration.verifier,
        reviewContract: manifest.configuration.reviewContract, verifierOutput: manifest.configuration.verifierOutput,
        analysisTimeoutMs: manifest.configuration.analysisTimeoutMs,
        onEvent: event => { if (event.phase === 'check') role = 'verifier'; } });
      const chunks = (state.scanResult?.metadata.semanticChunks || []).map((chunk, i) => ({ ...chunk, sourceChunkId: chunk.chunkId, chunkId: `chunk-${i + 1}` }));
      for (const call of calls.filter(call => call.case_id === item.id)) {
        call.runtime_schema_valid = false;
        try {
          const body = JSON.parse(call.response), schema = call.request.response_format.json_schema.schema;
          call.finish_reason = body.choices[0].finish_reason;
          const ids = (schema.properties.assessments.items.anyOf || []).map(shape => shape.properties.id.enum[0]);
          const expected = ids.map(id => state.suspicions.find(row => row.id === id));
          if (expected.some(row => !row)) throw new Error('Thiếu ID nghi vấn.');
          const chunkIds = new Set(schema.properties.discoveries.items.properties.chunkId.enum);
          parseReviewJson(body.choices[0].message.content, chunks.filter(chunk => chunkIds.has(chunk.chunkId)), expected, 'classic-v1');
          call.runtime_schema_valid = true;
        } catch (error) { call.validation_error = error.message; }
      }
      const events = state.events, detectorComplete = events.some(event => event.phase === 'check');
      const verifierExecuted = detectorComplete, verifierComplete = state.processingStatus === 'completed';
      const stage = (name, executed, complete) => ({ executed, complete, verdict: !executed ? null : !complete ? 'needs_review'
        : state.suspicions.some(row => row[name]?.stance === 'confirmed') ? 'ipi_detected'
          : state.suspicions.some(row => row[name]?.stance === 'uncertain') ? 'needs_review' : 'not_detected' });
      records.push({ id: item.id, source: item.source, group_id: item.group_id, language: item.language, label: item.expected_label,
        verdict: state.check?.verdict || 'needs_review', processing: state.processingStatus, seconds: (Date.now() - start) / 1000,
        error: state.error, coverage_limited: Boolean(state.scanResult?.metadata.coverage?.coverageLimited), coverage: state.scanResult?.metadata.coverage,
        span_granularity: item.span_granularity, agent_uncertain: state.suspicions.some(row => row.detector?.stance === 'uncertain' || row.verifier?.stance === 'uncertain'),
        citations: checkCitations(state, item.gold_spans), stages: {
          rule: { executed: Boolean(state.scanResult), complete: Boolean(state.scanResult?.ok), verdict: state.scanResult?.findings.length ? 'ipi_detected' : 'not_detected' },
          detector: stage('detector', events.some(event => event.phase === 'fix'), detectorComplete),
          verifier: stage('verifier', verifierExecuted, verifierComplete) }, state });
      save(); console.log(`${records.length}/72 ${item.id}: ${state.processingStatus}, ${state.check?.verdict}`);
    }
    if (JSON.stringify(fingerprints()) !== JSON.stringify(frozen)) throw new Error('Code/dữ liệu đổi cuối lượt.');
    status = 'complete';
  } catch (error) { status = 'incomplete'; throw error; }
  finally { clearInterval(timer); save(); delete globalThis.owaspWorkbench; await server.close(); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
