// Đo riêng người nhận và bao khung bằng model hiện tại; không sửa Agent.
const fs=require('fs');const {hash}=require('./context-annotations.cjs');const {select}=require('./run-agent-live-model-probe.cjs');const {request,parse,score}=require('./context-component-probe.cjs');
const out='benchmark/experiments/context-component-probe-v1',model='qwen2.5-coder:1.5b';
async function main(){
 if(fs.existsSync(out))throw Error('Không chạy lại/ghi đè');
 const source='benchmark/data/annotations/verifier-role-authority-controls-v1/mau-cho-duyet.jsonl',cases=select(fs.readFileSync(source,'utf8').trim().split(/\r?\n/).map(JSON.parse));
 const api=async(p,b,ms=8000)=>{const r=await fetch('http://127.0.0.1:11434'+p,{method:b?'POST':'GET',headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined,signal:AbortSignal.timeout(ms)});const raw=await r.text();if(!r.ok)throw Error(raw);return JSON.parse(raw);};
 const tags=await api('/api/tags'),version=await api('/api/version');const tag=tags.models.find(m=>m.name===model);if(!tag)throw Error('Không có model hiện tại');
 const files=['scripts/context-component-probe.cjs','scripts/run-context-component-probe.cjs',source];const fingerprint=()=>Object.fromEntries(files.map(p=>[p,hash(fs.readFileSync(p))]));const before=fingerprint();
 fs.mkdirSync(out);const save=(p,v)=>{const b=Buffer.from(JSON.stringify(v,null,2));fs.writeFileSync(out+'/'+p,b);if(!fs.readFileSync(out+'/'+p).equals(b))throw Error('Readback lỗi');};
 const plan={model,tag,version,code_and_data_sha256:before,request_budget:32,deadline_ms:45000,temperature:0,seed:42,max_tokens:512,
 scope:'Hai nhiệm vụ độc lập: người nhận và ngữ cảnh bao khung; không tìm finding, không gán stance/độ nguy hiểm, không ánh xạ nhãn sang kết luận sản phẩm.',cases:cases.map(c=>({id:c.id,group:c.group_id,language:c.language,expected:{addressee:c.annotation.addressee,framing:c.annotation.framing}})),
 requests:cases.map(c=>({addressee:request('addressee',c.text,model),framing:request('framing',c.text,model)})),
 gate:{each_task_valid_and_correct:16,each_language_no_error:true},stop:'Đủ 32 lượt thì đóng phép chẩn đoán; không chỉnh prompt/chạy lại/train. Nếu sai, báo thành phần sai; nếu đạt vẫn chưa chứng minh nhận diện IPI hoặc đủ điều kiện đưa vào Agent.',
 limits:['Cùng 16 dev tổng hợp đã dùng, không phải holdout hay dữ liệu thực độc lập.','Nhãn nguồn do AI gán; cần đối chiếu thủ công nếu phát hiện bất đồng hợp lý.','Hai prompt mới và nhiệm vụ ít hơn; không phải ablation xác định duy nhất yếu tố gây lỗi.','Không đo deviation, stance, Detector/pipeline hoặc tài liệu dài; quote nguyên văn không tự chứng minh hiểu đúng.','Bộ so sánh Qwen3/Coder đã có không được dùng để kết luận model mạnh hơn chắc chắn kém; không gọi model mới.']};save('giao-thuc-truoc-do.json',plan);
 const rows=[],calls=[];try{
 const startLoad=performance.now();await api('/api/generate',{model,keep_alive:'5m'},120000);save('nap-model.json',{seconds:(performance.now()-startLoad)/1000});
 for(const [i,c]of cases.entries())for(const task of i%2?['framing','addressee']:['addressee','framing']){
 const row={id:c.id,group_id:c.group_id,language:c.language,task,expected:c.annotation[task],valid:false,predicted:null};const start=performance.now();
 try{const body=request(task,c.text,model);if(body.messages.some(m=>m.content.includes(c.id)||m.content.includes(c.group_id)))throw Error('Lộ metadata');const r=await api('/v1/chat/completions',body,45000);row.seconds=(performance.now()-start)/1000;const ps=await api('/api/ps');calls.push({id:c.id,task,request:body,response:r,resources:ps});save('model-calls.json',calls);if(r.model!==model)throw Error('Model thay đổi');const v=parse(task,r.choices?.[0]?.message?.content||'',c.text);row.valid=true;row.predicted=v.value;row.quote=v.quote;row.finish_reason=r.choices?.[0]?.finish_reason;row.usage=r.usage;
 }catch(e){row.error=e.message;row.seconds??=(performance.now()-start)/1000;}rows.push(row);save('cases.json',rows);console.log(JSON.stringify({done:rows.length,total:32,task,valid:row.valid,correct:row.valid&&row.predicted===row.expected}));
 }
 if(JSON.stringify(before)!==JSON.stringify(fingerprint()))throw Error('Code/dữ liệu đổi');if((await api('/api/tags')).models.find(m=>m.name===model)?.digest!==tag.digest)throw Error('Model đổi');
 const tasks=Object.fromEntries(['addressee','framing'].map(k=>[k,score(rows.filter(r=>r.task===k))]));const breakdown={};for(const f of ['language','group_id'])breakdown[f]=Object.fromEntries([...new Set(rows.map(r=>r[f]))].map(k=>[k,Object.fromEntries(['addressee','framing'].map(t=>[t,score(rows.filter(r=>r[f]===k&&r.task===t))]))]));
 const passed=Object.values(tasks).every(t=>t.examples===16&&t.valid===16&&t.correct===16);const summary={complete:rows.length===32,diagnostic_closed:true,component_gate_passed:passed,tasks,breakdown,failures:rows.filter(r=>!r.valid||r.predicted!==r.expected),model_sufficient_for_full_task:null,security_improvement_demonstrated:false,product_changed:false,new_model_called:false,training:false,independent_validation_complete:false,limits:plan.limits};save('tong-hop.json',summary);console.log(JSON.stringify(summary));
 }catch(e){save('loi.json',{error:e.message,completed:rows.length});throw e;}finally{await api('/api/generate',{model,keep_alive:0},8000).catch(()=>{});}
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;});
