// Rà kỹ thuật tài liệu gốc; không suy nhãn bảo mật hoặc quyền dùng từ kết quả.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const JSZip = require('jszip');
const { extractDocumentText } = require('../engine/document/extractors/document-text-extractor');
const { runIpiDocScan } = require('../engine/scanner/ipi-doc-scan');
const root = path.resolve(__dirname, '..');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
async function main() {
  const inputPath = 'benchmark/experiments/public-vi-native-intake-v1/ket-qua.json';
  const input = fs.readFileSync(path.join(root, inputPath));
  const output = path.join(root, 'benchmark/experiments/public-vi-native-audit-v1');
  if (fs.existsSync(output)) throw new Error('Đợt rà đã tồn tại; không ghi đè.');
  const records = [];
  for (const item of JSON.parse(input).files) {
    const file = path.resolve(root, item.path);
    if (!file.startsWith(path.join(root, 'benchmark/data/incoming') + path.sep)) throw new Error('Đường dẫn ngoài incoming.');
    const bytes = fs.readFileSync(file);
    if (hash(bytes) !== item.sha256) throw new Error(`Hash nguồn thay đổi: ${item.id}`);
    const started = performance.now();
    const extracted = await extractDocumentText(file);
    if (!extracted.ok || !extracted.text.trim()) throw new Error(`Không trích xuất được: ${item.id}`);
    const text = extracted.text;
    const snapshot = fs.readFileSync(path.join(path.dirname(file), item.id + '-van-ban.txt'), 'utf8');
    const flags = {
      email_matches: [...text.matchAll(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi)].length,
      phone_like_matches: [...text.matchAll(/(?:\+84|0)[\d .()-]{8,14}\d/g)].length,
      credential_word_matches: [...text.matchAll(/mật khẩu|password|api[ _-]?key|secret/gi)].length,
      replacement_characters: [...text.matchAll(/\uFFFD/g)].length,
      unexpected_controls: [...text.matchAll(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g)].length,
    };
    let structure;
    if (path.extname(file) === '.docx') {
      const zip = await JSZip.loadAsync(bytes);
      const names = Object.keys(zip.files);
      const xml = await zip.file('word/document.xml').async('string');
      structure = {
        media_entries: names.filter(n => n.startsWith('word/media/') && !zip.files[n].dir).length,
        embedded_entries: names.filter(n => n.startsWith('word/embeddings/') && !zip.files[n].dir).length,
        macro_entries: names.filter(n => /vbaProject/i.test(n)).length,
        comment_parts: names.filter(n => /^word\/comments.*\.xml$/.test(n)).length,
        tracked_change_tags: [...xml.matchAll(/<w:(?:ins|del)\b/g)].length,
        tables: [...xml.matchAll(/<w:tbl\b/g)].length,
        metadata_parts: names.filter(n => /^docProps\/.*\.xml$/.test(n)),
        relationship_parts: names.filter(n => n.endsWith('.rels')).length,
        visual_and_metadata_content_review: 'pending',
      };
    } else {
      const { PDFParse } = require('pdf-parse');
      const parser = new PDFParse({ data: bytes });
      try {
        const pages = await parser.getText();
        structure = { pages: pages.pages.map(p => ({ page: p.num, characters_utf16: p.text.length })),
          visual_and_metadata_content_review: 'pending' };
      } finally { await parser.destroy(); }
    }
    const scans = [];
    for (const profile of ['balanced', 'deep']) {
      const scan = await runIpiDocScan([file], { scanProfile: profile });
      scans.push({ requested_profile: profile, coverage: scan.metadata.coverage,
        findings: scan.findings.map(f => ({ ruleId: f.ruleId, severity: f.severity })),
        note: 'Số được chọn không phải số model đã đọc; chưa gọi Detector/Verifier.' });
    }
    records.push({ id: item.id, parent_id: item.parent_id, sha256: hash(bytes), text_sha256: hash(text),
      extraction_matches_previous_snapshot: text === snapshot, characters_utf16: text.length,
      flags, structure, scans, elapsed_ms: Math.round(performance.now() - started),
      security_label: null, training_eligible: false, final_split: null,
      privacy_review: 'automated_triage_only', reuse_permission: item.reuse_permission });
    console.log(JSON.stringify({ id: item.id, flags, scans: scans.map(s => s.coverage) }));
  }
  const combined = [];
  for (const profile of ['balanced', 'deep']) {
    const scan = await runIpiDocScan(JSON.parse(input).files.map(f => path.resolve(root, f.path)), { scanProfile: profile });
    combined.push({ requested_profile: profile, coverage: scan.metadata.coverage });
  }
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, 'ket-qua.json'), JSON.stringify({ created_at: new Date().toISOString(),
    input: { path: inputPath, sha256: hash(input) }, script_sha256: hash(fs.readFileSync(__filename)),
    code_sha256: Object.fromEntries(['engine/scanner/ipi-doc-scan.js', 'engine/document/extractors/document-text-extractor.js',
      'engine/document/chunking/semantic-chunker.js', 'engine/config/document-scan-config.js'].map(p => [p, hash(fs.readFileSync(path.join(root, p)))])),
    records, combined, model_called: false, runtime_changed: false, priority_one_complete: false,
    limits: ['Chưa kiểm tra ảnh, thứ tự đọc và metadata bằng mắt.', 'Regex riêng tư chỉ gắn cờ, không xác nhận an toàn.',
      'Chưa xác minh quyền train/tái phân phối.', 'Chưa gán nhãn hoặc đo chất lượng nhận diện toàn pipeline.'],
  }, null, 2) + '\n', { flag: 'wx' });
}
main().catch(error => { console.error(error); process.exitCode = 1; });
