// Hợp đồng thí nghiệm paired-context, chưa được gọi trong scanner hoặc huấn luyện.
const {hash}=require('./context-annotations.cjs');
const TRUSTED_DATASET_FIELDS=new Set(['User Instruction','user_query']);
function modelFeatures(row){
 const task=row.trustedTask;
 if(!task||task.text===null||typeof task.text==='string'&&!task.text.trim())return{status:'needs_context',features:null};
 if(typeof task.text!=='string'||!['user_input','curated_dataset_task'].includes(task.origin))throw Error('Nhiệm vụ không có nguồn tin cậy được khai báo.');
 if(task.origin==='curated_dataset_task'&&(!task.provenanceVerified||!TRUSTED_DATASET_FIELDS.has(task.sourceField)||!task.sourceFile||!task.sourceRevision))throw Error('Chưa xác minh nhiệm vụ gốc; không dùng task/attacker objective trong dữ liệu.');
 if(task.textSha256!==hash(task.text))throw Error('Nhiệm vụ khác hash đã rà.');
 if(typeof row.document!=='string'||!row.document.trim())throw Error('Thiếu tài liệu không tin cậy.');
 // Không truyền nhãn, finding, group, nguồn dataset hoặc lời giải vào model.
 return{status:'ready',features:{trustedTask:task.text,untrustedDocument:row.document}};
}
function validateSplits(rows){
 const groups=new Map(),documents=new Map();
 for(const row of rows){
  if(!row.group||!['train','dev','probe'].includes(row.role))throw Error('Thiếu group/role.');
  for(const [map,key]of [[groups,row.group],[documents,hash(row.document.normalize('NFKC').replace(/\s+/gu,' ').trim())]]){
   if(map.has(key)&&map.get(key)!==row.role)throw Error('Nhóm hoặc tài liệu dùng chung bị chia qua role.');map.set(key,row.role);
  }
 }
}
function validateTraining(rows,protectedDocumentHashes=new Set()){
 validateSplits(rows);
 for(const row of rows){
  if(row.role!=='train'||row.training_eligible!==true||row.never_use_for_training===true||row.review?.status!=='approved_for_paired_context'||row.review?.scope!=='task_document_label_spans')throw Error('Chưa được duyệt cho train paired-context.');
  if(modelFeatures(row).status!=='ready')throw Error('Không train hàng thiếu nhiệm vụ.');
  if(protectedDocumentHashes.has(hash(row.document)))throw Error('Tài liệu đã dành đánh giá, không được chuyển sang train.');
  if(!['benign','ipi','uncertain'].includes(row.annotation?.label))throw Error('Sai nhãn ba lớp.');
  for(const span of [...(row.annotation.directiveSpans||[]),...(row.annotation.contextSpans||[])]){
   if(!Number.isSafeInteger(span.start)||!Number.isSafeInteger(span.end)||span.start<0||span.end<=span.start||row.document.slice(span.start,span.end)!==span.quote)throw Error('Span không khớp nguồn UTF-16.');
  }
  if(row.annotation.label==='ipi'&&!(row.annotation.directiveSpans||[]).length)throw Error('Nhãn IPI thiếu directive đã rà.');
 }
 return true;
}
module.exports={modelFeatures,validateSplits,validateTraining};
