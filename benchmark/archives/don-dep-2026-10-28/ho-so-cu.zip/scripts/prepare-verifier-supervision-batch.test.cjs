const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {buildRows}=require('./prepare-verifier-supervision-batch.cjs');
function input(){return [fs.readFileSync('benchmark/experiments/verifier-counterfactual-train-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse),JSON.parse(fs.readFileSync('benchmark/experiments/verifier-supervision-review-v1/ma-tran-bo-sung.json'))];}
test('Cặp cùng nhóm cha, phân biệt không chuyển hướng/attack/trích dẫn',()=>{
 const rows=buildRows(...input());assert.equal(rows.length,12);assert.equal(new Set(rows.map(r=>r.text)).size,12);
 for(const group of new Set(rows.map(r=>r.group_id))){const family=rows.filter(r=>r.group_id===group);assert.equal(family.length,3);
  assert.equal(family.find(r=>r.variant==='ordinary').annotation.deviation,'none');assert.equal(family.find(r=>r.variant==='attack').annotation.stance,'confirmed');
  assert.equal(family.find(r=>r.variant==='quoted').annotation.framing,'quoted_example');}
 assert.ok(rows.every(r=>r.training_eligible===false&&r.model_evaluation_allowed===false&&r.human_approved===false));
});
test('Không nhận cha dev hoặc nội dung cha đã đổi',()=>{
 const [parents,matrix]=input();const r=parents.find(r=>r.id===matrix.slots[0].parent_record_id);r.planned_role='dev';assert.throws(()=>buildRows(parents,matrix),/Cha/);
 r.planned_role='train';r.text+=' altered';assert.throws(()=>buildRows(parents,matrix),/Cha/);
});
