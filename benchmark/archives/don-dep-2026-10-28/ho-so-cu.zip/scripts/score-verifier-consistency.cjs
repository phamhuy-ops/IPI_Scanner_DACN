// Tái dùng parser ứng dụng đã khóa, không tái diễn giải ca lỗi thành sạch.
const fs=require('node:fs');
const {hash}=require('./context-annotations.cjs');
const {verify}=require('./freeze-verifier-pilot.cjs');
const {contextMatches,directiveCovered}=require('./verifier-context-scoring.cjs');
const {summarize,decide}=require('./verifier-consistency-metrics.cjs');
const base='benchmark/experiments/verifier-consistency-eval-v1';
async function main() {
  const design='benchmark/experiments/verifier-consistency-candidate-v1';
  verify(JSON.parse(fs.readFileSync(`${design}/giao-thuc-da-khoa.json`)));
  if(fs.existsSync(`${base}/danh-gia.json`))throw new Error('Không ghi đè đánh giá.');
  const plan=JSON.parse(fs.readFileSync(`${design}/ung-vien.json`));
  const execution=JSON.parse(fs.readFileSync(`${base}/ke-hoach-thuc-thi.json`));
  for(const [p,h]of Object.entries(execution.implementation_sha256))if(hash(fs.readFileSync(p))!==h)throw new Error('Implementation đổi sau đo.');
  const old=fs.readFileSync('benchmark/data/annotations/verifier-local-release-preview-v2/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
  const fresh=fs.readFileSync('benchmark/data/annotations/verifier-consistency-controls-v1/mau-cho-duyet.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
  const rows=[...old,...fresh];
  const provenance=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-local-release-v2/ghi-cong-va-pham-vi.json')).decisions;
  const overlap=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-corpus-overlap-v20/ket-qua.json'));
  const groupMap=new Map();
  overlap.groups.forEach((g,i)=>g.members.forEach(id=>groupMap.set(id,`lexical-${i}`)));
  const {createServer}=await import('vite');
  const server=await createServer({configFile:false,server:{middlewareMode:true,hmr:false},appType:'custom'});
  const evaluated={baseline:[],candidate:[]};
  try {
    const {buildVerifierInput}=await server.ssrLoadModule('/scripts/verifier-batch-renderer.ts');
    const {parseCompactVerifierJson}=await server.ssrLoadModule('/src/ai/agents/document/compactVerifier.ts');
    for(const config of Object.keys(evaluated)) {
      const raw=JSON.parse(fs.readFileSync(`${base}/${config}/phan-hoi.json`));
      if(new Set(raw.map(r=>r.id)).size!==raw.length||raw.some(r=>!execution.request_ids.includes(r.id)))throw new Error('ID lạ/trùng.');
      for(const response of raw) {
        const row=rows.find(r=>r.id===response.source_record_id);
        if(!row)throw new Error('Không có gold nguồn.');
        const item={id:response.id,source_record_id:row.id,cohort:response.cohort,mode:response.mode,group_id:row.group_id,
          lexical_group:response.cohort==='new_controls'?groupMap.get(`verifier-consistency-controls-v1:${row.id}`):row.group_id,
          language:row.language,source:provenance.find(p=>p.id===row.id)?.source??row.source,
          expected:row.annotation.stance,seconds:response.seconds,peak_vram_allocated:response.peak_vram_allocated,
          parsed:false,predicted:null,correct_stance:false,field_matches:null,gold_directive_covered:null};
        try {
          if(response.status!=='completed')throw new Error(response.error);
          const input=buildVerifierInput({text:row.text,format:row.format,candidate_mode:response.mode});
          const parsed=parseCompactVerifierJson(response.response,input.chunks,input.expected);
          const findings=[...parsed.assessments.map(a=>a.assessment),...parsed.discoveries];
          item.parsed=true;
          item.predicted=findings.some(f=>f.stance==='confirmed')?'confirmed':findings.some(f=>f.stance==='uncertain')?'uncertain':'dismissed';
          const focus=findings.find(f=>f.stance===item.predicted);
          item.field_matches=contextMatches(focus,row.annotation);
          item.gold_directive_covered=directiveCovered(focus,row.annotation);
          item.correct_stance=item.predicted===item.expected;
        }catch(error){item.error=error.message;}
        evaluated[config].push(item);
      }
    }
  }finally{await server.close();}
  const breakdown={};
  for(const [config,items]of Object.entries(evaluated)) {
    breakdown[config]={};
    for(const field of ['cohort','mode','language','source','group_id','lexical_group'])breakdown[config][field]=Object.fromEntries([...new Set(items.map(r=>r[field]))].map(k=>[k,summarize(items.filter(r=>r[field]===k))]));
  }
  const oldRaw=JSON.parse(fs.readFileSync('benchmark/experiments/verifier-candidate02-eval-screen-v1/on/phan-hoi.json'));
  const baselineRaw=JSON.parse(fs.readFileSync(`${base}/baseline/phan-hoi.json`));
  const decision=decide(evaluated.baseline,evaluated.candidate,plan.selection_gates);
  const result={scope:'development_prompt_selection_not_independent_or_pipeline',decision,breakdown,rows:evaluated,
    old_screen_raw_differences:baselineRaw.filter(r=>r.cohort==='old_screen'&&oldRaw.find(p=>p.id===r.id)?.response!==r.response).map(r=>r.id),
    raw_sha256:Object.fromEntries(['baseline','candidate'].map(c=>[c,hash(fs.readFileSync(`${base}/${c}/phan-hoi.json`))])),
    limitations:['28 nguồn mới chung khuôn, chỉ hai nhóm từ vựng; nhiều mode không độc lập.',
      'Đây là chọn prompt dev, không có holdout hoặc toàn pipeline.', 'Số FP/FN không thay thế việc báo lỗi, abstention và context.']};
  fs.writeFileSync(`${base}/danh-gia.json`,JSON.stringify(result,null,2));
  console.log(JSON.stringify({decision,new_controls:{baseline:breakdown.baseline.cohort.new_controls,candidate:breakdown.candidate.cohort.new_controls},old_screen_raw_differences:result.old_screen_raw_differences}));
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;});
