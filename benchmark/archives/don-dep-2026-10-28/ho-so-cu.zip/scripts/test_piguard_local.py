"""Fixture tensor nhỏ kiểm đúng first-token head, không dùng weights PIGuard thật."""
import unittest
import torch
from transformers import DebertaV2Config
from piguard_local import ReviewedPIGuard
from types import SimpleNamespace


class Encoder(torch.nn.Module):
    def forward(self, **kwargs):
        states = torch.tensor([[[1., 2., 3., 4.], [100., 200., 300., 400.]]])
        return SimpleNamespace(last_hidden_state=states)


class ArchitectureTests(unittest.TestCase):
    def test_first_token_linear_head_matches_reviewed_source(self):
        model = ReviewedPIGuard(DebertaV2Config(vocab_size=16, hidden_size=4, intermediate_size=8,
                               num_hidden_layers=1, num_attention_heads=2, num_labels=2, relative_attention=False))
        model.deberta = Encoder()
        with torch.no_grad():
            model.classifier.weight.copy_(torch.tensor([[1., 0., 0., 0.], [0., 0., 0., 1.]]))
            model.classifier.bias.zero_()
        result = model(input_ids=torch.tensor([[1, 2]]), attention_mask=torch.ones(1, 2))
        self.assertEqual(result.logits.tolist(), [[1., 4.]])


if __name__ == '__main__':
    unittest.main()
