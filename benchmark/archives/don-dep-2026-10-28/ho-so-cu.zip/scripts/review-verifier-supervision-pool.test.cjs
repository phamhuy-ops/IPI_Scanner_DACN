const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const {inspect}=require('./review-verifier-supervision-pool.cjs');
function input(){const rows=[],examples=[];for(let i=1;i<=4;i++){const base=`benchmark/data/annotations/verifier-supervision-batch-v${i}`;
 rows.push(...fs.readFileSync(`${base}/mau-cho-duyet.jsonl`,'utf8').trim().split(/\r?\n/).map(JSON.parse));examples.push(...JSON.parse(fs.readFileSync(`${base}/ban-xem-truoc.json`)).examples);}
 return [rows,examples,JSON.parse(fs.readFileSync('benchmark/experiments/verifier-supervision-review-v1/ma-tran-bo-sung.json'))];}
test('Đủ 16 ô và đối chứng, giữ target rỗng và trạng thái chưa phát hành',()=>{const result=inspect(...input());assert.deepEqual(result.errors,[]);assert.deepEqual(result.stance_counts,{dismissed:20,confirmed:16,uncertain:12});assert.equal(result.parent_train_groups,4);});
test('Chặn thiếu preview, thay vai trò hoặc lộ corpus ID',()=>{const [rows,examples,matrix]=input();examples.pop();rows[0].training_eligible=true;examples[0].payload.messages[1].content+=' '+rows[0].id;const errors=inspect(rows,examples,matrix).errors;assert.ok(errors.some(e=>e.includes('thiếu/trùng')));assert.ok(errors.some(e=>e.includes('nâng quyền')));assert.ok(errors.some(e=>e.includes('metadata')));});
